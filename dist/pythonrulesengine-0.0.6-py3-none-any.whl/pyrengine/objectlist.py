
# Worth reading:
#   https://stackoverflow.com/questions/972/adding-a-method-to-an-existing-object-instance-in-python
#   https://stackoverflow.com/questions/4698493/can-i-add-custom-methods-attributes-to-built-in-python-types

from __future__ import annotations # For forware reference
from typing import List, Union

from collections import OrderedDict 
import fnmatch
import json

from pyrengine.op import OP
from pyrengine.date import DATE

# Disable pdoc3 document generating for these classes/methods
__pdoc__ = {
    'ARRAY_FOR': False,
    'FILTERED_BY_COLUMN': False,
    'JOINED_OBJECTLIST_FOR': False,
    'OBJECTLIST.filter_by_column': False
}


# Intermediate class to support for all values in array
class ARRAY_FOR:
    """
    *Deprecated.* An internal class to iterate all objects in an ARRAY and check if `all` or `any` objects in ARRAY 
    satisfy a condition that follows. 
    
    Support simple standard operator <, <=, ==, !=, >=, >.
    It is instantiated by ARRAY.all() or ARRAY.any().
    >>> array = ARRAY([1, 2, 3, 4, 10])
    >>> array.all() # Return ARRAY_FOR.
    >>> array.any() # Return ARRAY_FOR

    Arguments
    ----------
    array : list
    
    quantifier: str, "all" or "any"
        `all` for all objects.
        `any` for any objects

    Operators
    ---------
    ```py
    <, <=, ==, !=, >=, > 
    ```
    
    Raises
    ------
    Exception
        Any errors cause exception.
        
    Example
    -------
    >>> array = ARRAY([1, 2, 3, 4, 10])
    >>> array.all() > 10 # Return False
    >>> array.any() >= 10 # Return True
    >>> array.any() == 10 # Return True
    """         
    def __init__(self, array: list, quantifier: str):
        self.array = array
        if quantifier is None:
            raise Exception("ARRAY_FOR requires quantifier 'all' or 'any'")
        self.quantifier = quantifier
        
        if quantifier == "all": 
            self.func = all
        elif quantifier == "any":
            self.func = any
        else:
            raise Exception("ARRAY_FOR found unknown quantifier {}, only 'all' or 'any' are allowed".format(quantifier))
    
    def like(self, pattern: str) -> bool:
        """
        Check if `all` or `any` strings in ARRAY matches the pattern (ignoring case). Supports wildcard * and ? 
        
        Example
        -------
        >>> array = ARRAY(['Z510', 'Z511'])
        >>> array.all().like('Z51*')
        >>> array.all().like('z51*')
        """        
        if not isinstance(pattern, str):
            raise NotImplementedError('Operator like() supports only string')
        return self.func([fnmatch.fnmatch(e.lower(), pattern.lower()) for e in self.array])
    
    def not_like(self, pattern: str) -> bool:
        """
        Check if `all` or `any` strings in ARRAY do not match the pattern (ignoring case). Supports wildcard * and ?.
         
        Example
        -------
        >>> array = ARRAY(['Z510', 'Z511'])
        >>> array.all().not_like('Z51*')
        >>> array.all().not_like('z51*')
        """        
        if not isinstance(pattern, str):
            raise NotImplementedError('Operator like() supports only string')
        return not self.func([fnmatch.fnmatch(e.lower(), pattern.lower()) for e in self.array])

    # supported_operators() is used for pdoc3 to create documentation for supported operators.
    def supported_operators():
        """
        Supported operators are
        ```py
        <, <=, ==, !=, >=, > 
        ```
        Example
        -------
        >>> array = ARRAY([1, 2, 3, 4, 10])
        >>> array.all() > 10 # Return False
        >>> array.any() >= 10 # Return True
        >>> array.any() == 10 # Return True
        """        
        return ['<', '<=', '==', '!=', '>=', '>']
    
    ###############################################
    #  Support standard math comparison operators #
    ###############################################
    # https://docs.python.org/3/library/operator.html    
    def __lt__(self, other: Union[int, float]): 
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator <= supports only int or float')
        return self.func([e <= other for e in self.array])
    
    def __le__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator < supports only int or float')
        return self.func([e < other for e in self.array])
    
    def __eq__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator == supports only int or float')
        return self.func([e == other for e in self.array])
    
    def __ne__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator != supports only int or float')
        return self.func([e != other for e in self.array])
    
    def __ge__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator >= supports only int or float')
        return self.func([e >= other for e in self.array])
    
    def __gt__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator > supports only int or float')
        return self.func([e > other for e in self.array])
    
    def __str__(self):
        return 'ARRAY_FOR({})'.format(self.quantifier)  

    def __repr__(self):
        return 'ARRAY_FOR({})'.format(self.quantifier)      
    

# Extended list, so it inherits methods from list.
class ARRAY(list):
    """
    ARRAY is an extended version of python list. 
    
    Additional methods to operate with list are added.

    Example
    -------
    >>> ARRAY([1, 2, 3])
    >>> ARRAY(["a", "b", "c"])
    >>> array = ARRAY([1, 2, 3, 4, 1, 2])
    """    

    def get(self, index: int) -> object:
        """
        Return an object at position `index`.
        
        Arguments
        ----------
        index : int
            Position starting at 0.

        Returns
        -------
        object
            An object in the ARRAY.
            
        Example
        -------
        >>> array.get(1) # is as same as array[1]
        """        
        return self[index]
    
    def sum(self) -> Union[int, float]:
        """
        Return summation of all objects in the ARRAY, assuming that they can be added.
        
        Returns
        -------
        int or float
            Summation value 
            
        Example
        -------
        >>> array.sum() 
        """         
        return sum(self)
    
    def count(self) -> int:
        """
        Return the number of objects in the ARRAY.

        Returns
        -------
        int
            The number of objects in the ARRAY.
            
        Example
        -------
        >>> array.count()
        """        
        return len(self)
    
    def count_distinct(self) -> int:
        """
        Return the number of distinct objects in the ARRAY.

        Returns
        -------
        int
            The number of distinct objects in the ARRAY.
            
        Example
        -------
        >>> array.count_distinct()
        """              
        return len(set(self))
    
    def distinct(self) -> ARRAY:
        """
        Return a new ARRAY without duplicated objects.

        Returns
        -------
        ARRAY
            A new ARRAY without duplicated objects.
            
        Example
        -------
        >>> array.distinct()
        [1, 2, 3, 4]    
        """        
        return ARRAY(list(OrderedDict.fromkeys(self))) 

    def exclude(self, other: list) -> ARRAY:
        """
        Return a new ARRAY with all objects not in the other list, dupliction allowed. 
        
        Arguments
        ----------
        other : ARRAY or list
        """        
        return ARRAY([e for e in self if e not in other])
    
    def union(self, other: list) -> ARRAY:
        """
        Return a new ARRAY with all objects from both list, no duplication.

        Arguments
        ----------
        other : ARRAY or list
        """        
        result = OrderedDict.fromkeys(self)
        result.update(OrderedDict.fromkeys(other))
        return ARRAY(list(result))
    
    def union_all(self, other: list) -> ARRAY:
        """
        Return a new ARRAY with all objects from both list, duplication allowed. 
        As same as ARRAY1 + ARRAY2.

        Arguments
        ----------
        other : ARRAY or list
        """        
        return ARRAY(self + other)
    
    def all(self) -> bool:
        """
        Return True if all elements of the ARRAY can be evaluated to True; otherwise False.

        Example
        -------
        >>> ARRAY([True, True, False]).all()
        False
        >>> ARRAY([1, 3, 2]).all()
        True
        """        
        return all(self)
    
    def any(self) -> bool:
        """
        Return True if any elements of the ARRAY can be evaluated to True; otherwise False.

        Example
        -------
        >>> ARRAY([True, True, False]).any()
        True
        >>> ARRAY([0, 0, 0]).any()
        False
        """    
        return any(self)
    
    def contains(self, o: object) -> bool:
        """
        Return True if an object is in this ARRAY; otherwise False.

        The following expressions are the same.
        >>> 1 in ARRAY([1, 2, 3])
        >>> ARRAY([1, 2, 3]).contains(1)

        Arguments
        ----------
        other : object
        """          
        return o in self

    def not_contains(self, o: object) -> bool:
        """
        Return True if an object is not in this ARRAY; otherwise False.

        The following expressions are the same.
        >>> 1 not in ARRAY([1, 2, 3])
        >>> ARRAY([1, 2, 3]).not_contains(1)

        Arguments
        ----------
        other : object
        """          
        return not self.contains(o)    

    # If other is empty, always return False
    def is_overlap(self, other: list) -> bool:
        """
        Return True if there exists an object in this ARRAY and in the other list too; otherwise False.

        Arguments
        ----------
        other : ARRAY or list
        """         
        if not isinstance(other, list):
            raise Exception('ARRAY.is_overlap() requires a list argument')
        return len(set(self).intersection(set(other))) > 0
    
    def is_not_overlap(self, other: list) -> bool:
        """
        Return True if no object in this ARRAY appears to be in the other list; otherwise False.

        Arguments
        ----------
        other : ARRAY or list
        """             
        return not self.is_overlap(other)

    def lt(self, operand: Union[int, float]) -> ARRAY:
        """
        For each element *e* in ARRAY, check if *e* is less than (<) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """        
        if not isinstance(operand, (int, float)):
            raise NotImplementedError('Operator <= supports only int or float')
        return ARRAY([e <= operand for e in self])
    
    def le(self, operand: Union[int, float]):
        """
        For each element *e* in ARRAY, check if *e* is less than or equal to (<=) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """             
        if not isinstance(operand, (int, float)):
            raise NotImplementedError('Operator < supports only int or float')
        return ARRAY([e < operand for e in self])
    
    def eq(self, operand: Union[int, float, str]):
        """
        For each element *e* in ARRAY, check if *e* is equal to (==) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """         
        if not isinstance(operand, (int, float, str)):
            raise NotImplementedError('Operator == supports only int or float or str')
        return ARRAY([e == operand for e in self])
    
    def neq(self, operand: Union[int, float, str]):
        """
        For each element *e* in ARRAY, check if *e* is not equal to (!=) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """        
        if not isinstance(operand, (int, float, str)):
            raise NotImplementedError('Operator != supports only int or float or str')
        return ARRAY([e != operand for e in self])
    
    def ge(self, operand: Union[int, float]):
        """
        For each element *e* in ARRAY, check if *e* is greater than or equal to (>=) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """        
        if not isinstance(operand, (int, float)):
            raise NotImplementedError('Operator >= supports only int or float')
        return ARRAY([e >= operand for e in self])
    
    def gt(self, operand: Union[int, float]):
        """
        For each element *e* in ARRAY, check if *e* is greater than (>) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """        
        if not isinstance(operand, (int, float)):
            raise NotImplementedError('Operator > supports only int or float')
        return ARRAY([e > operand for e in self])

    def like(self, pattern: str) -> ARRAY:        
        """
        For each element *e* in ARRAY, check if *e* is a string and matches the pattern (ignoring case). Supports wildcard * and ?. 

        Arguments
        ----------
        pattern : str
            Pattern string with wildcard * and ?. 
            Wildcard * matches any number of characters or none.
            Wildcard ? matches at most one character. 

        Returns
        -------
        ARRAY
            ARRAY of True/False.

        Raises
        ------
        Exception
            Any errors cause exception.            

        Example
        -------
        >>> array = ARRAY(['Z510', 'Z511'])
        >>> array.like('Z51*')
        >>> array.like('z51*')
        """        
        if not isinstance(pattern, str):
            raise Exception('Method like() requires pattern argument to be a string.')
        if not all([isinstance(e, str) for e in self]):
            raise Exception("Method like() supports only string elements.")
        return ARRAY([fnmatch.fnmatch(e.lower(), pattern.lower()) for e in self])
    
    def not_like(self, pattern: str) -> bool:
        """
        For each element *e* in ARRAY, check if *e* is a string and does not match the pattern (ignoring case). Supports wildcard * and ?. 

        Arguments
        ----------
        pattern : str
            Pattern string with wildcard * and ?. 
            Wildcard * matches any number of characters or none.
            Wildcard ? matches at most one character. 

        Returns
        -------
        ARRAY
            ARRAY of True/False.

        Raises
        ------
        Exception
            Any errors cause exception.            

        Example
        -------
        >>> array = ARRAY(['Z510', 'Z511'])
        >>> array.not_like('Z51*')
        >>> array.not_like('z51*')
        """            
        if not isinstance(pattern, str):
            raise Exception('Method not_like() requires pattern argument to be a string.')
        if not all([isinstance(e, str) for e in self]):
            raise Exception("Method not_like() supports only string elements.")
        return ARRAY([not fnmatch.fnmatch(e.lower(), pattern.lower()) for e in self])
    
    def sort(self, reverse=False) -> ARRAY:
        """
        Return a new ARRAY with elements are sorted.

        Parameters
        ----------
        reverse: True or False, default = False
            If True, elements are sorted in descending order.

        """
        return ARRAY(sorted(self, reverse=reverse))        
    
    def to_date(self) -> ARRAY[DATE]:
        """
        Return a new ARRAY with all string elements are converted to DATE.

        Raises
        ------
        Exception
            If any elements are not string in ISO format (YYYY-MM-DD).
      
        """
        if not all([isinstance(e, str) for e in self]):
            raise Exception("Method to_DATE() requires all elements are string.")
        return ARRAY([DATE.from_string(e) for e in self])   

    def date_diff(self) -> ARRAY[int]:
        """
        Return numbers of days different between two consecutive elements in a DATE ARRAY.

        Raises
        ------
        Exception
            If any elements are not DATE objects.
            
        Example
        -------
        >>> array = ARRAY(['2023-01-01', '2023-01-03', '2023-01-03', '2023-02-01'])
        >>> array.to_date().date_diff()
        ARRAY([2, 0, 29])
       
        """        
        if not all([isinstance(e, DATE) for e in self]):
            raise Exception("Method date_diff() requires all elements are DATE objects.")
                
        return ARRAY([(j-i).days for i, j in zip(self, self[1:])] )
    
    def __str__(self) -> str:
        return 'ARRAY({})'.format(super().__str__())
    
    def __repr__(self) -> str:
        return 'ARRAY({})'.format(super().__repr__())    
    

# Obsoleted
# Return OBJECTLIST
class FILTERED_BY_COLUMN:
    def __init__(self, data, column):
        self.data = data
        self.column = column
        
    # Cannot use 'in' since it is a reserved word.
    def is_in(self, arr):
        return OBJECTLIST(list(filter(lambda o: o.get(self.column) in arr, self.data)))
        
    def not_in(self, arr):
        return OBJECTLIST(list(filter(lambda o: o.get(self.column) not in arr, self.data)))

    def __str__(self):
        return 'FILTERED_BY_COLUMN(' + str(self.data) + ', ' + self.column + ')'  

# Return OBJECTLIST
class GROUPBY:
    """
    A group of objects that share the same column value(s). 
    
    An internal representation of GROUPBY is a dict where a key is a tuple and a value is a list of objects.
    Each key consists of one or many tuples of column name and value.
    Each object in the list is an object encoded as a dict.
    It is instantiated by `OBJECTLIST.group_by()`.
    
    For example, given a GROUPBY
    ```
    {(('id', '001'), ('name', 'john')): [obj1, obj2, ...], (('id', '002'), ('name', 'mary')): [obj10, obj11, ...]}
    ```
    The first group has id = 001 and name = john. Since obj1 and obj2 are in this group, both of them have these values. 
    The second group has id = 002 and name = mary. obj10 and obj11 are in the second group.
    
    Raises
    ------
    Exception
        Any errors cause exception.
    NotImplementedError
        Some usages are not supported.
    """    
    def __init__(self, data: dict[tuple[tuple], list[object]]):
        self.data = data
        for k, v in self.data.items():
            if not isinstance(k, tuple):
                raise Exception('GROUPBY requires dict key to be a tuple of tuples')
            for t in k:
                if not isinstance(t, tuple):
                    raise Exception('GROUPBY requires dict key to be a tuple of tuples')
            if not isinstance(v, list):
                raise Exception('GROUPBY requires dict value to be a list of object')
        
    def count(self, column: str = None) -> OBJECTLIST:
        """
        Return the number of objects in each group.

        Arguments
        ----------
        column : str, default = None
            Column of object to count.  If None, count all objects. 
            If a string, count only objects with the column. 
            If such column is missing from some objects, count() will exclude those objects. 

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST where each object has only group_by columns and count column.

        Raises
        ------
        NotImplementedError
            Some usages are unsupported.
            
        Example
        -------
        >>> objectlist.group_by(["id", "name"]).count('name')
        [{"id": "001", "name": "john", "count": 2}, {"id": "002", "name": "many", "count": 4} ]
        
        """   
        
        if column is not None and not isinstance(column, str):
            raise NotImplementedError('GROUPBY.count() supports at most one column only.')        
        
        new_objects = []
        for k, v in self.data.items():
            new_object = {}
            for t in k: 
                new_object[t[0]] = t[1]
            if column is None:
                new_object['count'] = len(v)
            else:
                new_object['count'] = sum([1 for obj in v if column in obj])
            new_objects.append(new_object)
                
        return OBJECTLIST(new_objects)

    def sum(self, column: str) -> OBJECTLIST:
        """
        Return the summation of values in a specfied column of all objects in each group.

        Arguments
        ----------
        column : str
            Column name of objects for summation.

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST where each object has only group_by columns and sum column.

        Raises
        ------
        NotImplementedError
            Some usages are unsupported.
            
        Example
        -------
        >>> groupby.sum('amount')
        [{"id": "001", "name": "john", "sum": 100000}, {"id": "002", "name": "many", "sum": 200000} ]
        
        """        
        if not isinstance(column, str):
            raise NotImplementedError('GROUPBY.sum() requires single column only.')
        
        new_objects = []
        for k, v in self.data.items():
            new_object = {}
            for t in k: 
                new_object[t[0]] = t[1]
            new_object['sum'] = sum([obj[column] for obj in v if column in obj])
            new_objects.append(new_object)
                
        return OBJECTLIST(new_objects)    
    
    def __str__(self) -> str:
        return 'GROUPBY({})'.format(self.data)
    
    def to_string(self) -> str:
        """
        Return the string of GROUPBY object in tabular format.

        Returns
        -------
        str
            The string of GROUPBY object in tabular format.

        Example
        -------
        >>> ol = OBJECTLIST([{"name": "John", "age": 37, "salary": 10000}, {"name": "Mary", "age": 42, "salary": 30000}])
        >>> print(ol.group_by('name').to_string())
        GROUPBY({
            (('name', 'John'),): [{'name': 'John', 'age': 37, 'salary': 10000}]
            (('name', 'Mary'),): [{'name': 'Mary', 'age': 42, 'salary': 30000}]
        })
        """                
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join(['{}: {}'.format(k, v) for k, v in self.data.items()]))
        else:
            table = ''
        return 'GROUPBY({{{}}})'.format(table) # {{ and }} are the escaped characters { and }.      
    
    def __repr__(self) -> str:
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join(['{}: {}'.format(repr(k),repr(v)) for k, v in self.data.items()]))
        else:
            table = ''        
        return 'GROUPBY({{{}}})'.format(table) # {{ and }} are the escaped characters { and }.


class JOINED_OBJECTLIST_FOR:
    """
    *Deprecated." An internal class to iterate all joined objects in the JOINED_OBJECTLIST and check if `all` or `any` joined
      objects satisfy a condition that follows. 
    
    It is instantiated by JOINED_OBJECTLIST.all() or JOINED_OBJECTLIST.any().
    >>> array.all() # Return JOINED_OBJECTLIST_FOR.
    >>> array.any() # Return JOINED_OBJECTLIST_FOR    

    Arguments
    ----------
    data : JOINED_OBJECTLIST
        
    quantifier : str, "all" or "any"
        `all` for all joined objects.
        `any` for any joined objects

    Raises
    ------
    Exception
        Any errors cause exception.
    """         
    def __init__(self, data: JOINED_OBJECTLIST, quantifier: str):
        self.data = data
        if quantifier is None:
            raise Exception("JOINED_OBJECTLIST_FOR requires quantifier 'all' or 'any'")
        self.quantifier = quantifier
        
        if quantifier == "all": 
            self.func = all
        elif quantifier == "any":
            self.func = any
        else:
            raise Exception("JOINED_OBJECTLIST_FOR found unknown quantifier {}, only 'all' or 'any' are allowed".format(quantifier))

    def check_if(self, l_column: str, operator: Union[OP, str], r_column: str) -> bool:
        """
        Return True/False after checking if the joined objects in the JOINED_OBJECTLIST pass the condition.
        
        For `all`, return True if all joined objects pass the condition; otherwise False.
        For `any`, return True if any joined objects pass the condition; otherwise False. 

        Arguments
        ----------
        l_column : str
            Column name of the left object to compare.
        operator : Union[OP, str]
            An operator to compare columns of the left and right objects. See `pyrengine.op.OP`.
        r_column : str
            Column name of the right object to compare.

        Returns
        -------
        bool
            True or False

        Raises
        ------
        Exception
            Any errors cause exception.
        NotImplementedError
            Unsupported operation or arguments.
            
        Example
        -------
        >>> objectlist1 = OBJECTLIST([{"code": "001", "amount": 1000}, {"code": "001", "amount": 2000}, {"code": "002", "amount": 3000}])
        >>> objectlist2 = OBJECTLIST([{"code": "001", "max_amount": 2000}, {"code": "002", "max_amount": 3000}])
        >>> objectlist1.inner_join(objectlist2, "code")
        [(('001',), ({'code': '001', 'amount': 1000}, {'code': '001', 'max_amount': 2000})), (('001',), ({'code': '001', 'amount': 2000}, {'code': '001', 'max_amount': 2000})), (('002',), ({'code': '002', 'amount': 3000}, {'code': '002', 'max_amount': 3000}))]
    
        >>> objectlist1.inner_join(objectlist2, "code").all().check_if("amount", "gt", "max_amount")
        False 
        """ 
               
        if not isinstance(l_column, str):
            raise Exception("check_if() l_column requires string")
        
        if not isinstance(r_column, str):
            raise Exception("check_if() r_column requires string")

        if isinstance(operator, str):
            try:
                operator = OP[operator]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator {} in check_if()'.format(operator)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred
                
        # TODO: Type checking for each operator, e.g. gt needs both operands have the same type 
        results = []
        for joined_objects in self.data:
            keys = joined_objects[0]
            v = joined_objects[1]
            result = False

            if v[0][l_column] is None:
                raise Exception('Column {} not found in left OBJECTLIST {}'.format(l_column, v[0]))
            
            if v[1] is not None and v[1][r_column] is not None:
                if operator == OP.gt:
                    result = (v[0][l_column] > v[1][r_column])
                elif operator == OP.ge:
                    result = (v[0][l_column] >= v[1][r_column])
                elif operator == OP.eq:
                    result = (v[0][l_column] == v[1][r_column])
                elif operator == OP.neq:
                    result = (v[0][l_column] != v[1][r_column])
                elif operator == OP.lt:
                    result = (v[0][l_column] < v[1][r_column])
                elif operator == OP.le:
                    result = (v[0][l_column] <= v[1][r_column])
                elif operator in (OP.is_in, OP.is_not_in):
                    switch = False if operator == OP.is_in else True  # It is used for XOR (^) 
                    if isinstance(v[1][r_column], list):
                        result =  ((v[0][l_column] in v[1][r_column]) ^ switch)
                    else:
                        raise NotImplementedError('{} not supported by {} operator check_if() is_in/is_not_in where'.format(type(v[1][r_column]), operator.name))
                elif operator in (OP.like, OP.not_like):
                    switch = False if operator == OP.like else True  # It is used for XOR (^)
                    result (fnmatch.fnmatch(v[0][l_column].lower(), v[1][r_column].lower()) ^ switch)
                else:
                    raise NotImplementedError('Unknown operator {} in check_if()'.format(operator))
            
            results.append(result)

        return self.func(results)
    
    def __str__(self) -> str:
        return 'JOINED_OBJECTLIST_FOR({})'.format(self.quantifier)
    
    def __repr__(self) -> str:
        return 'JOINED_OBJECTLIST_FOR({})'.format(self.quantifier)    
    

class JOINED_OBJECTLIST:
    """
    A list of joined objects where each element is a tuple of joined keys and a pair of objects.
    
    The matching keys are a tuple. A pair of objects is also a tuple. Left object comes from one OBJECTLIST.
    Right object comes from another OBJECTLIST. Right object could be None if left_join().
    The key of all elements of the JOINED_OBJECTLIST is not necessary to be unique as we can join one object to multiple objects having the same joined key.
    A JOINED_OBJECTLIST looks like.
    ```
    [
        ((key1, key2), (left_object1, right_object1)) 
        ((key3, key4), (left_object2, right_object2))
    ]
    ```
    
    Arguments
    ----------
    data : list of tuples that represents joined objects.
    
    Example
    -------
    >>> objectlist1 = OBJECTLIST([{"code": "001", "amount": 1000}, {"code": "001", "amount": 2000}, {"code": "002", "amount": 3000}])
    >>> objectlist2 = OBJECTLIST([{"code": "001", "max_amount": 2000}, {"code": "002", "max_amount": 3000}])
    >>> objectlist1.inner_join(objectlist2, "code")
    JOINED_OBJECTLIST([
        (('001',), ({'code': '001', 'amount': 1000}, {'code': '001', 'max_amount': 2000}))
        (('001',), ({'code': '001', 'amount': 2000}, {'code': '001', 'max_amount': 2000}))
        (('002',), ({'code': '002', 'amount': 3000}, {'code': '002', 'max_amount': 3000}))
    ])
    """   
    def __init__(self, data):
        self.data = data

    def select(self, column: str) -> ARRAY:
        """
        Return an ARRAY of values in the selected column, skip NULL.
        
        Arguments
        ----------
        column : str
            Column name of the left object if exists or right object.

        Returns
        -------
        ARRAY
            ARRAY of values in the selected column.
            
        Example
        -------
        >>> objectlist1.inner_join(objectlist2, "code").select("amount")
        [1000, 2000, 3000]
        """        
       
        results = []
        for joined_objects in self.data:
            keys = joined_objects[0]
            v = joined_objects[1]            
            if column in v[0]:
                results.append(v[0][column])
            elif v[1] is not None and column in v[1]:
                results.append(v[1][column])

        return results

    def check_if(self, l_column: str, operator: Union[OP, str], r_column: str) -> ARRAY:
        """
        For each pair of left and right objects in the JOINED_OBJECTLIST, 
        compare left object to the right with the specified condition.
        
        Arguments
        ----------
        l_column : str
            Column name of the left object to compare.
        operator : Union[OP, str]
            An operator to compare columns of the left and right objects. See `pyrengine.op.OP`.
        r_column : str
            Column name of the right object to compare.

        Returns
        -------
        ARRAY
            ARRAY of True/False 

        Raises
        ------
        Exception
            Any errors cause exception.
        NotImplementedError
            Unsupported operation or arguments.
            
        Example
        -------
        >>> objectlist1.inner_join(objectlist2, "code").check_if("amount", "gt", "max_amount")
        ARRAY([False, False, False])
        """ 
               
        if not isinstance(l_column, str):
            raise Exception("check_if() l_column requires string")
        
        if not isinstance(r_column, str):
            raise Exception("check_if() r_column requires string")

        if isinstance(operator, str):
            try:
                operator = OP[operator]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator {} in check_if()'.format(operator)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred
                
        # TODO: Type checking for each operator, e.g. gt needs both operands have the same type 
        results = []
        for joined_objects in self.data:
            keys = joined_objects[0]
            v = joined_objects[1]
            result = False

            if v[0][l_column] is None:
                raise Exception('Column {} not found in left OBJECTLIST {}'.format(l_column, v[0]))
            
            if v[1] is not None and v[1][r_column] is not None:
                if operator == OP.gt:
                    result = (v[0][l_column] > v[1][r_column])
                elif operator == OP.ge:
                    result = (v[0][l_column] >= v[1][r_column])
                elif operator == OP.eq:
                    result = (v[0][l_column] == v[1][r_column])
                elif operator == OP.neq:
                    result = (v[0][l_column] != v[1][r_column])
                elif operator == OP.lt:
                    result = (v[0][l_column] < v[1][r_column])
                elif operator == OP.le:
                    result = (v[0][l_column] <= v[1][r_column])
                elif operator in (OP.is_in, OP.is_not_in):
                    switch = False if operator == OP.is_in else True  # It is used for XOR (^) 
                    if isinstance(v[1][r_column], list):
                        result = ((v[0][l_column] in v[1][r_column]) ^ switch)
                    else:
                        raise NotImplementedError('{} not supported by {} operator check_if() is_in/is_not_in where'.format(type(v[1][r_column]), operator.name))
                elif operator in (OP.like, OP.not_like):
                    switch = False if operator == OP.like else True  # It is used for XOR (^)
                    result = (fnmatch.fnmatch(v[0][l_column].lower(), v[1][r_column].lower()) ^ switch)
                else:
                    raise NotImplementedError('Unknown operator {} in check_if()'.format(operator))
            
            results.append(result)

        return ARRAY(results)
    
    def count_if(self, l_column: str, operator: Union[OP, str], r_column: str) -> int:
        """
        Return the number of joined objects in the JOINED_OBJECTLIST that pass the condition.
        
        Arguments
        ----------
        l_column : str
            Column name of the left object to compare.
        operator : Union[OP, str]
            An operator to compare columns of the left and right objects. See `pyrengine.op.OP`.
        r_column : str
            Column name of the right object to compare.

        Returns
        -------
        int
            The number of joined objects that pass the condition.

        Raises
        ------
        Exception
            Any errors cause exception.
        NotImplementedError
            Unsupported operation or arguments.
            
        Example
        -------
        >>> objectlist1.inner_join(objectlist2, "code").count_if("amount", "gt", "max_amount")
        0 
        """     
        return sum(self.check_if(l_column, operator, r_column))

    def __str__(self) -> str:
        return 'JOINED_OBJECTLIST({})'.format(self.data)
    
    def to_string(self) -> str:
        """
        Return the string of JOINED_OBJECTLIST in tabular format.

        Returns
        -------
        str
            The string of JOINED_OBJECTLIST in tabular format.

        Example
        -------
        >>> print(objectlist1.inner_join(objectlist2, "code").to_string())
        JOINED_OBJECTLIST([
            (('001',), ({'code': '001', 'amount': 1000}, {'code': '001', 'max_amount': 2000}))
            (('001',), ({'code': '001', 'amount': 2000}, {'code': '001', 'max_amount': 2000}))
            (('002',), ({'code': '002', 'amount': 3000}, {'code': '002', 'max_amount': 3000}))
        ])
        """               
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([str(o) for o in self.data]))
        else:
            table = ''
        return 'JOINED_OBJECTLIST([{}])'.format(table)        

    def __repr__(self) -> str:
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([repr(o) for o in self.data]))
        else:
            table = ''        
        return 'JOINED_OBJECTLIST([{}])'.format(table)
    

# Some methods return a primitive. Others return a new ARRAY or OBJECTLIST 
class OBJECTLIST:
    """
    OBJECTLIST represents a list of objects. Each object is encoded as a python dict.
    An OBJECTLIST can be viewed as a small table with rows and columns.

    Arguments
    ---------
    data: list[dict]
        A list of objects 
    
    allow_duplication: bool, default=True
        When creating an OBJECTLIST, check if there exist any duplicate objects.

    Example
    -------
    >>> ol = OBJECTLIST([{"name": "John", "age": 37, "salary": 10000}, {"name": "Mary", "age": 42, "salary": 30000}])

    This OBJECTLIST can be viewed as a small table:
    ```
    name,age,salary
    John,37,10000
    May,42,30000
    ```
    """ 
    def __init__(self, data: list[dict], allow_duplication=True):
        if isinstance(data, OBJECTLIST):
            # Just in case that you create OBJECTLIST from OBJECTLIST. The new OBJECTLIST is  
            #   another reference to the exact same data.
            self.data = data.data   
        else:
            self.data = data
        if not allow_duplication:
            seen = set()
            for o in self.data:
                object_as_hashable_set = frozenset(o.items()) # Convert dict to hashable set
                if object_as_hashable_set in seen:
                    raise Exception("With allow_duplication set to False, duplicated objects are not allowed in OBJECTLIST")
                seen.add(object_as_hashable_set)

    ######################
    # Return a primitive #
    ######################
    
    def sum_of_column(self, column: str) -> Union[int, float]:
        """
        Return the summation of all values in the selected column.
        
        Arguments
        ----------
        column : str
            Name of selected column for summation. All values are required to be int or float.

        Returns
        -------
        int or float
            Summation of all values in the selected column.

        Example
        -------
        >>> ol.sum_of_column('age')
        """
        return  sum([o.get(column, 0) for o in self.data])
    
    def count(self) -> int:
        """
        Return the number of objects.

        Returns
        -------
        int
            The number of objects.
            
        Example
        -------
        >>> ol.count()
        """                
        return len(self.data)
    
    ########################
    # Return a dict object #
    ########################
    def get(self, index: int) -> dict:
        """
        Return the object at the `index`.

        Arguments
        ----------
        index : int
            The index starting from 0.

        Returns
        -------
        dict
            The object at the `index`.
            
        Example
        -------
        >>> ol.get(1)  
        
        Since a dict object is returned, we can get a value from a field.
        >>> ol.get(1).get('age')
        """        
        return self.data[index]

    ######################################
    # Return an ARRAY (subclass of list) #
    ######################################
    def select(self, column: str) -> ARRAY:
        """
        Return an ARRAY of values in the selected column, skip NULL.

        Arguments
        ----------
        column : str
            Column name to select values.

        Returns
        -------
        ARRAY
            ARRAY of values in the selected column.
            
        Example
        -------
        >>> ol.select("name")
        """        
        return ARRAY([o[column] for o in self.data if column in o])
    
    def select_distinct(self, column: str) -> ARRAY:  # Remove duplicates
        """
        Return an ARRAY of distinct values in the selected column, skip NULL.

        Arguments
        ----------
        column : str
            Column name to select values.

        Returns
        -------
        ARRAY
            ARRAY of distinct values in the selected column.
            
        Example
        -------
        >>> ol.select_distinct("name")
        """               
        return ARRAY(list(OrderedDict.fromkeys(self.select(column)))) 

    ########################
    # Return an OBJECTLIST #
    ########################    
   
    def where(self, column: str, operator: Union[OP, str], value: Union[str, int, float, list] ) -> OBJECTLIST:
        """
        Return a new OBJECTLIST which object matches the condition in where(). 
        
        If an object passes the condition, it is included in the returned OBJECTLIST. 
        Each object is tested with its column value, operator and value.

        Arguments
        ---------
        column : str
            Column name of the object to compare.
        operator : OP or str
            Operator to compare. See `pyrengine.op.OP`.
        value : str or int or float or list
            Depending on the operator, the value type must match the operator.

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST which each object matches the condition in where().

        Raises
        ------
        NotImplementedError
            Some usages are unsupported.
            
        Example
        -------
        >>> ol.where("name", "eq", "John")
        >>> ol.where("age", "gt", 60)
        >>> ol.where("name", "like", "Jo*")
        >>> ol.where("name", "is_in", ["Jonh", "Mary"])
            
        """        
        if isinstance(operator, str):
            try:
                operator = OP[operator]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator {} in where()'.format(operator)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred
                
        # TODO: Type checking for each operator, e.g. gt needs both operands have the same type 
        if operator == OP.gt:
            return OBJECTLIST([o for o in self.data if column in o and o[column] > value])
        elif operator == OP.ge:
            return OBJECTLIST([o for o in self.data if column in o and o[column] >= value])
        elif operator == OP.eq:
            return OBJECTLIST([o for o in self.data if column in o and o[column] == value])
        elif operator == OP.neq:
            return OBJECTLIST([o for o in self.data if column in o and o[column] != value])
        elif operator == OP.lt:
            return OBJECTLIST([o for o in self.data if column in o and o[column] < value])
        elif operator == OP.le:
            return OBJECTLIST([o for o in self.data if column in o and o[column] <= value])
        elif operator in (OP.is_in, OP.is_not_in):
            switch = False if operator == OP.is_in else True  # It is used for XOR (^) 
            if isinstance(value, list):
                return OBJECTLIST([o for o in self.data if column in o and ((o[column] in value) ^ switch)])
            else:
                raise NotImplementedError('{} not supported by {} operator where() is_in/is_not_in'.format(type(value), operator.name))
        elif operator in (OP.like, OP.not_like):
            switch = False if operator == OP.like else True  # It is used for XOR (^)
            return OBJECTLIST([o for o in self.data if column in o and (fnmatch.fnmatch(o[column].lower(), value.lower()) ^ switch)])
        else:
            raise NotImplementedError('Unknown operator {} in where()'.format(operator))
    
    # Return non-duplicated object list
    #   https://stackoverflow.com/questions/11092511/list-of-unique-dictionaries
    #   https://stackoverflow.com/a/46060873
    def distinct(self) -> OBJECTLIST:
        """
        Return a new OBJECTLIST with duplicated objects removed.

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST with duplicated objected removed.
            
        Example
        -------
        >>> ol.distinct()
        """        
        seen = set()
        results = []
        for o in self.data:
            object_as_hashable_set = frozenset(o.items()) # Convert dict to hashable set
            if object_as_hashable_set not in seen:
                results.append(o)
                seen.add(object_as_hashable_set)
        return OBJECTLIST(results)

    #################################
    # Return an intermediate object #
    #################################    
    
    # return GROUPBY 
    def group_by(self, column: Union[str, list[str]]) -> GROUPBY:
        """
        Return a GROUPBY which will be used to put objects with the same column value into the same group.
        
        The GROUPBY is often invoked with count() or sum() methods.

        Arguments
        ----------
        column : str or list[str]
            Column or list of columns to separate each group.

        Returns
        -------
        GROUPBY
            a GROUPBY which will be used to put objects with the same column value into the same group.

        Raises
        ------
        Exception
            Any errors cause exception.
            
        Example
        -------
        >>> ol.group_by("name").count()
        
        >>> ol.group_by("name").sum("salary)
        """        
        if column is None:
            raise Exception("OBJECTLIST.group_by() requires column")
        
        if isinstance(column, str):
            columns = [column]
        else:
            columns = column
            
        groups = {}
        for o in self.data:
            keys = []
            for c in columns: 
                if c in o:
                    keys.append((c, o[c]))
                else:
                    #keys.append((c, None))
                    raise Exception('group_by() cannot find column {} in {}'.format(c, o))
            group = tuple(keys)
            if group not in groups:
                groups[group] = []
            groups[group].append(o)
        return GROUPBY(groups)
    
    # return FILTERED_BY_COLUMN
    def filter_by_column(self, column: str) -> FILTERED_BY_COLUMN:
        """
        `Obsoleted`

        Arguments
        ----------
        column : str
            
        Returns
        -------
        FILTERED_BY_COLUMN
            A FILTERED_BY_COLUMN.
        """        
        return FILTERED_BY_COLUMN(self.data, column)
    
    def inner_join(self, other: OBJECTLIST, on_key: Union[str, list[str]], on_other_key: Union[str, list[str]] = None) -> JOINED_OBJECTLIST:
        """
        Return a JOINED_OBJECTLIST which is a list of inner-joined objects from this and the other OBJECTLIST based on joined keys. 
        
        Arguments
        ----------
        other : OBJECTLIST
            Another OBJECTLIST to join.
        on_key : str or list[str]
            The column or columns which objects between two OBJECTLISTs are joined on. 
        on_other_key : str or list[str], default = None
            The column names of the other OBJECTLIST to join on if different than the first OBJECTLIST.             

        Returns
        -------
        JOINED_OBJECTLIST
            A JOINED_OBJECTLIST which is a list of inner-joined objects from this and the other OBJECTLIST based on joined key.

        Raises
        ------
        Exception
            Any errors cause exception.
            
        """        
        if on_key is None:
            raise Exception("OBJECTLIST.inner_join() requires on_key argument")
        
        if isinstance(on_key, str):
            keys = [on_key]
        elif isinstance(on_key, list) and all(isinstance(key, str) for key in on_key):
            keys = on_key

        if on_other_key is not None:
            if isinstance(on_other_key, str):
                other_keys = [on_other_key]
            elif isinstance(on_other_key, list) and all(isinstance(key, str) for key in on_other_key):
                other_keys = on_other_key
            if len(keys) != len(other_keys):
                raise Exception("OBJECTLIST.inner_join() requires the number of columns of on_other_key == on_key")
        else:
            other_keys = keys

        results = []
        # TODO: join optimization
        for left in self.data:
            if not all(key in left for key in keys):
                raise Exception("inner_join() requires keys {} in left object {}".format(keys, left))            
            new_key = tuple(left[key] for key in keys)
            for right in other.data:
                if not all(key in right for key in other_keys):
                    raise Exception("inner_join() requires keys {} in right object {}".format(other_keys, right))
                if all(left[key] == right[rkey] for key, rkey in zip(keys, other_keys)):
                    result = (new_key, (left, right))
                    results.append(result)
        return JOINED_OBJECTLIST(results)
    
    def left_join(self, other: OBJECTLIST, on_key: Union[str, list[str]], on_other_key: Union[str, list[str]] = None) -> JOINED_OBJECTLIST:
        """
        Return a JOINED_OBJECTLIST which is a list of left-joined objects from this and the other OBJECTLIST based on joined keys. 
        If no matching object in the other OBJECTLIST, None is used to join with the left object.
        
        Arguments
        ----------
        other : OBJECTLIST
            Another OBJECTLIST to join.
        on_key : str or list[str]
            The column or columns which objects between two OBJECTLISTs are joined on.
        on_other_key : str or list[str], default = None
            The column names of the other OBJECTLIST to join on if different than the first OBJECTLIST.             

        Returns
        -------
        JOINED_OBJECTLIST
            A JOINED_OBJECTLIST which is a list of left-joined objects from this and the other OBJECTLIST based on joined key.

        Raises
        ------
        Exception
            Any errors cause exception.
            
        """        
        if on_key is None:
            raise Exception("OBJECTLIST.left_join() require on_key argument")
        
        if isinstance(on_key, str):
            keys = [on_key]
        elif isinstance(on_key, list) and all(isinstance(key, str) for key in on_key):
            keys = on_key

        if on_other_key is not None:
            if isinstance(on_other_key, str):
                other_keys = [on_other_key]
            elif isinstance(on_other_key, list) and all(isinstance(key, str) for key in on_other_key):
                other_keys = on_other_key
            if len(keys) != len(other_keys):
                raise Exception("OBJECTLIST.left_join() requires the number of columns of on_other_key == on_key")
        else:
            other_keys = keys            

        results = []
        # TODO: join optimization
        for left in self.data:
            result = None
            if not all(key in left for key in keys):
                raise Exception("left_join() requires keys {} in left object {}".format(keys, left))
            new_key = tuple(left[key] for key in keys)
            for right in other.data:
                if not all(key in right for key in other_keys):
                    raise Exception("left_join() requires keys {} in right object {}".format(other_keys, right))
                if all(left[key] == right[rkey] for key, rkey in zip(keys, other_keys)):
                    result = (new_key, (left, right))
                    results.append(result)
            if result is None:
                result = (new_key, (left, None))
                results.append(result)
        return JOINED_OBJECTLIST(results)

    def __str__(self) -> str:
        return 'OBJECTLIST({})'.format(self.data)

    # TODO: Pretty print OBJECTLIST as a table
    #   https://stackoverflow.com/questions/60577354/creating-a-table-with-prettytable-from-list-of-dictionaries
    #   https://stackoverflow.com/questions/11399384/extract-all-keys-from-a-list-of-dictionaries
    #   https://stackoverflow.com/questions/1523660/how-to-print-a-list-in-python-nicely
    def to_string(self) -> str:    
        """
        Return the string of OBJECTLIST in tabular format.

        Returns
        -------
        str
            The string of OBJECTLIST in tabular format.

        Example
        -------
        >>> ol = OBJECTLIST([{"name": "John", "age": 37, "salary": 10000}, {"name": "Mary", "age": 42, "salary": 30000}])
        >>> print(ol.to_string())
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000}
            {'name': 'Mary', 'age': 42, 'salary': 30000}
        ])
        """          
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([str(o) for o in self.data]))
        else:
            table = ''
        return 'OBJECTLIST([{}])'.format(table)

    def __repr__(self) -> str:
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([repr(o) for o in self.data]))
        else:
            table = ''        
        return 'OBJECTLIST([{}])'.format(table)
    