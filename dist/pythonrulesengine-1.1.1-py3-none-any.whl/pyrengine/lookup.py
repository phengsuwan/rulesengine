import json
import csv
import os
from ast import literal_eval

from pyrengine.objectlist import OBJECTLIST
from typing import Union

REFERENCE_DIR = "./db/lookup"

# Disable pdoc3 document generating for developer methods
__pdoc__ = {
    'LOOKUP.cache': False,
    'LOOKUP.listtable': False,
    'LOOKUP.load': False,
    'LOOKUP.reference_dir': False,
    'LOOKUP.remove': False,
    'LOOKUP.reset': False,
    'LOOKUP.set': False,
    'LOOKUP.set_reference_dir': False,
}

# current version will support only three data types
# another data type will be proceeded by 'eval' method 
TYPE_CONVERTER = {
    'str': str,
    'float': float,
    'int': int,
}

class LOOKUP:
    """
    LOOKUP is used to access a static lookup table from external source like JSON or CSV file.

    Example
    -------
    The following expression returns the lookup table named 'group_cs_05'.
    >>> LOOKUP.get('group_cs_05')

    Or equivalently, 
    >>> LOOKUP['group_cs_05']
    """    
    cache = {}
    reference_dir = REFERENCE_DIR

    # set_reference_dir is used to set the lookup table base directory 
    @classmethod
    def set_reference_dir(cls, reference_dir=REFERENCE_DIR): 
        cls.reference_dir = reference_dir


    @classmethod
    def __dtype(cls, val, data_type):
        try:
            result = TYPE_CONVERTER[data_type](val)
            # result = TYPE_CONVERTER[data_type](literal_eval(val))
        except KeyError:
            try: 
                result = literal_eval(val)
            except: 
                result = None
        except Exception as e:
            result = None
    
        return result


    # check a file in the lookup table directory and identify file type (json or csv)
    # if file does not exist or file extensions are not json nor csv, the method will return None
    @classmethod
    def __lookup_file(cls, name: str): 
        if os.path.isfile('{}/{}.json'.format(cls.reference_dir, name)): 
            lftype = "json"
        elif os.path.isfile('{}/{}.csv'.format(cls.reference_dir, name)): 
            lftype = "csv"
        else: 
            print('file {}'.format(name) + ' missed, either json or csv format')
            lftype = None

        return lftype


    # load csv file to create lookup table
    @classmethod
    def __lookup_csv(cls, name: str): 
        filename = '{}/{}.csv'.format(cls.reference_dir, name)
        #print('Loading {}'.format(filename))
        try: 
            with open(filename, 'r', encoding="utf8") as f:
                cr = csv.reader(f, delimiter=',')
                headers = next(cr, None)
                dtypes = next(cr, None)
                num_cols = len(headers)
                csv_dict = [{headers[i]: cls.__dtype(row[i], dtypes[i]) for i in range(num_cols)} for row in cr]
                ref = OBJECTLIST(csv_dict)
                cls.cache[name] = ref
                return ref
        except Exception as ex:
            print('Loading file {}'.format(filename) + ' failed: {}'.format(ex))
            return None


    # TODO: Check file format.
    # TODO: Error handling.
    @classmethod
    def __load_json(cls, name: str):
        filename = '{}/{}.json'.format(cls.reference_dir, name)
        #print('Loading {}'.format(filename))
        try:
            with open(filename, 'r') as f:
                ref = json.load(f)
                ref = OBJECTLIST(ref)
                cls.cache[name] = ref
                return ref
        except Exception as ex:
            print('Loading file {}'.format(filename) + ' failed: {}'.format(ex))
            return None


    @classmethod
    def load(cls, name: str):
        lf_type = cls.__lookup_file(name)
        if lf_type is not None: 
            f_lookup = cls.__load_json if lf_type == "json" else cls.__lookup_csv
            return f_lookup(name)
        else: 
            return None


    @classmethod
    def get(cls, name: str):
        """
        Return a static lookup table from external source like JSON or CSV file.

        Returns
        -------
        `pyrengine.objectlist.OBJECTLIST`
            A static lookup table from external source like JSON or CSV file.

        Example
        -------
        The following expression returns the lookup table named 'group_cs_05'.
        >>> LOOKUP.get('group_cs_05')

        Or equivalently, 
        >>> LOOKUP['group_cs_05']        

        Raises
        ------
        Exception
            Any errors cause exception.
        """            
        if name not in cls.cache:
            rt=cls.load(name)
            if rt is None:
                 #return None
                 raise Exception("LOOKUP has no {}".format(name))

        return cls.cache[name]

    # Class subscription
    # https://stackoverflow.com/a/63663183
    # https://stackoverflow.com/questions/73562722/extending-generic-class-getitem-in-python-to-accept-more-params
    @classmethod
    def __class_getitem__(cls, name: str):  # Support LOOKUP[name]  
        return cls.get(name)
        
    @classmethod
    def set(cls, name: str, db: Union[list, OBJECTLIST]):
        if not isinstance(db, OBJECTLIST):
            db = OBJECTLIST(db)
        cls.cache[name]=db
        return True

    @classmethod
    def remove(cls, name: str):
        rf=False
        if name in cls.cache:
            rf=True
            del cls.cache[name]

        return rf

    @classmethod
    def listtable(cls):
        ret=[]
        for r in cls.cache.keys():
            ret.append(r)

        return ret
    
    @classmethod
    def reset(cls):
        cls.cache.clear()

        return True