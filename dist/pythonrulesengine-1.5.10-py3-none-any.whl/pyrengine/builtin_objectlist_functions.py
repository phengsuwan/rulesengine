from pyrengine.objectlist import OBJECTLIST
from typing import Union,Optional
from pyrengine.lookup import LOOKUP_TABLE


def _get_collective_field(data:OBJECTLIST,field:str) -> OBJECTLIST:
    """
    Extracts and aggregates elements from a collective field in a collective data.

    Parameters
    ----------
    data: A collective data containing multiple items, where each item has a collective field
    field: The name of the field to extract from each item in `data`

    Returns
    -------
    OBJECTLIST: A new collective data containing all aggregated elements from the collective field

    Raises
    ------
    ValueError: If any item in the collective field is not of type OBJECTLIST
    
    Examples
    --------
    >>> data = OBJECTLIST([
    ...     {"items": OBJECTLIST([{"item":1},{"item":2}])},
    ...     {"items": OBJECTLIST([{"item":4}]), }
    ... ])
    >>> get_collective_field(data, "items")
    OBJECTLIST([{"item":1},{"item":2},{"item":4])

    Profile
    -------
    ```{json}
    {
        "name": "get_collective_field", 
        "display_name": "Get Collective Field",
        "description": "Extracts and aggregates elements from a collective field in a collective data.", 
        "params": [
            { "name": "data", "description": "A collective data containing multiple items, where each item has a collective field ", "type": ["objectlist"]},
            { "name": "field", "description": "The name of the field to extract from each item in `data`", "type": ["string"]}
        ],
        "return_type": {
            "type": "objectlist"
        }
    }
    ```
    """
    output = []
    for item in data.select(field):
        if not isinstance(item,OBJECTLIST):
            raise ValueError(f"field must be of type OBJECTLIST")
        for j in item :
            output.append(j)

    return OBJECTLIST(output)

def _c_groupby_count(data:OBJECTLIST,columns:Union[str,list[str]],count_column:Optional[str]) -> int:
    """
    Count values for a specified column, grouped by specified columns in the data.

    Parameters
    ----------
    data: The data object containing entries to be grouped and counted
    columns: Columns to group by, specified as a string or a list of strings
    count_column: Column name to count

    Returns
    -------
    int: The count of entries grouped by the specified columns

    Examples
    --------
    >>> c_groupby_count(data, 'column_name', 'count_column')
    42
    
    Profile
    -------
    ```{json}
    {
        "name": "c_groupby_count", 
        "display_name" : "Count Group By",
        "description": "Count values for a specified column, grouped by specified columns in the data.", 
        "params" : [
            { "name" : "data" , "description" : "The data object containing entries to be grouped and counted" , "type" : ["OBJECTLIST"]},
            { "name" : "columns" , "description" : "Columns to group by, specified as a string or a list of strings" , "type" : ["string", "list_string"]},
            { "name" : "count_column" , "description" : "Column name to count" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "objectlist"
        }
    }
    ```
    """
    return data.group_by(columns).count(count_column)

def _c_groupby_sum(data:OBJECTLIST,columns:Union[str,list[str]],sum_column:str) -> Union[float,int]:
    """
    Sum values for a specified column, grouped by specified columns in the data.

    Parameters
    ----------
    data: The data object containing entries to be grouped and summed
    columns: Columns to group by, specified as a string or a list of strings
    sum_column: Column name whose values will be summed

    Returns
    -------
    float : The sum of values in the specified column, grouped by the specified columns

    Examples
    --------
    >>> c_groupby_sum(data, 'column_name', 'sum_column')
    123.45
    
    Profile
    -------
    ```{json}
    {
        "name": "c_groupby_sum", 
        "display_name" : "Sum Group By",
        "description": "Sum values for a specified column, grouped by specified columns in the data.", 
        "params" : [
            { "name" : "data" , "description" : "The data object containing entries to be grouped and summed" , "type" : ["objectlist"]},
            { "name" : "columns" , "description" : "Columns to group by, specified as a string or a list of strings" , "type" : ["string", "list_string"]},
            { "name" : "sum_column" , "description" : "Column name whose values will be summed" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "objectlist"
        }
    }
    ```
    """
    return data.group_by(columns).sum(sum_column)



def c_exists(data:OBJECTLIST,jpath:str,value:object,wildcard:bool=False)-> bool:
    """
    Check if a value is found in this OBJECTLIST at the specified json path.

    Parameters
    ----------
    data:  Collective data
    value: An object (of type int, float, string or other) to find in this Collective data
    jpath: JSONPATH string
    wildcard : Use wildcard ? for single character and * for any number of characters in value. Valid only if value is a string; otherwise ignored

    Returns
    -------
    bool : True if found else false.
    
    Examples
    --------
    >>> ol = OBJECTLIST([{"name": "John", "age": 37, "salary": 10000}, {"name": "Mary", "age": 42, "salary": 30000}])
    >>> c_exists(ol,'John', '$[*].name')
    True
    >>> c_exists(ol,'J*', '$[*].name', True)  
    True      
    >>> c_exists(ol,'A*', '$[*].name', True)
    False
    
    Profile
    -------
    ```{json}
    {
    "name": "c_exists",
    "display_name": "Check value exists in collective data",
    "description":
        "Check if a value is found in this OBJECTLIST at the specified json path.",
    "params": [
        { "name": "data", "description": "Collective data", "type": ["objectlist"] },
        {
        "name": "jpath",
        "description": "JSONPATH string",
        "type": ["jsonpath"],
        "depends_on": [
            {
            "source_param": "data",
            "source_attr": "value",
            "self_attr": "input"
            }
        ]
        },
        {
        "name": "value",
        "description":
            "An object (of type int, float, string or other) to find in this Collective data",
        "type": ["string", "number", "boolean", "datetime"],
        "depends_on": [
            {
            "source_param": "jpath",
            "source_attr": "value_type",
            "self_attr": "type"
            }
        ]
        },
        {
        "name": "wildcard",
        "description":
            "Use wildcard ? for single character and * for any number of characters in value. Valid only if value is a string; otherwise ignored",
        "type": ["boolean"],
        "options": [true, false],
        "default": false,
        "depends_on": [
            {
            "source_param": "jpath",
            "source_attr": "value_type",
            "self_attr": "enabled",
            "enabled_if": {
                "value": "source_attr",
                "operator": "==",
                "expected_value": "string"
            }
            }
        ]
        }
    ],
    "return_type": {
        "type": "boolean"
    }
    }
```
    """

    return data.exists(value,jpath,wildcard)


def c_assign(data :OBJECTLIST,column:str,value:Union[object,list[object]]) -> OBJECTLIST:
    """
    Assign a new column to all objects or replacing the existing column. Return a new OBJECTLIST. This method doesn't check the schema of objects.

    Parameters
    ----------
    data:  Collective data
    column: Column name
    value: If value is a single value, assign it to all objects. If value is a list of values, assign each element to a different object in order.

    Returns
    -------
    OBJECTLIST : A new OBJECTLIST with the assigned column.
    
    Examples
    --------
    >>> ol = OBJECTLIST([{"name": "John", "age": 37, "salary": 10000}, {"name": "Mary", "age": 42, "salary": 30000}])
    >>> c_assign(ol,'dept','Sales')
    OBJECTLIST([
        {'name': 'John', 'age': 37, 'salary': 10000, 'dept': 'Sales'}
        {'name': 'Mary', 'age': 42, 'salary': 30000, 'dept': 'Sales'}
    ])     
    >>> c_assign(ol,'dept',['Finance', 'Sales'])
    OBJECTLIST([
        {'name': 'John', 'age': 37, 'salary': 10000, 'dept': 'Finance'}
        {'name': 'Mary', 'age': 42, 'salary': 30000, 'dept': 'Sales'}
    ])
    
    Profile
    -------
    ```{json}
    {
    "name": "c_assign",
    "display_name": "Add new column to objectlist",
    "description":
        "Assign a new column to all objects or replacing the existing column. Return a new OBJECTLIST. This method doesn't check the schema of objects.",
    "params": [
        { "name": "data", "description": "Collective data", "type": ["objectlist"] },
        {
        "name": "column",
        "description": "Column name",
        "type": ["string"]
        },
        {
        "name": "value",
        "description":
            "If value is a single value, assign it to all objects. If value is a list of values, assign each element to a different object in order.",
        "type": ["string", "number", "boolean", "datetime","list_string","list_number","list_boolean","list_datetime"]
        }
    ],
    "return_type": {
        "type": "objectlist",
        "inherit_attributes_from" : {
            "source_params" : "data",
            "source_attr" : "value",
            "self_attr" : "input"
        },
        "extended_attributes" : {
            "name" :  {
                "source_params" : "column",
                "source_attr" : "value",
                "self_attr" : "input"
            },
            "type" :  {
                "source_params" : "value",
                "source_attr" : "value_type",
                "self_attr" : "input"
            }
        }
        
    }
    }
```
    """
    return data.assign(column,value)

def c_intersect(data1:OBJECTLIST,data2:OBJECTLIST,compare_attributes:list[str]) -> OBJECTLIST:
    """
    Find the intersection of two OBJECTLISTs based on specified attributes.

    Parameters
    ----------
    data1: an OBJECTLIST containing the first set of data
    data2: an OBJECTLIST containing the second set of data
    compare_attributes: a list of attribute names to compare for intersection

    Returns
    -------
    OBJECTLIST: a new OBJECTLIST containing the intersected elements based on the given attributes

    Raises
    ------
    ValueError: if the compare_attributes contain invalid keys or the data objects don't have those attributes
    
    Examples
    --------
    >>> data1 =  OBJECTLIST([
        {"time": 2041, "number": 4, "name": "Alice1"},
        {"time": 2042, "number": 5, "name": "Bob1"},
        {"time": 2043, "number": 6, "name": "Charlie1"}
    ])
    >>> data2 = OBJECTLIST([
        {"time": 2041, "number": 4, "name": "Alice2"},
        {"time": 2042, "number": 5, "name": "Bob2"},
        {"time": 2044, "number": 7, "name": "Charlie2"}
    ])
    >>> c_intersect(data1, data2, ["time", "number"])
    OBJECTLIST([{'time': 2041, 'number': 4, 'name': 'Alice1'}, {'time': 2042, 'number': 5, 'name': 'Bob1'}])

    Profile
    -------
    ```{json}
    {
        "name": "c_intersect", 
        "display_name" : "Intersection of Two OBJECTLISTs",
        "description": "Find the intersection of two OBJECTLISTs based on specified attributes.", 
        "params" : [
            { "name" : "data1" , "description" : "First OBJECTLIST to compare" , "type" : ["objectlist"]},
            { "name" : "data2" , "description" : "Second OBJECTLIST to compare" , "type" : ["objectlist"]},
            { "name" : "compare_attributes" , "description" : "List of attribute names to compare" , "type" : ["list_string"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "inherit_attributes_from" : {
                "source_params" : "data1",
                "source_attr" : "value",
                "self_attr" : "input"
            } 
        }
    }
    ```
    """
    if isinstance(data2, LOOKUP_TABLE):
       return OBJECTLIST([d for d in data1 if {k: d[k] for k in compare_attributes} in data2.select(compare_attributes)])
    
    list1 = data1.to_list()
    list2 = data2.to_list()

    set2 = {tuple(d[key] for key in compare_attributes) for d in list2}

    intersection = [
        dict1 for dict1 in list1
        if tuple(dict1[key] for key in compare_attributes) in set2
    ]
    return OBJECTLIST(intersection)

def c_difference(data1:OBJECTLIST,data2:OBJECTLIST,compare_attributes:list[str]) -> OBJECTLIST:
    """
    Find the difference between two OBJECTLISTs based on specified attributes.

    Parameters
    ----------
    data1: an OBJECTLIST containing the first set of data
    data2: an OBJECTLIST containing the second set of data
    compare_attributes: a list of attribute names to compare for difference

    Returns
    -------
    OBJECTLIST: a new OBJECTLIST containing the elements from data1 that do not exist in data2 based on the given attributes

    Raises
    ------
    ValueError: if the compare_attributes contain invalid keys or the data objects don't have those attributes
    
    Examples
    --------
    >>> data1 =  OBJECTLIST([
        {"time": 2041, "number": 4, "name": "Alice1"},
        {"time": 2042, "number": 5, "name": "Bob1"},
        {"time": 2043, "number": 6, "name": "Charlie1"}
    ])
    >>> data2 = OBJECTLIST([
        {"time": 2041, "number": 4, "name": "Alice2"},
        {"time": 2042, "number": 5, "name": "Bob2"},
        {"time": 2044, "number": 7, "name": "Charlie2"}
    ])
    >>> c_difference(data1, data2, ["time", "number"])
    OBJECTLIST([{"time": 2043, "number": 6, "name": "Charlie1"}])

    Profile
    -------
    ```{json}
    {
        "name": "c_difference", 
        "display_name" : "Difference Between Two OBJECTLISTs",
        "description": "Find the difference between two OBJECTLISTs based on specified attributes.", 
        "params" : [
            { "name" : "data1" , "description" : "First OBJECTLIST to compare" , "type" : ["objectlist"]},
            { "name" : "data2" , "description" : "Second OBJECTLIST to compare" , "type" : ["objectlist"]},
            { "name" : "compare_attributes" , "description" : "List of attribute names to compare" , "type" : ["list_string"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "inherit_attributes_from" : {
                "source_params" : "data1",
                "source_attr" : "value",
                "self_attr" : "input"
            } 
        }
    }
    ```
    """
    if isinstance(data2, LOOKUP_TABLE):
       return OBJECTLIST([d for d in data1 if {k: d[k] for k in compare_attributes} not in data2.select(compare_attributes)])
    
    list1 = data1.to_list()
    list2 = data2.to_list()
    
    set2 = {tuple(d[key] for key in compare_attributes) for d in list2}
    
    difference = [
        dict1 for dict1 in list1
        if tuple(dict1[key] for key in compare_attributes) not in set2
    ]
    return OBJECTLIST(difference)


def c_flat_group_by(data :OBJECTLIST,columns=list[str],group_id_key=str) -> OBJECTLIST:
    """
    Groups the data by specified columns.

    Parameters
    ----------
    data : OBJECTLIST
        The data to be grouped.
    columns : list of str, optional
        The columns by which the data will be grouped, defaults to an empty list.
    group_id_key : str
        The key name for assigning group IDs to the data.

    Returns
    -------
    OBJECTLIST
        The grouped data with assigned group IDs.

    Raises
    ------
    ValueError
        If an invalid data structure or grouping column is provided.
    
    Examples
    --------
    >>> c_flat_group_by(data, ['column1', 'column2'], 'group_id')
    OBJECTLIST([{'column1': value1, 'column2': value2, 'group_id': 1}, ...])

    Profile
    -------
    ```{json}
    {
        "name": "c_flat_group_by", 
        "display_name" : "Flat Group By Function",
        "description": "Groups the data by specified columns.", 
        "params" : [
            { "name" : "data" , "description" : "The data to be grouped." , "type" : ["objectlist"]},
            { "name" : "columns" , "description" : "Columns by which to group the data." , "type" : ["list_string"]},
            { "name" : "group_id_key" , "description" : "The key name to assign group IDs." , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "inherit_attributes_from" : {
                "source_param" : "data",
                "source_attr" : "value",
                "self_attr" : "input"
            },
            "extended_attributes" : {
                "name" : {
                    "source_param" :"group_id_key",
                    "source_attr" : "value",
                    "self_attr" : "input"
                    },
                "type" : {
                    "source_param" : "group_id_key",
                    "source_attr" : "value_type",
                    "self_attr" : "input"
                }
            }
        }
    }
    ```
    """
    sorted_data = data.group_by(column=columns)
    
    results = None
    group_number = 1
    for _,v in sorted_data.data.items():
        new_data = OBJECTLIST(v).assign(group_id_key,group_number)
        if results is None :
            results = new_data
        else :
            results = results.append(new_data)
        group_number +=1 
    return results
        
        
def c_flat_group_by_time_period(data:OBJECTLIST,column:str,time_period :int,group_id_key:str) -> OBJECTLIST:
    """
    Groups the data by time periods based on the specified column and time threshold.

    Parameters
    ----------
    data : OBJECTLIST
        The data to be grouped.
    column : str
        The column containing the time values for grouping.
    time_period : int
        The maximum time period (in seconds) between entries in the same group.
    group_id_key : str
        The key name for assigning group IDs to the data.

    Returns
    -------
    OBJECTLIST
        The data with time-based group IDs assigned.

    Raises
    ------
    ValueError
        If the time column is invalid or the data is not sorted correctly.
    
    Examples
    --------
    >>> c_flat_group_by_time_period(data, 'timestamp', 3600, 'group_id')
    OBJECTLIST([{'timestamp': value1, 'group_id': 1}, ...])

    Profile
    -------
    ```{json}
    {
        "name": "c_flat_group_by_time_period", 
        "display_name" : "Flat Group By Time Period Function",
        "description": "Groups the data by time periods based on the specified column and time threshold.", 
        "params" : [
            { "name" : "data" , "description" : "The data to be grouped." , "type" : ["objectlist"]},
            { "name" : "column" , "description" : "The column containing the time values for grouping." , "type" : ["string"]},
            { "name" : "time_period" , "description" : "The maximum time period (in seconds) between entries in the same group." , "type" : ["integer"]},
            { "name" : "group_id_key" , "description" : "The key name to assign group IDs." , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "inherit_attributes_from" : {
                "source_param" : "data",
                "source_attr" : "value",
                "self_attr" : "input"
            },
            "extended_attributes" : {
                "name" : {
                    "source_param" :"group_id_key",
                    "source_attr" : "value",
                    "self_attr" : "input"
                    },
                "type" : {
                    "source_param" : "group_id_key",
                    "source_attr" : "value_type",
                    "self_attr" : "input"
                }
            }
        }
    }
    ```
    """
    data = data.sort(column,ascending=True)
    diffs = [0]+[(j-i).seconds for i,j in zip(data.select(column).to_list(),data.select(column).to_list()[1:])]

    results =[]
    group_number = 1
    for i in range(len(diffs)):
        _diff = diffs[i]
        _data_item = data.get(i)
        
        if _diff <= time_period:
            _data_item[group_id_key] = group_number
        else :
            group_number += 1
            _data_item[group_id_key]  = group_number
        results.append(_data_item)

    return OBJECTLIST(results)
            