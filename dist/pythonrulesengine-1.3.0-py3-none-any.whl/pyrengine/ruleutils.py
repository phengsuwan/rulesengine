import decimal
import jsonpath_ng
import html
import graphviz

from datetime import datetime
from typing import Iterable

from pyrengine.objectlist import OBJECTLIST
from pyrengine.objectlist import ARRAY
from pyrengine.model import RulePackage

TYPE_MAPPING = {
    "str": "",
    "int": 0,
    "float": 0.0,
    "bool": False,
    "datetime": '2024-01-01 00:00:00',
    "OBJECTLIST": OBJECTLIST([]),
    "ARRAY": ARRAY([])
}

# filter fields that contain array list and convert
# into OBJECTLIST object
def convert(input_json):
    fields_names = list(input_json.keys())
    for fn in fields_names:
        if type(input_json[fn]) is list : 
            if len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict :
                input_json[fn] = OBJECTLIST(input_json[fn])
            else: 
                input_json[fn] = ARRAY(input_json[fn])
    return input_json

# This is the previous version of convert
# def convert(input_json):
#     fields_names = list(input_json.keys())
#     for fn in fields_names:
#         if type(input_json[fn]) is list and len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict:
#             input_json[fn] = OBJECTLIST(input_json[fn])
#     return input_json


# Update the rule dict by *non-verbose* audit tree dict. The structure of rule dict and 
#   result dict are required to be compatible; otherwise an exception or unexpected outcome occurs.
# https://stackoverflow.com/questions/71396284/python-how-to-recursively-merge-2-dictionaries
def merge_rule_result(rule: dict, result: dict):
    for key, val in result.items():
        if key == "__result__":
            rule[key] = val
            continue

        if key in rule:
            if isinstance(val, dict):
                if not isinstance(rule[key], dict):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a dict".format(key))
                merge_rule_result(rule[key], val)
            elif isinstance(val, list):
                if not isinstance(rule[key], list):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a list".format(key))
                if len(val) != len(rule[key]):
                    raise Exception("The value of rule's key {} has different length than that of result".format(key))
                for i in range(len(val)):
                    if not isinstance(val[i], dict):
                        raise Exception("Expect element {} of result's key {} to be a dict".format(i, key))
                    if not isinstance(rule[key][i], dict):
                        raise Exception("Expect element {} of rule's key {} to be a dict".format(i, key))                
                    merge_rule_result(rule[key][i], val[i])
            else:
                pass # Skip other primitive values
        else:
            raise Exception('Unknown result key {}'.format(key))


def validate_by_example(obj: object, example: dict, deep = False, numeric_compatible=False) -> bool:
    """
    A helper function to validate data type of an input object. The structure of 
    the input object must be a superset of the example, i.e. having same or more keys with
    the exact same data type (not subclasses).

    Parameters
    ----------
    obj : object
        An input oject 
    example : dict
        An object prototype. 
    deep : bool, optional
        Recursively validate sub-structure too, by default False (Not implemented yet).
    numeric_compatible : bool, optional
        Allow int and float and decimal.Decimal values to be compatible, by default False.

    Returns
    -------
    bool
        True if the input object has the same structure as least as the example.

    Raises
    ------
    NotImplementedError
        Not implemented yet. Future maybe.
    Exception
        Any error found.
    """    
    if deep:
        raise NotImplementedError('deep validation not support yet')
    
    if not isinstance(obj, dict):
        raise NotImplementedError('For now, obj argument must be a dict')
    
    for key in example:
        if key not in obj:
            raise Exception('Key {} not found in the obj'.format(key))
        
        if numeric_compatible and isinstance(example[key], (int, float, decimal.Decimal)) and isinstance(obj[key], (int, float, decimal.Decimal)):
            continue
        
        if type(obj[key]) != type(example[key]):
            raise Exception('The value of {} is of type {} but expected {}'.format(key, type(obj[key]).__name__, type(example[key]).__name__))
        
    return True

def json_rules_to_example(rules: Iterable[dict], dtype: dict) -> dict:
    """
    A helper function to generate example json data from a list of rules and type mapping file. 
    The field names come from rule condition. The data types come from mapping file. 

    Parameters
    ----------
    rules : Iterable[dict]
        A sequence of json rules. 
    dtype : dict
        A type mapping for json data. 

    Returns
    -------
    dict
        example json (dict) data.

    Raises
    ------
    NotImplementedError
        Not implemented yet. Future maybe.
    Exception
        Any error found.
    """    

    query = jsonpath_ng.parse("$..[fact]") # Find any facts in the tree
    example = {}
    for rule in rules:
        for match in query.find(rule): # For each matching fact
            fieldname = match.value
            if isinstance(fieldname, str):
                fieldtype = dtype.get(fieldname)
                if fieldtype is None:
                    raise Exception("Field name {} is not found in type mapping file".format(fieldname))
                mapped_fieldtype = TYPE_MAPPING.get(fieldtype)
                if mapped_fieldtype is None:
                    raise Exception("Field type {} is unknown".format(fieldtype))

                example[fieldname] = mapped_fieldtype

    return example


def to_lowercase_key(input: dict | list) -> dict | list:
    """
    A helper function to convert all keys of dict to lowercase recursively, including dicts in any 
    objectlists.
    Keys must be string; otherwise an exception raises.

    Parameters
    ----------
    input : dict | list
        An input dict. If input is a list, apply to each element in the list. 

    Returns
    -------
    dict | list
        Output dict or list, corresponding to the input.

    Raises
    ------
    Exception
        Any error found.
    """    

    if isinstance(input, dict):
        output = {k.lower(): to_lowercase_key(v) if isinstance(v, (dict, list)) else
                                OBJECTLIST([to_lowercase_key(o) for o in v.data]) if isinstance(v, OBJECTLIST) else 
                                v
                  for k, v in input.items()}        
    elif isinstance(input, list):
        output = [to_lowercase_key(e) if isinstance(e, (dict, list)) else
                    OBJECTLIST([to_lowercase_key(o) for o in e.data]) if isinstance(e, OBJECTLIST) else
                    e
                  for e in input]
    else:
        raise NotImplementedError("Unsupport data type {}".format(type(input)))

    return output


def _property_diff(old: dict, new: dict) -> dict:
    old_keys = set(old.keys())
    new_keys = set(new.keys())
    added_properties = set(new_keys).difference(old_keys)
    deleted_properties = set(old_keys).difference(new_keys)
    same_properties = set(old_keys).intersection(new_keys)
    diff = {}
    if added_properties:
        diff['add'] = [{'property': key, 'value': new[key]} for key in sorted(added_properties)]
    if deleted_properties:
        diff['delete'] = [{'property': key, 'value': old[key]} for key in sorted(deleted_properties)]
    if same_properties:
        modified = [{'property': key, 'old_value': old[key], 'new_value': new[key]} for key in sorted(same_properties) if old[key] != new[key]] 
        if modified: 
            diff['modify'] = modified
    return diff


def rpdiff(old: RulePackage | dict, new: RulePackage | dict) -> dict:
    """
    Compare two rule packages.

    Parameters
    ----------
    old : RulePackage | dict
        Old rule package or json graph.
    new : RulePackage | dict
        New rule package or json graph. 

    Returns
    -------
    dict
        Changes (add, delete, modify) between two versions.
    """ 

    # First, convert to json graph for comparison.
    if isinstance(old, dict):
        o = RulePackage.from_graph(old)  # Validate format
        old = o.to_graph()  # Get properties only what we want
    elif isinstance(old, RulePackage):
        old = RulePackage.to_graph()  # Convert to json graph

    if isinstance(new, dict):
        n = RulePackage.from_graph(new)  # Validate format
        new = n.to_graph()  # Get properties only what we want
    elif isinstance(new, RulePackage):
        new = RulePackage.to_graph()  # Convert to json graph    

    old_package_id = old['package_id']
    new_package_id = new['package_id']        

    old_components = dict()
    old_components.update({node['node_id']: node for node in old.get('nodes') or []})
    old_components.update({(edge['src_id'], edge['dst_id']): edge for edge in old.get('edges') or []})
    old_components.update({(old_package_id, node_id): None for node_id in old.get('attached_nodes') or []})

    new_components = dict()
    new_components.update({node['node_id']: node for node in new.get('nodes') or []})
    new_components.update({(edge['src_id'], edge['dst_id']): edge for edge in new.get('edges') or []})
    new_components.update({(old_package_id, node_id): None for node_id in new.get('attached_nodes') or []})

    diff = {}
    """
    # diff dict looks like:
    diff = {
        'add': {
            'nodes': [

            ],
            'edges': [

            ],
            'attached_nodes': [

            ]
        },
        'delete': {
            'nodes': [

            ],
            'edges': [

            ],
            'attached_nodes': [
                
            ]
        },
        'modify': {
            'package': {
                'modify': [
                    {'property': 'package_id', 'old_value': 'a', 'new_value': 'x'},
                ],
            },
            'nodes': [
                {
                    'node_id': 'abcde',
                    'add': [
                        {'property': 'template', 'value': 'Hello World'},
                    ],
                    'delete': [
                        {'property': 'property2', 'value': 'Some value'},
                    ]
                    'modify': [
                        {'property': 'node_type', 'old_value': 'a', 'new_value': 'x'},
                        {'property': 'expression', 'old_value': 'b', 'new_value': 'y'}
                    ]
                },
                {
                    'node_id': '12344', 
                    'modify': [
                        {'property': 'node_type', 'old_value': 'a', 'new_value': 'x'},
                        {'property': 'expression', 'old_value': 'a', 'new_value': 'x'}
                    ]
                }
            ], 
            'edges': [
                {
                    'src_id': 'a',
                    'dst_id': 'b',
                    'add': [
                        {'property': 'property3', 'value': 'Some value'},
                    ],
                    'modify': [
                        {'property': 'case', 'old_value': 'a', 'new_value': 'x'}
                    ]
                }

            ]

        }
    }
    """

    # Check nodes
    old_nodes = {node['node_id'] for node in old.get('nodes') or []}
    new_nodes = {node['node_id'] for node in new.get('nodes') or []}
    added_nodes = new_nodes.difference(old_nodes)
    deleted_nodes = old_nodes.difference(new_nodes)
    if added_nodes:
        if 'add' not in diff:
            diff['add'] = {}
        diff['add']['nodes'] = [new_components[node] for node in sorted(added_nodes)]
    if deleted_nodes:
        if 'delete' not in diff:
            diff['delete'] = {}
        diff['delete']['nodes'] = [old_components[node] for node in sorted(deleted_nodes)]

    # Check edges
    old_edges = {(edge['src_id'], edge['dst_id']) for edge in old.get('edges') or []}
    new_edges = {(edge['src_id'], edge['dst_id']) for edge in new.get('edges') or []}
    added_edges = new_edges.difference(old_edges)
    deleted_edges = old_edges.difference(new_edges)
    if added_edges:
        if 'add' not in diff:
            diff['add'] = {}        
        diff['add']['edges'] = [new_components[edge] for edge in sorted(added_edges)]
    if deleted_edges:
        if 'delete' not in diff:
            diff['delete'] = {}        
        diff['delete']['edges'] = [old_components[edge] for edge in sorted(deleted_edges)]

    # Check attached nodes
    old_attached_nodes = {node_id for node_id in old.get('attached_nodes') or []}     
    new_attached_nodes = {node_id for node_id in new.get('attached_nodes') or []}
    added_attached_nodes = new_attached_nodes.difference(old_attached_nodes)
    deleted_attached_nodes = old_attached_nodes.difference(new_attached_nodes)
    if added_attached_nodes:
        if 'add' not in diff:
            diff['add'] = {}         
        diff['add']['attached_nodes'] = sorted(added_attached_nodes)
    if deleted_attached_nodes:
        if 'delete' not in diff:
            diff['delete'] = {}        
        diff['delete']['attached_nodes'] = sorted(deleted_attached_nodes)

    # Check property change
    if old_package_id != new_package_id:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['package'] = {
            'modify': [
                {'property': 'package_id', 'old_value': old_package_id, 'new_value': new_package_id}
            ]
        }
    same_nodes = old_nodes.intersection(new_nodes)
    modified_nodes = []
    for node in sorted(same_nodes):
        prop_diff = _property_diff(old_components[node], new_components[node])
        if prop_diff:
            node_diff = {'node_id': old_components[node]['node_id']}
            node_diff.update(prop_diff)
            modified_nodes.append(node_diff)
    if modified_nodes:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['nodes'] = modified_nodes

    
    modified_edges = []
    same_edges = old_edges.intersection(new_edges)
    for edge in sorted(same_edges):
        prop_diff = _property_diff(old_components[edge], new_components[edge])
        if prop_diff:
            edge_diff = {'src_id': old_components[edge]['src_id'], 'dst_id': old_components[edge]['dst_id']}
            edge_diff.update(prop_diff)
            modified_edges.append(edge_diff)
    if modified_edges:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['edges'] = modified_edges     

    return diff


def  rpdiff_to_graphviz(old: RulePackage | dict, new: RulePackage | dict) -> graphviz.graphs.Digraph:
    """
    Compare two rule packages.

    Parameters
    ----------
    old : RulePackage | dict
        Old rule package or json graph.
    new : RulePackage | dict
        New rule package or json graph. 

    Returns
    -------
    graphviz.graphs.Digraph
        A graph in graphviz dot language format to show changes (add, delete, modify) between two versions.
    """     
    diff = rpdiff(old, new)

    delete_color = 'lightgray'  # '#FFCCCC'
    add_color = 'blue'
    modify_color = 'red'

    # all_components are union of old and new components.
    all_nodes = old.get('nodes') or []
    all_edges = old.get('edges') or []
    all_attached_nodes = old.get('attached_nodes') or []
    color_map = {}
    if diff.get('add') is not None:
        if diff['add'].get('nodes') is not None:
            all_nodes = all_nodes + diff['add']['nodes']
            color_map.update({node['node_id']: add_color for node in diff['add']['nodes']})
        if diff['add'].get('edges') is not None:
            all_edges = all_edges + diff['add']['edges']
            color_map.update({(edge['src_id'], edge['dst_id']): add_color for edge in diff['add']['edges']})
        if diff['add'].get('attached_nodes') is not None:
            all_attached_nodes = all_attached_nodes + diff['add']['attached_nodes']
            color_map.update({(old['package_id'], node_id): add_color for node_id in diff['add']['attached_nodes']})

    if diff.get('delete') is not None:
        if diff['delete'].get('nodes') is not None:
            color_map.update({node['node_id']: delete_color for node in diff['delete']['nodes']})
        if diff['delete'].get('edges') is not None:
            color_map.update({(edge['src_id'], edge['dst_id']): delete_color for edge in diff['delete']['edges']})
        if diff['delete'].get('attached_nodes') is not None:
            color_map.update({(old['package_id'], edge['dst_id']): delete_color for edge in diff['delete']['attached_nodes']})

    if diff.get('modify') is not None:
        if diff['modify'].get('package') is not None:
            color_map.update({old['package_id']: modify_color})
        if diff['modify'].get('nodes') is not None:
            color_map.update({node['node_id']: modify_color for node in diff['modify']['nodes']})
        if diff['modify'].get('edges') is not None:
            color_map.update({(edge['src_id'], edge['dst_id']): modify_color for edge in diff['modify']['edges']})

    all_components = {}
    all_components.update({node['node_id']: node for node in all_nodes})
    all_components.update({(edge['src_id'], edge['dst_id']): edge for edge in all_edges})
    all_components.update({(old['package_id'], node_id): None for node_id in all_attached_nodes})

    # TODO: Find better way to display modified components.
    # new_components is a dict used only for displaying modified package and edges.
    new_components = {}
    new_components.update({node['node_id']: node for node in new.get('nodes') or []})
    new_components.update({(edge['src_id'], edge['dst_id']): edge for edge in new.get('edges') or []})
    new_components.update({(new['package_id'], node_id): None for node_id in new.get('attached_nodes') or []})    

    g = graphviz.Digraph(old['package_id'])
    g.attr(rankdir='LR')
    node_shapes = {
        'BigTableNode': 'cylinder',
        'ForkNode': 'point', 
        'TransformNode': 'rect', 
        'SelectNode': 'invtrapezium',
        'SwitchNode': 'switch', 
        'FlagNode': 'parallelogram', 
        'AuditNode': 'circle',
        'BranchNode': 'diamond'
    }
    nodes = {node_type: [] for node_type, node_shape in node_shapes.items()}

    for node in all_nodes:
        nodes[node['node_type']].append(node)

    edges = {}
    for edge in all_edges:
        if edges.get(edge['src_id']) is None:
            edges[edge['src_id']] = []
        edges[edge['src_id']].append(edge)

    g.attr('node', shape = 'folder')
    color = color_map.get(old['package_id'], 'black')
    if color == modify_color and old['package_id'] != new['package_id']:
        label = '<<s>{}</s> {}>'.format(html.escape(old['package_id']), html.escape(new['package_id']))
    else: 
        label = html.escape(old.get('name') if old.get('name') else old['package_id']) 
    g.node(old['package_id'], label=label, color=color, fontcolor=color)
    for node_type, node_list in nodes.items():
        shape = node_shapes[node_type]
        if shape == 'switch':
            g.attr('node', shape = 'record')
            for node in node_list:
                rows = []
                node_name = html.escape(node.get('name')) if node.get('name') else node['node_id']
                rows.append('<selector> {}'.format(node_name))
                idx = 0
                for edge in edges.get(node['node_id']) or []:
                    rows.append('<f{}> '.format(idx))
                    idx = idx + 1   
                label = '|'.join(rows)  # https://graphviz.org/Gallery/directed/datastruct.html
                color = color_map.get(node['node_id'], 'black')
                g.node(node['node_id'], label=label, color=color, fontcolor=color)
        else:
            g.attr('node', shape=shape)
            for node in node_list:
                #label = html.escape(node.get('name')) if node.get('name') else (node['node_id'] if node['node_type'] != 'FlagNode' else node['flag'])
                label = html.escape(node.get('name')) if node.get('name') else node['node_id']
                color = color_map.get(node['node_id'], 'black')
                g.node(node['node_id'], label=label, color=color, fontcolor=color) 

    for node_id in all_attached_nodes:
        dst = '{}:selector'.format(node_id) if all_components[node_id]['node_type'] == 'SwitchNode' else node_id    
        color = color_map.get((old['package_id'], node_id), 'black')
        g.edge(old['package_id'], dst, color=color, fontcolor=color)   
    for node_id, edge_list in edges.items():
        if all_components[node_id]['node_type'] == 'SwitchNode':
            idx = 0
            for edge in edge_list:
                dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                if edge.get('case') is not None:
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        new_case_or_default = new_edge.get('case') or 'default'
                        label = '<<s>{}</s> {}>'.format(html.escape(str(edge['case'])), html.escape(new_case_or_default)) 
                    else: 
                        label = html.escape(str(edge['case']))
                    g.edge('{}:f{}'.format(node_id, idx), dst, color=color, fontcolor=color, label=label)
                elif 'default' in edge:
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        new_case_or_default = new_edge.get('case') or 'default'
                        label = '<<s>default</s> {}>'.format(html.escape(new_case_or_default)) 
                    else: 
                        label = 'default'                    
                    g.edge('{}:f{}'.format(node_id, idx), dst, color=color, fontcolor=color, label=label)
                idx = idx + 1
        elif all_components[node_id]['node_type'] == 'BranchNode':
            for edge in edge_list:
                if edge.get('case') is not None:
                    dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        label = '<<s>{}</s> {}>'.format(edge['case'], new_edge['case']) 
                    else: 
                        label = str(edge['case'])                          
                    g.edge(node_id, dst, label=label, color=color, fontcolor=color)                        
        else:
            for edge in edge_list:
                dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                color = color_map.get((node_id, edge['dst_id']), 'black')              
                g.edge(node_id, dst, color=color, fontcolor=color)

    return g                              
