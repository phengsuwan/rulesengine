from datetime import datetime, date, timedelta


# Define DATE a subclass of date()
# https://stackoverflow.com/questions/66396017/inherit-python-datetime-and-add-new-attribute-for-the-instance-in-using-super
# obj is a date object or string in 'YYYY-MM-DD' format.
class DATE(date):
    
    # Don't try to override date.__new__() with different arguments. It's
    #   overly complicated and doesn't work.
    # Use __new__ instead of __init__ because date() is immutable object
    #def __new__(cls, obj):  
    #    if isinstance(obj, str): 
    #        d = date.fromisoformat(obj)
    #    elif isinstance(obj, date):
    #        d = obj
    #    else: 
    #        raise NotImplementedError("DATE requires date() or YYYY-MM-DD string")
    #
    #    return super().__new__(cls, d.year, d.month, d.day)
    
    @classmethod
    def from_string(cls, date_str):
        if isinstance(date_str, str):
            d = date.fromisoformat(date_str)
        else:
            raise NotImplementedError("DATE.from_string() requires YYYY-MM-DD string")

        return cls(d.year, d.month, d.day)
    
        
    # Support DATE + int and Date + timedelta()
    def __add__(self, other):
        if isinstance(other, int):
            other = timedelta(days=other)
        return super().__add__(other)
    
    
    # Support int + DATE and timedelta() + DATE
    __radd__ = __add__
    
            
    # Support DATE - int and Date - timedelta()
    def __sub__(self, other):
        if isinstance(other, int):
            other = timedelta(days=other)
        return super().__sub__(other)
            
