
# Should operator.add() be used instead?
# import operator
# operator.add(1, 2)
def ADD(op1, op2): 
    """
    Return op1 + op2.
    
    It provides operator + as a function. 
    
    Parameters
    ----------
    op1 : 
        Left operand.
    op2 : 
        Right operand.

    Returns
    -------
    The summation of left and right operands.
    """    
    return op1 + op2


def MUL(op1, op2): 
    """
    Return op1 * op2.
    
    It provides operator * as a function. 
    
    Parameters
    ----------
    op1 : 
        Left operand.
    op2 : 
        Right operand.

    Returns
    -------
    The summation of left and right operands.
    """    
    return op1 * op2
