from pyrengine.objectlist import OBJECTLIST
from pyrengine.objectlist import ARRAY
import decimal


# filter fields that contain array list and convert
# into OBJECTLIST object
def convert(input_json):
    fields_names = list(input_json.keys())
    for fn in fields_names:
        if type(input_json[fn]) is list : 
            if len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict :
                input_json[fn] = OBJECTLIST(input_json[fn])
            else: 
                input_json[fn] = ARRAY(input_json[fn])
    return input_json

# This is the previous version of convert
# def convert(input_json):
#     fields_names = list(input_json.keys())
#     for fn in fields_names:
#         if type(input_json[fn]) is list and len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict:
#             input_json[fn] = OBJECTLIST(input_json[fn])
#     return input_json


# Update the rule dict by *non-verbose* audit tree dict. The structure of rule dict and 
#   result dict are required to be compatible; otherwise an exception or unexpected outcome occurs.
# https://stackoverflow.com/questions/71396284/python-how-to-recursively-merge-2-dictionaries
def merge_rule_result(rule: dict, result: dict):
    for key, val in result.items():
        if key == "__result__":
            rule[key] = val
            continue

        if key in rule:
            if isinstance(val, dict):
                if not isinstance(rule[key], dict):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a dict".format(key))
                merge_rule_result(rule[key], val)
            elif isinstance(val, list):
                if not isinstance(rule[key], list):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a list".format(key))
                if len(val) != len(rule[key]):
                    raise Exception("The value of rule's key {} has different length than that of result".format(key))
                for i in range(len(val)):
                    if not isinstance(val[i], dict):
                        raise Exception("Expect element {} of result's key {} to be a dict".format(i, key))
                    if not isinstance(rule[key][i], dict):
                        raise Exception("Expect element {} of rule's key {} to be a dict".format(i, key))                
                    merge_rule_result(rule[key][i], val[i])
            else:
                pass # Skip other primitive values
        else:
            raise Exception('Unknown result key {}'.format(key))


def validate_by_example(obj: object, example: dict, deep = False, numeric_compatible=False) -> bool:
    """
    A helper function to validate data type of an input object. The structure of 
    the input object must be a superset of the example, i.e. having same or more keys with
    the exact same data type (not subclasses).

    Parameters
    ----------
    obj : object
        An input oject 
    example : dict
        An object prototype. 
    deep : bool, optional
        Recursively validate sub-structure too, by default False (Not implemented yet)
    numeric_compatible : bool, optional
        Allow int and float and decimal.Decimal values to be compatible, by default False

    Returns
    -------
    bool
        True if the input object has the same structure as least as the example.

    Raises
    ------
    NotImplementedError
        Not implemented yet. Future maybe.
    Exception
        Any error found.
    """    
    if deep:
        raise NotImplementedError('deep validation not support yet')
    
    if not isinstance(obj, dict):
        raise NotImplementedError('For now, obj argument must be a dict')
    
    for key in example:
        if key not in obj:
            raise Exception('Key {} not found in the obj'.format(key))
        
        if numeric_compatible and isinstance(example[key], (int, float, decimal.Decimal)) and isinstance(obj[key], (int, float, decimal.Decimal)):
            continue
        
        if type(obj[key]) != type(example[key]):
            raise Exception('The value of {} is of type {} but expected {}'.format(key, type(obj[key]).__name__, type(example[key]).__name__))
        
    return True