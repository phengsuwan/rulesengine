"""
Python Rule Engine API Reference

.. include:: ./documentation.md

"""
# Document for pdoc3
# https://github.com/pdoc3/pdoc/tree/master/doc
# https://github.com/pdoc3/pdoc/issues/233

# Disable pdoc3 document generating for these modules
__pdoc__ = {
    'compiler': False,
    'collection': False,
    'converter': False,
    'date': False,
    'ruleutils': False,
    'DDD': False,
    'where': False,
    'rulecontext': False,
    'verification': False,
}
