import fnmatch
from pyrengine.objectlist import ARRAY

def strConcat(a: str, b: str) -> str:
    """
    Concatenate two strings.

    Parameters
    ----------
    a: the first string
    b: the second string

    Returns
    -------
    str: the concatenated result of the two input strings

    Examples
    --------
    >>> strConcat("Hello, ", "world!")
    'Hello, world!'

    Profile
    -------
    ```{json}
    {
        "name": "strConcat", 
        "display_name": "Concat (string)",
        "description": "Concatenate two strings.", 
        "params" : [
            { "name" : "a" , "description" : "the first string" , "type" : ["string"]},
            { "name" : "b" , "description" : "the second string" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "string"
        }
    }
    ```
    """
    return str(a) + str(b)


def uppercase(a: str) -> str:
    """
    Convert a string to uppercase.

    Parameters
    ----------
    a: the string to convert

    Returns
    -------
    str: the uppercase version of the input string

    Examples
    --------
    >>> uppercase("hello")
    'HELLO'

    Profile
    -------
    ```{json}
    {
        "name": "uppercase", 
        "display_name": "Uppercase (string)",
        "description": "Convert a string to uppercase.", 
        "params" : [
            { "name" : "a" , "description" : "the string to convert" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "string"
        }
    }
    ```
    """
    return a.upper()


def lowercase(a: str) -> str:
    """
    Convert a string to lowercase.

    Parameters
    ----------
    a: the string to convert

    Returns
    -------
    str: the lowercase version of the input string

    Examples
    --------
    >>> lowercase("HELLO")
    'hello'

    Profile
    -------
    ```{json}
    {
        "name": "lowercase", 
        "display_name": "Lowercase (string)",
        "description": "Convert a string to lowercase.", 
        "params" : [
            { "name" : "a" , "description" : "the string to convert" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "string"
        }
    }
    ```
    """
    return a.lower()


def trim(a: str) -> str:
    """
    Remove leading and trailing whitespace from a string.

    Parameters
    ----------
    a: the string to strip

    Returns
    -------
    str: the string with leading and trailing whitespace removed

    Examples
    --------
    >>> trim("  hello  ")
    'hello'

    Profile
    -------
    ```{json}
    {
        "name": "trim", 
        "display_name": "Trim (string)",
        "description": "Remove leading and trailing whitespace from a string.", 
        "params" : [
            { "name" : "a" , "description" : "the string to strip" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "string"
        }
    }
    ```
    """
    return a.strip()


def left(a: str, n: int) -> str:
    """
    Extract the leftmost n characters from a string.

    Parameters
    ----------
    a: the string from which to extract
    n: the number of characters to extract from the left

    Returns
    -------
    str: the leftmost n characters of the input string

    Examples
    --------
    >>> left("hello", 3)
    'hel'

    Profile
    -------
    ```{json}
    {
        "name": "left", 
        "display_name": "Left (string)",
        "description": "Extract the leftmost n characters from a string.", 
        "params" : [
            { "name" : "a" , "description" : "the string from which to extract" , "type" : ["string"]},
            { "name" : "n" , "description" : "the number of characters to extract from the left" , "type" : ["integer"]}
        ],
        "return_type" : {
            "type" : "string"
        }
    }
    ```
    """
    return a[:n]


def right(a: str, n: int) -> str:
    """
    Extract the rightmost n characters from a string.

    Parameters
    ----------
    a: the string from which to extract
    n: the number of characters to extract from the right

    Returns
    -------
    str: the rightmost n characters of the input string

    Examples
    --------
    >>> right("hello", 3)
    'llo'

    Profile
    -------
    ```{json}
    {
        "name": "right", 
        "display_name": "Right (string)",
        "description": "tract the rightmost n characters from a string.", 
        "params" : [
            { "name" : "a" , "description" : "the string from which to extract" , "type" : ["string"]},
            { "name" : "n" , "description" : "the number of characters to extract from the right" , "type" : ["integer"]}
        ],
        "return_type" : {
            "type" : "string"
        }
    }
    ```
    """
    if n == 0:
        return ""
    return a[-n:]


def mid(a: str, start_n: int, num_chars: int):
    """
    Extract a substring from a text string, starting at a specified position and continuing for a specified number of characters

    Parameters
    ----------
    a: the string from which to extract
    start_n: the position in the text string where the extraction starts (The first character in the string is position 1)
    num_chars: the number of characters to extract from the text string

    Returns
    -------
    str: the substring from the start position to the stop position

    Examples
    --------
    >>> mid("hello world", 1, 5)
    'hello'

    Profile
    -------
    ```{json}
    {
        "name": "mid", 
        "display_name": "Mid (string)",
        "description": "Extract a substring from a text string, starting at a specified position and continuing for a specified number of characters", 
        "params" : [
            { "name" : "a" , "description" : "the string from which to extract" , "type" : ["string"]},
            { "name" : "start_n" , "description" : "the position in the text string where the extraction starts (The first character in the string is position 1)" , "type" : ["integer"]},
            { "name" : "num_chars" , "description" : "the number of characters to extract from the text string" , "type" : ["integer"]}
        ],
        "return_type" : {
            "type" : "string"
        }
    }
    ```
    """
    # Adjust indices for 0-based indexing
    if num_chars == 0 :
        return ""
    stop_n = start_n-1 + num_chars 
    return a[start_n-1:stop_n]


def strContains(a: str, b: str) -> bool:
    """
    Check if one string is contained within another.

    Parameters
    ----------
    a: the substring to search for
    b: the string to search within

    Returns
    -------
    bool: True if the substring is found within the string, False otherwise

    Examples
    --------
    >>> strContains("hello", "hello world")
    True
    >>> strContains("world", "hello")
    False

    Profile
    -------
    ```{json}
    {
        "name": "strContains", 
        "display_name": "Contains (string)",
        "description": "Check if one string is contained within another.", 
        "params" : [
            { "name" : "a" , "description" : "the substring to search for" , "type" : ["string"]},
            { "name" : "b" , "description" : "the string to search within" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "boolean"
        }
    }
    ```
    """
    return a in b


def match(a: str, pattern: str) -> bool:
    """
    Check if a string matches a pattern (ignoring case) with wildcard support.

    Parameters
    ----------
    a: the string to check
    pattern: the pattern with '*' for multiple characters and '?' for a single character

    Returns
    -------
    bool: True if the string matches the pattern, False otherwise

    Examples
    --------
    >>> match("hello", "h*o")
    True
    >>> match("hello", "h?llo")
    True
    >>> match("hello", "h*llo")
    True

    Profile
    -------
    ```{json}
    {
        "name": "match", 
        "display_name": "Match (string)",
        "description": "Check if a string matches a pattern (ignoring case) with wildcard support", 
        "params" : [
            { "name" : "a" , "description" : "the string to check" , "type" : ["string"]},
            { "name" : "pattern" , "description" : "the pattern with '*' for multiple characters and '?' for a single character" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "boolean"
        }
    }
    ```
    """

    return fnmatch.fnmatch(a.lower(), pattern.lower())



def strSplit(a:str,separator:str) -> ARRAY[str]:
    """
    Splits a string into a list of substrings based on a specified separator.

    Parameters
    ----------
    a: The string to be split
    separator: The separator used to split the string

    Returns
    -------
    ARRAY[str]: A list containing the substrings resulting from the split operation

    Examples
    --------
    >>> strSplit("apple,banana,cherry", ",")
    ARRAY(["apple", "banana", "cherry"])

    Profile
    -------
    ```{json}
    {
        "name": "strSplit", 
        "display_name": "Split (string)",
        "description": "Splits a string into a list of substrings based on a specified separator.", 
        "params": [
            { "name": "a", "description": "The string to be split", "type": ["string"]},
            { "name": "separator", "description": "The separator used to split the string", "type": ["string"]}
        ],
        "return_type": {
            "type": "list_string"
        }
    }
    ```
    """
    return ARRAY(a.split(separator))

########################################################################
### ARRAY
########################################################################

def checkStrArrayOverlap(a:ARRAY[str],b:ARRAY[str]) -> bool:
    """
    Checks if there is any overlap between two arrays of strings.

    Parameters
    ----------
    a: The first array of strings
    b: The second array of strings

    Returns
    -------
    bool: True if there is at least one common string between the two arrays, False otherwise

    Examples
    --------
    >>> checkStrArrayOverlap(ARRAY(["apple", "banana"]), ARRAY(["banana", "cherry"]))
    True

    >>> checkStrArrayOverlap(ARRAY(["apple", "banana"]), ARRAY(["cherry", "date"]))
    False

    Profile
    -------
    ```{json}
    {
        "name": "checkStrArrayOverlap", 
        "display_name": "Check String Array Overlap",
        "description": "Checks if there is any overlap between two arrays of strings.", 
        "params": [
            { "name": "a", "description": "The first array of strings", "type": ["list_string"]},
            { "name": "b", "description": "The second array of strings", "type": ["list_string"]}
        ],
        "return_type": {
            "type": "boolean"
        }
    }
    ```
    """
    return a.is_overlap(b)

def getStrArrayIntersect(a:ARRAY[str],b:ARRAY[str]) ->ARRAY[str]:
    """
    Computes the intersection of two arrays of strings, returning the common elements.

    Parameters
    ----------
    a: The first array of strings
    b: The second array of strings

    Returns
    -------
    ARRAY[str]: An array containing the strings that are present in both input arrays

    Examples
    --------
    >>> getStrArrayIntersect(ARRAY(["apple", "banana"]), ARRAY(["banana", "cherry"]))
    ARRAY(["banana"])

    >>> getStrArrayIntersect(ARRAY(["apple", "banana"]), ARRAY(["cherry", "date"]))
    ARRAY([])

    Profile
    -------
    ```{json}
    {
        "name": "getStrArrayIntersect", 
        "display_name": "Get String Array Intersection",
        "description": "Computes the intersection of two arrays of strings, returning the common elements.", 
        "params": [
            { "name": "a", "description": "The first array of strings", "type": ["list_string"]},
            { "name": "b", "description": "The second array of strings", "type": ["list_string"]}
        ],
        "return_type": {
            "type": "list_string"
        }
    }
    ```
    """
    return a.intersect(b)