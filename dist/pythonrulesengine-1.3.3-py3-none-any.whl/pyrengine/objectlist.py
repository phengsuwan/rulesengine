
# Worth reading:
#   https://stackoverflow.com/questions/972/adding-a-method-to-an-existing-object-instance-in-python
#   https://stackoverflow.com/questions/4698493/can-i-add-custom-methods-attributes-to-built-in-python-types

from __future__ import annotations # For forware reference
from typing import List, Union

from collections import OrderedDict 
import fnmatch
import json

from pyrengine.op import OP
from pyrengine.date import DATE
from pyrengine.where import parse_string

# Disable pdoc3 document generating for these classes/methods
__pdoc__ = {
    'ARRAY_FOR': False,
    'FILTERED_BY_COLUMN': False,
    'JOINED_OBJECTLIST_FOR': False,
    'OBJECTLIST.filter_by_column': False
}


# Intermediate class to support for all values in array
class ARRAY_FOR:
    """
    *Deprecated.* An internal class to iterate all objects in an ARRAY and check if `all` or `any` objects in ARRAY 
    satisfy a condition that follows. 
    
    Support simple standard operator <, <=, ==, !=, >=, >.
    It is instantiated by ARRAY.all() or ARRAY.any().
    >>> array = ARRAY([1, 2, 3, 4, 10])
    >>> array.all() # Return ARRAY_FOR.
    >>> array.any() # Return ARRAY_FOR

    Parameters
    ----------
    array : list
    quantifier : str, "all" or "any"
        `all` for all objects.
        `any` for any objects

    Operators
    ---------
    ```py
    <, <=, ==, !=, >=, > 
    ```
    
    Raises
    ------
    Exception
        Any errors cause exception.
        
    Examples
    --------
    >>> array = ARRAY([1, 2, 3, 4, 10])
    >>> array.all() > 10 # Return False
    >>> array.any() >= 10 # Return True
    >>> array.any() == 10 # Return True
    """         
    def __init__(self, array: list, quantifier: str):
        self.array = array
        if quantifier is None:
            raise Exception("ARRAY_FOR requires quantifier 'all' or 'any'")
        self.quantifier = quantifier
        
        if quantifier == "all": 
            self.func = all
        elif quantifier == "any":
            self.func = any
        else:
            raise Exception("ARRAY_FOR found unknown quantifier {}, only 'all' or 'any' are allowed".format(quantifier))
    
    def like(self, pattern: str) -> bool:
        """
        Check if `all` or `any` strings in ARRAY matches the pattern (ignoring case). Supports wildcard * and ? 
        
        Examples
        --------
        >>> array = ARRAY(['Z510', 'Z511'])
        >>> array.all().like('Z51*')
        >>> array.all().like('z51*')
        """        
        if not isinstance(pattern, str):
            raise NotImplementedError('Operator like() supports only string')
        return self.func([fnmatch.fnmatch(e.lower(), pattern.lower()) for e in self.array])
    
    def not_like(self, pattern: str) -> bool:
        """
        Check if `all` or `any` strings in ARRAY do not match the pattern (ignoring case). Supports wildcard * and ?.
         
        Examples
        --------
        >>> array = ARRAY(['Z510', 'Z511'])
        >>> array.all().not_like('Z51*')
        >>> array.all().not_like('z51*')
        """        
        if not isinstance(pattern, str):
            raise NotImplementedError('Operator like() supports only string')
        return not self.func([fnmatch.fnmatch(e.lower(), pattern.lower()) for e in self.array])

    # supported_operators() is used for pdoc3 to create documentation for supported operators.
    def supported_operators():
        """
        Supported operators are
        ```py
        <, <=, ==, !=, >=, > 
        ```
        Examples
        --------
        >>> array = ARRAY([1, 2, 3, 4, 10])
        >>> array.all() > 10 # Return False
        >>> array.any() >= 10 # Return True
        >>> array.any() == 10 # Return True
        """        
        return ['<', '<=', '==', '!=', '>=', '>']
    
    ###############################################
    #  Support standard math comparison operators #
    ###############################################
    # https://docs.python.org/3/library/operator.html    
    def __lt__(self, other: Union[int, float]): 
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator <= supports only int or float')
        return self.func([e <= other for e in self.array])
    
    def __le__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator < supports only int or float')
        return self.func([e < other for e in self.array])
    
    def __eq__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator == supports only int or float')
        return self.func([e == other for e in self.array])
    
    def __ne__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator != supports only int or float')
        return self.func([e != other for e in self.array])
    
    def __ge__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator >= supports only int or float')
        return self.func([e >= other for e in self.array])
    
    def __gt__(self, other: Union[int, float]):
        if not isinstance(other, (int, float)):
            raise NotImplementedError('Operator > supports only int or float')
        return self.func([e > other for e in self.array])
    
    def __str__(self):
        return 'ARRAY_FOR({})'.format(self.quantifier)  

    def __repr__(self):
        return 'ARRAY_FOR({})'.format(self.quantifier)      
    

# Extended list, so it inherits methods from list.
class ARRAY(list):
    """
    ARRAY is an extended version of python list. 
    
    Additional methods to operate with list are added.

    Examples
    --------
    >>> ARRAY([1, 2, 3])
    >>> ARRAY(["a", "b", "c"])
    >>> array = ARRAY([1, 2, 3, 4, 1, 2])
    """    

    def get(self, index: int) -> object:
        """
        Return an object at position `index`.
        
        Parameters
        ----------
        index : int
            Position starting at 0.

        Returns
        -------
        object
            An object in the ARRAY.
            
        Examples
        --------
        >>> array.get(1) # is as same as array[1]
        """        
        return self[index]
    
    def sum(self) -> Union[int, float]:
        """
        Return summation of all objects in the ARRAY, assuming that they can be added.
        
        Returns
        -------
        int or float
            Summation value 
            
        Examples
        --------
        >>> array.sum() 
        """         
        return sum(self)
    
    def count(self) -> int:
        """
        Return the number of objects in the ARRAY.

        Returns
        -------
        int
            The number of objects in the ARRAY.
            
        Examples
        --------
        >>> array.count()
        """        
        return len(self)
    
    def count_distinct(self) -> int:
        """
        Return the number of distinct objects in the ARRAY.

        Returns
        -------
        int
            The number of distinct objects in the ARRAY.
            
        Examples
        --------
        >>> array.count_distinct()
        """              
        return len(set(self))
    
    def distinct(self) -> ARRAY:
        """
        Return a new ARRAY without duplicated objects.

        Returns
        -------
        ARRAY
            A new ARRAY without duplicated objects.
            
        Examples
        --------
        >>> array.distinct()
        [1, 2, 3, 4]    
        """        
        return ARRAY(list(OrderedDict.fromkeys(self))) 

    def exclude(self, other: list) -> ARRAY:
        """
        Return a new ARRAY with all objects not in the other list, dupliction allowed. 
        
        Parameters
        ----------
        other : ARRAY or list
        """        
        return ARRAY([e for e in self if e not in other])
    
    def intersect(self, other: list) -> ARRAY:
        """
        Return a new ARRAY with common objects from both list, no duplication, order not preserved.

        Parameters
        ----------
        other : ARRAY or list
        """        
        return ARRAY(set(self).intersection(set(other)))

    def union(self, other: list) -> ARRAY:
        """
        Return a new ARRAY with all objects from both list, no duplication.

        Parameters
        ----------
        other : ARRAY or list
        """        
        result = OrderedDict.fromkeys(self)
        result.update(OrderedDict.fromkeys(other))
        return ARRAY(list(result))
    
    def union_all(self, other: list) -> ARRAY:
        """
        Return a new ARRAY with all objects from both list, duplication allowed. 
        As same as ARRAY1 + ARRAY2.

        Parameters
        ----------
        other : ARRAY or list
        """        
        return ARRAY(self + other)
    
    def all(self) -> bool:
        """
        Return True if all elements of the ARRAY can be evaluated to True; otherwise False.

        Examples
        --------
        >>> ARRAY([True, True, False]).all()
        False
        >>> ARRAY([1, 3, 2]).all()
        True
        """        
        return all(self)
    
    def any(self) -> bool:
        """
        Return True if any elements of the ARRAY can be evaluated to True; otherwise False.

        Examples
        --------
        >>> ARRAY([True, True, False]).any()
        True
        >>> ARRAY([0, 0, 0]).any()
        False
        """    
        return any(self)
    
    def contains(self, o: object) -> bool:
        """
        Return True if an object is in this ARRAY; otherwise False.

        The following expressions are the same.
        >>> 1 in ARRAY([1, 2, 3])
        >>> ARRAY([1, 2, 3]).contains(1)

        Parameters
        ----------
        other : object
        """          
        return o in self

    def not_contains(self, o: object) -> bool:
        """
        Return True if an object is not in this ARRAY; otherwise False.

        The following expressions are the same.
        >>> 1 not in ARRAY([1, 2, 3])
        >>> ARRAY([1, 2, 3]).not_contains(1)

        Parameters
        ----------
        other : object
        """          
        return not self.contains(o)    

    # If other is empty, always return False
    def is_overlap(self, other: list) -> bool:
        """
        Return True if there exists an object in this ARRAY and in the other list too; otherwise False.

        Parameters
        ----------
        other : ARRAY or list
        """         
        if not isinstance(other, list):
            raise Exception('ARRAY.is_overlap() requires a list argument')
        return len(set(self).intersection(set(other))) > 0
    
    def is_not_overlap(self, other: list) -> bool:
        """
        Return True if no object in this ARRAY appears to be in the other list; otherwise False.

        Parameters
        ----------
        other : ARRAY or list
        """             
        return not self.is_overlap(other)

    def lt(self, operand: Union[int, float]) -> ARRAY:
        """
        For each element *e* in ARRAY, check if *e* is less than (<) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """        
        if not isinstance(operand, (int, float)):
            raise NotImplementedError('Operator <= supports only int or float')
        return ARRAY([e <= operand for e in self])
    
    def le(self, operand: Union[int, float]):
        """
        For each element *e* in ARRAY, check if *e* is less than or equal to (<=) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """             
        if not isinstance(operand, (int, float)):
            raise NotImplementedError('Operator < supports only int or float')
        return ARRAY([e < operand for e in self])
    
    def eq(self, operand: Union[int, float, str]):
        """
        For each element *e* in ARRAY, check if *e* is equal to (==) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """         
        if not isinstance(operand, (int, float, str)):
            raise NotImplementedError('Operator == supports only int or float or str')
        return ARRAY([e == operand for e in self])
    
    def neq(self, operand: Union[int, float, str]):
        """
        For each element *e* in ARRAY, check if *e* is not equal to (!=) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """        
        if not isinstance(operand, (int, float, str)):
            raise NotImplementedError('Operator != supports only int or float or str')
        return ARRAY([e != operand for e in self])
    
    def ge(self, operand: Union[int, float]):
        """
        For each element *e* in ARRAY, check if *e* is greater than or equal to (>=) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """        
        if not isinstance(operand, (int, float)):
            raise NotImplementedError('Operator >= supports only int or float')
        return ARRAY([e >= operand for e in self])
    
    def gt(self, operand: Union[int, float]):
        """
        For each element *e* in ARRAY, check if *e* is greater than (>) the operand. 

        Returns
        -------
        ARRAY
            ARRAY of True/False

        Raises
        ------
        NotImplementedError
            Some usages are not supported.
        """        
        if not isinstance(operand, (int, float)):
            raise NotImplementedError('Operator > supports only int or float')
        return ARRAY([e > operand for e in self])

    def like(self, pattern: str) -> ARRAY:        
        """
        For each element *e* in ARRAY, check if *e* is a string and matches the pattern (ignoring case). Supports wildcard * and ?. 

        Parameters
        ----------
        pattern : str
            Pattern string with wildcard * and ?. 
            Wildcard * matches any number of characters or none.
            Wildcard ? matches at most one character. 

        Returns
        -------
        ARRAY
            ARRAY of True/False.

        Raises
        ------
        Exception
            Any errors cause exception.            

        Examples
        --------
        >>> array = ARRAY(['Z510', 'Z511'])
        >>> array.like('Z51*')
        >>> array.like('z51*')
        """        
        if not isinstance(pattern, str):
            raise Exception('Method like() requires pattern argument to be a string.')
        if not all([isinstance(e, str) for e in self]):
            raise Exception("Method like() supports only string elements.")
        return ARRAY([fnmatch.fnmatch(e.lower(), pattern.lower()) for e in self])
    
    def not_like(self, pattern: str) -> bool:
        """
        For each element *e* in ARRAY, check if *e* is a string and does not match the pattern (ignoring case). Supports wildcard * and ?. 

        Parameters
        ----------
        pattern : str
            Pattern string with wildcard * and ?. 
            Wildcard * matches any number of characters or none.
            Wildcard ? matches at most one character. 

        Returns
        -------
        ARRAY
            ARRAY of True/False.

        Raises
        ------
        Exception
            Any errors cause exception.            

        Examples
        --------
        >>> array = ARRAY(['Z510', 'Z511'])
        >>> array.not_like('Z51*')
        >>> array.not_like('z51*')
        """            
        if not isinstance(pattern, str):
            raise Exception('Method not_like() requires pattern argument to be a string.')
        if not all([isinstance(e, str) for e in self]):
            raise Exception("Method not_like() supports only string elements.")
        return ARRAY([not fnmatch.fnmatch(e.lower(), pattern.lower()) for e in self])
    
    def sort(self, reverse:bool = False) -> ARRAY:
        """
        Return a new ARRAY with elements are sorted.

        Parameters
        ----------
        reverse : bool, default = False
            If True, elements are sorted in descending order.

        """
        return ARRAY(sorted(self, reverse=reverse))        
    
    def to_date(self) -> ARRAY[DATE]:
        """
        Return a new ARRAY with all string elements are converted to DATE.

        Raises
        ------
        Exception
            If any elements are not string in ISO format (YYYY-MM-DD).
      
        """
        if not all([isinstance(e, str) for e in self]):
            raise Exception("Method to_DATE() requires all elements are string.")
        return ARRAY([DATE.from_string(e) for e in self])   
    
    def to_list(self) -> list:
        """
        Return a list of all elements from this ARRAY.

        """
        return list(self)   

    def date_diff(self) -> ARRAY[int]:
        """
        Return numbers of days different between two consecutive elements in a DATE ARRAY.

        Raises
        ------
        Exception
            If any elements are not DATE objects.
            
        Examples
        --------
        >>> array = ARRAY(['2023-01-01', '2023-01-03', '2023-01-03', '2023-02-01'])
        >>> array.to_date().date_diff()
        ARRAY([2, 0, 29])
       
        """        
        if not all([isinstance(e, DATE) for e in self]):
            raise Exception("Method date_diff() requires all elements are DATE objects.")
                
        return ARRAY([(j-i).days for i, j in zip(self, self[1:])] )
    
    # Disable __str__() as the superclass list.__str__() eventually calls __repr__(), making double keywords ARRAY prepended to the string.
    #def __str__(self) -> str:
    #    return 'ARRAY({})'.format(super().__str__())
    
    def __repr__(self) -> str:
        return 'ARRAY({})'.format(super().__repr__())    
    

# Obsoleted
# Return OBJECTLIST
class FILTERED_BY_COLUMN:
    def __init__(self, data, column):
        self.data = data
        self.column = column
        
    # Cannot use 'in' since it is a reserved word.
    def is_in(self, arr):
        return OBJECTLIST(list(filter(lambda o: o.get(self.column) in arr, self.data)))
        
    def not_in(self, arr):
        return OBJECTLIST(list(filter(lambda o: o.get(self.column) not in arr, self.data)))

    def __str__(self):
        return 'FILTERED_BY_COLUMN(' + str(self.data) + ', ' + self.column + ')'  

# Return OBJECTLIST
class GROUPBY:
    """
    A group of objects that share the same column value(s). 
    
    An internal representation of GROUPBY is a dict where a key is a tuple and a value is a list of objects.
    Each key consists of one or many tuples of column name and value.
    Each object in the list is an object encoded as a dict.
    It is instantiated by `OBJECTLIST.group_by()`.
    
    For example, given a GROUPBY
    ```
    {(('id', '001'), ('name', 'john')): [obj1, obj2, ...], (('id', '002'), ('name', 'mary')): [obj10, obj11, ...]}
    ```
    The first group has id = 001 and name = john. Since obj1 and obj2 are in this group, both of them have these values. 
    The second group has id = 002 and name = mary. obj10 and obj11 are in the second group.
    
    Raises
    ------
    Exception
        Any errors cause exception.
    NotImplementedError
        Some usages are not supported.
    """    
    def __init__(self, data: dict[tuple[tuple], list[object]]):
        self.data = data
        for k, v in self.data.items():
            if not isinstance(k, tuple):
                raise Exception('GROUPBY requires dict key to be a tuple of tuples')
            for t in k:
                if not isinstance(t, tuple):
                    raise Exception('GROUPBY requires dict key to be a tuple of tuples')
            if not isinstance(v, list):
                raise Exception('GROUPBY requires dict value to be a list of object')
        
    def count(self, column: str = None) -> OBJECTLIST:
        """
        Return the number of objects in each group.

        Parameters
        ----------
        column : str, default = None
            Column of object to count.  If None, count all objects. 
            If a string, count only objects with the column. 
            If such column is missing from some objects, count() will exclude those objects. 

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST where each object has only group_by columns and count column.

        Raises
        ------
        NotImplementedError
            Some usages are unsupported.
            
        Examples
        --------
        >>> objectlist.group_by(["id", "name"]).count('name')
        [{"id": "001", "name": "john", "count": 2}, {"id": "002", "name": "many", "count": 4} ]
        
        """   
        
        if column is not None and not isinstance(column, str):
            raise NotImplementedError('GROUPBY.count() supports at most one column only.')        
        
        new_objects = []
        for k, v in self.data.items():
            new_object = {}
            for t in k: 
                new_object[t[0]] = t[1]
            if column is None:
                new_object['count'] = len(v)
            else:
                new_object['count'] = sum([1 for obj in v if column in obj])
            new_objects.append(new_object)
                
        return OBJECTLIST(new_objects)

    def sum(self, column: str) -> OBJECTLIST:
        """
        Return the summation of values in a specfied column of all objects in each group.

        Parameters
        ----------
        column : str
            Column name of objects for summation.

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST where each object has only group_by columns and sum column.

        Raises
        ------
        NotImplementedError
            Some usages are unsupported.
            
        Examples
        --------
        >>> groupby.sum('amount')
        [{"id": "001", "name": "john", "sum": 100000}, {"id": "002", "name": "many", "sum": 200000} ]
        
        """        
        if not isinstance(column, str):
            raise NotImplementedError('GROUPBY.sum() requires single column only.')
        
        new_objects = []
        for k, v in self.data.items():
            new_object = {}
            for t in k: 
                new_object[t[0]] = t[1]
            new_object['sum'] = sum([obj[column] for obj in v if column in obj])
            new_objects.append(new_object)
                
        return OBJECTLIST(new_objects)    
    
    def __str__(self) -> str:
        return 'GROUPBY({})'.format(self.data)
    
    def to_string(self) -> str:
        """
        Return the string of GROUPBY object in tabular format.

        Returns
        -------
        str
            The string of GROUPBY object in tabular format.

        Examples
        --------
        >>> ol = OBJECTLIST([{"name": "John", "age": 37, "salary": 10000}, {"name": "Mary", "age": 42, "salary": 30000}])
        >>> print(ol.group_by('name').to_string())
        GROUPBY({
            (('name', 'John'),): [{'name': 'John', 'age': 37, 'salary': 10000}]
            (('name', 'Mary'),): [{'name': 'Mary', 'age': 42, 'salary': 30000}]
        })
        """                
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join(['{}: {}'.format(k, v) for k, v in self.data.items()]))
        else:
            table = ''
        return 'GROUPBY({{{}}})'.format(table) # {{ and }} are the escaped characters { and }.      
    
    def __repr__(self) -> str:
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join(['{}: {}'.format(repr(k),repr(v)) for k, v in self.data.items()]))
        else:
            table = ''        
        return 'GROUPBY({{{}}})'.format(table) # {{ and }} are the escaped characters { and }.


class JOINED_OBJECTLIST_FOR:
    """
    *Deprecated." An internal class to iterate all joined objects in the JOINED_OBJECTLIST and check if `all` or `any` joined
      objects satisfy a condition that follows. 
    
    It is instantiated by JOINED_OBJECTLIST.all() or JOINED_OBJECTLIST.any().
    >>> array.all() # Return JOINED_OBJECTLIST_FOR.
    >>> array.any() # Return JOINED_OBJECTLIST_FOR    

    Parameters
    ----------
    data : JOINED_OBJECTLIST
        
    quantifier : str, "all" or "any"
        `all` for all joined objects.
        `any` for any joined objects

    Raises
    ------
    Exception
        Any errors cause exception.
    """         
    def __init__(self, data: JOINED_OBJECTLIST, quantifier: str):
        self.data = data
        if quantifier is None:
            raise Exception("JOINED_OBJECTLIST_FOR requires quantifier 'all' or 'any'")
        self.quantifier = quantifier
        
        if quantifier == "all": 
            self.func = all
        elif quantifier == "any":
            self.func = any
        else:
            raise Exception("JOINED_OBJECTLIST_FOR found unknown quantifier {}, only 'all' or 'any' are allowed".format(quantifier))

    def check_if(self, l_column: str, operator: Union[OP, str], r_column: str) -> bool:
        """
        Return True/False after checking if the joined objects in the JOINED_OBJECTLIST pass the condition.
        
        For `all`, return True if all joined objects pass the condition; otherwise False.
        For `any`, return True if any joined objects pass the condition; otherwise False. 

        Parameters
        ----------
        l_column : str
            Column name of the left object to compare.
        operator : Union[OP, str]
            An operator to compare columns of the left and right objects. See `pyrengine.op.OP`.
        r_column : str
            Column name of the right object to compare.

        Returns
        -------
        bool
            True or False

        Raises
        ------
        Exception
            Any errors cause exception.
        NotImplementedError
            Unsupported operation or Parameters.
            
        Examples
        --------
        >>> objectlist1 = OBJECTLIST([{"code": "001", "amount": 1000}, {"code": "001", "amount": 2000}, {"code": "002", "amount": 3000}])
        >>> objectlist2 = OBJECTLIST([{"code": "001", "max_amount": 2000}, {"code": "002", "max_amount": 3000}])
        >>> objectlist1.inner_join(objectlist2, "code")
        [(('001',), ({'code': '001', 'amount': 1000}, {'code': '001', 'max_amount': 2000})), (('001',), ({'code': '001', 'amount': 2000}, {'code': '001', 'max_amount': 2000})), (('002',), ({'code': '002', 'amount': 3000}, {'code': '002', 'max_amount': 3000}))]
    
        >>> objectlist1.inner_join(objectlist2, "code").all().check_if("amount", "gt", "max_amount")
        False 
        """ 
               
        if not isinstance(l_column, str):
            raise Exception("check_if() l_column requires string")
        
        if not isinstance(r_column, str):
            raise Exception("check_if() r_column requires string")

        if isinstance(operator, str):
            try:
                operator = OP[operator]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator {} in check_if()'.format(operator)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred
                
        # TODO: Type checking for each operator, e.g. gt needs both operands have the same type 
        results = []
        for joined_objects in self.data:
            keys = joined_objects[0]
            v = joined_objects[1]
            result = None

            if l_column not in v[0]:
                raise Exception('Column {} not found in left OBJECTLIST {}'.format(l_column, v[0]))
            
            if v[1] is not None and r_column in v[1]:
                if operator in (OP.gt, OP['>']):
                    result = (v[0][l_column] is not None and v[1][r_column] is not None and v[0][l_column] > v[1][r_column])
                elif operator in (OP.ge, OP['>=']):
                    result = (v[0][l_column] is not None and v[1][r_column] is not None and v[0][l_column] >= v[1][r_column])
                elif operator in (OP.eq, OP['=']):
                    result = (v[0][l_column] == v[1][r_column])
                elif operator in (OP.neq, OP['<>']):
                    result = (v[0][l_column] != v[1][r_column])
                elif operator in (OP.lt, OP['<']):
                    result = (v[0][l_column] is not None and v[1][r_column] is not None and v[0][l_column] < v[1][r_column])
                elif operator in (OP.le, OP['<=']):
                    result = (v[0][l_column] is not None and v[1][r_column] is not None and v[0][l_column] <= v[1][r_column])
                elif operator in (OP.is_in, OP.is_not_in):
                    switch = False if operator == OP.is_in else True  # It is used for XOR (^) 
                    if isinstance(v[1][r_column], list):
                        result =  ((v[0][l_column] in v[1][r_column]) ^ switch)
                    else:
                        raise NotImplementedError('{} not supported by {} operator check_if() is_in/is_not_in where'.format(type(v[1][r_column]), operator.name))
                elif operator in (OP.like, OP.not_like):
                    switch = False if operator == OP.like else True  # It is used for XOR (^)
                    result (fnmatch.fnmatch(v[0][l_column].lower(), v[1][r_column].lower()) ^ switch)
                else:
                    raise NotImplementedError('Unknown operator {} in check_if()'.format(operator))
            
            results.append(result)

        return self.func(results)
    
    def __str__(self) -> str:
        return 'JOINED_OBJECTLIST_FOR({})'.format(self.quantifier)
    
    def __repr__(self) -> str:
        return 'JOINED_OBJECTLIST_FOR({})'.format(self.quantifier)    
    

class JOINED_OBJECTLIST:
    """
    A list of joined objects where each element is a tuple of joined keys and a pair of objects.
    
    The matching keys are a tuple. A pair of objects is also a tuple. Left object comes from one OBJECTLIST.
    Right object comes from another OBJECTLIST. Right object could be None if left_join().
    The key of all elements of the JOINED_OBJECTLIST is not necessary to be unique as we can join one object to multiple objects having the same joined key.
    A JOINED_OBJECTLIST looks like.
    ```
    [
        ((key1, key2), (left_object1, right_object1)) 
        ((key3, key4), (left_object2, right_object2))
    ]
    ```
    
    Parameters
    ----------
    data : list of tuples that represents joined objects.
    
    Examples
    --------
    >>> objectlist1 = OBJECTLIST([{"code": "001", "amount": 1000}, {"code": "001", "amount": 2000}, {"code": "002", "amount": 3000}])
    >>> objectlist2 = OBJECTLIST([{"code": "001", "max_amount": 2000}, {"code": "002", "max_amount": 3000}])
    >>> objectlist1.inner_join(objectlist2, "code")
    JOINED_OBJECTLIST([
        (('001',), ({'code': '001', 'amount': 1000}, {'code': '001', 'max_amount': 2000}))
        (('001',), ({'code': '001', 'amount': 2000}, {'code': '001', 'max_amount': 2000}))
        (('002',), ({'code': '002', 'amount': 3000}, {'code': '002', 'max_amount': 3000}))
    ])
    >>> objectlist1.inner_join(objectlist2, "code").where('amount', 'lt', 'max_amount')  
    JOINED_OBJECTLIST([
        (('001',), ({'code': '001', 'amount': 1000}, {'code': '001', 'max_amount': 2000}))
    ])
    """
    def __init__(self, data):
        self.data = data

    def select(self, column: Union[str, list]) -> Union[ARRAY, OBJECTLIST]:
        """
        Return an ARRAY of values of the selected column, including NULL (None).
        Or return an OBJECTLIST for a list of selected columns.
                
        Parameters
        ----------
        column : str or list
            Column name of the left object if exists or right object, or list of column names.            

        Returns
        -------
        ARRAY or OBJECTLIST
            ARRAY of values of the selected column, or OBJECTLIST for list of selected columns.            

        Raises
        ------
        Exception
            If an error occurs.                  
            
        Examples
        --------
        >>> objectlist1.inner_join(objectlist2, "code").select("amount")
        ARRAY([1000, 2000, 3000])
        >>> objectlist1.inner_join(objectlist2, "code").select(["code", "amount"])
        OBJECTLIST([
            {'code': '001', 'amount': 1000}
            {'code': '001', 'amount': 2000}
            {'code': '002', 'amount': 3000}
        ])
        """        
       
        results = []
        if isinstance(column, str):
            for joined_objects in self.data:
                keys = joined_objects[0]
                v = joined_objects[1]            
                if column in v[0]:
                    results.append(v[0][column])
                elif v[1] and column in v[1]:
                    results.append(v[1][column])
                else:
                    results.append(None)
            return ARRAY(results)
        elif isinstance(column, list): 
            for joined_objects in self.data:
                keys = joined_objects[0]
                v = joined_objects[1]
                d = {}
                for c in column:            
                    if c in v[0]:
                        d[c] = v[0][c]
                    elif v[1] and c in v[1]:
                        d[c] = v[1][c]
                    else:
                        d[c] = None  
                results.append(d)          
            return OBJECTLIST(results)
        else:
            raise Exception("Unsupported type {} in select()".format(type(column))) 
        

    def check_if(self, l_column: str, operator: Union[OP, str], r_column: str) -> ARRAY:
        """
        For each pair of left and right objects in the JOINED_OBJECTLIST, 
        compare left object to the right with the specified condition.
        
        Parameters
        ----------
        l_column : str
            Column name of the left object to compare.
        operator : Union[OP, str]
            An operator to compare columns of the left and right objects. See `pyrengine.op.OP`.
        r_column : str
            Column name of the right object to compare.

        Returns
        -------
        ARRAY
            ARRAY of True/False 

        Raises
        ------
        Exception
            Any errors cause exception.
        NotImplementedError
            Unsupported operation or Parameters.
            
        Examples
        --------
        >>> objectlist1.inner_join(objectlist2, "code").check_if("amount", "gt", "max_amount")
        ARRAY([False, False, False])
        """ 
               
        if not isinstance(l_column, str):
            raise Exception("check_if() l_column requires string")
        
        if not isinstance(r_column, str):
            raise Exception("check_if() r_column requires string")

        if isinstance(operator, str):
            try:
                operator = OP[operator]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator {} in check_if()'.format(operator)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred
                
        # TODO: Type checking for each operator, e.g. gt needs both operands have the same type 
        results = []
        for joined_objects in self.data:
            keys = joined_objects[0]
            v = joined_objects[1]
            result = None

            if l_column not in v[0]:
                raise Exception('Column {} not found in left OBJECTLIST {}'.format(l_column, v[0]))
            
            if v[1] is not None and r_column in v[1]:
                if operator in (OP.gt, OP['>']):
                    result = (v[0][l_column] is not None and v[1][r_column] is not None and v[0][l_column] > v[1][r_column])
                elif operator in (OP.ge, OP['>=']):
                    result = (v[0][l_column] is not None and v[1][r_column] is not None and v[0][l_column] >= v[1][r_column])
                elif operator in (OP.eq, OP['=']):
                    result = (v[0][l_column] == v[1][r_column])
                elif operator in (OP.neq, OP['<>']):
                    result = (v[0][l_column] != v[1][r_column])
                elif operator in (OP.lt, OP['<']):
                    result = (v[0][l_column] is not None and v[1][r_column] is not None and v[0][l_column] < v[1][r_column])
                elif operator in (OP.le, OP['<=']):
                    result = (v[0][l_column] is not None and v[1][r_column] is not None and v[0][l_column] <= v[1][r_column])
                elif operator in (OP.is_in, OP.is_not_in):
                    switch = False if operator == OP.is_in else True  # It is used for XOR (^) 
                    if isinstance(v[1][r_column], list):
                        result = ((v[0][l_column] in v[1][r_column]) ^ switch)
                    else:
                        raise NotImplementedError('{} not supported by {} operator check_if() is_in/is_not_in where'.format(type(v[1][r_column]), operator.name))
                elif operator in (OP.like, OP.not_like):
                    switch = False if operator == OP.like else True  # It is used for XOR (^)
                    result = (fnmatch.fnmatch(v[0][l_column].lower(), v[1][r_column].lower()) ^ switch)
                else:
                    raise NotImplementedError('Unknown operator {} in check_if()'.format(operator))
            
            results.append(result)

        return ARRAY(results)
    
    def count_if(self, l_column: str, operator: Union[OP, str], r_column: str) -> int:
        """
        Return the number of joined objects in the JOINED_OBJECTLIST that pass the condition.
        
        Parameters
        ----------
        l_column : str
            Column name of the left object to compare.
        operator : Union[OP, str]
            An operator to compare columns of the left and right objects. See `pyrengine.op.OP`.
        r_column : str
            Column name of the right object to compare.

        Returns
        -------
        int
            The number of joined objects that pass the condition.

        Raises
        ------
        Exception
            Any errors cause exception.
        NotImplementedError
            Unsupported operation or Parameters.
            
        Examples
        --------
        >>> objectlist1.inner_join(objectlist2, "code").count_if("amount", "gt", "max_amount")
        0 
        """     
        return sum([e for e in self.check_if(l_column, operator, r_column) if e is not None])
    

    def where(self, l_column: str, operator: Union[OP, str], r_column: str) -> JOINED_OBJECTLIST:
        """
        For each pair of left and right objects in the JOINED_OBJECTLIST, 
        return JOINED_OBJECTLIST that the left object and the right pass the specified condition.
        
        Parameters
        ----------
        l_column : str
            Column name of the left object to compare.
        operator : Union[OP, str]
            An operator to compare columns of the left and right objects. See `pyrengine.op.OP`.
        r_column : str
            Column name of the right object to compare.

        Returns
        -------
        JOINED_OBJECTLIST
            JOINED_OBJECTLIST that the left object and the right pass the specified condition.

        Raises
        ------
        Exception
            Any errors cause exception.
        NotImplementedError
            Unsupported operation or Parameters.
            
        Examples
        --------
        >>> objectlist1.inner_join(objectlist2, "code").where("amount", "gt", "max_amount")
        
        """ 
               
        results = [e[1] for e in zip(self.check_if(l_column, operator, r_column), self.data) if e[0]]

        return JOINED_OBJECTLIST(results)    

    def __str__(self) -> str:
        return 'JOINED_OBJECTLIST({})'.format(self.data)
    
    def to_string(self) -> str:
        """
        Return the string of JOINED_OBJECTLIST in tabular format.

        Returns
        -------
        str
            The string of JOINED_OBJECTLIST in tabular format.

        Examples
        --------
        >>> print(objectlist1.inner_join(objectlist2, "code").to_string())
        JOINED_OBJECTLIST([
            (('001',), ({'code': '001', 'amount': 1000}, {'code': '001', 'max_amount': 2000}))
            (('001',), ({'code': '001', 'amount': 2000}, {'code': '001', 'max_amount': 2000}))
            (('002',), ({'code': '002', 'amount': 3000}, {'code': '002', 'max_amount': 3000}))
        ])
        """               
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([str(o) for o in self.data]))
        else:
            table = ''
        return 'JOINED_OBJECTLIST([{}])'.format(table)        

    def __repr__(self) -> str:
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([repr(o) for o in self.data]))
        else:
            table = ''        
        return 'JOINED_OBJECTLIST([{}])'.format(table)
    

# Some methods return a primitive. Others return a new ARRAY or OBJECTLIST 
class OBJECTLIST:
    """
    OBJECTLIST represents a list of objects. Each object is encoded as a python dict.
    An OBJECTLIST can be viewed as a small table with rows and columns.
    Each object is represented by a row and the object attributes by columns.
    The data type of an attribute is expected to be primitive.

    Although the OBJECTLIST allows non-primitive data type, e.g. list or ARRAY, many methods cannot 
    work for non-primitive attributes such as distinct() or union(). 
    These methods currently require 'flat' objects which be hashed, thus, it is not true if data type is not primitive.

    Parameters
    ----------
    data : list[dict]
        A list of objects 
    
    allow_duplication : bool, default=True
        When creating an OBJECTLIST, check if there exist any duplicate objects.

    Examples
    --------
    >>> ol = OBJECTLIST([{"name": "John", "age": 37, "salary": 10000}, {"name": "Mary", "age": 42, "salary": 30000}])

    This OBJECTLIST can be viewed as a small table:
    ```
    name,age,salary
    John,37,10000
    May,42,30000
    ```
    """ 
    def __init__(self, data: list[dict], allow_duplication=True):
        if isinstance(data, OBJECTLIST):
            # Just in case that you create OBJECTLIST from OBJECTLIST. The new OBJECTLIST is  
            #   another reference to the exact same data.
            self.data = data.data   
        else:
            self.data = data
        if not allow_duplication:
            seen = set()
            for o in self.data:
                object_as_hashable_set = frozenset(o.items()) # Convert dict to hashable set
                if object_as_hashable_set in seen:
                    raise Exception("With allow_duplication set to False, duplicated objects are not allowed in OBJECTLIST")
                seen.add(object_as_hashable_set)

        self.iter_idx = 0

    ######################
    # Return a primitive #
    ######################
    
    def sum_of_column(self, column: str) -> Union[int, float]:
        """
        Return the summation of all values in the selected column.
        
        Parameters
        ----------
        column : str
            Name of selected column for summation. All values are required to be int or float.

        Returns
        -------
        int or float
            Summation of all values in the selected column.

        Examples
        --------
        >>> ol.sum_of_column('age')
        """
        return  sum([o.get(column, 0) for o in self.data])
    
    def count(self) -> int:
        """
        Return the number of objects.

        Returns
        -------
        int
            The number of objects.
            
        Examples
        --------
        >>> ol.count()
        """                
        return len(self.data)
    
    ########################
    # Return a dict object #
    ########################
    def get(self, index: int) -> dict:
        """
        Return the object at the `index`.

        Parameters
        ----------
        index : int
            The index starting from 0.

        Returns
        -------
        dict
            The object at the `index`.
            
        Examples
        --------
        >>> ol.get(1)  
        
        Since a dict object is returned, we can get a value from a field.
        >>> ol.get(1).get('age')
        """        
        return self.data[index]

    ######################################
    # Return an ARRAY (subclass of list) #
    ######################################
    def select(self, column: Union[str, list]) -> Union[ARRAY, OBJECTLIST]:
        """
        Return an ARRAY of values of the selected column, including NULL (None).
        Or return an OBJECTLIST for a list of selected columns.

        Parameters
        ----------
        column : str or list
            Column name to select values, or list of column names.

        Returns
        -------
        ARRAY or OBJECTLIST
            ARRAY of values of the selected column, or OBJECTLIST for list of selected columns.

        Raises
        ------
        Exception
            If an error occurs.            
            
        Examples
        --------
        >>> ol.select("name")
        ARRAY(['John', 'Mary'])

        >>> ol.select(["name"])
        OBJECTLIST([
            {'name': 'John'}
            {'name': 'Mary'}
        ])
        """        
        if isinstance(column, str):
            #return ARRAY([o[column] for o in self.data if column in o]) # Excluding None
            return ARRAY([o.get(column) for o in self.data])
        elif isinstance(column, list): 
            #return OBJECTLIST([{c: o[c] for c in column if c in o} for o in self.data]) # Excluding None
            return OBJECTLIST([{c: o.get(c) for c in column} for o in self.data])
        else:
            raise Exception("Unsupported type {} in select()".format(type(column)))

    
    def select_distinct(self, column: Union[str, list]) -> Union[ARRAY, OBJECTLIST]:  # Remove duplicates
        """
        Return an ARRAY of distinct values in the selected column, including NULL (None).
        Or return an OBJECTLIST without duplication for a list of selected columns.

        Parameters
        ----------
        column : str or list
            Column name to select values, or list of column names.

        Returns
        -------
        ARRAY or OBJECTLIST
            ARRAY of distinct values in the selected column, or OBJECTLIST without duplication for list of selected columns.

        Raises
        ------
        Exception
            If an error occurs. 

        Examples
        --------
        >>> ol.select_distinct("name")
        >>> ol.select_distinct(["name", "age"])
        """               
        if isinstance(column, str): 
            return ARRAY(list(OrderedDict.fromkeys(self.select(column)))) 
        elif isinstance(column, list):
            # https://stackoverflow.com/questions/9427163/remove-duplicate-dict-in-list-in-python
            l = []
            for o in self.data:
                d = {c: o.get(c) for c in column}
                if d not in l:
                    l.append(d)
            return OBJECTLIST(l)
        else:
            raise Exception("Unsupported type {} in select()".format(type(column)))
                

    ########################
    # Return an OBJECTLIST #
    ########################    
   
    def where(self, column: str, operator: Union[OP, str] = None, value: Union[str, int, float, list] = None) -> OBJECTLIST:
        """
        Return a new OBJECTLIST which object matches the condition in where(). 
        
        If an object passes the condition, it is included in the returned OBJECTLIST. 
        Each object is tested with its column value, operator and value.

        Parameters
        ----------
        column : str
            Column name of the object to compare, or a string of complete where() expression.
            If the object doesn't have this column, it's just ignored.
            If column is a where() expression, operator and value must be None.
            The where() expression consists of single condition or multiple conditions with *and* or *or* operators. 
            The where() expression may contains placeholder variables which will be substitued 
            by the value from transaction context.
        operator : OP or str, default = None
            Operator to compare. See `pyrengine.op.OP`.
        value : str or int or float or list, default = None
            Depending on the operator, the value type must match the operator.

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST which each object matches the condition in where().

        Raises
        ------
        NotImplementedError
            Some usages are unsupported.
            
        Examples
        --------
        >>> ol.where("name", "eq", "John")
        >>> ol.where("name", "=", "John")
        >>> ol.where("name", "neq", "John")
        >>> ol.where("name", "<>", "John")
        >>> ol.where("age", "gt", 60)
        >>> ol.where("age", ">", 60)
        >>> ol.where("name", "like", "Jo*")
        >>> ol.where("name", "is_in", ["Jonh", "Mary"])
        >>> ol.where("name = 'John'")
        >>> ol.where("age > 60")
        >>> ol.where("name", "eq", "John").where("age", "gt", 60)
        >>> ol.where("name = 'Jonh' and age > 60")
        >>> ol.where("name = 'Jonh' and (age > 60 or age < 10)")
        >>> ol.where("name = 'Jonh' and age > $max_age")
            
        """        
        
        if not column:
            raise Exception('Column cannot be empty')

        if operator is None and value is None:
            eval_tree = parse_string(column)
            if eval_tree is None:
                raise Exception("Something wrong while parsing where() conditions {}".format(column))
            
            return OBJECTLIST([o for o in self.data if eval_tree.eval(o, None)])


        if isinstance(operator, str):
            try:
                operator = OP[operator]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator {} in where()'.format(operator)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred
                
        # TODO: Type checking for each operator, e.g. gt needs both operands have the same type 
        if operator in (OP.gt, OP['>']):
            return OBJECTLIST([o for o in self.data if column in o and o[column] is not None and value is not None and o[column] > value])
        elif operator in (OP.ge, OP['>=']):
            return OBJECTLIST([o for o in self.data if column in o and o[column] is not None and value is not None and o[column] >= value])
        elif operator in (OP.eq, OP['=']):
            return OBJECTLIST([o for o in self.data if column in o and o[column] == value])
        elif operator in (OP.neq, OP['<>']):
            return OBJECTLIST([o for o in self.data if column in o and o[column] != value])
        elif operator in (OP.lt, OP['<']):
            return OBJECTLIST([o for o in self.data if column in o and o[column] is not None and value is not None and o[column] < value])
        elif operator in (OP.le, OP['<=']):
            return OBJECTLIST([o for o in self.data if column in o and o[column] is not None and value is not None and o[column] <= value])
        elif operator in (OP.is_in, OP.is_not_in):
            switch = False if operator == OP.is_in else True  # It is used for XOR (^) 
            if isinstance(value, list):
                return OBJECTLIST([o for o in self.data if column in o and ((o[column] in value) ^ switch)])
            else:
                raise NotImplementedError('{} not supported by {} operator where() is_in/is_not_in'.format(type(value), operator.name))
        elif operator in (OP.like, OP.not_like):
            switch = False if operator == OP.like else True  # It is used for XOR (^)
            return OBJECTLIST([o for o in self.data if column in o and (fnmatch.fnmatch(o[column].lower(), value.lower()) ^ switch)])
        else:
            raise NotImplementedError('Unknown operator {} in where()'.format(operator))
    
    # Return non-duplicated object list
    #   https://stackoverflow.com/questions/11092511/list-of-unique-dictionaries
    #   https://stackoverflow.com/a/46060873
    def distinct(self) -> OBJECTLIST:
        """
        Return a new OBJECTLIST with duplicated objects removed.

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST with duplicated objected removed.
            
        Examples
        --------
        >>> ol.distinct()
        """        
        seen = set()
        results = []
        for o in self.data:
            object_as_hashable_set = frozenset(o.items()) # Convert dict to hashable set
            if object_as_hashable_set not in seen:
                results.append(o)
                seen.add(object_as_hashable_set)
        return OBJECTLIST(results)
    

    # https://stackoverflow.com/questions/62380562/sort-list-of-dicts-by-two-keys
    def sort(self, column: Union[str, list], ascending: Union[bool, list] = True) -> OBJECTLIST:
        """
        Return sorted OBJECTLIST.
        
        Parameters
        ----------
        column : str or list[str]
            Column or list of columns to sort.
        ascending : bool or list[bool], default = True
            Sort ascending or descending.

        Returns
        -------
        OBJECTLIST
            Sorted OBJECTLIST.

        Raises
        ------
        Exception
            Any errors cause exception.
            
        Examples
        --------
        >>> ol.sort("name")

        >>> ol.sort(["name", "age"])

        >>> ol.sort(["name", "age"], [True, False])
        """              
        if isinstance(column, str):
            column = [column]

        if isinstance(ascending, bool):
            ascending = [ascending] * len(column)

        if len(column) != len(ascending):
            raise Exception('Size of ascending {} not matched with number of columns {}'.format(len(ascending), len(column)))
    
        tmp = list(self.data)  # shallow copy list
        for col, order in zip(reversed(column), reversed(ascending)):
            tmp.sort(key=lambda k: k[col], reverse=not order)  # in-place stable sort
        return OBJECTLIST(tmp)


    def assign(self, column: str, value: Union[object, list[object]]) -> OBJECTLIST:
        """
        Assign a new column to all objects or replacing the existing column. Return a new OBJECTLIST. 
        This method doesn't check the schema of objects.

        Parameters
        ----------
        column : str
            Column name
        value : Union[object, list[object]]
            If value is a single value, assign it to all objects.
            If value is a list of values, assign each element to a different object in order.

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST with the assigned column.

        Raises
        ------
        Exception
            Any errors cause exception.

        Examples
        --------
        >>> ol
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000}
            {'name': 'Mary', 'age': 42, 'salary': 30000}
        ])
        >>> ol.assign('dept', 'Sales')        
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000, 'dept': 'Sales'}
            {'name': 'Mary', 'age': 42, 'salary': 30000, 'dept': 'Sales'}
        ]) 
        >>> ol.assign('dept', ['Finance', 'Sales'])        
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000, 'dept': 'Finance'}
            {'name': 'Mary', 'age': 42, 'salary': 30000, 'dept': 'Sales'}
        ])                       
        """
        l = []
        if isinstance(value, list):
            if len(value) != len(self.data):
                raise Exception("The number of elements in value {} doesn't match with the number of objects".format(value))
            l = [{**o, column: e} for o, e in zip(self.data, value)]
        else:
            l = [{**o, column : value} for o in self.data] 
        return OBJECTLIST(l)
    

    def append(self, other: OBJECTLIST) -> OBJECTLIST:
        """
        Append an OBJECTLIST to another, duplication allowed. Return a new OBJECTLIST. 
        This method doesn't check the schema of objects.

        Parameters
        ----------
        other : OBJECTLIST

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST with objects from both OBJECTLISTs.

        Raises
        ------
        Exception
            Any errors cause exception.

        Examples
        --------
        >>> ol.where("name", "eq" "John")
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000}
        ])
        >>> ol.where("salary", "qt" 20000)            
        OBJECTLIST([
            {'name': 'Mary', 'age': 42, 'salary': 30000}
        ])
        >>> ol.where("name", "eq", "John").append(ol.where("salary", "gt", 20000))
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000}
            {'name': 'Mary', 'age': 42, 'salary': 30000}
        ])        
        """
        return OBJECTLIST(self.data + other.data)


    def union(self, other: OBJECTLIST) -> OBJECTLIST:
        """
        Return a new OBJECTLIST with all objects from both OBJECTLISTs, no duplication.
        This method doesn't check the schema of objects.

        Parameters
        ----------
        other : OBJECTLIST

        Returns
        -------
        OBJECTLIST
            The union of OBJECTLISTs.

        Raises
        ------
        Exception
            Any errors cause exception.

        Examples
        --------
        >>> ol.where("name", "eq" "John")
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000}
        ])
        >>> ol.where("salary", "qt" 20000)            
        OBJECTLIST([
            {'name': 'Mary', 'age': 42, 'salary': 30000}
        ])
        >>> ol.where("name", "eq", "John").union(ol.where("salary", "gt", 20000))
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000}
            {'name': 'Mary', 'age': 42, 'salary': 30000}
        ])        

        """        
        seen = set()
        results = []
        for o in self.data + other.data:
            object_as_hashable_set = frozenset(o.items()) # Convert dict to hashable set
            if object_as_hashable_set not in seen:
                results.append(o)
                seen.add(object_as_hashable_set)
        return OBJECTLIST(results)
    
    def rename(self, old_column: str, new_column: str) -> OBJECTLIST:
        """
        Rename a column of all objects.  Return a new OBJECTLIST. 

        Parameters
        ----------
        old_column : str
            Current column name
        new_column : str
            New column name

        Returns
        -------
        OBJECTLIST
            A new OBJECTLIST with the renamed column.

        Raises
        ------
        Exception
            Any errors cause exception.

        Examples
        --------
        >>> ol
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000}
            {'name': 'Mary', 'age': 42, 'salary': 30000}
        ])
        >>> ol.rename('name', 'firstname')        
        OBJECTLIST([
            {'firstname': 'John', 'age': 37, 'salary': 10000}
            {'firstname': 'Mary', 'age': 42, 'salary': 30000}
        ])
        """
        l = [{(k if k != old_column else new_column): v for k, v in o.items()} for o in self.data] 
        return OBJECTLIST(l)
    
    
    #################################
    # Return an intermediate object #
    #################################    
    
    # return GROUPBY 
    def group_by(self, column: Union[str, list[str]]) -> GROUPBY:
        """
        Return a GROUPBY which will be used to put objects with the same column value into the same group.
        
        The GROUPBY is often invoked with count() or sum() methods.

        Parameters
        ----------
        column : str or list[str]
            Column or list of columns to separate each group.

        Returns
        -------
        GROUPBY
            A GROUPBY which will be used to put objects with the same column value into the same group.

        Raises
        ------
        Exception
            Any errors cause exception.
            
        Examples
        --------
        >>> ol.group_by("name").count()
        
        >>> ol.group_by("name").sum("salary)
        """        
        if column is None:
            raise Exception("OBJECTLIST.group_by() requires column")
        
        if isinstance(column, str):
            columns = [column]
        else:
            columns = column
            
        groups = {}
        for o in self.data:
            keys = []
            for c in columns: 
                if c in o:
                    keys.append((c, o[c]))
                else:
                    #keys.append((c, None))
                    raise Exception('group_by() cannot find column {} in {}'.format(c, o))
            group = tuple(keys)
            if group not in groups:
                groups[group] = []
            groups[group].append(o)
        return GROUPBY(groups)
    
    '''
    # return FILTERED_BY_COLUMN
    def filter_by_column(self, column: str) -> FILTERED_BY_COLUMN:
        """
        `Obsoleted`

        Parameters
        ----------
        column : str
            
        Returns
        -------
        FILTERED_BY_COLUMN
            A FILTERED_BY_COLUMN.
        """        
        return FILTERED_BY_COLUMN(self.data, column)
    '''
    
    def inner_join(self, other: OBJECTLIST, on_key: Union[str, list[str]], on_other_key: Union[str, list[str]] = None) -> JOINED_OBJECTLIST:
        """
        Return a JOINED_OBJECTLIST which is a list of inner-joined objects from this and the other OBJECTLIST based on joined keys. 
        
        Parameters
        ----------
        other : OBJECTLIST
            Another OBJECTLIST to join.
        on_key : str or list[str]
            The column or columns which objects between two OBJECTLISTs are joined on. 
        on_other_key : str or list[str], default = None
            The column names of the other OBJECTLIST to join on if different than the first OBJECTLIST.             

        Returns
        -------
        JOINED_OBJECTLIST
            A JOINED_OBJECTLIST which is a list of inner-joined objects from this and the other OBJECTLIST based on joined key.

        Raises
        ------
        Exception
            Any errors cause exception.
            
        """        
        if on_key is None:
            raise Exception("OBJECTLIST.inner_join() requires on_key argument")
        
        if isinstance(on_key, str):
            keys = [on_key]
        elif isinstance(on_key, list) and all(isinstance(key, str) for key in on_key):
            keys = on_key

        if on_other_key is not None:
            if isinstance(on_other_key, str):
                other_keys = [on_other_key]
            elif isinstance(on_other_key, list) and all(isinstance(key, str) for key in on_other_key):
                other_keys = on_other_key
            if len(keys) != len(other_keys):
                raise Exception("OBJECTLIST.inner_join() requires the number of columns of on_other_key == on_key")
        else:
            other_keys = keys

        results = []
        
        for left in self.data:
            if not all(key in left for key in keys):
                raise Exception("inner_join() requires keys {} in left object {}".format(keys, left))            
            new_key = tuple(left[key] for key in keys)
            # If right object is LOOKUP, use hash join
            for right in other._get_possible_objects_by_keys(other_keys, new_key):
                if not all(key in right for key in other_keys):
                    raise Exception("inner_join() requires keys {} in right object {}".format(other_keys, right))
                if all(left[key] == right[rkey] for key, rkey in zip(keys, other_keys)):
                    result = (new_key, (left, right))
                    results.append(result)
        return JOINED_OBJECTLIST(results)
    
    def left_join(self, other: OBJECTLIST, on_key: Union[str, list[str]], on_other_key: Union[str, list[str]] = None) -> JOINED_OBJECTLIST:
        """
        Return a JOINED_OBJECTLIST which is a list of left-joined objects from this and the other OBJECTLIST based on joined keys. 
        If no matching object in the other OBJECTLIST, None is used to join with the left object.
        
        Parameters
        ----------
        other : OBJECTLIST
            Another OBJECTLIST to join.
        on_key : str or list[str]
            The column or columns which objects between two OBJECTLISTs are joined on.
        on_other_key : str or list[str], default = None
            The column names of the other OBJECTLIST to join on if different than the first OBJECTLIST.             

        Returns
        -------
        JOINED_OBJECTLIST
            A JOINED_OBJECTLIST which is a list of left-joined objects from this and the other OBJECTLIST based on joined key.

        Raises
        ------
        Exception
            Any errors cause exception.
            
        """        
        if on_key is None:
            raise Exception("OBJECTLIST.left_join() require on_key argument")
        
        if isinstance(on_key, str):
            keys = [on_key]
        elif isinstance(on_key, list) and all(isinstance(key, str) for key in on_key):
            keys = on_key

        if on_other_key is not None:
            if isinstance(on_other_key, str):
                other_keys = [on_other_key]
            elif isinstance(on_other_key, list) and all(isinstance(key, str) for key in on_other_key):
                other_keys = on_other_key
            if len(keys) != len(other_keys):
                raise Exception("OBJECTLIST.left_join() requires the number of columns of on_other_key == on_key")
        else:
            other_keys = keys            

        results = []

        for left in self.data:
            result = None
            if not all(key in left for key in keys):
                raise Exception("left_join() requires keys {} in left object {}".format(keys, left))
            new_key = tuple(left[key] for key in keys)
            # If right object is LOOKUP, use hash join
            for right in other._get_possible_objects_by_keys(other_keys, new_key):
                if not all(key in right for key in other_keys):
                    raise Exception("left_join() requires keys {} in right object {}".format(other_keys, right))
                if all(left[key] == right[rkey] for key, rkey in zip(keys, other_keys)):
                    result = (new_key, (left, right))
                    results.append(result)
            if result is None:
                result = (new_key, (left, None))
                results.append(result)
        return JOINED_OBJECTLIST(results)
    

    # Private methods begin with __
    # Protect methods begin with _      
    # Trying to return a list of objects with matching keys if possible.
    # So it returns all objects as the worst case.
    # For normal OBJECTLIST which has no index, so return all objects.
    def _get_possible_objects_by_keys(self, on_keys: list[str], values: list[object]) -> list[dict]:
        return self.data
    

    def __eq__(self, other) -> bool:
        if not isinstance(other, OBJECTLIST):
            return False
        return self.data == other.data


    def __str__(self) -> str:
        return 'OBJECTLIST({})'.format(self.data)

    # TODO: Pretty print OBJECTLIST as a table
    #   https://stackoverflow.com/questions/60577354/creating-a-table-with-prettytable-from-list-of-dictionaries
    #   https://stackoverflow.com/questions/11399384/extract-all-keys-from-a-list-of-dictionaries
    #   https://stackoverflow.com/questions/1523660/how-to-print-a-list-in-python-nicely
    def to_string(self) -> str:    
        """
        Return the string of OBJECTLIST in tabular format.

        Returns
        -------
        str
            The string of OBJECTLIST in tabular format.

        Examples
        --------
        >>> ol = OBJECTLIST([{"name": "John", "age": 37, "salary": 10000}, {"name": "Mary", "age": 42, "salary": 30000}])
        >>> print(ol.to_string())
        OBJECTLIST([
            {'name': 'John', 'age': 37, 'salary': 10000}
            {'name': 'Mary', 'age': 42, 'salary': 30000}
        ])
        """          
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([str(o) for o in self.data]))
        else:
            table = ''
        return 'OBJECTLIST([{}])'.format(table)
    
    def to_list(self) -> list:    
        """
        Return a new list of all objects in OBJECTLIST.
        """    
        return list(self.data)

    def __repr__(self) -> str:
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([repr(o) for o in self.data]))
        else:
            table = ''        
        return 'OBJECTLIST([{}])'.format(table)
    
    def __iter__(self):
        return iter(self.data)

        
    
