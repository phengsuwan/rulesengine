from typing import List
from datetime import datetime,timedelta


def maxDate(datetimes: List[datetime]) -> datetime:
    """
    Find the maximum datetime from a list of datetimes.

    Parameters
    ----------
    datetimes: A list of datetimes

    Returns
    -------
    datetime: The maximum datetime in the list

    Raises
    ------
    ValueError: If `datetimes` is empty

    Examples
    --------
    >>> maxDate([datetime.datetime(2023,1,20),datetime.datetime(2023,1,21)])
    datetime.datetime(2023,01,21)

    Profile
    -------
    ```{json}
    {
        "name": "maxDate", 
        "display_name": "Max (datetime)", 
        "description": "Find the maximum datetime from a list of datetimes.", 
        "params" : [
            { "name" : "datetimes" , "description" : "the list of datetimes" , "type" : ["list_datetime"]}
        ],
        "return_type" : {
            "type" : "datetime"
        }
    }
    ```
    """
    if not datetimes:
        raise ValueError("The datetimes list is empty")
    return max(datetimes)


def minDate(datetimes: List[datetime]) -> datetime:
    """
    Find the minimum date from a list of datetimes.

    Parameters
    ----------
    datetimes: A list of datetimes

    Returns
    -------
    datetime: The minimum datetime in the list

    Raises
    ------
    ValueError: If `datetimes` is empty

    Examples
    --------
    >>> minDate([datetime.datetime(2023,1,20),datetime.datetime(2023,1,21)])
    datetime.datetime(2023,01,20)

    Profile
    -------
    ```{json}
    {
        "name": "minDate", 
        "display_name": "Min (datetime)",
        "description": "Find the minimum date from a list of datetimes.", 
        "params" : [
            { "name" : "datetimes" , "description" : "the list of datetimes" , "type" : ["list_datetime"]}
        ],
        "return_type" : {
            "type" : "datetime"
        }
    }
    ```
    """
    if not datetimes:
        raise ValueError("The datetimes list is empty")
    return min(datetimes)


def dateDiff(a: datetime, b: datetime, unit: str = 'day') -> int:
    """
    Calculate the difference between a and b.

    Parameters
    ----------
    a: The first datetime
    b: The second datetime
    unit: The unit of time to measure the difference. Can be 'day', 'hour', 'minute', or 'second'

    Returns
    -------
    int: The difference between `a` and `b` in the specified unit. Can be negative if a < b

    Raises
    ------
    ValueError: If `unit` is not one of 'day', 'hour', 'minute', or 'second'

    Examples
    --------
    >>> dateDiff([datetime.datetime(2023,1,20),datetime.datetime(2023,1,21)],'day')
    1
    >>> dateDiff([datetime.datetime(2023,1,21),datetime.datetime(2023,1,20)],'hour')
    -24
    
    Profile
    -------
    ```{json}
    {
        "name": "dateDiff", 
        "display_name": "Diff (datetime)",
        "description": "Calculate the difference between a and b.", 
        "params" : [
            { "name" : "a" , "description" : "The first datetime" , "type" : ["datetime"]},
            { "name" : "b" , "description" : "The second datetime" , "type" : ["datetime"]},
            { "name" : "unit" , "description" : "The unit of time to measure the difference. Can be 'day', 'hour', 'minute', or 'second'" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """

    if unit not in {'day', 'hour', 'minute', 'second'}:
        raise ValueError(
            "Invalid unit. Must be 'day', 'hour', 'minute', or 'second'.")
        
    if unit == 'hour':
        a = a.replace(minute=0,second=0)
        b= b.replace(minute=0,second=0)
    elif unit == 'minute':
        a = a.replace(second=0)
        b =b.replace(second=0)

    delta = a - b

    if unit == 'day':
        return delta.days
    elif unit == 'hour':
        return int((delta.days * 24) + (delta.seconds // 3600))
    elif unit == 'minute':
        return int((delta.days * 24 * 60) + (delta.seconds // 60))
    elif unit == 'second':
        return int((delta.days * 24 * 3600) + delta.seconds)


def str2Datetime(txt: str, format: str) -> datetime:
    """
    Convert a string to a datetime using a [specified format](https://docs.python.org/3/library/datetime.html#strftime-and-strptime-format-codes). 

    Parameters
    ----------
    txt: The string representation of the date and time
    format: The format string that specifies the expected date and time format 

    Returns
    -------
    datetime: A `datetime` object representing the parsed date and time

    Raises
    ------
    ValueError: If the string does not match the specified format

    Examples
    --------
    >>> str2Datetime("2024-08-06 14:30", "%Y-%m-%d %H:%M")
    datetime.datetime(2024, 8, 6, 14, 30)

    Profile
    -------
    ```{json}
    {
        "name": "str2Datetime", 
        "display_name": "String to datetime (datetime)",
        "description": "Convert a string to a datetime", 
        "params" : [
            { "name" : "txt" , "description" : "string representation of the date and time" , "type" : ["string"]},
            { "name" : "format" , "description" : "Formats datetime values according to https://docs.python.org/3/library/datetime.html#strftime-and-strptime-format-codes" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "datetime"
        }
    }
    ```
    """

    try:
        _datetime = datetime.strptime(txt, format)
        return _datetime
    except ValueError as e:
        raise e
    
def dateAdd(a:datetime,interval:int,unit:str) -> datetime:
    """
    Add a specified interval to a given date.

    Parameters
    ----------
    a: datetime object to which the interval is added
    interval: amount of time to add
    unit: unit of time to add, must be one of 'days', 'hours', 'minutes', 'seconds'

    Returns
    -------
    datetime: new date with the interval added

    Raises
    ------
    ValueError: if the unit is not one of 'days', 'hours', 'minutes', 'seconds'

    Examples
    --------
    >>> from datetime import datetime
    >>> dateAdd(datetime(2024, 1, 1), 5, 'days')
    datetime.datetime(2024, 1, 6, 0, 0)
    
    Profile
    -------
    ```{json}
    {
        "name": "dateAdd", 
        "display_name": "Add (datetime)",
        "description": "Add a specified interval to a given date.", 
        "params" : [
            { "name" : "a" , "description" : "datetime object to which the interval is added" , "type" : ["datetime"]},
            { "name" : "interval" , "description" : "amount of time to add" , "type" : ["number"]},
            { "name" : "unit" , "description" : "unit of time to add, must be one of 'days', 'hours', 'minutes', 'seconds'" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "datetime"
        }
    }
    ```
    """
    if unit not in {'days', 'hours', 'minutes', 'seconds'}:
        raise ValueError(
            "Invalid unit. Must be 'days', 'hours', 'minutes', or 'seconds'.")
    kwargs = {unit:interval}

    return a + timedelta(**kwargs)

def dateSubtract(a:datetime,interval:int,unit:str) -> datetime:
    """
    Subtract a specified interval from a given date.

    Parameters
    ----------
    a: datetime object from which the interval is subtracted
    interval: amount of time to subtract
    unit: unit of time to subtract, must be one of 'days', 'hours', 'minutes', 'seconds'

    Returns
    -------
    datetime: new date with the interval subtracted

    Raises
    ------
    ValueError: if the unit is not one of 'days', 'hours', 'minutes', 'seconds'

    Examples
    --------
    >>> from datetime import datetime
    >>> dateSubtract(datetime(2024, 1, 10), 5, 'days')
    datetime.datetime(2024, 1, 5, 0, 0)
    
    Profile
    -------
    ```{json}
    {
        "name": "dateSubtract", 
        "display_name": "Subtract (datetime)",
        "description": "Subtract a specified interval from a given date.", 
        "params" : [
            { "name" : "a" , "description" : "datetime object from which the interval is subtracted" , "type" : ["datetime"]},
            { "name" : "interval" , "description" : "amount of time to subtract" , "type" : ["number"]},
            { "name" : "unit" , "description" : "unit of time to subtract, must be one of 'days', 'hours', 'minutes', 'seconds'" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "datetime"
        }
    }
    ```
    """
    if unit not in {'days', 'hours', 'minutes', 'seconds'}:
        raise ValueError(
            "Invalid unit. Must be 'days', 'hours', 'minutes', or 'seconds'.")
    kwargs = {unit:interval}

    return a - timedelta(**kwargs)

def dateTruncate (a:datetime,unit:str) -> datetime:
    """
    Truncate a date to the specified unit.

    Parameters
    ----------
    a: datetime object to be truncated
    unit: unit to truncate to, must be one of 'day', 'month', 'year'

    Returns
    -------
    datetime: truncated date

    Raises
    ------
    ValueError: if the unit is not one of 'day', 'month', 'year'

    Examples
    --------
    >>> from datetime import datetime
    >>> dateTruncate(datetime(2024, 5, 15, 10, 30, 45), 'month')
    datetime.datetime(2024, 5, 1, 0, 0)
    
    Profile
    -------
    ```{json}
    {
        "name": "dateTruncate", 
        "display_name": "Truncate (datetime)",
        "description": "Truncate a date to the specified unit.", 
        "params" : [
            { "name" : "a" , "description" : "datetime object to be truncated" , "type" : ["datetime"]},
            { "name" : "unit" , "description" : "unit to truncate to, must be one of 'day', 'month', 'year'" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "datetime"
        }
    }
    ```
    """
    kwargs = {
        'hour':0,
        'minute':0,
        'second':0,
        'microsecond':0
    }
    if unit not in {'day','month','year'}:
        raise ValueError(
            "Invalid unit. Must be 'day', 'month' or 'year'")
    match unit:
        case 'day':
            month,day =None,None
        case 'month':
            month,day =None,1
        case 'year':
            month,day =1,1
        case _:
            pass
    if month:
        kwargs['month'] = month
    if day:
        kwargs['day'] = day
        
    return a.replace(**kwargs)

def extractDate(a:datetime,unit:str)-> int:
    """
    Extract a specific component from a datetime.

    Parameters
    ----------
    a: datetime object from which the component is extracted
    unit: component to extract, must be one of 'year', 'month', 'day', 'hour', 'minute', 'second'

    Returns
    -------
    int: value of the specified component

    Raises
    ------
    ValueError: if the unit is not one of 'year', 'month', 'day', 'hour', 'minute', 'second'

    Examples
    --------
    >>> from datetime import datetime
    >>> extractDate(datetime(2024, 5, 15, 10, 30, 45), 'month')
    5
    
    Profile
    -------
    ```{json}
    {
        "name": "extractDate", 
        "display_name": "Extract (datetime)",
        "description": " Extract a specific component from a datetime.", 
        "params" : [
            { "name" : "a" , "description" : "datetime object from which the component is extracted" , "type" : ["datetime"]},
            { "name" : "unit" , "description" : "component to extract, must be one of 'year', 'month', 'day', 'hour', 'minute', 'second'" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    if unit not in {'year','month','day','hour','minute','second'}:
        raise ValueError(
            "Invalid unit. Must be 'year', 'month', 'day', 'hour', 'minute' or 'second'")
    return getattr(a,unit)