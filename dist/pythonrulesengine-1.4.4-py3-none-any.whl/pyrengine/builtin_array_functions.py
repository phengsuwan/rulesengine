from pyrengine.objectlist import ARRAY

def count_array(a:ARRAY)-> int:
    """
    Count the number of elements in the array.

    Parameters
    ----------
    a: ARRAY
        The array whose elements are to be counted

    Returns
    -------
    int
        The count of elements in the array

    Examples
    --------
    >>> count_array([1, 2, 3])
    3
    
    Profile
    -------
    ```{json}
    {
        "name": "count_array", 
        "display_name": "Count Array",
        "description": "Count the number of elements in the array.", 
        "params": [
            { "name": "a", "description": "The array whose elements are to be counted", "type": ["list_string","list_number","list_datetime"]}
        ],
        "return_type": {
            "type": "number"
        }
    }
    ```
    """
    return a.count()