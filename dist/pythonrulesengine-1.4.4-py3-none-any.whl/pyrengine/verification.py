import ast
import builtins
import inspect
import typing
import types
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

# Explicitly import modules as globals() works only for the current module 
from pyrengine.objectlist import ARRAY as MYARRAY  # ARRAY name is conflicted with z3.ARRAY
from pyrengine.model import *
from pyrengine.date import DATETIME
from pyrengine.rulecontext import FUNCTIONCALL_SYMBOLS
from pyrengine.compiler import register_function

from z3 import *


_LITERAL_TYPE = ast.Constant | ast.List
_VAR_TYPE = ast.Name | ast.Attribute | ast.Call

register_function('DATETIME', DATETIME)
register_function('ARRAY', MYARRAY)

# TODO: Handle different timezone 
#EPOCH = DATETIME('1970-01-01')  # A reference to the origin of time, used as a work around for timezone variation.
#EPOCH = datetime.fromtimestamp(0, tz=ZoneInfo("Asia/Bangkok"))  # A reference to the origin of time, used as a work around for timezone variation.
EPOCH = datetime.fromtimestamp(0, tz=timezone.utc)  # A reference to the origin of time, used as a work around for timezone variation.

# Find return type of a function or a method from signature.
# https://stackoverflow.com/questions/70967266/what-exactly-is-python-typing-callable
# https://stackoverflow.com/questions/3061/calling-a-function-of-a-module-by-using-its-name-a-string
def _get_return_type(callable_name: str, class_name: str = None) -> typing.Type:
    # callable_name: function or method name

    if class_name:
        # globals() can see only imports in the current module 
        cls = globals().get(class_name)
        if not (cls and inspect.isclass(cls)): 
            raise RuleVerificationException("Class {} not found in verification import".format(class_name))    

        callable = getattr(cls, callable_name, None)    # Method not bound to an object is treated as a function.
        if not (callable and inspect.isfunction(callable)): 
            raise RuleVerificationException("Method {} not found in verification import".format(callable_name))    
    else:
        callable = globals().get(callable_name)
        if not callable: 
            callable = getattr(builtins, callable_name)  # https://stackoverflow.com/questions/68919220/using-getattr-to-access-built-in-functions
        if not (callable and (inspect.isbuiltin(callable) or inspect.isfunction(callable))): 
            raise RuleVerificationException("Function {} not found in verification import".format(callable_name))            
        
    hints = typing.get_type_hints(callable)
    return_type = hints.get('return') # https://stackoverflow.com/questions/49560974/inspect-params-and-return-types
    
    #https://stackoverflow.com/questions/74544539/python-how-to-check-what-types-are-in-defined-types-uniontype
    origin = typing.get_origin(return_type)  # For return type with Union or |
    if origin is typing.Union or origin is types.UnionType:   #  types.UnionType if using |
        return_type = typing.get_args(return_type)[0]  # Get only the first type

    return return_type or float

    
# https://gist.github.com/jtpio/cb30bca7abeceae0234c9ef43eec28b4
# https://greentreesnakes.readthedocs.io/en/latest/
# https://docs.python.org/3/reference/grammar.html
# https://docs.python.org/3/library/ast.html
class Z3Formulas(ast.NodeVisitor):
    """
    Convert AST tree to Z3 formulas. Each term in an expression are substituted with a variable x1, x2, ...
    A term can be a name, a function call (possibly nested) or a chain of method calls. 
    We treat whole nested function calls and chain of method calls as a single variable because 
       we cannot determine the exact return value of each step; we can determine only return type.
    The data type of each term is determined from context or guessed from function/method signatures and 
       should be eventually ended up to Int, Real, Bool, String of Z3 data type.
    """

    def __init__(self, symbols: dict):
        self.variable_map: dict[str, str] = {}   # Map of seen expression to variable name, e.g. age -> x0, price -> x1, maxint(1, 2) -> x3
        self.variables: dict[str, typing.Type] = {} #  Dict of variable name and type), e.g. (x0, int), (x1, float), (x3, int)
        self.assignment_map: dict[str, str] =  {}  # Dict of assignment, e.g. x = a + b
        self.constraints: list[str] = []
        self.symbols = symbols # Map of identifier to object or class


    # https://stackoverflow.com/questions/70967266/what-exactly-is-python-typing-callable
    # https://stackoverflow.com/questions/3061/calling-a-function-of-a-module-by-using-its-name-a-string
    # Recursively determine return type of a name or a Call (nested functions or method call chain).
    def _get_variable_return_type(self, variable: _VAR_TYPE) -> typing.Type:
        if isinstance(variable, ast.Name):
            id = variable.id

            idx = self.variable_map.get(id)  # First from seen (local) variable
            if idx is not None:
                return self.variables[idx]
                        
            # TODO: Get type from external mapping XXXXX
            if id.startswith("c_"):   # Second priority from transaction
                return OBJECTLIST        

            if id in self.symbols:   # Third from symbol table
                obj = self.symbols[id]
                if inspect.isclass(obj):
                    return obj
                return type(obj)

            if id in FUNCTIONCALL_SYMBOLS:   # Forth functions from rulecontext
                name = FUNCTIONCALL_SYMBOLS[id]
            else: 
                name = getattr(builtins, id, None)  # Otherwise from builtin functions. https://stackoverflow.com/questions/68919220/using-getattr-to-access-built-in-functions

            if not name:
                raise RuleVerificationException("Name {} not found in verification".format(id))            
            
            if inspect.isbuiltin(name) or inspect.isfunction(name): 
                callable = name
            else:
                raise RuleVerificationException("Name {} not a function in verification".format(name))            

        elif isinstance(variable, ast.Call):  # function call func() or method call obj.method()
            cls = self._get_variable_return_type(variable.func)   # Determine return type based on function name, ignoring any arguments
            return cls

        elif isinstance(variable, ast.Attribute):  # Attribute is the method in obj.method()
            cls = self._get_variable_return_type(variable.value)
            if not (cls and inspect.isclass(cls)): 
                raise RuleVerificationException("Class {} not found in verification".format(cls))    
            attr = getattr(cls, variable.attr, None)    
            if not attr:
                raise RuleVerificationException("Method {} not found for class {} in verification".format(variable.attr, cls.__name__))
            if inspect.isfunction(attr): # Method not bound to an object is treated as a function since attr is determined from class not object.
                callable = attr
            else: 
                raise RuleVerificationException("{} is not callable for class {}".format(variable.attr, cls.__name__))
        else:
            raise RuleVerificationException("Require python variable, function or method call but {} is found".format(variable))

            
        hints = typing.get_type_hints(callable)
        return_type = hints.get('return') # https://stackoverflow.com/questions/49560974/inspect-params-and-return-types
        
        #https://stackoverflow.com/questions/74544539/python-how-to-check-what-types-are-in-defined-types-uniontype
        origin = typing.get_origin(return_type)  # For return type with Union or |
        if origin is typing.Union or origin is types.UnionType:   #  types.UnionType if using |
            return_type = typing.get_args(return_type)[0]  # Get only the first type

        return return_type or float
        

    # Variables refers to terms or expressions which their values are not known at verification time. 
    # They represent fields from incoming data.
    # They also represent function or method calls since the verifier doesn't know the exact return value of these.
    # TODO: Use different name suffix of different data types, e.g. xi_1 for int, xf_1 for float.
    # Return the mapped variables x0, x1, ... for seen expressions or create a new one.
    def getOrCreateVariable(self, expr: str, expr_type: typing.Type) -> str:
        idx = self.variable_map.get(expr)
        if idx is None:
            idx = f"x{len(self.variables)}"
            self.variable_map[expr] = idx
            self.variables[idx] = expr_type
            #print(expr, idx)
        return idx
    
        
    def add_constraint(self, expr: str):
        tree = ast.parse(expr, mode='eval')
        constraint = self.visit(tree)  # The returned constraint is converted with mapped variables. 
        self.constraints.append(constraint)

    
    # For assignment statement:
    #   x = a + b   => x = a + b
    #   x = [1, 2]  => x = [1, 2]
    #   x = DATETIME('2020-12-01')  => x = timestamp_1
    #   x = ARRAY([1, 2])  => x = [1, 2]
    #   x = ARRAY([DATETIME('2020-12-01'), DATETIME('2020-12-02')])  => x = [timestamp1, timestamp2]
    def add_assignment(self, name: str, expr: str):
        tree = ast.parse(expr, mode='eval')      
        expression = self.visit(tree)  # The returned expression is converted with mapped variables.
        # Add new variable, assuming no duplication
        idx = f"x{len(self.variables)}"
        self.variable_map[name] = idx
        var_name = idx
        self.variables[var_name] = typing.Any  # Type is Any since this variable is evaluated in python, so Z3 don't know for sure. Since this variable is computed, assign Any should not change the solutions.
        self.assignment_map[var_name] = expression
        #print(name, idx)
     
    
    def get_z3_formulas(self, datetime_ignore_time=True) -> str:
        variable_declarations = []
        for expr, var_name in self.variable_map.items():
            var_type = self.variables[var_name]
            if var_type is typing.Any:
                variable_declaration = "{} = {} # {}".format(var_name, self.assignment_map[var_name], expr)
            elif issubclass(var_type, types.NoneType): 
                variable_declaration = "{} = None".format(var_name)
            elif issubclass(var_type, int):
                variable_declaration = "{} = Int('{}') # {}".format(var_name, var_name, expr)  
            elif issubclass(var_type, float):
                variable_declaration = "{} = Real('{}') # {}".format(var_name, var_name, expr)  
            elif issubclass(var_type, bool):
                variable_declaration = "{} = Bool('{}') # {}".format(var_name, var_name, expr)  
            elif issubclass(var_type, str):
                variable_declaration = "{} = String('{}') # {}".format(var_name, var_name, expr)  
            elif issubclass(var_type, datetime):   # Encoded by float timestamp with constraint
                variable_declaration = "{} = Int('{}') # {}, datetime encoded as int timestamp".format(var_name, var_name, expr)
                if datetime_ignore_time:
                    self.add_constraint("{} % 86400 == 0  # Force date resolution".format(expr))  # For date resolution, modulo it with seconds per day. 82800 = 24*3600
            elif issubclass(var_type, list): 
                # TODO: encode list as a sequence of Ints, Reals, Bools or Strings.
                variable_declaration = "{} = Const('{}', SeqSort(StringSort())) # {}, list always encoded as a sequence of strings".format(var_name, var_name, expr)  
            else:
                raise RuleVerificationException("Cannot convert type {}".format(var_type.__name__))
            variable_declarations.append(variable_declaration)
        
        head_section = "\n".join(variable_declarations)    
        body_section = "solve({})".format(",".join(self.constraints))
        return "\n".join([head_section, body_section])

    
    # Handle DATETIME('2020-01-01'). The args[0] must be string.
    def _DATETIME_casting(self, node: ast.Call) -> datetime:
        if not isinstance(node, ast.Call):
            return None
        
        if node.func.id == 'DATETIME' :          
            if len(node.args) != 1:
                raise RuleVerificationException("DATETIME() requires one argument")
            if isinstance(node.args[0], ast.Constant):
                return DATETIME(ast.literal_eval(node.args[0]))

        return None    


    # Literals are strings, bytes, numbers, tuples, lists, dicts, sets, booleans, None, bytes and sets.
    def _convert_literal(self, node: _LITERAL_TYPE) -> str:
        
        literal = ast.literal_eval(node)
        if isinstance(literal, types.NoneType | int | float | str):
            return repr(literal)
        
        if isinstance(literal, list):
            if len(literal) > 0:
                if not isinstance(literal[0], types.NoneType | int | float | str):
                    raise RuleVerificationException("Element in list must be a primitive data type, but type {} is found".format(type(literal[0])))

                if not all(type(literal[0]) == type(e) for e in literal):
                    raise RuleVerificationException("All elements in list must have the same type")
                
            return repr(literal)
        
        raise RuleVerificationException("Type {} not allow for literal".format(type(literal)))


    def visit_Expression(self, node: ast.Expr) -> str:
        return self.visit(node.body)
    

    def visit_Name(self, node: ast.Name) -> str:  # Variable name
        var_type = self._get_variable_return_type(node)
        var = self.getOrCreateVariable(node.id, var_type)        
        return var


    def visit_Constant(self, node: ast.Constant) -> str: # Primitive constant
        return self._convert_literal(node)


    def visit_List(self, node: ast.List) -> str: # List 
        return self._convert_literal(node)


    #Expr(
    #  value=Call(
    #    func=Name(id='func', ctx=Load()),
    #    args=[],
    #    keywords=[]))
    #
    #Expr(
    #  value=Call(
    #    func=Attribute(
    #      value=Name(id='obj', ctx=Load()),
    #      attr='method',
    #      ctx=Load()),
    #    args=[],
    #    keywords=[]))
    def visit_Call(self, node: ast.Call) -> str: # Function or method call

        if isinstance(node.func, ast.Name): # Special handling for DATETIME() and ARRAY()
            if node.func.id == 'DATETIME' :  # Handle DATETIME('2020-01-01')
                dt = self._DATETIME_casting(node)
                if dt is not None:
                    #return repr(dt)  
                    return repr(dt.timestamp() - EPOCH.timestamp())
                else:
                    pass # Since args[0] may be a name, a Call or others, just create a variable as is.
            
            elif node.func.id == 'ARRAY':  # Handle ARRAY([e1, e2, ...])
                if len(node.args) != 1:
                    raise RuleVerificationException("ARRAY() requires one argument")      
                if isinstance(node.args[0], ast.List):
                    # Check if type of each element is primitive or datetime 
                    if all([isinstance(e, ast.Constant) for e in node.args[0].elts]):  # List of primitive constants
                        arr = [ast.literal_eval(e) for e in node.args[0].elts]
                        return repr(arr) 
                    else:   # List of DATETIME() elements
                        arr = [self._DATETIME_casting(e) for e in node.args[0].elts]
                        if all(arr): # All elements are datetime
                            #return repr(arr)
                            return repr([e.timestamp() - EPOCH.timestamp() for e in arr])
                else:
                    pass # Since args[0] may be a name, a Call or others, just create a variable as is.                

        var_type = self._get_variable_return_type(node)
        return self.getOrCreateVariable(ast.unparse(node), var_type)
    

    #Expr(
    #  value=Attribute(
    #    value=Name(id='obj', ctx=Load()),
    #    attr='attr',
    #    ctx=Load()))        
    def visit_Attribute(self, node: ast.Attribute) -> str: # obj.attr
        raise RuleVerificationException("Get object attribute not supported")
        #var_type = self._get_variable_return_type(node)
        #return self.getOrCreateVariable(ast.unparse(node), var_type)  # We cannot determine the attribute type
            

    def visit_BoolOp(self, node: ast.BoolOp) -> str:
        values = " ".join(["{} {}".format(self.visit(node.op), self.visit(value)) for value in node.values[1:]])
        return "({} {})".format(self.visit(node.values[0]), values)


    def visit_BinOp(self, node: ast.BinOp) -> str:
        l_operand = node.left
        if isinstance(l_operand, _LITERAL_TYPE):
            left = self._convert_literal(l_operand)
        elif isinstance(l_operand, _VAR_TYPE):
            #left_type = self._get_variable_return_type(l_operand)
            #left = self.getOrCreateVariable(ast.unparse(l_operand), left_type)
            left = self.visit(l_operand)
        else: 
            # TODO: what is allowed to visit() or raise Exception
            left = self.visit(l_operand)

        op = self.visit(node.op)
        
        r_operand = node.right
        if isinstance(r_operand, _LITERAL_TYPE):
            right = self._convert_literal(r_operand)
        elif isinstance(r_operand, _VAR_TYPE):
            #right_type = self._get_variable_return_type(r_operand)
            #right = self.getOrCreateVariable(ast.unparse(r_operand), right_type)
            right = self.visit(r_operand)
        else:
            # TODO: what is allowed to visit() or raise Exception
            right = self.visit(r_operand)
       
        return "({} {} {})".format(left, op, right)
    

    def visit_Compare(self, node: ast.Compare) -> str:
        if len(node.ops) > 1:
            raise RuleVerificationException("Support simple comparison expression; but {}".format(ast.unparse(node)))
        
        l_operand = node.left
        if isinstance(l_operand, _LITERAL_TYPE):
            left = self._convert_literal(l_operand)
        elif isinstance(l_operand, _VAR_TYPE):
            #left_type = self._get_variable_return_type(l_operand)
            #left = self.getOrCreateVariable(ast.unparse(l_operand), left_type)
            left = self.visit(l_operand)
        else:
            # TODO: what is allowed to visit() or raise Exception
            left = self.visit(l_operand)

        op = self.visit(node.ops[0])

        r_operand = node.comparators[0]
        if op == 'in':   # Support l_operand in r_operand. 
            # TODO: r_operand is a list variable (sequence in Z3). We need to change the solver to cvc5.
            #  https://stackoverflow.com/questions/59945139/how-i-can-to-check-if-a-const-is-containing-in-a-list-in-z3py
            #  https://stackoverflow.com/questions/78103909/unknown-when-working-sequence-of-type-stringsort

            #  Example:
            #  https://hackmd.io/@s-fish/H1nqUvx6j
            #  from cvc5.pythonic import *   
            #  sseq = Const('sseq', SeqSort(StringSort()))
            #  solve(Contains(sseq, Unit(StringVal('1234'))), Contains(sseq, Unit(StringVal('123'))))   # sseq contains '1234' and '123'
            #
            # 'Operator "in" needs a list or ARRAY of primitive constants
            if isinstance(r_operand, ast.List):   # If r_operand is a list 
                if all([isinstance(e, ast.Constant) for e in r_operand.elts]): # List of primitive constants
                    right = [ast.literal_eval(e) for e in r_operand.elts]   
                else:   # List of DATETIME() elements
                    right = [self._DATETIME_casting(e) for e in r_operand.elts]
                    if not all(right): # Not all elements are datetime
                        raise RuleVerificationException("All elements in ARRAY() must be constant")
                    right = [e.timestamp() - EPOCH.timestamp() for e in right] 
            elif isinstance(r_operand, ast.Call) and isinstance(r_operand.func, ast.Name) and r_operand.func.id == 'ARRAY':  # Handle ARRAY([e1, e2, ...])
                if len(r_operand.args) != 1: 
                    raise RuleVerificationException("ARRAY() requires one argument")   
                if isinstance(r_operand.args[0], ast.List):
                    # Check if type of each element is primitive or datetime 
                    if all([isinstance(e, ast.Constant) for e in r_operand.args[0].elts]):  # List of primitive constants
                        right = [ast.literal_eval(e) for e in r_operand.args[0].elts]
                    else:   # List of DATETIME() elements
                        right = [self._DATETIME_casting(e) for e in r_operand.args[0].elts]
                        if not all(right): # Not all elements are datetime
                            raise RuleVerificationException("All elements in ARRAY() must be constant")     
                        right = [e.timestamp() - EPOCH.timestamp() for e in right]                               
            else:   # For complex operand, cannot unfold into multiple Or, so it is reformed as IS_IN(l_operand, r_operand) == True
                right_type = self._get_variable_return_type(r_operand)
                if not issubclass(right_type, list):
                    raise RuleVerificationException('Operator "in" needs a list or ARRAY of primitive constants but {} is found'.format(right_type))                
                right = self.getOrCreateVariable(ast.unparse(r_operand), right_type)
                reformed = self.getOrCreateVariable('IS_IN({}, {})'.format(left, right), bool) # A variable is created for the reformed IS_IN
                return '({} == True)'.format(reformed)

            if isinstance(right, list):
                if len(right) > 0:
                    if not isinstance(right[0], types.NoneType | int | float | str):
                        raise RuleVerificationException("Element in list must be a primitive data type, but type {} is found".format(type(right[0])))

                    if not all(type(right[0]) == type(e) for e in right):
                        raise RuleVerificationException("All elements in list must have the same type")
            
                    # Unfold 'in' operator to multiple ORs.
                    return 'Or({})'.format(', '.join('{} == {}'.format(left, repr(e)) for e in right))
                else:
                    return '(False)'

            raise RuleVerificationException("Type {} not allow for list literal".format(type(right)))
                
        if isinstance(r_operand, _LITERAL_TYPE):
            right = self._convert_literal(r_operand)
        elif isinstance(r_operand, _VAR_TYPE):
            #right_type = self._get_variable_return_type(r_operand)
            #right = self.getOrCreateVariable(ast.unparse(r_operand), right_type)
            right = self.visit(r_operand)
        else:
            # TODO: what is allowed to visit() or raise Exception
            right = self.visit(r_operand)

        return "({} {} {})".format(left, op, right)


    def visit_Or(self, node: ast.Or) -> str:
        return("or")


    def visit_And(self, node: ast.And) -> str:
        return("and")        
    

    def visit_Eq(self, node: ast.Eq) -> str:
        return("==")


    def visit_NotEq(self, node: ast.NotEq) -> str:
        return("!=")


    def visit_Lt(self, node: ast.Lt) -> str:
        return("<")


    def visit_LtE(self, node: ast.LtE) -> str:
        return("<=")


    def visit_Gt(self, node: ast.Gt) -> str:
        return(">")

    def visit_GtE(self, node: ast.GtE) -> str:
        return(">=")


    def visit_Is(self, node: ast.Is) -> str:
        return("is")


    def visit_IsNot(self, node: ast.IsNot) -> str:
        return("is not")


    def visit_In(self, node: ast.In) -> str:
        return("in")


    # TODO: convert not operator to Z3 Not()
    def visit_NotIn(self, node: ast.NotIn) -> str:
        raise NotImplementedError("No support for operator 'not in'")        
        return("not in")


    def visit_Add(self, node: ast.Add) -> str:
        return("+")


    def visit_Mult(self, node: ast.Mult) -> str:
        return("*")


    # TODO: convert not operator to Z3 Not()
    def visit_Not(self, node: ast.Not) -> str:
        raise NotImplementedError("No support for operator 'not'")
        return("not")     
    

    def visit_Mod(self, node: ast.Mod) -> str:
        return("%")
    

    def generic_visit(self, node: ast.AST) -> str:
        raise NotImplementedError(f"Unsupported syntax '{type(node).__name__}'")
        


class Z3Solver():
    def __init__(self):
        self.solver = Solver()


    def _to_pyval(self, obj: object, value_type: typing.Type) -> object:
        if isinstance(obj, IntNumRef) and issubclass(value_type, bool):
            return obj.as_long() == 1
        elif isinstance(obj, IntNumRef) and issubclass(value_type, int) :
            return obj.as_long()
        elif isinstance(obj, RatNumRef) and issubclass(value_type, float): 
            return obj.numerator_as_long()/obj.denominator_as_long()
        elif isinstance(obj, IntNumRef) and issubclass(value_type, datetime):
            return datetime.fromtimestamp(obj.as_long() +  EPOCH.timestamp())
        elif isinstance(obj, SeqRef) and issubclass(value_type, str):
            return obj.as_string()
        else:
            raise RuleVerificationException("Cannot convert data type Z3 {} into python {}".format(obj.__class__.__name__, value_type.__name__))
        

    # Return solution (dict) or None
    def solve(self, formulas: Z3Formulas, negation: bool = False) -> dict: 
        """
        Find a solution (aka. model) to formulas.

        Parameters
        ----------
        formulas : Z3Formulas
            Z3 formulas object
        negation : bool, default = False
            Negate the formulars before solve, e.g. (x > 1 and y < 0) becomes (x <= 1 or y >=0).

        Returns
        -------
        dict
            A solution if satisfiable or None if unsatisfiable. Each variable appears as a key of dict. 
            If key is not found, it means the value of the variable can be any (don't care).

        Raises
        ------
        Exception
            Any error.

        """        
        symbols = {}  # Variables for Z3       
        expr_map = {}   # Map x1 -> expression
        constraints = []
        for expr, var_name in formulas.variable_map.items():
            var_type = formulas.variables[var_name]
            expr_map[var_name] = expr
            if var_type is typing.Any:
                symbols[var_name] = eval(formulas.assignment_map[var_name], {}, symbols)
            elif issubclass(var_type, types.NoneType): 
                symbols[var_name] = None
            elif issubclass(var_type, int):
                symbols[var_name] = Int(var_name) 
            elif issubclass(var_type, float):
                symbols[var_name] = Real(var_name)
            elif issubclass(var_type, bool):
                symbols[var_name] = Bool(var_name)
            elif issubclass(var_type, str):
                symbols[var_name] = String(var_name)
            elif issubclass(var_type, datetime):
                symbols[var_name] = Int(var_name)   
            elif issubclass(var_type, list): 
                # In Z3, 'Constant' refers to an actual constant (like 1.0) or a variable (like x) without quantifier. 
                # https://stackoverflow.com/questions/12448583/z3-const-declaration
                # TODO: encode list as a sequence of Ints, Reals, Bools or Strings.
                symbols[var_name] = Const(var_name, SeqSort(StringSort())) # list always encoded as a sequence of strings  
            else:
                raise RuleVerificationException("Cannot convert type {}".format(var_type.__name__))

        #print(json.dumps(symbols, indent=2, default=str))            
        
        for c in formulas.constraints:
            if negation:
                constraints.append(Not(eval(c, {'Or': z3.Or}, symbols)))
            else:
                constraints.append(eval(c, {'Or': z3.Or}, symbols))

        if negation:
            self.solver.add(Or(constraints))
        else:
            self.solver.add(And(constraints))
   
        if self.solver.check() == unsat:
            return None
    
        model = self.solver.model()

        # Convert Z3 data types into python data types.
        solution = {expr_map[v.name()]: self._to_pyval(model[v], formulas.variables[v.name()] ) for v in model}
        
        return solution
        

    def is_contradict(self, model: dict) -> bool:
        """
        Check if model is contradict (no possible assignment).

        Parameters
        ----------
        model : dict
            A solution from solve()

        Returns
        -------
        bool
            True if contradict; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """              
        if model is None:   # Unsatisfiable
            return True
        
        return False
    

    def is_tautology(self, model: dict) -> bool:
        """
        Check if model is a tautology (True for any assignment).

        Parameters
        ----------
        model : dict
            A solution from solve()

        Returns
        -------
        bool
            True if tautology; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """              
        if self.is_contradict(model):
            return False
        
        if isinstance(model, dict) and len(model) == 0: # Tautology. All variables are not necessary
            return True
        
        return False    
        

    def is_contingent(self, model: dict) -> bool:
        """
        Check if model is contingent. In other words, the true or false of formulas depends on the variable assignment (data).

        Parameters
        ----------
        model : dict
            A solution from solve()

        Returns
        -------
        bool
            True if not tautology and not contradiction; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """                
        if self.is_contradict(model):
            return False
        
        if self.is_tautology(model):
            return False
        
        return True
        

# TODO: Consider changing symbols to the dict of data type only.
def _verify_paths(node: Node, symbols: dict, state: dict, analysis: dict = {}) -> dict:
    # Verify if the path to a flag node in RulePackage is contingent.
    # node is the current visited node. 
    # symbols is the dict that maps a symbol to an example value or its type. Currently the supported types are 
    #   int, float, str.  TODO: datetime, ARRAY, OBJECTLIST
    # state stores the state of the current node, e.g. list of constraints accumulated from the first node to the current node.

    last_constraints: list[str] = state['constraints'] if 'constraints' in state else []
    last_assignments: list[tuple[str, str]] = state['assignments'] if 'assignments' in state else []
    last_path: list[str] = state['path'] if 'path' in state else []
    new_constraints: list[str] = last_constraints.copy()
    new_assignments: list[tuple[str, str]] = last_assignments.copy()
    new_path: list[str] = last_path.copy()

    if isinstance(node, (ForkNode, BigTableNode)):
        new_path.append(node.node_id)
        state = {'constraints': new_constraints, 'assignments': new_assignments, 'path': new_path}          
        for child in node.children:
            _verify_paths(child, symbols, state, analysis)     

    elif isinstance(node, TransformNode):
        expr = node.transformer.raw
        if not isinstance(expr, str):
            raise RuleVerificationException("Only expression string is supported in verification")
        
        # TODO: check required fields are available
        field_name = node.field_name
        new_path.append(node.node_id)
        new_assignments.append((field_name, expr))
        state = {'constraints': new_constraints, 'assignments': new_assignments, 'path': new_path}
        for child in node.children:
            _verify_paths(child, symbols, state, analysis)

    elif isinstance(node, SelectNode):
        field_names = node.field_names
        new_symbols = {key: symbols[key] for key in symbols if key in field_names}
        new_assignments = [assignment for assignment in new_assignments if assignment[0] in field_names]
        new_path.append(node.node_id)
        state = {'constraints': new_constraints, 'assignments': new_assignments, 'path': new_path}         
        for child in node.children:
            _verify_paths(child, new_symbols, state, analysis)

    elif isinstance(node, SwitchNode):
        expr = node.raw
        if not isinstance(expr, str):
            raise RuleVerificationException("Only expression string is supported in verification")
        
        # TODO: check required fields are available
        for oper, case, child in node.children: # Loop all cases   # TODO: XXX
            new_constraints = last_constraints.copy()
            new_constraints.append("({}) == {}".format(expr, case))
            new_path = last_path.copy()
            new_path.append("{}({})".format(node.node_id, case))
            state = {'constraints': new_constraints, 'assignments': new_assignments, 'path': new_path}       
            _verify_paths(child, symbols, state, analysis)

        if node.default_child is not None:
            new_constraints = last_constraints.copy()
            for oper, case, child in node.children: # Loop all cases to negate them  # TODO: XXX
                new_constraints.append("({}) != {}".format(expr, case))  
            new_path = last_path.copy()
            new_path.append("{}(*)".format(node.node_id))
            state = {'constraints': new_constraints, 'assignments': new_assignments, 'path': new_path}
            _verify_paths(node.default_child, symbols, state, analysis)           

    elif isinstance(node, FlagNode):
        if isinstance(node.template, Template):
            for name in node.template.get_identifiers():
                #facts.add(name)
                # TODO: check required fields are available
                pass
        elif isinstance(node.template, dict):
            query = jsonpath_ng.parse("$..*") # Find all possible children
            for match in query.find(node.template): # For each matching element
                if match.path == jsonpath_ng.jsonpath.Fields('$ref'):
                    #facts.add(match.value) 
                    # TODO: check required fields are available
                    pass
                elif isinstance(match.value, Template):
                    for name in match.value.get_identifiers():
                        #facts.add(name)
                        # TODO: check required fields are available
                        pass                     
        else: 
            raise RuleVerificationException('Unknown template {}'.format(node.template))
        
        z3f = Z3Formulas(symbols)
        for assignment in last_assignments:
            z3f.add_assignment(assignment[0], assignment[1])
        for constraint in last_constraints:
            z3f.add_constraint(constraint)
        path_label = '-> '.join(new_path)
        #print(path_label)
        #print(z3f.get_z3_formulas()) 
        #print("--------------------------------------")
        solver = Z3Solver()
        solution = solver.solve(z3f)
        if solver.is_contradict(solution):
            analysis[path_label] = 'Not reachable'
        elif solver.is_tautology(solution):
            analysis[path_label] = 'Always reachable'
        else:
            analysis[path_label] = solution
            pass
        
        state = {'constraints': new_constraints, 'assignments': new_assignments, 'path': new_path}
        for child in node.children:
            _verify_paths(child, symbols, state, analysis)

    elif isinstance(node, AuditNode):
        raise RuleVerificationException("AuditNode is not supported in verification")
    elif isinstance(node, BranchNode):
        raise RuleVerificationException("BranchNode is not supported in verification")
    else:
        raise RuleVerificationException("Cannot verify node type {}".format(node.__class__.__name__))    
    
    return analysis


def verify_paths(rule_package: RulePackage, symbols: dict) -> dict:
    analysis = {}
    state = {}
    for child in rule_package.children:
        _verify_paths(child, symbols, state, analysis) 

    return analysis


class RuleVerificationException(Exception):
    pass