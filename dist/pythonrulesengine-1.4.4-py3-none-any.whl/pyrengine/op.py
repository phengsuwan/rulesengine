from enum import Enum

# Worth reading.
# https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
# Advanced enum lib https://stackoverflow.com/questions/31537316/python-enums-with-duplicate-values

# OP is used in OBJECTLIST.where(), where.operator, JOINED_OBJECTLIST.check_if() and SwitchNode.
OP = Enum("OP", [
    "gt", 
    "ge", 
    "eq", 
    "neq", 
    "lt", 
    "le", 
    "is_in", 
    "is_not_in", 
    "like",  # Match pattern in a string, ignoring case.
    "not_like", # Do not match pattern in a string, ignoring case.
    ">",
    ">=",
    "=", 
    "<>",
    "<",
    "<=",
    "between",    # For int and float, use <= and <=. For datetime, use <= and <.
    "not_between",
    #  Following operators are supported in SwithNode only.
    "contains",   # Check if left operand (array) contains right operand.
    "is_overlap",    #  Check if left and right operands (arrays) contains at least one common element.
    "is_not_overlap",
])
OP.__doc__ = "" # Suppression Enum docstring

# class OP(Enum):
#     """
#     OP is used to define operator in OBJECTLIST.where() and JOINED_OBJECTLIST_FOR.check_if().

#     Example
#     -------
#     >>> objectlist.where("amount", "gt", 0)

    
#     >>> from pyrengine.op import OP
#     >>> objectlist.where("amount", OP.gt, 0)

#     """
#     gt = 0
#     ge = 1
#     eq = 2
#     neq = 3
#     lt = 4
#     le = 5
#     is_in = 6  # 'in' is a python reserved word.
#     is_not_in = 7
#     #: Match pattern in a string, ignoring case.
#     like = 8
#     #: Do not match pattern in a string, ignoring case.
#     not_like = 9
