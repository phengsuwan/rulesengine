from __future__ import annotations # For forware reference
import json
import csv
import os
from typing import Type, Self
from ast import literal_eval

from pyrengine.objectlist import ARRAY, OBJECTLIST
from typing import Union

REFERENCE_DIR = "./db/lookup"

# Disable pdoc3 document generating for developer methods
__pdoc__ = {
    'LOOKUP.cache': False,
    'LOOKUP.listtable': False,
    'LOOKUP.load': False,
    'LOOKUP.reference_dir': False,
    'LOOKUP.remove': False,
    'LOOKUP.reset': False,
    'LOOKUP.set': False,
    'LOOKUP.set_reference_dir': False,
    'LOOKUP_TABLE_META': False,
}

# current version will support only three data types
# another data type will be proceeded by 'eval' method 
TYPE_CONVERTER = {
    'str': str,
    'float': float,
    'int': int,
}


# Make inherited methods like LOOKUP.where() to returns LOOKUP_TABLE instead of OBJECTLIST.
# https://stackoverflow.com/questions/65917217/wrap-all-methods-of-python-superclass
# https://discuss.python.org/t/return-child-object-when-parent-methods-are-called/21337/2
def _wrap_objectlist_method(fun):
    """Turn from Base- to Child-instance-returning function."""
    def wrapper(*args, **kwargs):
        result = fun(*args, **kwargs)
        if type(result) is OBJECTLIST:
            return LOOKUP_TABLE(result)
        return result
    
    return wrapper


# LOOKUP_TABLE_META class is used to override __new__() method of the LOOKUP_TABLE class.
# https://divyakhatnar.medium.com/metaclass-in-python-bbf4a628e978
class LOOKUP_TABLE_META(type):

    def __new__(cls, name, bases, dct):
        child = super().__new__(cls, name, bases, dct)
        for base in bases:
            for field_name, field in base.__dict__.items():  # For inherited fields
                # https://stackoverflow.com/questions/7751930/is-there-a-way-to-identify-an-inherited-method-in-python
                if callable(field) and field_name not in child.__dict__:  # Field is a method and it is not overridden
                    setattr(child, field_name, _wrap_objectlist_method(field))
        return child    
    

class LOOKUP():   
    """
    LOOKUP is used to access a static lookup table from external source like JSON or CSV file.

    Example
    -------
    The following expression returns the lookup table named 'group_cs_05'.
    >>> LOOKUP.get('group_cs_05')

    Or equivalently, 
    >>> LOOKUP['group_cs_05']
    """    
    cache = {}
    reference_dir = REFERENCE_DIR

    # set_reference_dir is used to set the lookup table base directory 
    @classmethod
    def set_reference_dir(cls, reference_dir=REFERENCE_DIR): 
        cls.reference_dir = reference_dir


    @classmethod
    def __dtype(cls, val, data_type) -> Type:
        try:
            result = TYPE_CONVERTER[data_type](val)
            # result = TYPE_CONVERTER[data_type](literal_eval(val))
        except KeyError:
            try: 
                result = literal_eval(val)
            except: 
                result = None
        except Exception as e:
            result = None
    
        return result


    # check a file in the lookup table directory and identify file type (json or csv)
    # if file does not exist or file extensions are not json nor csv, the method will return None
    @classmethod
    def __lookup_file(cls, name: str) -> str: 
        if os.path.isfile('{}/{}.json'.format(cls.reference_dir, name)): 
            lftype = "json"
        elif os.path.isfile('{}/{}.csv'.format(cls.reference_dir, name)): 
            lftype = "csv"
        else: 
            print('file {}'.format(name) + ' missed, either json or csv format')
            lftype = None

        return lftype


    # load csv file to create lookup table
    @classmethod
    def __lookup_csv(cls, name: str) -> Self: 
        filename = '{}/{}.csv'.format(cls.reference_dir, name)
        #print('Loading {}'.format(filename))
        try: 
            with open(filename, 'r', encoding="utf8") as f:
                cr = csv.reader(f, delimiter=',')
                headers = next(cr, None)
                dtypes = next(cr, None)
                num_cols = len(headers)
                csv_dict = [{headers[i]: cls.__dtype(row[i], dtypes[i]) for i in range(num_cols)} for row in cr]
                ref = LOOKUP_TABLE(csv_dict)
                cls.cache[name] = ref
                return ref
        except Exception as ex:
            print('Loading file {}'.format(filename) + ' failed: {}'.format(ex))
            return None


    # TODO: Check file format.
    # TODO: Error handling.
    @classmethod
    def __load_json(cls, name: str) -> Self:
        filename = '{}/{}.json'.format(cls.reference_dir, name)
        #print('Loading {}'.format(filename))
        try:
            with open(filename, 'r') as f:
                ref = json.load(f)
                ref = LOOKUP_TABLE(ref)
                cls.cache[name] = ref
                return ref
        except Exception as ex:
            print('Loading file {}'.format(filename) + ' failed: {}'.format(ex))
            return None


    @classmethod
    def load(cls, name: str) -> Self:
        lf_type = cls.__lookup_file(name)
        if lf_type is not None: 
            f_lookup = cls.__load_json if lf_type == "json" else cls.__lookup_csv
            return f_lookup(name)
        else: 
            return None


    @classmethod
    def get(cls, name: str) -> Self:
        """
        Return a static lookup table from external source like JSON or CSV file.

        Returns
        -------
        `pyrengine.lookup.LOOKUP_TABLE`
            A static lookup table from external source like JSON or CSV file.

        Example
        -------
        The following expression returns the lookup table named 'group_cs_05'.
        >>> LOOKUP.get('group_cs_05')

        Or equivalently, 
        >>> LOOKUP['group_cs_05']        

        Raises
        ------
        Exception
            Any errors cause exception.
        """            
        if name not in cls.cache:
            rt=cls.load(name)
            if rt is None:
                 #return None
                 raise Exception("LOOKUP has no {}".format(name))

        return cls.cache[name]

    # Class subscription
    # https://stackoverflow.com/a/63663183
    # https://stackoverflow.com/questions/73562722/extending-generic-class-getitem-in-python-to-accept-more-params
    @classmethod
    def __class_getitem__(cls, name: str) -> Self:  # Support LOOKUP[name]  
        return cls.get(name)
        
    @classmethod
    def set(cls, name: str, db: Union[list, OBJECTLIST]) -> bool:
        if not isinstance(db, OBJECTLIST):
            db = OBJECTLIST(db)
        cls.cache[name]=db
        return True

    @classmethod
    def remove(cls, name: str) -> bool:
        rf=False
        if name in cls.cache:
            rf=True
            del cls.cache[name]

        return rf

    @classmethod
    def listtable(cls) -> list:
        ret=[]
        for r in cls.cache.keys():
            ret.append(r)

        return ret
    
    @classmethod
    def reset(cls) -> bool:
        cls.cache.clear()

        return True
    

class LOOKUP_TABLE(OBJECTLIST, metaclass=LOOKUP_TABLE_META):  # Use LOOKUP_TABLE_META to wrap superclass methods 
    '''
    LOOKUP_TABLE is a subclass of `pyrengine.objectlist.OBJECTLIST`.
    It uses hash indices when joined with the left OBJECTLIST. For example, 
    >>> objectlist.inner_join(lookup_table, 'fscode')

    But if used as in the left side like `lookup_table.inner_join(objectlist)`, it won't use indices.

    Applying inherited methods on LOOKUP_TABLE like lookup_table.where() results in a new LOOKUP_TABLE. 
    However, the new LOOKUP_TABLE is not added into LOOKUP cache. So using `objectlist.inner_join(lookup_table.where('rate > 1000'))` 
    on different transactions will be so slow.

    '''  
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.index_on_keys = {}
        self.select_cache = {}  # Cache of select() output.
        self.select_distinct_cache = {}  # Cache of select_distinct() output.

    
    # Private methods begin with __
    def __build_index(self, on_keys: list[str]) -> dict:
        index = {}
        for obj in self.data:
            keys = tuple([obj.get(key) for key in on_keys])
            objs = index.get(keys)
            if objs is None:
                objs = []
                index[keys] = objs
            index[keys].append(obj)
        self.index_on_keys[tuple(on_keys)] = index
        return index


    # @override
    def _get_possible_objects_by_keys(self, on_keys: list[str], values: list[object]) -> list[dict]:
        if len(on_keys) != len(values):
            raise Exception("Size of argument on_keys {} and values {} not matched".format(on_keys, values))
        index = self.index_on_keys.get(tuple(on_keys))
        if index is None:
            #raise Exception('No index on keys {}'.format(on_keys))
            index = self.__build_index(on_keys)

        objs = index.get(tuple(values), [])
        return objs 


    # @override
    def select(self, column: Union[str, list], use_cache=True) -> Union[ARRAY, LOOKUP_TABLE]:
        if isinstance(column, list):
            k = tuple(column)
        else:
            k = column
        if not use_cache or k not in self.select_cache:
            output = super().select(column)
            if type(output) is OBJECTLIST:
                output = LOOKUP_TABLE(output)
            self.select_cache[k] = output

        return self.select_cache[k]
    
    
    # @override
    def select_distinct(self, column: Union[str, list], use_cache=True) -> Union[ARRAY, LOOKUP_TABLE]:
        if isinstance(column, list):
            k = tuple(column)
        else:
            k = column
        if not use_cache or k not in self.select_distinct_cache:
            output = super().select_distinct(column)
            if type(output) is OBJECTLIST:
                output = LOOKUP_TABLE(output)
            self.select_distinct_cache[k] = output

        return self.select_distinct_cache[k]    
    

    # @override
    def __str__(self) -> str:
        return 'LOOKUP_TABLE({})'.format(self.data)
    

    def to_string(self) -> str:    
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([str(o) for o in self.data]))
        else:
            table = ''
        return 'LOOKUP_TABLE([{}])'.format(table)   


    def __repr__(self) -> str:
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([repr(o) for o in self.data]))
        else:
            table = ''        
        return 'LOOKUP_TABLE([{}])'.format(table)     
     