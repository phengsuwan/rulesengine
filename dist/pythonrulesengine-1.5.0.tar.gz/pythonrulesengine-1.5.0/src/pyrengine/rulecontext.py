import contextvars

# Transaction context used to pass current transaction to all methods (per thread) instead of passing it by an argument.
# https://stackoverflow.com/questions/73274021/python-contextvars-pass-and-access-a-variable-along-the-chain-of-calls
txcntx = contextvars.ContextVar('txcntx', default=None)  

# LOOKUP context
lookupcntx = contextvars.ContextVar('lkcntx', default=None)

# Worth reading
# https://stackoverflow.com/questions/31465702/how-do-i-programatically-find-what-symbols-were-imported-with-python-import-co
# Default classes or functions to be included in FunctionCall eval()
# These symbols can be globally overrided by main program (or other modules in the same process) with
#
# from pyrengine.compiler import register_function
# register_function('find_duplicated_items', a_function)
FUNCTIONCALL_SYMBOLS = {}

