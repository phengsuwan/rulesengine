from datetime import datetime
from typing import Dict, Optional,Union,Tuple
from pyrengine.objectlist import *
from string import Template

def get_intersect_object_list(
    x:OBJECTLIST,
    y:OBJECTLIST,
    key:str,
    show_details:Optional[bool] = False
    ) -> Union[ARRAY[str], Dict[str,OBJECTLIST]]:
    """
    Get intersection of two OBJECTLISTs based on the key
    
    Parameters
    ----------
    x : OBJECTLIST
        An OBJECTLIST
    y : OBJECTLIST
        An OBJECTLIST
    key : str
        The string to use as the key. Use '$your_attribute' for represent any attribute
    show_details : (Optional) bool=False
        given true for show more details
    Returns
    -------
    ARRAY (return when show_details is false)
        An ARRAY of intersection keys 
    dict (return when show_details is true)
        A dict to map intersect key to the intersect members per each intersection group

    Raises
    ------
    Exception
        Any errors cause exception.
    NotImplementedError
        Unsupported operation or arguments.
        
    Example
    -------
    >>>  get_intersect_object_list(
    >>>    OBJECTLIST([
    >>>    {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx1','stdcode': 'A002', 'billgrcs': 'A', 'qty': 21},]),
	>>>    OBJECTLIST([
    >>>    {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx2','stdcode': 'B002', 'billgrcs': 'B', 'qty': 21},]),
	>>>    key="$stdcode")
    ARRAY(['A001']) 
    >>>  get_intersect_object_list(
    >>>    OBJECTLIST([
    >>>    {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx1','stdcode': 'A002', 'billgrcs': 'A', 'qty': 21},]),
	>>>    OBJECTLIST([
    >>>    {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx2','stdcode': 'B002', 'billgrcs': 'B', 'qty': 21},]),
	>>>    key="$billgrcs|$stdcode", show_details=True)
    {'A|A001': OBJECTLIST([
        {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12, '__intersect_key': 'A|A001'}
        {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12, '__intersect_key': 'A|A001'}
    ])}
    """ 
    template = Template(key)
    
    
    new_x = OBJECTLIST([{**i,"__intersect_key":template.substitute(i)} for i  in x])
    new_y = OBJECTLIST([{**i,"__intersect_key":template.substitute(i)} for i  in y])
    
    intersect_results = {}
    for results_x in new_x:
        results_x : dict
        __intersect_key = results_x.get("__intersect_key")
        results_y = new_y.where("__intersect_key","eq",__intersect_key) # results_y is an OBJECTLIST
        if results_y.count() >= 1:
            intersect_results[__intersect_key] = OBJECTLIST([results_x,*results_y])
    if show_details:
        return intersect_results
    return ARRAY(intersect_results.keys())


def similarity_score(x:OBJECTLIST,y:OBJECTLIST,key:str) -> Tuple[float,Dict[str,OBJECTLIST]]:
    """
    Calculate similarity score for x and y based on the key
    
    Parameters
    ----------
    x : OBJECTLIST
        An OBJECTLIST
    y : OBJECTLIST
        An OBJECTLIST
    key : str
        The string to use as the key. Use '$your_column' for represent any column
    
    Returns
    -------
    Tuple
        float
            The similarity score between 0.0 (no matched) to 1.0 (exact matched).
        Dict [str,OBJECTLIST]
            intersect results for x and y

    Raises
    ------
    Exception
        Any errors cause exception.
    NotImplementedError
        Unsupported operation or arguments.
        
    Example
    -------
    >>> similarity_score(ARRAY(['stdcode1']), ARRAY(['stdcode1', 'stdcode2']))
    0.6666666666
    """ 
    
    intersect_things = get_intersect_object_list(x,y,key,show_details=True)
    score = 2*len(ARRAY(intersect_things.keys()))/(x.count() + y.count())
    return score,intersect_things
    

def find_duplicated_items(c_serv :OBJECTLIST):
    c_serv_item_code_list = c_serv.select(["item_code","billgrcs"])
    results = []    
    for serv_item in c_serv :
        stdcode = serv_item["stdcode"]
        item_code = serv_item["item_code"]
        _data_count = get_intersect_object_list(
            c_serv,
            c_serv_item_code_list,
            key="$billgrcs|$item_code",
            show_details=True
            )
        count = list(_data_count.values())[0].count()
        count -= 1 
        if count >= 2 : 
            data = dict()
            data["billgrcs"] = serv_item["billgrcs"]
            data["stdcode"] = stdcode
            data["item_code"] = item_code
            data["count"] = count
            results.append(data)
    return OBJECTLIST(results)


def calculate_duplication_score(
        trans_no: str,
        hcode: str,
        pdx : str,
        c_serv: OBJECTLIST,
        c_trans_by_date: OBJECTLIST
    ):
    c_scores = []
    this_c_serv_with_trans_no = OBJECTLIST([{"trans_no":trans_no,**i} for i in c_serv])
    
    for t in c_trans_by_date:
        that_c_serv_with_trans_no = OBJECTLIST([{"trans_no":t['trans_no'],**i} for i in  t['c_serv']])
        
        item_score,c_intersect_c_serv = similarity_score(
            this_c_serv_with_trans_no,
            that_c_serv_with_trans_no,
            key="$billgrcs|$item_code")
        
        hcode_score = 1 if hcode == t['hcode'] else 0
        pdx_score = 1 if pdx == t['pdx'] else 0
        c_scores.append({
            "trans_source" : trans_no,
            "trans_target" : t["trans_no"],
            "hcode_score" :  hcode_score ,
            "pdx_score" :  pdx_score ,
            "item_score" : item_score,
            "duplication_score" :  ( hcode_score * 0.25)+ (pdx_score * 0.25)+ (item_score * 0.5),
            "send_date" : t['send_date'],
            'c_intersect_c_serv': OBJECTLIST(c_intersect_c_serv),
        })
    return OBJECTLIST(c_scores)
