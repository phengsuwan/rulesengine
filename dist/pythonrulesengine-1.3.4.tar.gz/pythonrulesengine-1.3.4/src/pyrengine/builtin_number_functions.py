from pyrengine.objectlist import ARRAY
def _template(a:float,b:float)->float:
    """
    description here.

    Parameters
    ----------
    a: description in one line and not end with full stops
    b: description in one line and not end with full stops

    Returns
    -------
    float: description in one line and not end with full stops

    Raises
    ------
    ValueError: you can skip this part , if function dose not raise anything
    
    Examples
    --------
    >>> _template(2.0, 2.0)
    4.0
    
    Profile
    -------
    ```{json}
    {
        "name": "function_name", 
        "display_name" : "Function name",
        "description": "description here.", 
        "params" : [
            { "name" : "a" , "description" : "description ..." , "type" : ["number"]},
            { "name" : "b" , "description" : "description ..." , "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    pass
    
def add(a: float, b: float) -> float:
    """
    Add two numbers.

    Parameters
    ----------
    a: The first number
    b: The second number

    Returns
    -------
    float: The sum of a and b

    Examples
    --------
    >>> add(2.0, 2.0)
    4.0
    
    Profile
    -------
    ```{json}
    {
        "name": "add", 
        "display_name": "A + B (number)",
        "description": "Add two numbers.", 
        "params" : [
            { "name" : "a" , "description" : "the first number" , "type" : ["number"]},
            { "name" : "b" , "description" : "the second number" , "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """


    return a + b


def multiply(a: float, b: float) -> float:
    """
    Multiply two numbers

    Parameters
    ----------
    a: The first number
    b: The second number

    Returns
    -------
    float: The product of a and b

    Examples
    --------
    >>> multiply(2.0, 2.0)
    4.0
    
    Profile
    -------
    ```{json}
    {
        "name": "multiply", 
        "display_name": "A x B (number)",
        "description": "Multiply two numbers", 
        "params" : [
            { "name" : "a" , "description" : "the first number" , "type" : ["number"]},
            { "name" : "b" , "description" : "the second number" , "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    
    return a * b


def subtract(a: float, b: float) -> float:
    """
    Subtract the second number from the fist number.

    Parameters
    ----------
    a: The number to be subtracted from
    b: The number to subtract

    Returns
    -------
    float: The result of `a - b`
    
    Examples
    --------
    >>> subtract(2.0, 2.0)
    0.0
    
    Profile
    -------
    ```{json}
    {
        "name": "subtract", 
        "display_name": "A - B (number)",
        "description": "Subtract the second number from the fist number.", 
        "params" : [
            { "name" : "a" , "description" : "the first number" , "type" : ["number"]},
            { "name" : "b" , "description" : "the second number" , "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    return a - b


def divide(a: float, b: float) -> float:
    """
    Divide the first number by the second.

    Parameters
    ----------
    a: The dividend
    b: The divisor

    Returns
    -------
    float: The result of `a / b`

    Raises
    ------
    ZeroDivisionError: If `b` is zero

    Examples
    --------
    >>> divide(2.0, 2.0)
    1.0
    
    Profile
    -------
    ```{json}
    {
        "name": "divide", 
        "display_name": "A / B (number)",
        "description": "Divide the first number by the second.", 
        "params" : [
            { "name" : "a" , "description" : "the first number" , "type" : ["number"]},
            { "name" : "b" , "description" : "the second number" , "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b

def floor_division(a:float, b:float) -> int:
    """
    Computes the floor division of two numbers.

    Parameters
    ----------
    a: The dividend in the floor division operation
    b: The divisor in the floor division operation

    Returns
    -------
    int: The result of the floor division of `a` by `b`
    
    Raises
    ------
    ZeroDivisionError: If `b` is zero
    
    Examples
    --------
    >>> floor_division(10, 3)
    3
    >>> floor_division(10.5, 3)
    3

    Profile
    -------
    ```{json}
    {
        "name": "floor_division", 
        "display_name": "A // B (number)",
        "description": "Computes the floor division of two numbers", 
        "params" : [
            { "name" : "a", "description" : "The dividend in the floor division operation.", "type" : ["number"]},
            { "name" : "b", "description" : "The divisor in the floor division operation.", "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a // b

def modulus(a: float, b: float) -> int:
    """
    Computes the modulus of two numbers.

    Parameters
    ----------
    a: The dividend in the modulus operation
    b: The divisor in the modulus operation

    Returns
    -------
    float: The remainder of the division of `a` by `b`
    
    Raises
    ------
    ZeroDivisionError: If `b` is zero
    
    Examples
    --------
    >>> modulus(10.0, 3.0)
    1.0

    Profile
    -------
    ```{json}
    {
        "name": "modulus", 
        "display_name": "A % B (number)",
        "description": "Computes the modulus of two numbers.", 
        "params" : [
            { "name" : "a", "description" : "The dividend in the modulus operation.", "type" : ["number"]},
            { "name" : "b", "description" : "The divisor in the modulus operation.", "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a % b

def power(a: float, b: float) -> float:
    """
    Computes the power of a number raised to an exponent.

    Parameters
    ----------
    a: The base number
    b: The exponent to which the base is raised

    Returns
    -------
    float: The result of raising `a` to the power of `b`.

    Examples
    --------
    >>> power(2.0, 3.0)
    8.0

    Profile
    -------
    ```{json}
    {
        "name": "power", 
        "display_name": "A ^ B (number)",
        "description": "Computes the power of a number raised to an exponent.", 
        "params" : [
            { "name" : "a", "description" : "The base number.", "type" : ["number"]},
            { "name" : "b", "description" : "The exponent to which the base is raised.", "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    return a ** b

def round_number(a: float, ndigits: int) -> float:
    """
    Rounds a number to a specified number of decimal places.

    Parameters
    ----------
    a: The number to be rounded
    ndigits: The number of decimal places to round to. If `ndigits` is less than or equal to 0, the number is rounded to the nearest integer

    Returns
    -------
    float: The rounded number

    Examples
    --------
    >>> round_number(3.14159, 2)
    3.14
    >>> round_number(2.1,0)
    2

    Profile
    -------
    ```{json}
    {
        "name": "round_number", 
        "display_name": "ROUND (number)",
        "description": "Rounds a number to a specified number of decimal places.", 
        "params" : [
            { "name" : "a", "description" : "The number to be rounded.", "type" : ["number"]},
            { "name" : "ndigits", "description" : "The number of decimal places to round to. If less than or equal to 0, rounds to the nearest integer.", "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    if ndigits <= 0:
        ndigits = None
    return round(a, ndigits)

def abs_number(a:float) -> float:
    """
    Calculate the absolute value of a number.

    Parameters
    ----------
    a: the number for which to calculate the absolute value

    Returns
    -------
    float: the absolute value of the input number

    Examples
    --------
    >>> abs_number(-3.5)
    3.5
    >>> abs_number(2.0)
    2.0

    Profile
    -------
    ```{json}
    {
        "name": "abs_number", 
        "display_name": "ABS (number)",
        "description": " Calculate the absolute value of a number", 
        "params" : [
            { "name" : "a" , "description" : "the number for which to calculate the absolute value" , "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```
    """
    return abs(a)

########################################################################
### ARRAY
########################################################################

def min_number(a:ARRAY[float])->float:
    """
    Find the minimum number in a list of numbers.

    Parameters
    ----------
    a: List of number values to find the minimum from

    Returns
    -------
    float: The minimum value in the list

    Raises
    ------
    ValueError: If the list is empty

    Examples
    --------
    >>> min_number([1.0, 2.0, 3.0])
    1.0

    Profile
    -------
    ```{json}
    {
        "name": "min_number", 
        "display_name" : "Min (number)",
        "description": "Find the minimum number in a list of numbers.", 
        "params" : [
            { "name" : "a" , "description" : "List of number values to find the minimum from" , "type" : ["list_number"] }
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```

    """
    if not a:
        raise ValueError("The list is empty")
    return min(a)
def max_number(a:ARRAY[float])->float:
    """
    Find the maximum number in a list of numbers.

    Parameters
    ----------
    a: List of number values to find the maximum from

    Returns
    -------
    float: The maximum value in the list

    Raises
    ------
    ValueError: If the list is empty

    Examples
    --------
    >>> max_number([1.0, 2.0, 3.0])
    3.0

    Profile
    -------
    ```{json}
    {
        "name": "max_number", 
        "display_name" : "Max (number)",
        "description": "Find the maximum number in a list of numbers.", 
        "params" : [
            { "name" : "a" , "description" : "List of number values to find the maximum from" , "type" : ["list_number"] }
        ],
        "return_type" : {
            "type" : "number"
        }
    }
    ```

    """
    if not a:
        raise ValueError("The list is empty")
    return max(a)

