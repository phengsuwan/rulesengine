import decimal
import jsonpath_ng
import html
import graphviz
import json
import random

from string import Template
from datetime import datetime
from typing import Iterable

from pyrengine.objectlist import OBJECTLIST
from pyrengine.objectlist import ARRAY
from pyrengine.model import RulePackage

TYPE_MAPPING = {
    "str": "",
    "int": 0,
    "float": 0.0,
    "bool": False,
    "datetime": '2024-01-01 00:00:00',
    "OBJECTLIST": OBJECTLIST([]),
    "ARRAY": ARRAY([])
}

# filter fields that contain array list and convert
# into OBJECTLIST object
def convert(input_json):
    fields_names = list(input_json.keys())
    for fn in fields_names:
        if type(input_json[fn]) is list : 
            if len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict :
                input_json[fn] = OBJECTLIST(input_json[fn])
            else: 
                input_json[fn] = ARRAY(input_json[fn])
    return input_json

# This is the previous version of convert
# def convert(input_json):
#     fields_names = list(input_json.keys())
#     for fn in fields_names:
#         if type(input_json[fn]) is list and len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict:
#             input_json[fn] = OBJECTLIST(input_json[fn])
#     return input_json


# Update the rule dict by *non-verbose* audit tree dict. The structure of rule dict and 
#   result dict are required to be compatible; otherwise an exception or unexpected outcome occurs.
# https://stackoverflow.com/questions/71396284/python-how-to-recursively-merge-2-dictionaries
def merge_rule_result(rule: dict, result: dict):
    for key, val in result.items():
        if key == "__result__":
            rule[key] = val
            continue

        if key in rule:
            if isinstance(val, dict):
                if not isinstance(rule[key], dict):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a dict".format(key))
                merge_rule_result(rule[key], val)
            elif isinstance(val, list):
                if not isinstance(rule[key], list):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a list".format(key))
                if len(val) != len(rule[key]):
                    raise Exception("The value of rule's key {} has different length than that of result".format(key))
                for i in range(len(val)):
                    if not isinstance(val[i], dict):
                        raise Exception("Expect element {} of result's key {} to be a dict".format(i, key))
                    if not isinstance(rule[key][i], dict):
                        raise Exception("Expect element {} of rule's key {} to be a dict".format(i, key))                
                    merge_rule_result(rule[key][i], val[i])
            else:
                pass # Skip other primitive values
        else:
            raise Exception('Unknown result key {}'.format(key))


def validate_by_example(obj: object, example: dict, deep = False, numeric_compatible=False) -> bool:
    """
    A helper function to validate data type of an input object. The structure of 
    the input object must be a superset of the example, i.e. having same or more keys with
    the exact same data type (not subclasses).

    Parameters
    ----------
    obj : object
        An input oject 
    example : dict
        An object prototype. 
    deep : bool, optional
        Recursively validate sub-structure too, by default False (Not implemented yet).
    numeric_compatible : bool, optional
        Allow int and float and decimal.Decimal values to be compatible, by default False.

    Returns
    -------
    bool
        True if the input object has the same structure as least as the example.

    Raises
    ------
    NotImplementedError
        Not implemented yet. Future maybe.
    Exception
        Any error found.
    """    
    if deep:
        raise NotImplementedError('deep validation not support yet')
    
    if not isinstance(obj, dict):
        raise NotImplementedError('For now, obj argument must be a dict')
    
    for key in example:
        if key not in obj:
            raise Exception('Key {} not found in the obj'.format(key))
        
        if numeric_compatible and isinstance(example[key], (int, float, decimal.Decimal)) and isinstance(obj[key], (int, float, decimal.Decimal)):
            continue
        
        if type(obj[key]) != type(example[key]):
            raise Exception('The value of {} is of type {} but expected {}'.format(key, type(obj[key]).__name__, type(example[key]).__name__))
        
    return True

def json_rules_to_example(rules: Iterable[dict], dtype: dict) -> dict:
    """
    A helper function to generate example json data from a list of rules and type mapping file. 
    The field names come from rule condition. The data types come from mapping file. 

    Parameters
    ----------
    rules : Iterable[dict]
        A sequence of json rules. 
    dtype : dict
        A type mapping for json data. 

    Returns
    -------
    dict
        example json (dict) data.

    Raises
    ------
    NotImplementedError
        Not implemented yet. Future maybe.
    Exception
        Any error found.
    """    

    query = jsonpath_ng.parse("$..[fact]") # Find any facts in the tree
    example = {}
    for rule in rules:
        for match in query.find(rule): # For each matching fact
            fieldname = match.value
            if isinstance(fieldname, str):
                fieldtype = dtype.get(fieldname)
                if fieldtype is None:
                    raise Exception("Field name {} is not found in type mapping file".format(fieldname))
                mapped_fieldtype = TYPE_MAPPING.get(fieldtype)
                if mapped_fieldtype is None:
                    raise Exception("Field type {} is unknown".format(fieldtype))

                example[fieldname] = mapped_fieldtype

    return example


def to_lowercase_key(input: dict | list) -> dict | list:
    """
    A helper function to convert all keys of dict to lowercase recursively, including dicts in any 
    objectlists.
    Keys must be string; otherwise an exception raises.

    Parameters
    ----------
    input : dict | list
        An input dict. If input is a list, apply to each element in the list. 

    Returns
    -------
    dict | list
        Output dict or list, corresponding to the input.

    Raises
    ------
    Exception
        Any error found.
    """    

    if isinstance(input, dict):
        output = {k.lower(): to_lowercase_key(v) if isinstance(v, (dict, list)) else
                                OBJECTLIST([to_lowercase_key(o) for o in v.data]) if isinstance(v, OBJECTLIST) else 
                                v
                  for k, v in input.items()}        
    elif isinstance(input, list):
        output = [to_lowercase_key(e) if isinstance(e, (dict, list)) else
                    OBJECTLIST([to_lowercase_key(o) for o in e.data]) if isinstance(e, OBJECTLIST) else
                    e
                  for e in input]
    else:
        raise NotImplementedError("Unsupport data type {}".format(type(input)))

    return output


def _property_diff(old: dict, new: dict) -> dict:
    old_keys = set(old.keys())
    new_keys = set(new.keys())
    added_properties = set(new_keys).difference(old_keys)
    deleted_properties = set(old_keys).difference(new_keys)
    same_properties = set(old_keys).intersection(new_keys)
    diff = {}
    if added_properties:
        diff['add'] = [{'property': key, 'value': new[key]} for key in sorted(added_properties)]
    if deleted_properties:
        diff['delete'] = [{'property': key, 'value': old[key]} for key in sorted(deleted_properties)]
    if same_properties:
        modified = [{'property': key, 'old_value': old[key], 'new_value': new[key]} for key in sorted(same_properties) if old[key] != new[key]] 
        if modified: 
            diff['modify'] = modified
    return diff


def rpdiff(old: RulePackage | dict, new: RulePackage | dict) -> dict:
    """
    Compare two rule packages.

    Parameters
    ----------
    old : RulePackage | dict
        Old rule package or json graph.
    new : RulePackage | dict
        New rule package or json graph. 

    Returns
    -------
    dict
        Changes (add, delete, modify) between two versions.
    """ 

    # First, convert to json graph for comparison.
    if isinstance(old, dict):
        o = RulePackage.from_graph(old)  # Validate format
        old = o.to_graph()  # Get properties only what we want
    elif isinstance(old, RulePackage):
        old = RulePackage.to_graph()  # Convert to json graph

    if isinstance(new, dict):
        n = RulePackage.from_graph(new)  # Validate format
        new = n.to_graph()  # Get properties only what we want
    elif isinstance(new, RulePackage):
        new = RulePackage.to_graph()  # Convert to json graph    

    old_package_id = old['package_id']
    new_package_id = new['package_id']        

    old_components = dict()
    old_components.update({node['node_id']: node for node in old.get('nodes') or []})
    old_components.update({(edge['src_id'], edge['dst_id']): edge for edge in old.get('edges') or []})
    old_components.update({(old_package_id, node_id): None for node_id in old.get('attached_nodes') or []})

    new_components = dict()
    new_components.update({node['node_id']: node for node in new.get('nodes') or []})
    new_components.update({(edge['src_id'], edge['dst_id']): edge for edge in new.get('edges') or []})
    new_components.update({(old_package_id, node_id): None for node_id in new.get('attached_nodes') or []})

    diff = {}
    """
    # diff dict looks like:
    diff = {
        'add': {
            'nodes': [

            ],
            'edges': [

            ],
            'attached_nodes': [

            ]
        },
        'delete': {
            'nodes': [

            ],
            'edges': [

            ],
            'attached_nodes': [
                
            ]
        },
        'modify': {
            'package': {
                'modify': [
                    {'property': 'package_id', 'old_value': 'a', 'new_value': 'x'},
                ],
            },
            'nodes': [
                {
                    'node_id': 'abcde',
                    'add': [
                        {'property': 'template', 'value': 'Hello World'},
                    ],
                    'delete': [
                        {'property': 'property2', 'value': 'Some value'},
                    ]
                    'modify': [
                        {'property': 'node_type', 'old_value': 'a', 'new_value': 'x'},
                        {'property': 'expression', 'old_value': 'b', 'new_value': 'y'}
                    ]
                },
                {
                    'node_id': '12344', 
                    'modify': [
                        {'property': 'node_type', 'old_value': 'a', 'new_value': 'x'},
                        {'property': 'expression', 'old_value': 'a', 'new_value': 'x'}
                    ]
                }
            ], 
            'edges': [
                {
                    'src_id': 'a',
                    'dst_id': 'b',
                    'add': [
                        {'property': 'property3', 'value': 'Some value'},
                    ],
                    'modify': [
                        {'property': 'case', 'old_value': 'a', 'new_value': 'x'}
                    ]
                }

            ]

        }
    }
    """

    # Check nodes
    old_nodes = {node['node_id'] for node in old.get('nodes') or []}
    new_nodes = {node['node_id'] for node in new.get('nodes') or []}
    added_nodes = new_nodes.difference(old_nodes)
    deleted_nodes = old_nodes.difference(new_nodes)
    if added_nodes:
        if 'add' not in diff:
            diff['add'] = {}
        diff['add']['nodes'] = [new_components[node] for node in sorted(added_nodes)]
    if deleted_nodes:
        if 'delete' not in diff:
            diff['delete'] = {}
        diff['delete']['nodes'] = [old_components[node] for node in sorted(deleted_nodes)]

    # Check edges
    old_edges = {(edge['src_id'], edge['dst_id']) for edge in old.get('edges') or []}
    new_edges = {(edge['src_id'], edge['dst_id']) for edge in new.get('edges') or []}
    added_edges = new_edges.difference(old_edges)
    deleted_edges = old_edges.difference(new_edges)
    if added_edges:
        if 'add' not in diff:
            diff['add'] = {}        
        diff['add']['edges'] = [new_components[edge] for edge in sorted(added_edges)]
    if deleted_edges:
        if 'delete' not in diff:
            diff['delete'] = {}        
        diff['delete']['edges'] = [old_components[edge] for edge in sorted(deleted_edges)]

    # Check attached nodes
    old_attached_nodes = {node_id for node_id in old.get('attached_nodes') or []}     
    new_attached_nodes = {node_id for node_id in new.get('attached_nodes') or []}
    added_attached_nodes = new_attached_nodes.difference(old_attached_nodes)
    deleted_attached_nodes = old_attached_nodes.difference(new_attached_nodes)
    if added_attached_nodes:
        if 'add' not in diff:
            diff['add'] = {}         
        diff['add']['attached_nodes'] = sorted(added_attached_nodes)
    if deleted_attached_nodes:
        if 'delete' not in diff:
            diff['delete'] = {}        
        diff['delete']['attached_nodes'] = sorted(deleted_attached_nodes)

    # Check property change
    if old_package_id != new_package_id:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['package'] = {
            'modify': [
                {'property': 'package_id', 'old_value': old_package_id, 'new_value': new_package_id}
            ]
        }
    same_nodes = old_nodes.intersection(new_nodes)
    modified_nodes = []
    for node in sorted(same_nodes):
        prop_diff = _property_diff(old_components[node], new_components[node])
        if prop_diff:
            node_diff = {'node_id': old_components[node]['node_id']}
            node_diff.update(prop_diff)
            modified_nodes.append(node_diff)
    if modified_nodes:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['nodes'] = modified_nodes

    
    modified_edges = []
    same_edges = old_edges.intersection(new_edges)
    for edge in sorted(same_edges):
        prop_diff = _property_diff(old_components[edge], new_components[edge])
        if prop_diff:
            edge_diff = {'src_id': old_components[edge]['src_id'], 'dst_id': old_components[edge]['dst_id']}
            edge_diff.update(prop_diff)
            modified_edges.append(edge_diff)
    if modified_edges:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['edges'] = modified_edges     

    return diff


def  rpdiff_to_graphviz(old: RulePackage | dict, new: RulePackage | dict) -> graphviz.graphs.Digraph:
    """
    Compare two rule packages.

    Parameters
    ----------
    old : RulePackage | dict
        Old rule package or json graph.
    new : RulePackage | dict
        New rule package or json graph. 

    Returns
    -------
    graphviz.graphs.Digraph
        A graph in graphviz dot language format to show changes (add, delete, modify) between two versions.
    """     
    diff = rpdiff(old, new)

    delete_color = 'lightgray'  # '#FFCCCC'
    add_color = 'blue'
    modify_color = 'red'

    # all_components are union of old and new components.
    all_nodes = old.get('nodes') or []
    all_edges = old.get('edges') or []
    all_attached_nodes = old.get('attached_nodes') or []
    color_map = {}
    if diff.get('add') is not None:
        if diff['add'].get('nodes') is not None:
            all_nodes = all_nodes + diff['add']['nodes']
            color_map.update({node['node_id']: add_color for node in diff['add']['nodes']})
        if diff['add'].get('edges') is not None:
            all_edges = all_edges + diff['add']['edges']
            color_map.update({(edge['src_id'], edge['dst_id']): add_color for edge in diff['add']['edges']})
        if diff['add'].get('attached_nodes') is not None:
            all_attached_nodes = all_attached_nodes + diff['add']['attached_nodes']
            color_map.update({(old['package_id'], node_id): add_color for node_id in diff['add']['attached_nodes']})

    if diff.get('delete') is not None:
        if diff['delete'].get('nodes') is not None:
            color_map.update({node['node_id']: delete_color for node in diff['delete']['nodes']})
        if diff['delete'].get('edges') is not None:
            color_map.update({(edge['src_id'], edge['dst_id']): delete_color for edge in diff['delete']['edges']})
        if diff['delete'].get('attached_nodes') is not None:
            color_map.update({(old['package_id'], edge['dst_id']): delete_color for edge in diff['delete']['attached_nodes']})

    if diff.get('modify') is not None:
        if diff['modify'].get('package') is not None:
            color_map.update({old['package_id']: modify_color})
        if diff['modify'].get('nodes') is not None:
            color_map.update({node['node_id']: modify_color for node in diff['modify']['nodes']})
        if diff['modify'].get('edges') is not None:
            color_map.update({(edge['src_id'], edge['dst_id']): modify_color for edge in diff['modify']['edges']})

    all_components = {}
    all_components.update({node['node_id']: node for node in all_nodes})
    all_components.update({(edge['src_id'], edge['dst_id']): edge for edge in all_edges})
    all_components.update({(old['package_id'], node_id): None for node_id in all_attached_nodes})

    # TODO: Find better way to display modified components.
    # new_components is a dict used only for displaying modified package and edges.
    new_components = {}
    new_components.update({node['node_id']: node for node in new.get('nodes') or []})
    new_components.update({(edge['src_id'], edge['dst_id']): edge for edge in new.get('edges') or []})
    new_components.update({(new['package_id'], node_id): None for node_id in new.get('attached_nodes') or []})    

    g = graphviz.Digraph(old['package_id'])
    g.attr(rankdir='LR')
    node_shapes = {
        'BigTableNode': 'cylinder',
        'ForkNode': 'point', 
        'TransformNode': 'rect', 
        'SelectNode': 'invtrapezium',
        'SwitchNode': 'switch', 
        'FlagNode': 'parallelogram', 
        'AuditNode': 'circle',
        'BranchNode': 'diamond'
    }
    nodes = {node_type: [] for node_type, node_shape in node_shapes.items()}

    for node in all_nodes:
        nodes[node['node_type']].append(node)

    edges = {}
    for edge in all_edges:
        if edges.get(edge['src_id']) is None:
            edges[edge['src_id']] = []
        edges[edge['src_id']].append(edge)

    g.attr('node', shape = 'folder')
    color = color_map.get(old['package_id'], 'black')
    if color == modify_color and old['package_id'] != new['package_id']:
        label = '<<s>{}</s> {}>'.format(html.escape(old['package_id']), html.escape(new['package_id']))
    else: 
        label = html.escape(old.get('name') if old.get('name') else old['package_id']) 
    g.node(old['package_id'], label=label, color=color, fontcolor=color)
    for node_type, node_list in nodes.items():
        shape = node_shapes[node_type]
        if shape == 'switch':
            g.attr('node', shape = 'record')
            for node in node_list:
                rows = []
                node_name = html.escape(node.get('name')) if node.get('name') else node['node_id']
                rows.append('<selector> {}'.format(node_name))
                idx = 0
                for edge in edges.get(node['node_id']) or []:
                    rows.append('<f{}> '.format(idx))
                    idx = idx + 1   
                label = '|'.join(rows)  # https://graphviz.org/Gallery/directed/datastruct.html
                color = color_map.get(node['node_id'], 'black')
                g.node(node['node_id'], label=label, color=color, fontcolor=color)
        else:
            g.attr('node', shape=shape)
            for node in node_list:
                #label = html.escape(node.get('name')) if node.get('name') else (node['node_id'] if node['node_type'] != 'FlagNode' else node['flag'])
                label = html.escape(node.get('name')) if node.get('name') else node['node_id']
                color = color_map.get(node['node_id'], 'black')
                g.node(node['node_id'], label=label, color=color, fontcolor=color) 

    for node_id in all_attached_nodes:
        dst = '{}:selector'.format(node_id) if all_components[node_id]['node_type'] == 'SwitchNode' else node_id    
        color = color_map.get((old['package_id'], node_id), 'black')
        g.edge(old['package_id'], dst, color=color, fontcolor=color)   
    for node_id, edge_list in edges.items():
        if all_components[node_id]['node_type'] == 'SwitchNode':
            idx = 0
            for edge in edge_list:
                dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                if edge.get('case') is not None:
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        new_case_or_default = new_edge.get('case') or 'default'
                        label = '<<s>{}</s> {}>'.format(html.escape(str(edge['case'])), html.escape(new_case_or_default)) 
                    else: 
                        label = html.escape(str(edge['case']))
                    g.edge('{}:f{}'.format(node_id, idx), dst, color=color, fontcolor=color, label=label)
                elif 'default' in edge:
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        new_case_or_default = new_edge.get('case') or 'default'
                        label = '<<s>default</s> {}>'.format(html.escape(new_case_or_default)) 
                    else: 
                        label = 'default'                    
                    g.edge('{}:f{}'.format(node_id, idx), dst, color=color, fontcolor=color, label=label)
                idx = idx + 1
        elif all_components[node_id]['node_type'] == 'BranchNode':
            for edge in edge_list:
                if edge.get('case') is not None:
                    dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        label = '<<s>{}</s> {}>'.format(edge['case'], new_edge['case']) 
                    else: 
                        label = str(edge['case'])                          
                    g.edge(node_id, dst, label=label, color=color, fontcolor=color)                        
        else:
            for edge in edge_list:
                dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                color = color_map.get((node_id, edge['dst_id']), 'black')              
                g.edge(node_id, dst, color=color, fontcolor=color)

    return g            


# Create sankey plot function


# https://observablehq.com/@d3/sankey-component
def create_sankey_plot(rule_package: RulePackage, metrics: dict = None) -> str: 
    """
    Create sankey plot of traffic flow based on metrics.

    Parameters
    ----------
    rule_package: RulePackage
        Rule package.
    metrics : dict
        Metrics  

    Returns
    -------
    str
        HTML string with SVG sankey plot.
    """       
    gv = rule_package.to_graphviz()
    json_string = gv.pipe(format='json', encoding='utf-8')
    json_dict = json.loads(json_string)
    bounding_box = [float(i) for i in json_dict['bb'].split(',')]  # x0,y0,x1,y1
    width = bounding_box[2]
    height = bounding_box[3]
    #print(json.dumps(json_dict, indent=2))
    node_position_map = {}
    for obj in json_dict['objects']:
        node_position_map[obj['name']] = tuple([float(i) for i in obj['pos'].split(',')]) # node_id -> (x, y)

    # Convert into 0.0 - 1.0 range and flip vertically.
    node_position_map = {k: (v[0], height - v[1]) for k, v in node_position_map.items()} 
    #print(node_position_map)    

    value_map = {}
    if metrics is None:
        metrics = rule_package.get_metrics().to_dict()
    for metric in metrics['traffic']:
        src_id = metric['key'][0]
        dst_id = metric['key'][1]
        value_map[(src_id, dst_id)] = metric['value']
    #print(value_map)    

    graph = rule_package.to_graph()
    nodes = [
        {'id': rule_package.package_id, 
        'type': rule_package.__class__.__name__,
        'gv_x': node_position_map[rule_package.package_id][0], 
        'gv_y': node_position_map[rule_package.package_id][1]
        }
    ]
    nodes = nodes + [
        {'id': node['node_id'], 
        'name': node.get('name', ''),
        'type': node['node_type'],
        'gv_x': node_position_map[node['node_id']][0], 
        'gv_y': node_position_map[node['node_id']][1]
        } 
        for node in graph['nodes']
    ]
    links = []
    for child in rule_package.children:
        links.append({'source': rule_package.package_id, 'target': child.node_id, 'value': value_map.get((rule_package.package_id, child.node_id), 0.1)}) 
    links = links + [{'source': edge['src_id'], 'target': edge['dst_id'], 'value': value_map.get((edge['src_id'], edge['dst_id']), 0.1)} for edge in graph['edges']]
    #print(nodes)
    #print(links)

    graph = {
        'nodes': nodes,
        'links': links
    }    

    template = '''
      <!DOCTYPE html>
      <head>
        <style>
        .link:hover {
          stroke-opacity: 0.5;
          fill-opacity: 0.5;
        }
        </style>
      </head>
      <h1>$title</h1>
      <div id="$div_id"></div>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.js"></script>
      <!--script src="https://d3js.org/d3.v7.min.js"></script>
      <script src="https://unpkg.com/d3-array@1"></script>
      <script src="https://unpkg.com/d3-collection@1"></script>
      <script src="https://unpkg.com/d3-path@1"></script>
      <script src="https://unpkg.com/d3-shape@1"></script>
      <script src="https://unpkg.com/d3-sankey@0.12.3/dist/d3-sankey.js"></script-->

      <script>
        requirejs.config({
            paths: {
              "d3": "https://d3js.org/d3.v7.min",
              "d3-array": "https://unpkg.com/d3-array@1.2.4/dist/d3-array.min",
              "d3-collection": "https://unpkg.com/d3-collection@1.0.7/dist/d3-collection.min",
              "d3-path": "https://unpkg.com/d3-path@1.0.9/dist/d3-path.min",
              "d3-shape": "https://unpkg.com/d3-shape@1.3.7/dist/d3-shape.min",
              "d3-sankey": "https://unpkg.com/d3-sankey@0.12.3/dist/d3-sankey"
            },
            shim: {  // dependencies
              "d3-sankey": ["d3"]
            }
        });

        /*
        graph = {
          "nodes":[
            {"id":0,"name":"node0"},
            {"id":1,"name":"node1"},
            {"id":2,"name":"node2"},
            {"id":3,"name":"node3"},
            {"id":4,"name":"node4"}
          ],
          "links":[
            {"source":0,"target":2,"value":2},
            {"source":1,"target":2,"value":2},
            {"source":1,"target":3,"value":2},
            {"source":0,"target":4,"value":2},
            {"source":2,"target":3,"value":2},
            {"source":2,"target":4,"value":2},
            {"source":3,"target":4,"value":4}
          ]
        } 
        */

        graph = $graph

        require(['d3', 'd3-array', 'd3-collection', 'd3-path', 'd3-shape', 'd3-sankey'], 
          function (d3, d3array, d3collection, d3path, d3shape, d3sankey) {
            runit()

            function runit() {
              color = d3.scaleOrdinal(d3.schemeCategory10);  // Auto node color
              node_color_map = {  // Manually define node color
                'RulePackage': 'blue',
                'ForkNode': 'lightgreen', 
                'TransformNode': 'lightskyblue', 
                'SelectNode': 'lightseagreen',
                'SwitchNode': 'gold', 
                'FlagNode': 'orange', 
                'AuditNode': 'olive',
                'BranchNode': 'gold'    
              }              

              width = $width
              height = $height
              nodes = graph.nodes
              links = graph.links
              linkStrokeOpacity = 0.2, // link stroke opacity
              linkMixBlendMode = "multiply", // link blending mode
              linkPath = d3sankey.sankeyLinkHorizontal(), // given d in (computed) links, returns the SVG path
              nodeLabelPadding = 6, // horizontal separation between node and label    
              nodeWidth = 30, // width of node rects
              nodePadding = 30, // vertical separation between adjacent nodes
              nodeLabelPadding = 6, // horizontal separation between node and label
              arrowLen = 15 // if 0, no arrow.    

              // Compute node position
              d3sankey.sankey()
                .nodeId(function(d) {return d.id})
                .nodeWidth(nodeWidth)
                .nodePadding(nodePadding)      
                .extent([[0, 0], [width, height]])
                ({nodes, links})

              // Compute adjusted node height
              for (const node of nodes) {
                node.adjusted_height = Math.max(...[d3.max(node.sourceLinks, l => l.width), d3.max(node.targetLinks, l => l.width)].filter(e => !isNaN(e))) // d3.max([], f) returns undefined
              }      

              // We must update position x0,x1,y0,y1 of all nodes according to graphviz
              for (const node of nodes) {
                node.y0 = node.gv_y
                node.y1 = node.y0 + node.adjusted_height
                node.x0 = node.gv_x
                node.x1 = node.gv_x + nodeWidth
              }      

              // https://gist.github.com/KatiRG/90a972bad9109ae556c0
              d3sankey.sankey().update(graph);  // Recompute link positions          

              // Set node name
              for (const node of nodes) {
                if (!node.name) {
                  node.name = node.id
                }
              }      

              console.log(graph)   
              
              svg = d3.select("#$div_id")
                      .append("svg")                  
                        .attr("width", width)        
                        .attr("height", height * 1.25)
                        .attr("style", "background-color: white")

              if (arrowLen == 0) {
                // Calculate link source and target positions. If source is not a SwitchNode, use Y-center of node.
                linkPath = d3.linkHorizontal()
                  // Always use center X and Y of node.
                  //.source(d => [d.source.x1, (d.source.y0 + d.source.y1)/2])
                  //.target(d => [d.target.x0, (d.target.y0 + d.target.y1)/2])
                  .source(d => [d.source.x1, (d.source.type == 'SwitchNode' || d.source.type == 'BranchNode' ? d.y0 : (d.source.y0 + d.source.y1)/2)])
                  .target(d => [d.target.x0, d.y1])
            
                // Draw links
                link = svg.append("g")
                  .attr("fill", "none")
                  .attr("stroke-opacity", linkStrokeOpacity)
                  //.style("mix-blend-mode", linkMixBlendMode);  
                  .selectAll("path")
                  .data(links)
                  .join("path")
                    .attr("class", "link")
                    .attr("d", linkPath)
                    .attr("stroke", "black")
                    .attr("stroke-width", ({width}) => Math.max(1, width))
                    .call(path => path.append("title").text(d => d.source.name + "->" + d.target.name + "\\n" + (d.value >= 1 ? d.value : 0) )); // Set link title  

              } else {
                // Link arrow 
                //   https://github.com/plotly/plotly.js/blob/master/src/traces/sankey/render.js 
                //   https://www.sankey-diagrams.com/sankeys-with-circular-links/ 
                //   https://observablehq.com/@tomshanley/sankey-circular-deconstructed
                // Calculate link source and target positions for arrow link. 
                linkPath = function(d) {
                  curvature = 0.5
                  maxArrowLength = Math.abs((d.target.x0 - d.source.x1) / 2);
                  if(arrowLen > maxArrowLength) {
                    arrowLen = maxArrowLength;
                  }
                  x0 = d.source.x1;
                  y0 = (d.source.type == 'SwitchNode' || d.source.type == 'BranchNode' ? d.y0 : (d.source.y0 + d.source.y1)/2)
                  x1 = d.target.x0 - arrowLen;
                  y1 = d.y1
                  x2 = x3 = curvature * (x1-x0) + x0;
                  y0a = y0 - d.width / 2;
                  y0b = y0 + d.width / 2;
                  y1a = y1 - d.width / 2;
                  y1b = y1 + d.width / 2;
                  start = 'M' + x0 + ',' + y0a;
                  upperCurve = 'C' + x2 + ',' + y0a +
                    ' ' + x3 + ',' + y1a +
                    ' ' + x1 + ',' + y1a;
                  lowerCurve = 'C' + x3 + ',' + y1b +
                    ' ' + x2 + ',' + y0b +
                    ' ' + x0 + ',' + y0b;

                  rightEnd = arrowLen > 0 ? 'L' + (x1 + arrowLen) + ',' + (y1a + d.width / 2) : '';
                  rightEnd += 'L' + x1 + ',' + y1b;
                  return start + upperCurve + rightEnd + lowerCurve + 'Z';                
                }                                   

                // Draw links with filled area
                link = svg.append("g")
                  .attr("fill", "none")
                  .attr("stroke-opacity", linkStrokeOpacity)
                  //.style("mix-blend-mode", linkMixBlendMode);  
                  .selectAll("path")
                  .data(links)
                  .join("path")
                    .attr("class", "link")
                    .attr("d", linkPath)
                    .attr("fill", "black")
                    .attr("fill-opacity", linkStrokeOpacity)
                    .attr("stroke", "black")
                    .attr("stroke-width", ({width}) => width > 1 ? 0 : 1)  // If filled area, no stroke is needed.
                    .call(path => path.append("title").text(d => d.source.name + "->" + d.target.name + "\\n" + (d.value >= 1 ? d.value : 0) )); // Set link title  
                
              }

              // Draw link labels at the middle of link
              const  linkLabel = svg.append("g")
                .attr("font-family", "sans-serif")
                .attr("font-size", 10)      
                .selectAll("text")
                .data(links)
                .enter()
                  .append("text")
                  .attr("x", function(d) { return d.source.x0 + (d.target.x1 - d.source.x0)/2; })
                  .attr("y", function(d) { return ((d.source.type == 'SwitchNode' || d.source.type == 'BranchNode' ? d.y0 : (d.source.y0 + d.source.y1)/2) + d.y1)/2; }) 
                  .text(function(d) {return d.value < 1 ? 0 : d.value;})

              // Create graphic elements for nodes
              const node = svg.append("g")
                //.attr("stroke", nodeStroke)
                //.attr("stroke-width", nodeStrokeWidth)
                //.attr("stroke-opacity", nodeStrokeOpacity)
                //.attr("stroke-linejoin", nodeStrokeLinejoin)
                .attr("font-family", "sans-serif")
                .attr("font-size", 10)      
                .selectAll(".node")
                .data(nodes)
                .join("g")
                  .attr("class", "node")
                  .attr("transform", d => "translate(" + d.x0 + "," + (d.y1 + d.y0 - d.adjusted_height)/2 + ")") 
                  .call(d3.drag()
                    .subject(d => d)
                    .on('start', function () { this.parentNode.appendChild(this); })
                    .on('drag', dragmove))        
            
              // Draw nodes
              node
                .append("rect")
                  .attr("x", 0)
                  .attr("y", 0)
                  .attr("height", d => Math.max(d.adjusted_height, 1))
                  .attr("width", d => d.x1 - d.x0)      
                  //.attr("fill", d => color(d.id))
                  .attr("fill", d => node_color_map[d.type])
                .append("title")
                  .text(d => d.name)  // Hover text

              // Set node labels
              node.append("text")
                //.attr("x", d => d.x0 < width / 2 ? d.x1 + nodeLabelPadding : d.x0 - nodeLabelPadding)
                //.attr("y", d => (d.y1 + d.y0) / 2)
                .attr("x", d => d.x0 < width/2 ? nodeWidth + nodeLabelPadding : - nodeLabelPadding)
                .attr("y", d => d.adjusted_height/2)
                .attr("dy", "0.35em")
                .attr("text-anchor", d => d.x0 < width / 2 ? "start" : "end")
                .text(d => d.name)

              function dragmove(event, d) {
                var rectY = d3.select(this).select("rect").attr("y");
                var rectX = d3.select(this).select("rect").attr("x");
                d.y0 = d.y0 + event.dy;      
                d.y1 = d.y1 + event.dy;   
                d.x1 = d.x1 + event.dx;
                d.x0 = d.x0 + event.dx; 
                var yTranslate = (d.y1 + d.y0 - d.adjusted_height)/2 
                var xTranslate = d.x0 - rectX;
                d3.select(this).attr('transform', "translate(" + (xTranslate) + "," + (yTranslate) + ")");
                d3sankey.sankey().update(graph);  // Recompute link positions
                link.attr('d', linkPath);  // Update link
                linkLabel.attr("x", function(d) { return d.source.x0 + (d.target.x1 - d.source.x0)/2; }) // Update link label x
                linkLabel.attr("y", function(d) { return ((d.source.type == 'SwitchNode' || d.source.type == 'BranchNode' ? d.y0 : (d.source.y0 + d.source.y1)/2) + d.y1)/2; })  // Update link label y
              }    
              
            } // runit()

          }
        )
      
      </script>
    '''
    jstr = Template(template).substitute({'title': 'Sankey', 'graph': json.dumps(graph), 'width': width, 'height': height, 'div_id': 'sankey-id-{}'.format(random.randint(10000, 99999))})
    #print(jstr)

    return jstr    



