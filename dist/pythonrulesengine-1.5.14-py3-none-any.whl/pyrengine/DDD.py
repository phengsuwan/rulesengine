from datetime import datetime
from typing import Dict, Optional,Union,Tuple
from pyrengine.objectlist import *
from string import Template
import pprint
import pyrengine.builtin_objectlist_functions  as objlist_func


def _get_intersect_object_list(
    x:OBJECTLIST,
    y:OBJECTLIST,
    key:str,
    show_details:Optional[bool] = False
    ) -> Union[ARRAY[str], Dict[str,OBJECTLIST]]:
    """
    Get intersection of two OBJECTLISTs based on the key
    
    Parameters
    ----------
    x : OBJECTLIST
        An OBJECTLIST
    y : OBJECTLIST
        An OBJECTLIST
    key : str
        The string to use as the key. Use '$your_attribute' for represent any attribute
    show_details : (Optional) bool=False
        given true for show more details
        
    Returns
    -------
    ARRAY (return when show_details is false)
        An ARRAY of intersection keys 
    dict (return when show_details is true)
        A dict to map intersect key to the intersect members per each intersection group

    Raises
    ------
    Exception
        Any errors cause exception.
    NotImplementedError
        Unsupported operation or arguments.
        
    Examples
    --------
    >>>  get_intersect_object_list(
    >>>    OBJECTLIST([
    >>>    {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx1','stdcode': 'A002', 'billgrcs': 'A', 'qty': 21},]),
	>>>    OBJECTLIST([
    >>>    {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx2','stdcode': 'B002', 'billgrcs': 'B', 'qty': 21},]),
	>>>    key="$stdcode")
    ARRAY(['A001']) 
    >>>  get_intersect_object_list(
    >>>    OBJECTLIST([
    >>>    {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx1','stdcode': 'A002', 'billgrcs': 'A', 'qty': 21},]),
	>>>    OBJECTLIST([
    >>>    {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx2','stdcode': 'B002', 'billgrcs': 'B', 'qty': 21},]),
	>>>    key="$billgrcs|$stdcode", show_details=True)
    {'A|A001': OBJECTLIST([
        {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12, '__intersect_key': 'A|A001'}
        {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12, '__intersect_key': 'A|A001'}
    ])}
    """ 
    template = Template(key)
    
    
    new_x = OBJECTLIST([{**i,"__intersect_key":template.substitute(i)} for i  in x])
    new_y = OBJECTLIST([{**i,"__intersect_key":template.substitute(i)} for i  in y])
    
    intersect_results = {}
    for results_x in new_x:
        results_x : dict
        __intersect_key = results_x.get("__intersect_key")
        results_y = new_y.where("__intersect_key","eq",__intersect_key) # results_y is an OBJECTLIST
        if results_y.count() >= 1:
            intersect_results[__intersect_key] = OBJECTLIST([results_x,*results_y])
    if show_details:
        return intersect_results
    return ARRAY(intersect_results.keys())


def _similarity_score(x:OBJECTLIST,y:OBJECTLIST,key:str) -> Tuple[float,Dict[str,OBJECTLIST]]:
    """
    Calculate similarity score for x and y based on the key
    
    Parameters
    ----------
    x : OBJECTLIST
        An OBJECTLIST
    y : OBJECTLIST
        An OBJECTLIST
    key : str
        The string to use as the key. Use '$your_column' for represent any column
    
    Returns
    -------
    Tuple
        float
            The similarity score between 0.0 (no matched) to 1.0 (exact matched).
        Dict [str,OBJECTLIST]
            intersect results for x and y

    Raises
    ------
    Exception
        Any errors cause exception.
    NotImplementedError
        Unsupported operation or arguments.
        
    Examples
    --------
    >>> similarity_score(OBJECTLIST([
                {'stdcode': 'A001'},
                {'stdcode': 'A002'}
    ]), OBJECTLIST([
                {'stdcode': 'A001'},
                {'stdcode': 'A002'}
    ]),key="$stdcode")
    1.0
    """ 
    
    intersect_things = _get_intersect_object_list(x,y,key,show_details=True)
    score = (2*len(ARRAY(intersect_things.keys())))/(x.count() + y.count())
    return score,intersect_things
    

def count_duplicated_items_v2024(c_serv :OBJECTLIST) -> OBJECTLIST:
    """
    Identify items with duplicate entries based on item_code and bill billgrcs.

    Parameters
    ----------
    c_serv (OBJECTLIST): A OBJECTLIST , each object containing `item_code`, `billgrcs`, and `stdcode`

    Returns
    -------
    OBJECTLIST: An OBJECTLIST, each representing an item with duplicates. Each dictionary includes:
                - `billgrcs` : billgrcs value
                - `stdcode` : stdcode value
                - `item_code` : item_code value
                - `count`: The number of duplicates found (including the current record)

    Examples
    --------
    >>> c_serv = OBJECTLIST([
    >>>    {"item_code":"I001","billgrcs":"B001","stdcode":"S001"},
    >>>    {"item_code":"I001","billgrcs":"B001","stdcode":"S002"},
    >>>    {"item_code":"I001","billgrcs":"B002","stdcode":"S003"},
    >>> ])
    >>> count_duplicated_items_v2024(c_serv)
    OBJECTLIST([
        {"billgrcs": "B001", "stdcode": "S001", "item_code": "I001", "count": 2},
    ])

    Profile
    -------
    ```{json}
    {
        "name": "count_duplicated_items_v2024", 
        "display_name": "Get duplicated items v2024",
        "description": "Identify items with duplicate entries based on item_code and bill billgrcs.", 
        "params" : [
            { "name" : "c_serv" , "description" : "c_serv field" , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "billgrcs" , "description":  "billgrcs value", "type" : "number"},
                {"name" : "stdcode" , "description":  "stdcode value", "type" : "string"},
                {"name" : "item_code" , "description":  "item_code value", "type" : "string"},
                {"name" : "count" , "description":  "number of duplicates found (including the current record)", "type" : "number"}
            ]
        }
    }
    ```
    """
    ## เราใช้ group_by ตรงๆ  ไม่ได้เนื่องจาก stdcode อาจต่างกัน
    results = []
    for serv_item in c_serv :
        stdcode = serv_item["stdcode"]
        item_code = serv_item["item_code"]
        billgrcs = serv_item["billgrcs"]
        c_serv_filtered = c_serv.where("item_code","eq",item_code).where("billgrcs","eq",billgrcs)
        count = c_serv_filtered.count()
        if count >= 2 : 
            data = dict()
            data["billgrcs"] = billgrcs
            data["stdcode"] = stdcode
            data["item_code"] = item_code
            data["count"] = count
            results.append(data)
    return OBJECTLIST(results)


def calculate_duplication_score_v2024(
        trans_no: str,
        hcode: str,
        pdx : str,
        c_serv: OBJECTLIST,
        c_trans_by_date: OBJECTLIST
    ) -> OBJECTLIST:
    """
    Calculate a duplication score between a source transaction and multiple target transactions based on item similarities.
    
    Parameters
    ----------
    trans_no (str): The transaction number for the source transaction.
    hcode (str): The hcode for the source transaction.
    pdx (str): The pdx for the source transaction.
    c_serv (OBJECTLIST): A OBJECTLIST associated with the source transaction.
    c_trans_by_date (OBJECTLIST): A OBJECTLIST, each containing a list of service records.

    Returns
    -------
    OBJECTLIST: A OBJECTLIST, each representing the score between the source transaction and a target transaction. Each item includes:
                - `trans_source`: The source transaction number.
                - `trans_target`: The target transaction number.
                - `hcode_score`: Score based on matching hcode (1 if matches, 0 otherwise).
                - `pdx_score`: Score based on matching pdx (1 if matches, 0 otherwise).
                - `item_score`: Similarity score based on common items.
                - `duplication_score`: Overall duplication score calculated from hcode, pdx, and item scores.
                - `send_date`: The send date of the target transaction.
                - `c_intersect_c_serv`: A collection of intersecting service records between source and target transactions.
                - `details`: A collection of intersecting service records between source and target transactions.

    Examples
    --------
    >>> c_serv = OBJECTLIST([{"item_code":"I001","billgrcs":"B001","qty":1}])
    >>> c_trans_by_date = OBJECTLIST([{
        "trans_no" : "T124",
        "hcode" : "H001",
        "pdx" : "P002",
        "send_date" : "2024-08-05",
        c_serv : OBJECTLIST([{"item_code":"I001","billgrcs":"B001","qty":1}])
    }])
    >>> calculate_duplication_score_v2024("T123", "H001", "P001", c_serv, c_trans_by_date)
    OBJECTLIST([
        {
            "trans_source": "T123",
            "trans_target": "T124",
            "hcode_score": 1,
            "pdx_score": 0,
            "item_score": 1.0,
            "hpi_score": 0.75,
            "send_date": "2024-08-05",
            'c_intersect_c_serv': OBJECTLIST([{"item_code": "I001", "billgrcs": "B001"}]),
        }
    ])
    
    Profile
    -------
    ```{json}
    {
        "name": "calculate_duplication_score_v2024", 
        "display_name": "Calculate duplication score v2024",
        "description": "Calculate a duplication score between a source transaction and multiple target transactions based on item similarities.", 
        "params" : [
            { "name" : "trans_no" , "description" : "trans_no field" , "type" : ["string"]},
            { "name" : "hcode" , "description" : "hcode field" , "type" : ["string"]},
            { "name" : "pdx" , "description" : "pdx field" , "type" : ["string"]},
            { "name" : "c_serv" , "description" : "c_serv field" , "type" : ["objectlist"]},
            { "name" : "c_trans_by_date" , "description" : "c_trans_by_date field" , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "trans_source" , "description":  "the source transaction", "type" : "string"},
                {"name" : "trans_target" , "description":  "the target transaction", "type" : "string"},
                {"name" : "hcode_score" , "description":  "score based on matching hcode", "type" : "number"},
                {"name" : "pdx_score" , "description":  "score based on matching pdx", "type" : "number"},
                {"name" : "item_score" , "description":  "score based on matching item_code", "type" : "number"},
                {"name" : "hpi_score" , "description":  "overall duplication score ", "type" : "number"},
                {"name" : "send_date" , "description":  "the send date of the target transaction ", "type" : "datetime"}
            ]
        }
    }
    ```
    """
    c_scores = []
    this_c_serv_with_trans_no = OBJECTLIST([{"trans_no":trans_no,**i} for i in c_serv])
    
    for t in c_trans_by_date:
        that_c_serv_with_trans_no = OBJECTLIST([{"trans_no":t['trans_no'],**i} for i in  t['c_serv']])
        
        
        item_score,c_intersect_c_serv = _similarity_score(
            this_c_serv_with_trans_no,
            that_c_serv_with_trans_no,
            key="$billgrcs|$item_code") 
        
        hcode_score = 1 if hcode == t['hcode'] else 0
        pdx_score = 1 if pdx == t['pdx'] else 0
        c_scores.append({
            "trans_source" : trans_no,
            "trans_target" : t["trans_no"],
            "hcode_score" :  hcode_score ,
            "pdx_score" :  pdx_score ,
            "item_score" : item_score,
            "send_date" : t['send_date'],
            "hpi_score" :  ( hcode_score * 0.25)+ (pdx_score * 0.25)+ (item_score * 0.5),
            'c_intersect_c_serv': c_intersect_c_serv,
        })
    return OBJECTLIST(c_scores)




def count_duplicated_items(trans_no :str,c_serv :OBJECTLIST) -> OBJECTLIST:
    """
    Identify items with duplicate entries based on item_code and bill billgrcs.

    Parameters
    ----------
    trans_no (str): A transaction number
    c_serv (OBJECTLIST): A OBJECTLIST , each object containing `item_code`, `billgrcs`, and `stdcode`

    Returns
    -------
    OBJECTLIST: An OBJECTLIST, each representing an score with item duplicates. Each dictionary includes:
                - `trans_source`: The source transaction number.
                - `trans_target`: The list of target transaction number.
                - `item_score`:  1 if  there are duplicate items, else 0.
                - `details`: A collection of duplicate items.

    Examples
    --------
    >>> c_serv = OBJECTLIST([
    >>>    {"item_code":"I001","billgrcs":"B001","stdcode":"S001"},
    >>>    {"item_code":"I001","billgrcs":"B001","stdcode":"S002"},
    >>>    {"item_code":"I001","billgrcs":"B002","stdcode":"S003"},
    >>> ])
    >>> count_duplicated_items("T001",c_serv)
    OBJECTLIST([
        {
            "trans_source": "T001",
            "trans_target": ["T001"],
            "item_score": 1,
            'details': OBJECTLIST([{
                "item_code": "I001",
                "billgrcs": "B001",
                "stdcode":["S001","S002","S003"],
                "codesys":["CS001","CS002","CS003"],
                "count":3
            }]),
        }
    ])

    Profile
    -------
    ```{json}
    {
        "name": "count_duplicated_items", 
        "display_name": "Get duplicated items",
        "description": "Identify items with duplicate entries based on item_code and bill billgrcs.", 
        "params" : [
            { "name" : "trans_no" , "description" : "trans_no field" , "type" : ["string"]},
            { "name" : "c_serv" , "description" : "c_serv field" , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "audited_trans" , "description":  "the audited transaction", "type" : "string"},
                {"name" : "audited_source" , "description":  "the audited source", "type" : "string"},
                {"name" : "related_trans" , "description":  "the related transaction", "type" : "list_string"},
                {"name" : "related_source" , "description":  "the related source", "type" : "list_string"},
                {"name" : "item_score" , "description":  "score based on matching item_code", "type" : "number"},
                {"name" : "details" , "description":  "the duplicated items ", "type" : "objectlist"}
            ],
            "collective_fields" : {
                "details" : [
                    {"name" : "billgrcs" , "description":  "billgrcs value", "type" : "string"},
                    {"name" : "item_code" , "description":  "item_code value", "type" : "string"},
                    {"name" : "stdcode" , "description":  "stdcode value", "type" : "list_string"},
                    {"name" : "codesys" , "description":  "codesys value", "type" : "list_string"},
                    {"name" : "count" , "description":  "target'stdcode value", "type" : "number"}
                ]
            }
        }
    }
    ```
    """
    ## เราใช้ group_by ตรงๆ ไม่ได้เนื่องจาก stdcode อาจต่างกัน และเราจะไม่ได้รายละเอียดข้างใน
    results = dict()
    for serv_item in c_serv :
        stdcode_original = serv_item.get("stdcode_original")
        item_code_original = serv_item.get('item_code_original')
        stdcode = serv_item["stdcode"]
        codesys = serv_item["codesys"]
        item_code = serv_item["item_code"]
        billgrcs = serv_item["billgrcs"]
        c_serv_filtered = c_serv.where("item_code","eq",item_code).where("billgrcs","eq",billgrcs)
        count = c_serv_filtered.count()
        if count >= 2 : 
            r_key = f'{billgrcs}|{item_code}'
            data = dict()
            data["billgrcs"] = billgrcs
            data["stdcode"] = [stdcode]
            data["codesys"] = [codesys]
            data["item_code"] = item_code
            data['item_code_original'] = item_code_original
            data['stdcode_original'] = [stdcode_original]
            data["count"] = count
            
            if r_key not in results.keys():
                results[r_key] = data
            else :
                results[r_key]['stdcode'].append(stdcode)
                results[r_key]['stdcode_original'].append(stdcode_original)
                results[r_key]['codesys'].append(codesys)
    results = [v for v in results.values()]
    
    _source = c_serv.select_distinct("source")
    _source = _source[0] if len(_source) else "NHSO-DP" # FIXME hardcode
    _source = _source if _source is not None else "NHSO-DP"

    results = {
        "audited_trans" : trans_no,
        "audited_source" : _source,
        "related_trans" : [trans_no],
        "audited_source" : [_source],
        "item_score" : 1 if len(results) else 0,
        "details" :OBJECTLIST(results)
        }
    return OBJECTLIST([results])



def calculate_duplication_score(
        trans_no: str,
        hcode: str,
        pdx : str,
        c_serv: OBJECTLIST,
        c_trans_by_date: OBJECTLIST
    ) -> OBJECTLIST:
    """
    Calculate a duplication score between a source transaction and multiple target transactions based on item similarities.
    
    Parameters
    ----------
    trans_no (str): The transaction number for the source transaction.
    hcode (str): The hcode for the source transaction.
    pdx (str): The pdx for the source transaction.
    c_serv (OBJECTLIST): A OBJECTLIST associated with the source transaction.
    c_trans_by_date (OBJECTLIST): A OBJECTLIST, each containing a list of service records.

    Returns
    -------
    OBJECTLIST: A OBJECTLIST, each representing the score between the source transaction and a target transaction. Each item includes:
                - `audited_trans`: The source transaction number.
                - `related_trans`: The list of target transaction number.
                - `hcode_score`: Score based on matching hcode (1 if matches, 0 otherwise).
                - `pdx_score`: Score based on matching pdx (1 if matches, 0 otherwise).
                - `item_score`: Similarity score based on common items.
                - `duplication_score`: Overall duplication score calculated from hcode, pdx, and item scores.
                - `send_date`: The send date of the target transaction.
                - `c_intersect_c_serv`: A collection of intersecting service records between source and target transactions.
                - `details`: A collection of intersecting service records between source and target transactions.

    Examples
    --------
    >>> c_serv = OBJECTLIST([{"item_code":"I001","billgrcs":"B001","qty":1,"stdcode":"S001"}])
    >>> c_trans_by_date = OBJECTLIST([{
        "trans_no" : "T124",
        "hcode" : "H001",
        "pdx" : "P002",
        "send_date" : "2024-08-05",
        c_serv : OBJECTLIST([{"item_code":"I001","billgrcs":"B001","qty":1,"stdcode":"S002"}])
    }])
    >>> calculate_duplication_score("T123", "H001", "P001", c_serv, c_trans_by_date)
    OBJECTLIST([
        {
            "audited_trans": "T123",
            "related_trans": ["T124"],
            "hcode_score": 1,
            "pdx_score": 0,
            "item_score": 1.0,
            "hpi_score": 0.75,
            "send_date": "2024-08-05",
            'details': OBJECTLIST([{"item_code": "I001", "billgrcs": "B001","audited_stdcode":"S001","audited_codesys":"CS001","related_stdcode":"S002","audited_codesys":"CS001"}]),
        }
    ])
    
    Profile
    -------
    ```{json}
    {
        "name": "calculate_duplication_score", 
        "display_name": "Calculate duplication score",
        "description": "Calculate a duplication score between a source transaction and multiple target transactions based on item similarities.", 
        "params" : [
            { "name" : "trans_no" , "description" : "trans_no field" , "type" : ["string"]},
            { "name" : "hcode" , "description" : "hcode field" , "type" : ["string"]},
            { "name" : "pdx" , "description" : "pdx field" , "type" : ["string"]},
            { "name" : "c_serv" , "description" : "c_serv field" , "type" : ["objectlist"]},
            { "name" : "c_trans_by_date" , "description" : "c_trans_by_date field" , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "audited_trans" , "description":  "the audited transaction", "type" : "string"},
                {"name" : "audited_source" , "description":  "the audited source", "type" : "string"},
                {"name" : "related_trans" , "description":  "the related transaction", "type" : "list_string"},
                {"name" : "related_source" , "description":  "the related source", "type" : "list_string"},
                {"name" : "hcode_score" , "description":  "score based on matching hcode", "type" : "number"},
                {"name" : "pdx_score" , "description":  "score based on matching pdx", "type" : "number"},
                {"name" : "item_score" , "description":  "score based on matching item_code", "type" : "number"},
                {"name" : "hpi_score" , "description":  "overall duplication score ", "type" : "number"},
                {"name" : "send_date" , "description":  "the send date of the related transaction ", "type" : "datetime"},
                {"name" : "details" , "description":  "the duplicated items ", "type" : "objectlist"}
            ],
            "collective_fields" : {
                "details" : [
                    {"name" : "billgrcs" , "description":  "billgrcs value", "type" : "string"},
                    {"name" : "item_code" , "description":  "item_code value", "type" : "string"},
                    {"name" : "audited_stdcode" , "description":  "audited's stdcode value", "type" : "string"},
                    {"name" : "audited_codesys" , "description":  "audited's codesys value", "type" : "string"},
                    {"name" : "related_stdcode" , "description":  "related's stdcode value", "type" : "string"},
                    {"name" : "related_codesys" , "description":  "related's codesys value", "type" : "string"}
                ]
            }
        }
    }
    ```
    """
    # get tx's source from c_trans_by_date
    audited_source_list = c_trans_by_date.where("trans_no","eq",trans_no).select_distinct("source")
    audited_source = audited_source_list[0] if len(audited_source_list) else 'NHSO-DP' # FIXME : hardcode
    # นำ tx ตัวเองออกจาก c_trans_by_date
    c_trans_by_date = c_trans_by_date.where("trans_no","neq",trans_no)
    this_c_serv_with_trans_no = OBJECTLIST([{"trans_no":trans_no,**i} for i in c_serv])
    # ระวังเรื่อง transaction มีมากกว่า 1 ใน dateadm และ c_serv_ จะมากกว่า ต้องจับกลุ่มกันก่อน
    group_by_keys = ["trans_no","source","hcode","pdx"]
    distinct_c_trans_by_date_by_tx = []
    group_tx_c_trans_by_date = c_trans_by_date.group_by(group_by_keys)
    for k,v in group_tx_c_trans_by_date.data.items():
        new_object = {}
        for t in k: 
            new_object[t[0]] = t[1]
        
        c_serv = OBJECTLIST(v)
        new_object["c_serv"]  = c_serv
        new_object["send_date"] = c_serv.max("send_date")
        
        distinct_c_trans_by_date_by_tx.append(new_object)
    
    distinct_c_trans_by_date_by_tx = OBJECTLIST(distinct_c_trans_by_date_by_tx)
    
    
    c_scores = []
    for t in distinct_c_trans_by_date_by_tx:
        that_c_serv_with_trans_no = OBJECTLIST([{"trans_no":t['trans_no'],**i} for i in  t['c_serv']])
        
        item_score,c_intersect_c_serv = _similarity_score(
            this_c_serv_with_trans_no,
            that_c_serv_with_trans_no,
            key="$billgrcs|$item_code") 
        
        duplicated_items = []
        for d_obj in c_intersect_c_serv.values():
            d_obj : OBJECTLIST 
            try:
                d_item = d_obj.where('trans_no',"eq",trans_no).select(["billgrcs","item_code","stdcode","codesys","stdcode_original","item_code_original"])
                d_item = d_item.rename("stdcode","audited_stdcode").rename("codesys","audited_codesys")
                d_item = d_item.rename("stdcode_original","audited_stdcode_original").rename("item_code_original","audited_item_code_original")
                d_item = d_item.to_list()[0]
                related_codesys = d_obj.where("trans_no","neq",trans_no).select("codesys").to_list()[0]
                related_stdcode = d_obj.where("trans_no","neq",trans_no).select("stdcode").to_list()[0]
                related_stdcode_original = d_obj.where("trans_no","neq",trans_no).select("stdcode_original").to_list()[0]
                related_item_code_original = d_obj.where("trans_no","neq",trans_no).select("item_code_original").to_list()[0]
                d_item["related_stdcode"] = related_stdcode
                d_item["related_stdcode_original"] = related_stdcode_original
                d_item["related_item_code_original"] = related_item_code_original
                d_item["related_codesys"] = related_codesys
                duplicated_items.append(d_item)
            except Exception as e :
                raise e
            
        hcode_score = 1 if hcode == t['hcode'] else 0
        pdx_score = 1 if pdx == t['pdx'] else 0
        c_scores.append({
            "audited_trans" : trans_no,
            "audited_source" : audited_source,
            "related_trans" : [t["trans_no"]],
            "related_source" :[t["source"]],
            "hcode_score" :  hcode_score ,
            "pdx_score" :  pdx_score ,
            "item_score" : item_score,
            "hpi_score" :  ( hcode_score * 0.25)+ (pdx_score * 0.25)+ (item_score * 0.5),
            "send_date" : t['send_date'],
            "details" : OBJECTLIST(duplicated_items)
        })
    return OBJECTLIST(c_scores)

    
def density_filter_c_trans_by_date_from_c_duplication_score(
    c_trans_by_date: OBJECTLIST,
    c_duplication_score: OBJECTLIST
    ) -> OBJECTLIST:
    """
    Filters out transactions from c_trans_by_date that are related to transactions in c_duplication_score.

    Parameters
    ----------
    c_trans_by_date : OBJECTLIST
        The transactions to filter.
    c_duplication_score : OBJECTLIST
        The transactions containing related transaction IDs to remove from c_trans_by_date.

    Returns
    -------
    OBJECTLIST
        The filtered transactions excluding related transactions.

    Raises
    ------
    ValueError
        If the data structure is invalid or required columns are missing.

    Examples
    --------
    >>> density_filter_c_trans_by_date_from_c_duplication_score(c_trans_by_date, c_duplication_score)
    OBJECTLIST([{'trans_no': '12345', 'dateadm': '2023-01-01', 'hcode': 'A1'}, ...])

    Profile
    -------
    ```{json}
    {
        "name": "density_filter_c_trans_by_date_from_c_duplication_score", 
        "display_name" : "Density Filter Transactions",
        "description": "Filters out transactions from c_trans_by_date that are related to transactions in c_duplication_score.", 
        "params" : [
            { "name" : "c_trans_by_date" , "description" : "The transactions to filter." , "type" : ["objectlist"]},
            { "name" : "c_duplication_score" , "description" : "The transactions containing related transaction IDs to remove." , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "inherit_attributes_from" : {
                "source_param" : "c_trans_by_date",
                "source_attr" : "value",
                "self_attr" : "input"
            }
        }
    }
    ```
    """
    
    remove_txs = [item[0] for item in c_duplication_score.select("related_trans").to_list()]
    return c_trans_by_date.where("trans_no","is_not_in",remove_txs)
    
    
    
def density_group_tx(
    c_trans_by_date : OBJECTLIST
    ) -> OBJECTLIST :
    """
    Groups transactions by transaction number and extracts relevant transaction details.

    Parameters
    ----------
    c_trans_by_date : OBJECTLIST
        The data to be grouped by transaction number.

    Returns
    -------
    OBJECTLIST
        The grouped transactions with key details for each transaction.

    Raises
    ------
    ValueError
        If required columns are missing in the input data.

    Examples
    --------
    >>> density_group_tx(c_trans_by_date)
    OBJECTLIST([{'trans_no': '12345', 'dateadm': '2023-01-01', 'hcode': 'A1','service_type':'OP'}, ...])

    Profile
    -------
    ```{json}
    {
        "name": "density_group_tx", 
        "display_name" : "Density Group by Transaction",
        "description": "Groups transactions by transaction number and extracts relevant transaction details.", 
        "params" : [
            { "name" : "c_trans_by_date" , "description" : "The data to be grouped by transaction number." , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                { "name" : "trans_no" , "description" : "The transaction number." , "type" : "string"},
                { "name" : "dateadm" , "description" : "The dateadm." , "type" : "datetime"},
                { "name" : "hcode" , "description" : "The hcode." , "type" : "string"},
                { "name" : "source" , "description" : "The source." , "type" : "string"},
                { "name" : "servicetype" , "description" : "The servicetype." , "type" : "string"}
            ]
        }
    }
    ```
    """
    
    results = []
    g = c_trans_by_date.group_by("trans_no")
    for k,v in g.data.items():
        tx_data = v[0]
        tx_data = {k:v for k,v in tx_data.items() if k in ['trans_no','source','dateadm','hcode','servicetype']}
        results.append(tx_data)
        
    return OBJECTLIST(results)


def density_group_hcode (
    c_trans_by_date : OBJECTLIST,
    return_flat_objectlist:Optional[bool]=False
) -> OBJECTLIST:    
    """
    Groups transactions by healthcare code (hcode) and structures the results.

    Parameters
    ----------
    c_trans_by_date : OBJECTLIST
        The data to be grouped by healthcare code.
    return_flat_objectlist : bool, optional
        Whether to return a flat list or a nested group list, default is True (flat list).

    Returns
    -------
    OBJECTLIST
        The grouped transactions by healthcare code.

    Raises
    ------
    ValueError
        If required columns or data are missing.

    Examples
    --------
    >>> density_group_hcode(c_trans_by_date)
    OBJECTLIST([{'hcode': 'A1', 'txs': [...]}, ...])

    Profile
    -------
    ```{json}
    {
        "name": "density_group_hcode", 
        "display_name" : "Density Group by Hcode",
        "description": "Groups transactions by healthcare code and structures the results.", 
        "params" : [
            { "name" : "c_trans_by_date" , "description" : "The data to be grouped by healthcare code." , "type" : ["objectlist"]},
            { "name" : "return_flat_objectlist" , "description" : "Return a flat object list if True, nested group list if False." , "type" : ["boolean"], "default" : false}

        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                { "name" : "trans_no" , "description" : "The transaction number." , "type" : "string"},
                { "name" : "source" , "description" : "The source." , "type" : "string"},
                { "name" : "dateadm" , "description" : "The dateadm." , "type" : "datetime"},
                { "name" : "hcode" , "description" : "The hcode." , "type" : "string"},
                { "name" : "servicetype" , "description" : "The servicetype." , "type" : "string"},
                { "name" : "group_number" , "description" : "The group number." , "type" : "number"}
            ]

            
        }
    }
    ```
    """
    if not return_flat_objectlist :
        g = c_trans_by_date.group_by("hcode")

        results = []
        for k,v in g.data.items():
            hcode = k[0][1]
            data = {
                "hcode" : hcode,
                "txs" :  OBJECTLIST(v)
            }
            results.append(data)
        return OBJECTLIST(results)
    else :
        return objlist_func.c_flat_group_by(c_trans_by_date,['hcode'],'group_number')

def density_group_dateadm(
    c_trans_by_date_group_by_hcode:OBJECTLIST,
    max_hours:Optional[int]=4,
    return_flat_objectlist:Optional[bool]=False,
    from_flat_obj: Optional[bool]=False
) -> OBJECTLIST:
    """
    Groups transactions based on admission date and groups them based on a time threshold.

    Parameters
    ----------
    c_trans_by_date_group_by_hcode : OBJECTLIST
        The transactions grouped by healthcare code.
    max_hours : int, optional
        The maximum allowed time difference (in hours) for transactions to belong to the same group, default is 4 hours.
    return_flat_objectlist : bool, optional
        Whether to return a flat list or a nested group list, default is False (nested group list).
    from_flat_obj : bool, optional
        Whether to working with a flat list or a nested group list, default is False (nested group list).


    Returns
    -------
    OBJECTLIST
        The grouped transactions by admission date and time difference.

    Raises
    ------
    ValueError
        If the time or grouping column is missing or invalid.

    Examples
    --------
    >>> density_group_dateadm(c_trans_by_date_group_by_hcode, 4, True)
    OBJECTLIST([{'group_number': 1, 'txs': [...]}, ...])

    Profile
    -------
    ```{json}
    {
        "name": "density_group_dateadm", 
        "display_name" : "Density Group by Date and Admission Time",
        "description": "Groups transactions based on admission date and groups them based on a time threshold.", 
        "params" : [
            { "name" : "c_trans_by_date_group_by_hcode" , "description" : "The transactions grouped by healthcare code." , "type" : ["objectlist"]},
            { "name" : "max_hours" , "description" : "Maximum time difference in hours for grouping transactions." , "type" : ["integer"], "default" : 4},
            { "name" : "return_flat_objectlist" , "description" : "Return a flat object list if True, nested group list if False." , "type" : ["boolean"], "default" : false},
            { "name" : "from_flat_obj" , "description" : "Whether to working with a flat list or a nested group list, default is False (nested group list)." , "type" : ["boolean"], "default" : false}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                { "name" : "trans_no" , "description" : "The transaction number." , "type" : "string"},
                { "name" : "dateadm" , "description" : "The dateadm." , "type" : "datetime"},
                { "name" : "hcode" , "description" : "The hcode." , "type" : "string"},
                { "name" : "servicetype" , "description" : "The servicetype." , "type" : "string"},
                { "name" : "group_number" , "description" : "The group number." , "type" : "number"}
            ]

            
        }
    }
    ```
    """
    max_seconds = max_hours * 60 * 60
    
    if from_flat_obj:
        c_trans_by_date_group_by_hcode = density_group_hcode(
            c_trans_by_date_group_by_hcode,
            return_flat_objectlist=False
            )
    
    group_number = 1
    results = []
    for data in c_trans_by_date_group_by_hcode.data:
        _trans_same_hcode:OBJECTLIST = data['txs']
        _trans_same_hcode = _trans_same_hcode.sort("dateadm",ascending=True)
        diffs = [0]+[(j-i).seconds for i,j in zip(_trans_same_hcode.select('dateadm').to_list(),_trans_same_hcode.select('dateadm').to_list()[1:])]
    
        for i in range(len(diffs)):
            _diff = diffs[i]
            _trans = _trans_same_hcode.get(i)
            
            if  _diff <= max_seconds:
                _trans['group_number'] = group_number
            else :
                group_number += 1
                _trans['group_number'] = group_number
            results.append(_trans)
        group_number +=1

    results = OBJECTLIST(results)
    if return_flat_objectlist == True:
        return results
    else :
        new_results = []
        for k,v in results.group_by("group_number").data.items():
            group_number = k[0][1]
            data = {
                "group_number" : group_number,
                "txs" : OBJECTLIST(v)
            }
            new_results.append(data)
        return OBJECTLIST(new_results)

def _get_density_type_score(details:OBJECTLIST) -> Tuple[str,float]:
    h_count = details.select_distinct("hcode").count()
    h_count_ddd_type_score_map = {
        1 : ("Density:1hosp",0.4),
        2 : ("Density:2hosp",0.8),
        3 : ("Density:3hosp",1.0),
    }
    _type,_score = h_count_ddd_type_score_map.get(int(h_count),("Density:3hosp",1.0))
    return _type,_score

def density_create_details_from_group_hcode_from_flat_obj(
    trans_no:str,
    ddd_type : float,
    ddd_score : float,
    c_trans_group_hcode : OBJECTLIST,
) -> OBJECTLIST:    
    """
    Creates detailed transaction information from groups based on healthcare code.

    Parameters
    ----------
    trans_no : str
        The transaction number to use as a reference.
    ddd_type: Type of duplication
    ddd_score: Density score value
    c_trans_group_hcode : OBJECTLIST
        The grouped transactions based on healthcare code.

    Returns
    -------
    OBJECTLIST
        The details of the grouped transactions, including the reference transaction.

    Raises
    ------
    ValueError
        If the transaction number or data structure is invalid.

    Examples
    --------
    >>> density_create_details_from_group_hcode_from_flat_obj('12345','density',1, c_trans_group_hcode)
    OBJECTLIST([{'audited_trans': '12345', 'related_trans': [...], '3d_type': 'density', '3d_score': 1, 'details': [...]}, ...])

    Profile
    -------
    ```{json}
    {
        "name": "density_create_details_from_group_hcode_from_flat_obj", 
        "display_name" : "Create Details from Group by Hcode from flat obj",
        "description": "Creates detailed transaction information from groups based on healthcare code.", 
        "params" : [
            { "name" : "trans_no" , "description" : "The transaction number to use as a reference." , "type" : ["string"]},
            { "name" : "ddd_type" , "description" : "The type of density." , "type" : ["string"]},
            { "name" : "ddd_score" , "description" : "The score value." , "type" : ["number"]},
            { "name" : "c_trans_group_hcode" , "description" : "The grouped transactions based on healthcare code." , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "audited_trans" , "description":  "the audited transaction", "type" : "string"},
                {"name" : "audited_source" , "description":  "the audited source", "type" : "string"},
                {"name" : "related_trans" , "description":  "the related transaction", "type" : "list_string"},
                {"name" : "related_source" , "description":  "the related source", "type" : "list_string"},
                {"name" : "3d_type" , "description":  "3d type ", "type" : "string"},
                {"name" : "3d_score" , "description":  "3d score ", "type" : "number"},
                {"name" : "details" , "description":  "the transactions ", "type" : "objectlist"}
            ],
            "collective_fields" : {
                "details" : [
                    {"name" : "group_number" , "description":  "group number", "type" : "number"},
                    {"name" : "trans_no" , "description":  "transaction number", "type" : "string"},
                    {"name" : "service_type" , "description":  "service type value", "type" : "string"},
                    {"name" : "hcode" , "description":  "hcode value", "type" : "string"},
                    {"name" : "dateadm" , "description":  "date and time of the transaction admission", "type" : "datetime"}
                ]
            }
        }
    }
    ```
    """
    

    details  = c_trans_group_hcode
    denstiy_out = {
        "audited_trans" : trans_no,
        "audited_source" : details.where("trans_no","eq",trans_no).select("source")[0],
        "related_trans" : details.where("trans_no","neq",trans_no).select("trans_no"),
        "related_source" : details.where("trans_no","neq",trans_no).select("source"),
        "3d_type" :ddd_type,
        "3d_score": ddd_score,
        "details" : details
    }
    return OBJECTLIST([denstiy_out])




def density_create_details_from_group_dateadm_from_flat_obj(
    trans_no:str,
    ddd_type : float,
    ddd_score : float,
    c_trans_group_dateadm : OBJECTLIST,
) -> OBJECTLIST:    
    """
    Creates detailed transaction information from groups based on dateadm.

    Parameters
    ----------
    trans_no : str
        The transaction number to use as a reference.
    ddd_type: Type of duplication
    ddd_score: Density score value
    c_trans_group_dateadm : OBJECTLIST
        The grouped transactions based on dateadm.

    Returns
    -------
    OBJECTLIST
        The details of the grouped transactions, including the reference transaction.

    Raises
    ------
    ValueError
        If the transaction number or data structure is invalid.

    Examples
    --------
    >>> density_create_details_from_group_dateadm_from_flat_obj('12345','density',1, c_trans_group_dateadm)
    OBJECTLIST([{'audited_trans': '12345', 'related_trans': [...], '3d_type': 'density', '3d_score': 1, 'details': [...]}, ...])

    Profile
    -------
    ```{json}
    {
        "name": "density_create_details_from_group_dateadm_from_flat_obj", 
        "display_name" : "Create Details from Group by Dateadm from flat obj",
        "description": "Creates detailed transaction information from groups based on dateadm.", 
        "params" : [
            { "name" : "trans_no" , "description" : "The transaction number to use as a reference." , "type" : ["string"]},
            { "name" : "ddd_type" , "description" : "The type of density." , "type" : ["string"]},
            { "name" : "ddd_score" , "description" : "The score value." , "type" : ["number"]},
            { "name" : "c_trans_group_dateadm" , "description" : "The grouped transactions based on dateadm." , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "audited_trans" , "description":  "the source transaction", "type" : "string"},
                {"name" : "related_trans" , "description":  "the target transaction", "type" : "list_string"},
                {"name" : "3d_type" , "description":  "3d type ", "type" : "string"},
                {"name" : "3d_score" , "description":  "3d score ", "type" : "number"},
                {"name" : "details" , "description":  "the transactions ", "type" : "objectlist"}
            ],
            "collective_fields" : {
                "details" : [
                    {"name" : "group_number" , "description":  "group number", "type" : "number"},
                    {"name" : "trans_no" , "description":  "transaction number", "type" : "string"},
                    {"name" : "service_type" , "description":  "service type value", "type" : "string"},
                    {"name" : "hcode" , "description":  "hcode value", "type" : "string"},
                    {"name" : "dateadm" , "description":  "date and time of the transaction admission", "type" : "datetime"}
                ]
            }
        }
    }
    ```
    """

    details  = c_trans_group_dateadm
    denstiy_out = {
        "audited_trans" : trans_no,
        "audited_source" : details.where("trans_no","eq",trans_no).select("source")[0],
        "related_trans" : details.where("trans_no","neq",trans_no).select_distinct("trans_no"),
        "related_source" : details.where("trans_no","neq",trans_no).select("source"),
        "3d_type" :ddd_type,
        "3d_score": ddd_score,
        "details" : details
    }
    return OBJECTLIST([denstiy_out])

def duplication_create_details(
    ddd_type : str,
    ddd_score : float,
    c_duplication_score : OBJECTLIST,
    score_from_field : Optional[str] = "",
) -> OBJECTLIST:
    """
    Adds duplication details to the given object list.

    Parameters
    ----------
    ddd_type: Type of duplication
    ddd_score: Duplication score value
    c_duplication_score: Object list containing duplication details
    score_from_field: Use field to set duplication score

    Returns
    -------
    OBJECTLIST: Updated object list with added duplication details

    Examples
    --------
    >>> duplication_create_details("type1", 0.85, obj_list)
    obj_list_with_details

    Profile
    -------
    ```{json}
    {
        "name": "duplication_create_details", 
        "display_name" : "Duplication Create Details",
        "description": "Adds duplication details to the given object list.", 
        "params" : [
            { "name" : "ddd_type" , "description" : "Type of duplication" , "type" : ["string"]},
            { "name" : "ddd_score" , "description" : "Duplication score value" , "type" : ["number"]},
            { "name" : "c_duplication_score" , "description" : "Object list containing duplication details" , "type" : ["objectlist"]},
            { "name" : "score_from_field" , "description" : "Use field to set duplication score" , "type" : ["string"] ,"default":""}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "audited_trans" , "description":  "the audited transaction", "type" : "string"},
                {"name" : "audited_source" , "description":  "the audited source", "type" : "string"},
                {"name" : "related_trans" , "description":  "the related transaction", "type" : "list_string"},
                {"name" : "related_source" , "description":  "the related source", "type" : "list_string"},
                {"name" : "3d_type" , "description":  "3d type ", "type" : "string"},
                {"name" : "3d_score" , "description":  "3d score ", "type" : "number"},
                {"name" : "details" , "description":  "the duplicated items ", "type" : "objectlist"}
            ],
            "collective_fields" : {
                "details" : [
                    {"name" : "billgrcs" , "description":  "billgrcs value", "type" : "string"},
                    {"name" : "item_code" , "description":  "item_code value", "type" : "string"},
                    {"name" : "audited_stdcode" , "description":  "audited's stdcode value", "type" : "string"},
                    {"name" : "audited_codesys" , "description":  "audited's codesys value", "type" : "string"},
                    {"name" : "related_stdcode" , "description":  "related's stdcode value", "type" : "string"},
                    {"name" : "related_codesys" , "description":  "related's codesys value", "type" : "string"}
                ]
            }

        }
    }
    ```
    """

    c_duplication_score = c_duplication_score.assign('3d_type',ddd_type)
    if score_from_field == "" or score_from_field == "-":
        c_duplication_score = c_duplication_score.assign('3d_score',ddd_score)
    else :
        c_score = c_duplication_score.select(f"{score_from_field}")
        c_duplication_score = c_duplication_score.assign("3d_score",c_score)
    
    
    c_duplication_score = c_duplication_score.where("item_score",'gt',0)
    return c_duplication_score



def deviation_create_details(
    trans_no : str,
    ddd_type : str,
    ddd_score : float,
    c_serv : OBJECTLIST
) -> OBJECTLIST:
    """
    Creates deviation details with transaction and service information.

    Parameters
    ----------
    trans_no: Transaction number identifier
    ddd_type: Type of deviation
    ddd_score: Deviation score value
    c_serv: Object list containing service details

    Returns
    -------
    OBJECTLIST: Object list containing deviation details

    Examples
    --------
    >>> deviation_create_details("T123", "TypeA", 0.95, service_list)

    Profile
    -------
    ```{json}
    {
        "name": "deviation_create_details", 
        "display_name" : "Deviation Create Details",
        "description": "Creates deviation details with transaction and service information.", 
        "params" : [
            { "name" : "trans_no" , "description" : "Transaction number identifier" , "type" : ["string"]},
            { "name" : "ddd_type" , "description" : "Type of deviation" , "type" : ["string"]},
            { "name" : "ddd_score" , "description" : "Deviation score value" , "type" : ["number"]},
            { "name" : "c_serv" , "description" : "Object list containing service details" , "type" : ["objectlist"] }
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "audited_trans" , "description":  "the audited transaction", "type" : "string"},
                {"name" : "audited_source" , "description":  "the audited source", "type" : "string"},
                {"name" : "related_trans" , "description":  "the related transaction", "type" : "list_string"},
                {"name" : "related_source" , "description":  "the related source", "type" : "list_string"},
                {"name" : "3d_type" , "description":  "3d type ", "type" : "string"},
                {"name" : "3d_score" , "description":  "3d score ", "type" : "number"},
                {"name" : "details" , "description":  "the duplicated items ", "type" : "objectlist"}
            ],
            "collective_fields" : {
                "details" : [
                    {"name" : "billgrcs" , "description":  "billgrcs value", "type" : "string"},
                    {"name" : "item_code" , "description":  "item_code value", "type" : "string"},
                    {"name" : "stdcode" , "description":  "stdcode value", "type" : "string"},
                    {"name" : "codesys" , "description":  "codesys value", "type" : "string"},
                    {"name" : "qty" , "description":  "qty value", "type" : "string"}
                ]
            }

        }
    }
    ```
    """
    _source = c_serv.select_distinct("source")
    _source = _source[0] if len(_source) else 'NHSO-DP'
    _source = _source if _source is not None else "NHSO-DP"
    data = {
        "audited_trans"  : trans_no,
        "audited_source"  : _source,
        "related_trans"  : [trans_no],
        "related_source" : [_source],
        "3d_type"  : ddd_type,
        "3d_score" : ddd_score,
        "details" : c_serv
    }
    return OBJECTLIST([data])



def create_skip_details (
    trans_no : str,
    ddd_type : str,
    ddd_score : float
    ) -> OBJECTLIST:
    """
    Creates skip details with transaction and service information.

    Parameters
    ----------
    trans_no: Transaction number identifier
    ddd_type: Type of deviation
    ddd_score: Deviation score value

    Returns
    -------
    OBJECTLIST: Object list containing skip details

    Examples
    --------
    >>> create_skip_details("T123", "TypeA", 0.95,)

    Profile
    -------
    ```{json}
    {
        "name": "create_skip_details", 
        "display_name" : "Create Skip Details",
        "description": "Creates skip details with transaction and service information.", 
        "params" : [
            { "name" : "trans_no" , "description" : "Transaction number identifier" , "type" : ["string"]},
            { "name" : "ddd_type" , "description" : "Type of deviation" , "type" : ["string"]},
            { "name" : "ddd_score" , "description" : "Deviation score value" , "type" : ["number"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attributes" : [
                {"name" : "audited_trans" , "description":  "the source transaction", "type" : "string"},
                {"name" : "related_trans" , "description":  "the target transaction", "type" : "list_string"},
                {"name" : "3d_type" , "description":  "3d type ", "type" : "string"},
                {"name" : "3d_score" , "description":  "3d score ", "type" : "number"}

            ]
        }
    }
    ```
    """

    data = {
        "audited_trans" : trans_no,
        "related_trans" : [trans_no],
        "3d_type" : ddd_type,
        "3d_score" : ddd_score
    }
    return OBJECTLIST([data])


def convert_stdcode_itemcode_to_upper(
    data : OBJECTLIST,
    ) -> OBJECTLIST:
    """
    Convert stdcode and itemcode to uppercase, but keep the original values in other fields.

    Parameters
    ----------
    data: objectlist to modify

    Returns
    -------
    OBJECTLIST: Modified OBJECTLIST

    Examples
    --------
    >>> convert_stdcode_itemcode_to_upper(c_serv)

    Profile
    -------
    ```{json}
    {
        "name": "convert_stdcode_itemcode_to_upper", 
        "display_name" : "Convert stdcode & Itemcode to upper",
        "description": "Convert stdcode and itemcode to uppercase, but keep the original values in other fields", 
        "params" : [
            { "name" : "data" , "description" : "OBJECTLIST to modify" , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "inherit_attributes_from" : {
                "source_params" : "data",
                "source_attr" : "value",
                "self_attr" : "input"
            },
            "attributes" : [
                { "name" : "item_code_original" , "type" : "string" , "description" : "The original Itemcode" },
                { "name" : "stdcode_original" , "type" : "string" , "description" : "The original Stdcode" }
            ]
        }
    }
    ```
    """
    data = [{**serv,
            "stdcode_original" :str(serv['stdcode']),
            "stdcode" :str(serv['stdcode']).upper(),
            "item_code_original":str(serv['item_code']),
            "item_code":str(serv['item_code']).upper(),
            } for serv in data]
    return OBJECTLIST(data)


def deviation_join(left_table:OBJECTLIST,right_table:OBJECTLIST)->OBJECTLIST:
    """
    Join two OBJECTLISTs on special conditions for deviation rules

    Parameters
    ----------
    left_table: objectlist to join
    right_table: objectlist to join

    Returns
    -------
    OBJECTLIST: Joined OBJECTLIST

    Examples
    --------
    >>> deviation_join(c_serv,qty_stats)

    Profile
    -------
    ```{json}
    {
        "name": "deviation_join", 
        "display_name" : "Deviation Join",
        "description": "Join two OBJECTLISTs on special conditions for deviation rules", 
        "params" : [
            { "name" : "left_table" , "description" : "objectlist to join" , "type" : ["objectlist"]},
            { "name" : "right_table" , "description" : "objectlist to join" , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "inherit_attributes_from" : {
                "source_params" : "left_table",
                "source_attr" : "value",
                "self_attr" : "input"
            },
            "attributes" : [
                { "name" : "n" , "type" : "number" , "description" : "count of observations" },
                { "name" : "sum" , "type" : "number" , "description" : "sum of values" },
                { "name" : "sum_sq" , "type" : "number" , "description" : "sum of squared values" },
                { "name" : "mean" , "type" : "number" , "description" : "mean (average) value" },
                { "name" : "max" , "type" : "number" , "description" : "maximum value" },
                { "name" : "min" , "type" : "number" , "description" : "minimum value" },
                { "name" : "range" , "type" : "number" , "description" : "range(max-min)" },
                { "name" : "variance" , "type" : "number" , "description" : "variance of values" },
                { "name" : "sd" , "type" : "number" , "description" : "standard deviation" },
                { "name" : "z_level_1" , "type" : "number" , "description" : "z-score at level 1" },
                { "name" : "z_level_2" , "type" : "number" , "description" : "z-score at level 2" }
            ]
        }
    }
    ```
    """

    all_attributes = list(set(left_table.get(0).keys()).union(set(right_table.get(0).keys())).difference(set(['subtype','billgrcs','item_code'])))
    exact_join_results = left_table.left_join(
        right_table,
        on_key=['subtype','billgrcs','item_code'],
        on_other_key=['subtype','billgrcs','item_code']
    ).select(['subtype','billgrcs','item_code',]+all_attributes)
    
    # unmatch items
    leftover34_items = exact_join_results.where('billgrcs',"is_in",['03','04'])\
        .where('n','is',None)\
        .select(['subtype','billgrcs','item_code',]) 
    # remove unmatch items from matched items
    lo34_set = set(frozenset(x.items()) for x in leftover34_items)
    ex_final = []
    for item in exact_join_results:
        sbi =frozenset({'subtype':item['subtype'],'billgrcs':item['billgrcs'],'item_code':item['item_code']}.items())
        if sbi not in lo34_set:
            ex_final.append(item)
            
    ex_final_results = OBJECTLIST(ex_final)
    
    similar_join_results = leftover34_items.left_join(right_table,
                                                on_key=['subtype','item_code'],
                                                on_other_key=['subtype','item_code']
    ).select(['subtype','billgrcs','item_code',]+all_attributes)

    # concat two results together
    final_results = ex_final_results.append(similar_join_results)
    return final_results