import ast
import builtins
import copy
import inspect
import itertools
import typing
import types
import re
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo

# Explicitly import modules as globals() works only for the current module 
from pyrengine.objectlist import ARRAY 
from pyrengine.model import *
from pyrengine.date import DATETIME
from pyrengine.rulecontext import FUNCTIONCALL_SYMBOLS
from pyrengine.compiler import register_function
from pyrengine.op import OP
from pyrengine.lookup import LOOKUP
from pyrengine.where import UnknownPlaceHolderException

import z3


_LITERAL_TYPE = ast.Constant | ast.List

register_function('DATETIME', DATETIME)
register_function('ARRAY', ARRAY)
register_function('OBJECTLIST', OBJECTLIST)

STATIC_SYMBOLS = {  # Static symbols which the values are not changed from one transaction to another.
    'LOOKUP': LOOKUP,  
}

Z3_SYMBOLS = {
    'Not': z3.Not, 
    'Or': z3.Or, 
    'And': z3.And,
    'Concat': z3.Concat, 
    'Star': z3.Star, 
    'InRe': z3.InRe, 
    'Re': z3.Re,
    'AllChar': z3.AllChar,
    'ReSort': z3.ReSort,
    'StringSort': z3.StringSort,
}

# TODO: Handle different timezone. Right now python does not allow to find datetime diff 
#       (d1 - d2) if one datetime has timezone but the other datetime has not.
# We treat all datetimes without timezone. So, we compute timestamp relative to EPOCH without timezone.
EPOCH = DATETIME('1970-01-01')  # A reference to the origin of time, used as a work around for timezone variation.
#EPOCH = datetime.fromtimestamp(0, tz=ZoneInfo("Asia/Bangkok"))  # A reference to the origin of time, used as a work around for timezone variation.
#EPOCH = datetime.fromtimestamp(0, tz=timezone.utc)  # A reference to the origin of time, used as a work around for timezone variation.


CUSTOM_Z3_SYMBOLS = {   
    # Need to be an expression when used with eval()
    '__IS_IN': 'lambda a, A: Or([(a == e) for e in A])   # Check if a is in A, where A is a list of elements', 
}


#https://stackoverflow.com/questions/36197283/recursive-substitution-in-sympy
#https://stackoverflow.com/questions/62533948/how-can-i-write-an-ast-nodetransformer-to-convert-a-1-to-a-function-call-a-varia
#https://stackoverflow.com/questions/37112738/sympy-comparing-expressions
class VariableUnfolder(ast.NodeTransformer):
    """
    Traverse an AST tree and replace a specific variable from assignment statement (e.g. var1 = x + 1), 
    with the corresponding AST tree.
    The output AST tree consists of only input symbols (from transaction) and constants.
    For example, given var1 = x + 1; var2 = var1 + 1; it unfolds var2 to x + 1 + 1. 
    Note that testing if two expressions are equivalent is not always possible.
    For example, (a + b)** and a**2 + 2*a*b + b**2 are actually equivalent but not easy to check.  
    When a variable is reassigned with another expression like var1 = 1 + 2; var1 = 3 + 4, 
    the former assignment is not accessible anymore but the already unfolded expression is not affected.
    """
    def __init__(self):
        self.variable_map: dict[str, ast.AST] = {}  # Map of variable name to AST node, e.g. x -> Expr(value=BinOp(left=Name(id='a', ctx=Load()), op=Add(), right=Name(id='b', ctx=Load())))


    def add_assignment(self, name: str, expr: str | ast.Expression):
        #if name in self.variable_map:
        #    raise RuleVerificationException("Variable {} already exists in unfolding".format(name))
        
        if isinstance(expr, str):
            node = ast.parse(expr, mode='eval').body  # Parse the expression string into an AST node
        elif isinstance(expr, ast.Expression):
            node = expr.body  # Use the AST node directly
        else:
            raise RuleVerificationException("Expression must be a string or AST node, but {} is found".format(type(expr).__name__))

        self.variable_map[name] = self.visit(node)  # Visit the node to transform it first


    def visit_Name(self, node: ast.Name) -> ast.AST:  # The argument node is modified.
        if node.id in self.variable_map:
            # Replace the variable with the corresponding AST node
            return self.variable_map[node.id]
        else:
            # Return the original node if not found in variable map
            return node
        
    
    def unfold(self, node: ast.AST) -> ast.AST: # The argument node is unmodified.
        new_tree = copy.deepcopy(node)
        return self.visit(new_tree)


    # Function call:
    #Expr(
    #  value=Call(
    #    func=Name(id='func', ctx=Load()),
    #    args=[],
    #    keywords=[]))
    #
    # Method call:
    #Expr(
    #  value=Call(
    #    func=Attribute(
    #      value=Name(id='obj', ctx=Load()),
    #      attr='method',
    #      ctx=Load()),
    #    args=[],
    #    keywords=[]))    
    def visit_Call(self, node: ast.Call) -> ast.Call:

        node.func = self.visit(node.func)
        
        node.args = [self.visit(arg) for arg in node.args]  # Visit each argument in the function call

        return node


class VariableFinder(ast.NodeVisitor):
    """
    Traverse an AST tree to find all variables, excluding specified symbols. 
    It doesn't support placeholder variables ($var_name) in arguments like obj.where("age > $max_age")
    """
    def __init__(self, excluded: set = set()):
        self.variables: set = None
        self.excluded: set = excluded


    def visit_Name(self, node: ast.Name):
        self.variables.add(node.id)


    def find(self, node: ast.AST) -> set:
        self.variables = set()
        self.visit(node)
        return self.variables - self.excluded


# This class fails to detect placeholders in simple expression like obj.where("name = 'he$$o'").
# Wait for removing.
class PlaceHolderFinder(ast.NodeVisitor):
    """
    Traverse an AST tree to find all placeholder variables in OBJECTLIST.where() like obj.where("age > $max_age"). 
    """
    def __init__(self, get_type: Callable):
        self.placeholders = set()
        self.get_type = get_type

    # Function call:
    #Expr(
    #  value=Call(
    #    func=Name(id='OBJECTLIST', ctx=Load()),
    #    args=[...],
    #    keywords=[]))
    #
    # Method call:
    #Expr(
    #  value=Call(
    #    func=Attribute(
    #      value=Name(id='obj', ctx=Load()),
    #      attr='method',
    #      ctx=Load()),
    #    args=[],
    #    keywords=[]))
    def visit_Call(self, node: ast.Call) -> typing.Type | types.UnionType: # Function or method call
        for arg in node.args:
            self.visit(arg)

        if isinstance(node.func, ast.Name): # function call
            cls = self.visit_Name(node.func)
        elif isinstance(node.func, ast.Attribute): # method call
            cls = self.visit(node.func.value) # node.value can be a Call.
            if inspect.isclass(cls):
                possible_input_classes = (cls,)
            elif isinstance(cls, types.UnionType):
                possible_input_classes = typing.get_args(cls)
            else:
                raise RuleVerificationException("Expect a class or classes but {} is found in verification {}".format(cls, ast.unparse(node.func.value)))    

            if OBJECTLIST in possible_input_classes and node.func.attr == 'where':
                # Find placeholders in the where clause, e.g. obj.where("age > $max_age").
                # Using regex works surprisingly well even for nested placeholders. 
                # As all placeholders are detected from the whole argument of obj.where() at once.
                # However, special case like obj.where("age > $obj.where(\"name = 'john$ny'\")") fails.
                # Despite this, it is better than and the OBJECTLIST.where's PlaceHolderFinderMixin class is not used.
                if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                    # Extract placeholders from the string, e.g. "age > $max_age" -> $max_age
                    placeholders = re.findall(r'\$([a-zA-Z_][a-zA-Z0-9_]*)', node.args[0].value)
                    for placeholder in placeholders:
                        self.placeholders.add(placeholder) 

            cls = self.get_type(node.func) # get the class of method call
            if cls is None:
                raise RuleVerificationException('Expect a class from {} but not found'.format(ast.unparse(node.func)))        
        
        return cls

    
    def visit_Name(self, node: ast.Name) -> typing.Type | types.UnionType:
        cls = self.get_type(node)
        if cls is None:
            raise RuleVerificationException('Expect a class from {} but not found'.format(ast.unparse(node)))
        
        return cls
    
    
    def find(self, node: ast.AST) -> set:
        self.placeholders = set()
        self.visit(node)
        return self.placeholders
    
    
# https://gist.github.com/jtpio/cb30bca7abeceae0234c9ef43eec28b4
# https://greentreesnakes.readthedocs.io/en/latest/
# https://docs.python.org/3/reference/grammar.html
# https://docs.python.org/3/library/ast.html
class Z3Formulas(ast.NodeVisitor):
    """
    Convert AST tree of an expression to Z3 formulas. Each node in the AST tree is visited by self.visit(). 
    A term can be a name, a function call (possibly nested) or a chain of method calls. A term cannot contain operators.
    An expression consists of terms and operators.
    Each term in an expression (or the whole expression) is substituted with a variable x1, x2, ...
    We treat whole nested function calls and chain of method calls as a single variable because 
       we cannot determine the exact return value of each step; we can determine only return type.
    The data type of each term is determined from context or guessed from function/method signatures and 
       should be eventually ended up to Int, Real, Bool, String of Z3 data type.
    The two main user methods are add_assignment() and add_contraint().
    """

    def __init__(self, symbols: dict, datetime_ignore_time: bool = True):
        self.internal_variable_idx: int = 0 # the index for internal (mapped) variable x

        # Map of seen expression (no operator) or variable name of the assignment (var1 =) to mapped variable name, 
        #  e.g. age -> x0, price -> x1, maxint(1, 2) -> x3.
        # Note that if the same variable is reassigned, e.g. var1 = a; var1 = a + 1, the lastest is stored in this map. 
        self.expression_map: dict[str, str] = {}   
        self.full_expression_map: list[(str, str)] = []  # Store as same as expression_map but with all reassignment.

        self.variables: dict[str, typing.Type] = {} #  Dict of variable name to type, e.g. x0 -> int, x1 -> float, x3 -> int
        self.variable_comments: dict[str, str] = {}  # Map of variable name to comment, e.g. x0 -> "comment1", x1 -> "comment2"

        self.assignment_map: dict[str, str] =  {}  # Dict of user assignment statement (variable name to mapped expression), e.g. next_day = current_day + 1 becomes next_date = x1 + 1

        self.constraints: list[(str, str, bool)] = []  # List of (constraint, comment, negation), e.g. ("x > 0", "x must be positive", false)
        self.constraint_sources: list[(str, str, str)] = [] # List of (node_id, index, source_expr). It must parallel to self.constraints.
        
        self.expression_unfolder = VariableUnfolder()  # Unfold variable to its expression
        self.unfolded_expression_map: dict[str, str] = {}   # Map of seen unfolded expression to mapped variable name, e.g. given var1 = obj; var2 = var1.count(), the var1.count() becomes obj.count() -> x0

        self.symbols = symbols # Map of identifiers to object or class. They represent an input transaction which is dynamically changed from one to another.
        self.static_symbols = FUNCTIONCALL_SYMBOLS.copy() | STATIC_SYMBOLS.copy() 
        
        self.datetime_ignore_time = datetime_ignore_time   # When datetime is converted to timestamp (int), ignore time in datetime in Z3 formulas

        self.var_finder = VariableFinder(excluded= set(dir(builtins)) | set(STATIC_SYMBOLS.keys()) | set(FUNCTIONCALL_SYMBOLS.keys()))  # Find variables in the AST tree, excluding builtins, symbols and function calls
        #self.placeholder_finder = PlaceHolderFinder(get_type=self._get_expression_return_type)  # Set to PlaceHolderFinder (not 100% correct)
        self.placeholder_finder = None  # Set to None to use eval()

    def _get_new_internal_variable(self):
        idx = f"x{self.internal_variable_idx}"
        self.internal_variable_idx = self.internal_variable_idx + 1
        return idx
    

    def _get_type_hints(self, callable, cls=None):  # If callable is a method, cls must be a class
        #print(callable)
        hints = typing.get_type_hints(callable)
        return_type = hints.get('return') # https://stackoverflow.com/questions/49560974/inspect-params-and-return-types

        #https://stackoverflow.com/questions/74544539/python-how-to-check-what-types-are-in-defined-types-uniontype
        origin = typing.get_origin(return_type)  # For return type with Union or |
        if origin is typing.Union or origin is types.UnionType:   #  types.UnionType if using |
            #return_type = typing.get_args(return_type)[0]  # Get only the first type
            type_args = typing.get_args(return_type)
            if not type_args: 
                return typing.Any
            return_type = type_args[0]
            for i in range(1, len(type_args)):
                return_type = return_type | (type_args[i] if type_args[i] != typing.Self else cls) # return types.UnionType of all types
                
        if return_type is typing.Self and cls is not None:   # If class method returns typing.Self.
            return_type = cls

        return return_type or typing.Any   # Default to typing.Any if there is no return type hint or the type cannot be determined


    # https://stackoverflow.com/questions/70967266/what-exactly-is-python-typing-callable
    # https://stackoverflow.com/questions/3061/calling-a-function-of-a-module-by-using-its-name-a-string
    # Recursively determine return type of an expression, e.g. a name or a Call (nested functions or method call chain).
    def _get_expression_return_type(self, node: ast.AST) -> typing.Type | types.UnionType:
        cls = None
        
        if isinstance(node, ast.Constant):
            return type(node.value)  # Return type of a constant is its type
        
        elif isinstance(node, ast.List):
            return list
        
        elif isinstance(node, ast.Name):
            id = node.id

            idx = self.expression_map.get(id)  # First from seen (local) variable
            if idx is not None:
                return self.variables[idx] 

            if id in self.symbols:   # Second from symbol table
                obj = self.symbols[id]
                if inspect.isclass(obj):
                    return obj
                return type(obj)             

            if id in STATIC_SYMBOLS:
                obj = STATIC_SYMBOLS[id]
                if inspect.isclass(obj):
                    return obj
                return type(obj)                

            if id in FUNCTIONCALL_SYMBOLS:   # Forth functions from rulecontext
                func = FUNCTIONCALL_SYMBOLS[id]
            else: 
                func = getattr(builtins, id, None)  # Otherwise from builtin functions. https://stackoverflow.com/questions/68919220/using-getattr-to-access-built-in-functions

            if not func:
                raise RuleVerificationException("Name {} not found in verification {}".format(id, ast.unparse(node)))            
            
            if inspect.isbuiltin(func) or inspect.isfunction(func): 
                callable = func
            elif inspect.isclass(func):  # func is a class constructor
                return func
            else:
                raise RuleVerificationException("Name {} is mapped to {} but not a function in verification".format(id, func))            
            
            return self._get_type_hints(callable, None)  # For function

        elif isinstance(node, ast.Call):  # function call func() or method call obj.method(). A method call is then passed to ast.Attribute.
            cls = self._get_expression_return_type(node.func)   # Determine return type based on function name, ignoring any arguments

            if isinstance(node.func, ast.Name) and node.func.id in ('max', 'min'):  # Special handle for max, min
                if len(node.args) < 1:
                    raise RuleVerificationException("{}() requires at least one argument".format(node.func.id))
                return self._get_expression_return_type(node.args[0])  # Return type is the first argument type
                        
            return cls

        elif isinstance(node, ast.Attribute):  # Attribute is the actual method call obj.method()
            #Expression(
            #body=Call(
            #    func=Attribute(
            #      value=Name(id='obj', ctx=Load()),
            #      attr='get',
            #      ctx=Load()),
            #    args=[
            #    Constant(value='a')],
            #    keywords=[]))
            # Note that chain of method calls like obj.m1().m2() will be parsed into AST tree with m2 as parent node and m1 as child node.
            cls = self._get_expression_return_type(node.value)
            if not cls:
                raise RuleVerificationException("Cannot find a class for {} in verification {}".format(ast.unparse(node.value), ast.unparse(node)))    
            
            if inspect.isclass(cls):
                possible_input_classes = (cls,)
            elif typing.get_origin(cls) in (typing.Union, types.UnionType):
                possible_input_classes = typing.get_args(cls)
            else:
                raise RuleVerificationException("Expect a class or classes but {} is found in verification {}".format(cls, ast.unparse(node.value)))    
    
            possible_output_classes: typing.Type | types.UnionType = None  
            for cls in possible_input_classes:  # Try to find return class (or classes) from all possible input classes
                attr = getattr(cls, node.attr, None)    
                if not attr:  # Since some input classes may not have the speficied attribute, just skip
                    continue
                if inspect.isfunction(attr): # Method bound to an object is treated as a function since attr is determined from class not object.
                    callable = attr
                elif inspect.ismethod(attr):  # Method bound to a class (class method)
                    callable = attr           
                else: 
                    raise RuleVerificationException("{} is not callable for class {} in verification {}".format(node.attr, cls.__name__, ast.unparse(node)))
                
                if possible_output_classes is None: 
                    possible_output_classes = self._get_type_hints(callable, cls)
                else:
                    possible_output_classes = possible_output_classes | self._get_type_hints(callable, cls)
                
            if possible_output_classes is None:  # If none of possible input classes has such attribute.
                raise RuleVerificationException("Method {} not found for class {} in verification {}".format(node.attr, cls if isinstance(cls, types.UnionType) else cls.__name__ , ast.unparse(node)))                
            
            #print(ast.unparse(node.value), node.attr, possible_output_classes)
            return possible_output_classes
        
        elif isinstance(node, ast.BinOp):  # Expression with binary operator +, -, *, /
            left_cls = self._get_expression_return_type(node.left)
            right_cls = self._get_expression_return_type(node.right)

            # TODO: Use typeshed to determine return type of __add__(), __sub__(), etc. of each class.
            #       However, it cannot easily determine if 'abc'/2 is valid.
            # import ast
            # with open("typeshed/stdlib/builtins.pyi") as f:
            #     tree = ast.parse(f.read())

            # for node in tree.body:
            #     if isinstance(node, ast.FunctionDef):
            #         print(f"Function: {node.name}")
            operator = self.visit(node.op)
            if operator not in ('+', '-', '*', '/'):
                raise RuleVerificationException("Operator '{}' not supported in verification {}".format(ast.unparse(operator), ast.unparse(node)))
          
            if left_cls not in (int, float):
                raise RuleVerificationException("Cannot perform arithmetic operation on type {} in verification {}".format(left_cls if isinstance(left_cls, types.UnionType) else left_cls.__name__), ast.unparse(node))

            if right_cls not in (int, float):
                raise RuleVerificationException("Cannot perform arithmetic operation on type {} in verification {}".format(right_cls if isinstance(right_cls, types.UnionType) else right_cls.__name__), ast.unparse(node))

            elif left_cls == float and right_cls in (int, float):
                return float
            elif left_cls in (int, float) and right_cls == float:
                return float
            elif left_cls == int and right_cls == int:
                return int
            else:
                raise RuleVerificationException("Cannot perform operation '{}' on {} and {} in verification {}".format(operator, left_cls.__name__, right_cls.__name__), ast.unparse(node))

        else:
            raise RuleVerificationException("Require python expression but {} is found in verification {}".format(node.__class__.__name__, ast.unparse(node)))
      

    # Variables refers to terms or expressions which their values are not known at verification time. 
    # They represent fields (user variables) from incoming input transaction data.
    # They also represent function or method calls since the verifier doesn't know the exact return value of these.
    # The expr_type is a valid python type, including built-in and custom classes.
    # TODO: Use different name suffix of different data types, e.g. xi_1 for int, xf_1 for float.
    # Return the mapped variables x0, x1, ... for seen expressions or create a new one.
    def getOrCreateVariable(self, expr: str, expr_type: typing.Type) -> str:
        tree = ast.parse(expr, mode='eval') 
        unfolded_tree = self.expression_unfolder.unfold(tree)
        unfolded_expression = ast.unparse(unfolded_tree)  # Convert AST to string expression
        idx = self.unfolded_expression_map.get(unfolded_expression)

        if idx is None:
            idx = self.expression_map.get(expr) 

        if idx is None:
            idx = self._get_new_internal_variable()
            self.expression_map[expr] = idx
            self.full_expression_map.append((expr, idx)) 
            self.variables[idx] = expr_type
            self.unfolded_expression_map[unfolded_expression] = idx  # Add the unfolded expression to the map
            #print(f'Variable {idx}: {expr_type} = {expr} unfolded to {unfolded_expression}')
        elif self.variables[idx] != expr_type:
            raise RuleVerificationException("Expression {} is already defined with different types {} != {}".format(expr, self.variables[idx], expr_type))
        
        if unfolded_expression not in self.unfolded_expression_map:  # If the unfolded expression is not seen before, add it to the map
            self.unfolded_expression_map[unfolded_expression] = idx  # Add the unfolded expression to the map

        return idx
    
        '''
        #
        # Older code when not using unfolded_expression_map. Wating to remove.
        #
        idx = self.expression_map.get(expr) 

        if idx is None:
            idx = self._get_new_internal_variable()
            self.expression_map[expr] = idx
            self.variables[idx] = expr_type
            #print(f'Variable {idx}: {expr_type} = {expr} unfolded to {unfolded_expression}')
        elif self.variables[idx] != expr_type:
            raise RuleVerificationException("Expression {} is already defined with different types {} != {}".format(expr, self.variables[idx], expr_type))
        
        return idx
        '''


    def set_variable_comment(self, name: str, comment: str):
        self.variable_comments[name] = comment

        
    # Parameter negation is used to negate the constraint, i.e. x > 1 becomes not(x > 1).
    def add_constraint(self, expr: str, comment: str = "", negation: bool = False, node_id: str = None, index: int = None):
        '''
        Add a constraint to formulas. The expression is converted to internal variables before added.

        Parameters
        ----------
        expr : str
            An expression represents a constraint.
        comment : str, optional
            Any comment to this constraint.
        negation : bool, optional
            If True, the constraint is negated, e.g. x > 1 becomes not(x > 1). Default is False.

        '''        
        tree = ast.parse(expr, mode='eval')
        constraint = self.visit(tree)  # The returned constraint is converted with mapped variables. 
        #print(expr, '->', constraint)
        self.constraints.append((constraint, comment, negation))
        self.constraint_sources.append((node_id, index, expr))  # Store the source of the constraint for debugging or reference

    
    def is_reserved_word(self, name: str) -> bool:
        return name in Z3_SYMBOLS or name in STATIC_SYMBOLS or name in FUNCTIONCALL_SYMBOLS

    # For user assignment statement:
    #   var1 = a + b   => var1 = a + b
    #   var1 = [1, 2]  => var1 = [1, 2]
    #   var1 = DATETIME('2020-12-01')  => var1 = timestamp_1
    #   var1 = ARRAY([1, 2])  => var1 = [1, 2]
    #   var1 = ARRAY([DATETIME('2020-12-01'), DATETIME('2020-12-02')])  => var1 = [timestamp1, timestamp2]
    def add_assignment(self, name: str, expr: str):
        '''
        Add an assignment statement to formulas. The expression is converted using internal variables before added.

        Parameters
        ----------
        name : str
            An identifier for the left side of the assignment, e.g. var1.
        expr : str
            An expression for the right side of the assignment, e.g. a + b.

        '''
        tree = ast.parse(expr, mode='eval') 
        self.expression_unfolder.add_assignment(name, tree)  # Add the assignment to the unfolding map
        unfolded_tree = self.expression_unfolder.unfold(tree)
        unfolded_expression = ast.unparse(unfolded_tree)  # Convert AST to string expression

        if unfolded_expression in self.unfolded_expression_map:  # If the unfolded expression is already seen, use the mapped variable
            mapped_expression = self.unfolded_expression_map[unfolded_expression]  # Return single mapped variable
        else:
            mapped_expression = self.visit(tree)  # The returned expression is converted with mapped variables.

        if self.is_reserved_word(name): # If name is a reserved word 
            idx = self._get_new_internal_variable()
            var_name = idx
            self.variable_comments[var_name] = "is substituted by {} as it is a reserved word".format(var_name)
        elif name in self.expression_map: # Name already defined in the previous assignment statement
            idx = self._get_new_internal_variable()
            var_name = idx
            self.variable_comments[var_name] = "is substituted by {} as it is reassigned".format(var_name)
        else: # Add new variable due to the left side is a reserved word, assuming no duplication
            var_name = name  # Add new variable of the same name to Z3            
        
        if unfolded_expression not in self.unfolded_expression_map: 
            self.unfolded_expression_map[unfolded_expression] = var_name  # right size = var_name
        var_type = self._get_expression_return_type(tree.body)
        #self.variables[var_name] = typing.Any  # Type is Any since this variable is evaluated in python, so Z3 don't know for sure. Since this variable is computed, assign Any should not change the solutions.

        #if name in self.expression_map: # already defined in previous assignment statement
        #    #raise RuleVerificationException("Variable {} is already defined.".format(name))

        self.expression_map[name] = var_name  # Set left side of the assigment statement to var_name
        self.full_expression_map.append((name, var_name))  
        self.variables[var_name] = var_type  

        self.assignment_map[var_name] = mapped_expression
        #print(f'Assignment {name}: {var_type} = {var_name} from {expr}, mapped to {mapped_expression}, unfolded to {unfolded_expression}')

        '''
        #
        # Older code when not using unfolded_expression_map. Wating to remove.
        #        
        tree = ast.parse(expr, mode='eval') 
        mapped_expression = self.visit(tree)  # The returned expression is converted with mapped variables.

        if not self.is_reserved_word(name): # Add new variable of the same name to Z3
            var_name = name
        else: # Add new variable, assuming no duplication
            idx = self._get_new_internal_variable()
            var_name = idx
            self.variable_comments[var_name] = "is substituted by {} as it is a reserved word".format(var_name)            
        
        self.expression_map[name] = var_name  # left side = var_name
        var_type = self._get_expression_return_type(tree.body)
        #self.variables[var_name] = typing.Any  # Type is Any since this variable is evaluated in python, so Z3 don't know for sure. Since this variable is computed, assign Any should not change the solutions.
        self.variables[var_name] = var_type  
        self.assignment_map[var_name] = mapped_expression
        #print(f'Assignment {name}: {var_type} = {var_name} from {expr}, mapped to {mapped_expression}, unfolded to {unfolded_expression}')  
        '''      
     
    # **** Convert Z3Formulas to Z3 python code (for display only). For executing, see Z3Solver.solve() ****
    def get_z3_formulas(self) -> str:   
        variable_declarations = []
        datetime_ignore_time_constraints = []
        
        #for expr, var_name in self.expression_map.items():
        for expr, var_name in self.full_expression_map:
            var_type = self.variables[var_name]
            if var_name in self.assignment_map:
                if var_type in (bool, int, float, str, datetime, list):
                    variable_declaration = "{} = {} # {} {}".format(var_name, self.assignment_map[var_name], expr, self.variable_comments.get(var_name, ""))
                else:
                    variable_declaration = "# {} = {} # {} assignment is skipped because type {} is unknown to Z3. {}".format(var_name, self.assignment_map[var_name], expr, var_type if isinstance(var_type, types.UnionType) else var_type.__name__, self.variable_comments.get(var_name, ""))
            else:
                if var_type is typing.Any:
                    variable_declaration = "# {} = Any('{}') # {} {} assignment is skipped because type Any is unknown to Z3".format(var_name, var_name, expr, self.variable_comments.get(var_name, ""))
                elif var_type == types.NoneType: 
                    variable_declaration = "{} = None".format(var_name)
                elif var_type == bool:  # Make sure bool is in front of int as it is a subclass of int
                    variable_declaration = "{} = Bool('{}') # {} {}".format(var_name, var_name, expr, self.variable_comments.get(var_name, ""))  
                elif var_type == int:
                    variable_declaration = "{} = Int('{}') # {} {}".format(var_name, var_name, expr, self.variable_comments.get(var_name, ""))  
                elif var_type == float:
                    variable_declaration = "{} = Real('{}') # {} {}".format(var_name, var_name, expr, self.variable_comments.get(var_name, ""))  
                elif var_type == str:
                    variable_declaration = "{} = String('{}') # {} {}".format(var_name, var_name, expr, self.variable_comments.get(var_name, ""))  
                elif var_type == datetime:   # Encoded by int timestamp with constraint. TODO: Consider using Real if subsecond is required.
                    variable_declaration = "{} = Int('{}') # {} {}, datetime encoded as int timestamp. Resolution is in seconds.".format(var_name, var_name, expr, self.variable_comments.get(var_name, ""))    
                    if self.datetime_ignore_time: # For date resolution, modulo it with seconds per day. 82800 = 24*3600
                        datetime_ignore_time_constraints.append(("{} % 86400 == 0".format(var_name), 
                                                                "Force date resolution as datetime_ignore_time = {}".format(self.datetime_ignore_time),
                                                                False))  
                elif var_type == list: 
                    # TODO: encode list as a sequence of Ints, Reals, Bools or Strings.
                    # Currently we do not solve for a list, so we always define a list as a sequence of strings.
                    # The only operation allowed for lists is containment, i.e. x in y. 
                    variable_declaration = "{} = Const('{}', SeqSort(StringSort())) # {} {}, list always encoded as a sequence of strings".format(var_name, var_name, expr, self.variable_comments.get(var_name, ""))  
                else:
                    #raise RuleVerificationException("Cannot convert type {} for {}".format(var_type.__name__, expr))
                    variable_declaration = "# {} = {} # {} is skipped because type {} is unknown to Z3".format(var_name, expr, var_name, var_type if isinstance(var_type, types.UnionType) else var_type.__name__)

            variable_declarations.append(variable_declaration)
        
        custom_section = "\n".join(['{} = {}'.format(k, v) for k, v in CUSTOM_Z3_SYMBOLS.items()])
        head_section = "\n".join(variable_declarations)    
        body_section = "\n".join(['solver.add({}) # {}'.format(constraint, comment) if not negation else
                                  'solver.add(Not({})) # {}'.format(constraint, comment)
                                  for constraint, comment, negation in self.constraints])
        additional_section = "\n".join(['solver.add({}) # {}'.format(constraint, comment) if not negation else
                                  'solver.add(Not({})) # {}'.format(constraint, comment)
                                  for constraint, comment, negation in datetime_ignore_time_constraints])
        return "\n".join([custom_section, head_section, body_section, additional_section])

    
    # Handle DATETIME('2020-01-01'). The args[0] must be string.
    def _DATETIME_casting(self, node: ast.Call) -> datetime:
        if not isinstance(node, ast.Call):
            return None
        
        if node.func.id == 'DATETIME' :          
            if len(node.args) != 1:
                raise RuleVerificationException("DATETIME() requires one argument")
            if isinstance(node.args[0], ast.Constant):
                if not self.datetime_ignore_time:
                    return DATETIME(ast.literal_eval(node.args[0]))
                else:
                    return DATETIME(ast.literal_eval(node.args[0])).replace(hour=0, minute=0, second=0, microsecond=0) 

        return None    


    # Literals are strings, bytes, numbers, tuples, lists, dicts, sets, booleans, None, bytes and sets.
    def _convert_literal(self, node: _LITERAL_TYPE) -> str:
        
        literal = ast.literal_eval(node)
        if isinstance(literal, int | float | str):
            return repr(literal)
        
        if isinstance(literal, list):
            if len(literal) > 0:
                if not isinstance(literal[0], int | float | str):
                    raise RuleVerificationException("Element in list must be a primitive data type, but type {} is found".format(type(literal[0])))

                if not all(type(literal[0]) == type(e) for e in literal):
                    raise RuleVerificationException("All elements in list must have the same type")
                
            return repr(literal)
        
        # TODO: Handling types.NoneType is not simple.
        #    https://stackoverflow.com/questions/70843466/a-three-valued-boolean-logic-with-z3-solver
        #    https://stackoverflow.com/questions/70843466/a-three-valued-boolean-logic-with-z3-solver
        
        raise RuleVerificationException("Type {} not allow for literal".format(type(literal)))


    def visit_Expression(self, node: ast.Expr) -> str:
        return self.visit(node.body)
    

    def visit_Name(self, node: ast.Name) -> str:  # Variable name
        var_type = self._get_expression_return_type(node)
        var = self.getOrCreateVariable(node.id, var_type)        
        return var


    def visit_Constant(self, node: ast.Constant) -> str: # Primitive constant
        return self._convert_literal(node)


    def visit_List(self, node: ast.List) -> str: # List 
        return self._convert_literal(node)


    #
    # Convert function and method calls to Z3 python expressions or constants.
    # Special function calls are handled here. 
    #
    # Function call:
    #Expr(
    #  value=Call(
    #    func=Name(id='func', ctx=Load()),
    #    args=[],
    #    keywords=[]))
    #
    # Method call:
    #Expr(
    #  value=Call(
    #    func=Attribute(
    #      value=Name(id='obj', ctx=Load()),
    #      attr='method',
    #      ctx=Load()),
    #    args=[],
    #    keywords=[]))
    def visit_Call(self, node: ast.Call) -> str: # Function or method call

        if isinstance(node.func, ast.Name): # For function call func()           
            if node.func.id == 'DATETIME' :  # Special handle for DATETIME('2020-01-01')
                dt = self._DATETIME_casting(node)
                if dt is not None:
                    #return repr(dt.timestamp())  
                    return repr((dt - EPOCH).total_seconds())
                else:
                    pass # Since args[0] may be a name, a Call or others, just create a variable as is.
            
            elif node.func.id == 'ARRAY':  # Special handle for ARRAY([e1, e2, ...])
                if len(node.args) != 1:
                    raise RuleVerificationException("ARRAY() requires one argument")      
                if isinstance(node.args[0], ast.List):
                    # Check if type of each element is primitive or datetime 
                    if all([isinstance(e, ast.Constant) for e in node.args[0].elts]):  # List of primitive constants
                        arr = [ast.literal_eval(e) for e in node.args[0].elts]
                        #return repr(arr) # return as normal list
                        return ast.unparse(node) # return as is
                    else:   # List of DATETIME() elements
                        arr = [self._DATETIME_casting(e) for e in node.args[0].elts]
                        if all(arr): # All elements are datetime
                            #return repr([(e - EPOCH).total_seconds() for e in arr])
                            return repr(ARRAY([(e - EPOCH).total_seconds() for e in arr])) 
                else:
                    pass # Since args[0] may be a name, a Call or others, just create a variable as is. 

            elif node.func.id in ('LIKE', 'NOT_LIKE'):    # Special handle for builtin function to check if a string is like pattern
                if len(node.args) != 2:
                    raise RuleVerificationException("{}() requires two arguments".format(node.func.id))
                if isinstance(node.args[0], ast.Name) and isinstance(node.args[1], ast.Constant):
                    literal = ast.literal_eval(node.args[1])
                    if not isinstance(literal, str):  # Convert to string
                        raise RuleVerificationException("Cannot parse string pattern '{}' to string".format(node.args[1]))
                    expr = "InRe({}, {})".format(self.visit(node.args[0]), _convert_regex_to_z3(literal))
                    if node.func.id == 'NOT_LIKE':
                        expr = "Not({})".format(expr)
                    return expr                    
                else:
                    raise RuleVerificationException("Not support this expression {}".format(ast.unparse(node)))
                
            # TODO: Special handler for 'max' and 'min'. Is it possible to handle x < max(var1, 2)?
            #       https://stackoverflow.com/questions/67043494/max-and-min-of-a-set-of-variables-in-z3py
            
            elif node.func.id in Z3_SYMBOLS.keys():  # Z3 functions
                return "{}({})".format(node.func.id, ', '.join([self.visit(e) for e in node.args]))
            
            else: # For other function call func1(func2()), create a variable for the whole function call; only if it has user fields in it.
                unfolded_tree = self.expression_unfolder.unfold(node)
                if len(self.var_finder.find(unfolded_tree)) > 0: 
                    var_type = self._get_expression_return_type(node)
                    return self.getOrCreateVariable(ast.unparse(node), var_type)                
                else:
                    unfolded_expression = ast.unparse(unfolded_tree)  # Convert AST to unfold expression
                    if self.placeholder_finder is not None and len(self.placeholder_finder.find(unfolded_tree)) > 0:
                        var_type = self._get_expression_return_type(node)
                        return self.getOrCreateVariable(ast.unparse(node), var_type)                    
                    else:
                        # Try eval with necessary symbols to ensure that the unfolded expression has no placeholder variable in arguments like in OBJECTLIST.where()
                        try: 
                            result = eval(unfolded_expression, self.static_symbols)
                        except UnknownPlaceHolderException as ex:
                            var_type = self._get_expression_return_type(node)
                            return self.getOrCreateVariable(ast.unparse(node), var_type)

                    return unfolded_expression  # If no variables are found, just return the unfolded expression.

        elif isinstance(node.func, ast.Attribute):  # For method call obj.method1().method2(), create a variable for longest chain of method calls; only if it has user fields in it.
            unfolded_tree = self.expression_unfolder.unfold(node)
            if len(self.var_finder.find(unfolded_tree)) > 0: 
                var_type = self._get_expression_return_type(node)
                return self.getOrCreateVariable(ast.unparse(node), var_type)
            else:
                unfolded_expression = ast.unparse(unfolded_tree)  # Convert AST to unfold expression
                if self.placeholder_finder is not None and len(self.placeholder_finder.find(unfolded_tree)) > 0:
                    var_type = self._get_expression_return_type(node)
                    return self.getOrCreateVariable(ast.unparse(node), var_type)                   
                else:
                    # Try eval with necessary symbols to ensure that the unfolded expression has no placeholder variable in arguments like in OBJECTLIST.where()
                    try: 
                        result = eval(unfolded_expression, self.static_symbols)
                    except UnknownPlaceHolderException as ex:
                        var_type = self._get_expression_return_type(node)
                        return self.getOrCreateVariable(ast.unparse(node), var_type)

                return unfolded_expression  # If no variables are found, just return the unfolded expression.
        else:
            raise RuleVerificationException("Not support this expression {}".format(ast.unparse(node)))
        

    # Get object attribute obj.attr
    #Expr(
    #  value=Attribute(
    #    value=Name(id='obj', ctx=Load()),
    #    attr='attr',
    #    ctx=Load()))        
    def visit_Attribute(self, node: ast.Attribute) -> str: # obj.attr
        raise RuleVerificationException("Get object attribute not supported")
        #var_type = self._get_expression_return_type(node)
        #return self.getOrCreateVariable(ast.unparse(node), var_type)  # We cannot determine the attribute type
            

    def visit_UnaryOp(self, node: ast.UnaryOp) -> str:
        if isinstance(node.op, ast.Not) and isinstance(node.operand, ast.Compare):
            return "{}({})".format(self.visit(node.op), self.visit(node.operand))
        else:
            raise RuleVerificationException("Not support unary operator '{}'".format(ast.unparse(node)))    


    # Operator and is converted to And(). Similarly for or.
    def visit_BoolOp(self, node: ast.BoolOp) -> str:
        #values = " ".join(["{} {}".format(self.visit(node.op), self.visit(value)) for value in node.values[1:]])
        #return "({} {})".format(self.visit(node.values[0]), values)
        return "{}({})".format(self.visit(node.op), ', '.join([self.visit(value) for value in node.values]))


    def visit_BinOp(self, node: ast.BinOp) -> str:
        l_operand = node.left
        if isinstance(l_operand, _LITERAL_TYPE):
            left = self._convert_literal(l_operand)
        else: 
            left = self.visit(l_operand)

        op = self.visit(node.op)
        
        r_operand = node.right
        if isinstance(r_operand, _LITERAL_TYPE):
            right = self._convert_literal(r_operand)
        else:
            right = self.visit(r_operand)
       
        return "({} {} {})".format(left, op, right)
    

    def visit_Compare(self, node: ast.Compare) -> str:
        if len(node.ops) > 1:
            raise RuleVerificationException("Support simple comparison expression; but {}".format(ast.unparse(node)))
        
        l_operand = node.left
        if isinstance(l_operand, _LITERAL_TYPE):
            left = self._convert_literal(l_operand)
        else:
            left = self.visit(l_operand)

        op = self.visit(node.ops[0])

        r_operand = node.comparators[0]
        if op in ('in', 'not in'):   # Support 'l_operand in r_operand' or 'l_operand not in r_operand'
            #  TODO: Use z3.Contains for 'in' and 'not in'
            #
            # 'Operator "in" needs a list or ARRAY of primitive constants as the right operand.
            if isinstance(r_operand, ast.List):   # If r_operand is a list 
                if all([isinstance(e, ast.Constant) for e in r_operand.elts]): # List of primitive constants
                    right = [ast.literal_eval(e) for e in r_operand.elts]   
                else:   # List of DATETIME() elements
                    right = [self._DATETIME_casting(e) for e in r_operand.elts]
                    if not all(right): # Not all elements are datetime
                        raise RuleVerificationException("All elements in ARRAY() must be constant")
                    right = [(e - EPOCH).total_seconds() for e in right] 
            elif isinstance(r_operand, ast.Call) and isinstance(r_operand.func, ast.Name) and r_operand.func.id == 'ARRAY':  # Handle ARRAY([e1, e2, ...])
                if len(r_operand.args) != 1: 
                    raise RuleVerificationException("ARRAY() requires one argument")   
                if isinstance(r_operand.args[0], ast.List):
                    # Check if type of each element is primitive or datetime 
                    if all([isinstance(e, ast.Constant) for e in r_operand.args[0].elts]):  # List of primitive constants
                        right = [ast.literal_eval(e) for e in r_operand.args[0].elts]
                    else:   # List of DATETIME() elements
                        right = [self._DATETIME_casting(e) for e in r_operand.args[0].elts]
                        if not all(right): # Not all elements are datetime
                            raise RuleVerificationException("All elements in ARRAY() must be constant")     
                        right = [(e - EPOCH).total_seconds() for e in right] 
                else:
                    raise RuleVerificationException("ARRAY() requires a list as the only argument")                              
            else:   # For complex right operand, cannot unfold into multiple Or, so it is reformed as a dummy boolean function "IS_IN(l_operand, r_operand)"
                unfolded_tree = self.expression_unfolder.unfold(r_operand)
                right_type = self._get_expression_return_type(r_operand)
                if right_type not in (list, ARRAY):
                    raise RuleVerificationException('Operator "in" needs a list or ARRAY of primitive constants but {} is found'.format(right_type)) 
                if len(self.var_finder.find(unfolded_tree)) > 0: 
                    #right = self.getOrCreateVariable(ast.unparse(r_operand), right_type)
                    #reformed_variable = '({} in {})'.format(left, right) # A variable is created for the dummy boolean function
                    reformed_variable = '{} in {}'.format(ast.unparse(l_operand), ast.unparse(r_operand)) # A variable is created for the dummy boolean function
                    reformed = self.getOrCreateVariable(reformed_variable, bool) 
                    self.set_variable_comment(reformed, "Helper variable for complex '{} in {}'".format(ast.unparse(l_operand), ast.unparse(r_operand)))
                    if op == 'in':
                        return '({} == True)'.format(reformed)
                    else:
                        return '({} != True)'.format(reformed)
                else:
                    unfolded_expression = ast.unparse(unfolded_tree)  # Convert AST to unfold expression
                    if self.placeholder_finder is not None and len(self.placeholder_finder.find(unfolded_tree)) > 0:
                        reformed_variable = '{} in {}'.format(ast.unparse(l_operand), ast.unparse(r_operand)) # A variable is created for the dummy boolean function
                        reformed = self.getOrCreateVariable(reformed_variable, bool) 
                        self.set_variable_comment(reformed, "Helper variable for complex '{} in {}'".format(ast.unparse(l_operand), ast.unparse(r_operand)))
                        if op == 'in':
                            return '({} == True)'.format(reformed)
                        else:
                            return '({} != True)'.format(reformed)                        
                    else: 
                        # Try eval with necessary symbols to ensure that the unfolded expression has no placeholder variable in arguments like in OBJECTLIST.where()
                        try: 
                            result = eval(unfolded_expression, self.static_symbols)
                        except UnknownPlaceHolderException as ex:
                            reformed_variable = '{} in {}'.format(ast.unparse(l_operand), ast.unparse(r_operand)) # A variable is created for the dummy boolean function
                            reformed = self.getOrCreateVariable(reformed_variable, bool) 
                            self.set_variable_comment(reformed, "Helper variable for complex '{} in {}'".format(ast.unparse(l_operand), ast.unparse(r_operand)))
                            if op == 'in':
                                return '({} == True)'.format(reformed)
                            else:
                                return '({} != True)'.format(reformed)

                    right = unfolded_expression  # If no variables are found, just return the unfolded expression.
                    return '__IS_IN({}, {})'.format(left, right) 
               
            if isinstance(right, list):
                if len(right) > 0:
                    if not isinstance(right[0], types.NoneType | int | float | str):
                        raise RuleVerificationException("Element in list must be a primitive data type, but type {} is found".format(type(right[0])))

                    if not all(type(right[0]) == type(e) for e in right):
                        raise RuleVerificationException("All elements in list must have the same type")
            
                    # Unfold 'in' operator to multiple ORs.
                    if op == 'in':
                        return 'Or({})'.format(', '.join('{} == {}'.format(left, repr(e)) for e in right))
                    else:
                        return 'Not(Or({}))'.format(', '.join('{} == {}'.format(left, repr(e)) for e in right))
                else:
                    return '(False)' if op == 'in' else '(True)'

            raise RuleVerificationException("Type {} not allow for list literal".format(type(right)))
                
        if isinstance(r_operand, _LITERAL_TYPE):
            right = self._convert_literal(r_operand)
        else:
            right = self.visit(r_operand)

        return "({} {} {})".format(left, op, right)


    def visit_Or(self, node: ast.Or) -> str:
        return("Or")


    def visit_And(self, node: ast.And) -> str:
        return("And")        
    

    def visit_Eq(self, node: ast.Eq) -> str:
        return("==")


    def visit_NotEq(self, node: ast.NotEq) -> str:
        return("!=")


    def visit_Lt(self, node: ast.Lt) -> str:
        return("<")


    def visit_LtE(self, node: ast.LtE) -> str:
        return("<=")


    def visit_Gt(self, node: ast.Gt) -> str:
        return(">")

    def visit_GtE(self, node: ast.GtE) -> str:
        return(">=")


    def visit_Is(self, node: ast.Is) -> str:
        raise RuleVerificationException("{} should be handled by visit_Compare()".format(node))           
        return("is")


    def visit_IsNot(self, node: ast.IsNot) -> str:
        raise RuleVerificationException("{} should be handled by visit_Compare()".format(node))           
        return("is not")


    def visit_In(self, node: ast.In) -> str:
        return("in")  # handled by visit_Compare() subsequently


    def visit_NotIn(self, node: ast.NotIn) -> str:    
        return("not in") # handled by visit_Compare() subsequently


    def visit_Add(self, node: ast.Add) -> str:
        return("+")


    def visit_Sub(self, node: ast.Sub) -> str:
        return("-")
    

    def visit_Div(self, node: ast.Div) -> str:
        return("/")
        

    def visit_Mult(self, node: ast.Mult) -> str:
        return("*")


    def visit_Not(self, node: ast.Not) -> str:
        return("Not")     
    

    def visit_Mod(self, node: ast.Mod) -> str:
        return("%")
    

    def generic_visit(self, node: ast.AST) -> str:
        raise NotImplementedError(f"Unsupported syntax '{type(node).__name__}'")
        

class SolverResult():
    def __init__(self, sat_result: z3.CheckSatResult, model: dict = None, conflict_locations: list = None, conflict_constraints: list[str] = None):
        """
        Solver result from Z3 solver.

        Parameters
        ----------
        sat_result : z3.CheckSatResult
            Sat result from z3
        model : dict, if satisfied
            A solution from solve()
        conflict_locations: list, if unsatisfied
            Locations of conflicts such as line numbers or node ids, possibly None if the solver doesn't support.
        conflict_constraints: list, if unsatisfied
            Expressions that cause conflict, possibly None if the solver doesn't support.
        """            
        if not isinstance(sat_result, z3.CheckSatResult):
            raise RuleVerificationException("Parameter sat_result requires z3.CheckSatResult")

        self.sat_result = sat_result

        if self.sat_result == z3.sat:
            if not isinstance(model, dict):
                raise RuleVerificationException("Parameter model requires a dict")
            self.model = model

        elif self.sat_result == z3.unsat:
            self.conflict_locations = conflict_locations
            self.conflict_constraints = conflict_constraints


    def is_contradict(self) -> bool:
        """
        Check if model is contradict (no possible assignment).

        Returns
        -------
        bool
            True if contradict; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """              
        if self.sat_result == z3.unsat:   # Unsatisfiable
            return True
        
        return False
     

    def is_unknown(self) -> bool:
        """
        Check if solver fails to solve.

        Returns
        -------
        bool
            True if unknown; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """              
        if self.sat_result == z3.unknown:   # Fail to solve
            return True
        
        return False


    def is_satisfied(self) -> bool:
        """
        Check if model is satisfied.

        Returns
        -------
        bool
            True if satisfied; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """              
        if self.sat_result != z3.sat:
            return False
        
        return True

    
    def is_tautology(self) -> bool:
        """
        Check if model is a tautology (True for any assignment).

        Returns
        -------
        bool
            True if tautology; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """              
        if self.sat_result != z3.sat:
            return False
        
        if len(self.model) == 0: # Tautology. All variables are not necessary
            return True
        
        return False    
        

    def is_contingent(self) -> bool:
        """
        Check if model is contingent. In other words, the true or false of formulas depends on the variable assignment (data).

        Returns
        -------
        bool
            True if not tautology and not contradiction and not unknown; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """                
        if self.sat_result != z3.sat:
            return False
                
        if self.is_tautology():
            return False
                
        return True    
        
    
    has_no_solution = is_contradict
    has_solution = is_satisfied    

    
    def get_solution(self) -> dict:
        if self.sat_result != z3.sat:
            raise RuleVerificationException("Solution not existed")

        return self.model
    

    def get_conflict_locations(self) -> list:
        if self.sat_result != z3.unsat:
            raise RuleVerificationException("No conflict found")
        
        return self.conflict_locations
        

    def get_conflict_constraints(self) -> list:
        if self.sat_result != z3.unsat:
            raise RuleVerificationException("No conflict found")        
        
        return self.conflict_constraints
    

    def __str__(self) -> str:
        if self.sat_result == z3.unknown:
            return "Unknown solution"
        elif self.sat_result == z3.unsat:
            return "No solution"
        elif self.sat_result == z3.sat:
            if len(self.model) == 0:
                return "Tautology"
            else:
                return super().__str__()
        else:
            raise RuleVerificationException("Unknown sat result {}".format(self.sat_result))      

class Z3Solver():
    def __init__(self, unsat_core: bool = False):
        self.solver = z3.Solver()
        self.unsat_core = unsat_core
        self.solver.set(unsat_core=unsat_core)  # Set unsat core to True to get unsatisfiable core


    def _to_pyval(self, obj: object, value_type: typing.Type) -> object:
        if isinstance(obj, z3.BoolRef) and value_type == bool:
            return bool(obj)
        if isinstance(obj, z3.IntNumRef) and value_type == bool:
            return obj.as_long() == 1
        elif isinstance(obj, z3.IntNumRef) and value_type == int:
            return obj.as_long()
        elif isinstance(obj, z3.RatNumRef) and value_type == float: 
            return obj.numerator_as_long()/obj.denominator_as_long()
        elif isinstance(obj, z3.IntNumRef) and value_type == datetime:
            return EPOCH + timedelta(seconds=obj.as_long())
        elif isinstance(obj, z3.SeqRef) and value_type == str:
            return obj.as_string()
        else:
            raise RuleVerificationException("Cannot convert data type Z3 {} into python {}".format(obj.__class__.__name__, value_type.__name__))
        

    # **** Convert Z3Formulas for executing. For display only, see Z3Formulas.get_z3_formulas(). ****
    # Return a solution, unknown or no solution.
    def solve(self, formulas: Z3Formulas, negation: bool = False) -> SolverResult:  
        """
        Find a solution (aka. model) to formulas.

        Parameters
        ----------
        formulas : Z3Formulas
            Z3 formulas object
        negation : bool, default = False
            Negate the formulars before solve, e.g. (x > 1 and y < 0) becomes (x <= 1 or y >=0).

        Returns
        -------
        SolverResult
            Result from solver that can be satisfiable, unsatisfiable, or unknown. 
            If satisfiable, SolverResult.get_solution() returns a dict, each variable appears as a key of dict. 
            If key is not found, it means the value of the variable can be any (don't care).

        Raises
        ------
        Exception
            Any error.

        """        
        symbols = FUNCTIONCALL_SYMBOLS.copy() | STATIC_SYMBOLS.copy()  # Known variables for Z3. '|' is the union operator for dicts.

        for k, v in CUSTOM_Z3_SYMBOLS.items():
            if k not in symbols:
                symbols[k] = eval(v, Z3_SYMBOLS, symbols)  

        expr_map = {}   # Map x1 -> expression
        datetime_ignore_time_constraints = []  # Constraints for datetime resolution
        constraints = [] # List of all constraints
        constraint_sources = [] # List of constraint source (node_id, index, source_expr) for each constraint in constraints, None to don't care.        
        constraint_source_map = {} # Map of constraint label to constraint source 'node_id.index' -> constraint_source.
        #for expr, var_name in formulas.expression_map.items():
        for expr, var_name in formulas.full_expression_map:
            var_type = formulas.variables[var_name]
            if var_name in formulas.assignment_map:
                if var_type in (bool, int, float, str, datetime, list):
                    symbols[var_name] = eval(formulas.assignment_map[var_name], {}, symbols)
                else:
                    #raise RuleVerificationException("Cannot convert type {} for {}".format(var_type.__name__, expr))
                    #symbols[var_name] = eval(formulas.assignment_map[var_name], {}, symbols)
                    pass
            else:            
                expr_map[var_name] = expr
                if var_type is typing.Any:
                    raise RuleVerificationException("Cannot infer type (typing.Any) for variable {} = {}".format(var_name, expr))
                elif var_type == types.NoneType: 
                    symbols[var_name] = None
                    raise RuleVerificationException("Don't know know to convert NoneType to Z3 data type")
                elif var_type == int:
                    symbols[var_name] = z3.Int(var_name) 
                elif var_type == float:
                    symbols[var_name] = z3.Real(var_name)
                elif var_type == bool:
                    symbols[var_name] = z3.Bool(var_name)
                elif var_type == str:
                    symbols[var_name] = z3.String(var_name)
                elif var_type == datetime:
                    symbols[var_name] = z3.Int(var_name)   
                    if formulas.datetime_ignore_time: # For date resolution, modulo it with seconds per day. 82800 = 24*3600
                        datetime_ignore_time_constraints.append(("{} % 86400 == 0".format(var_name), 
                                                                "Force date resolution as datetime_ignore_time = {}".format(formulas.datetime_ignore_time),
                                                                False))  
                elif var_type == list: 
                    # In Z3, 'Constant' refers to an actual constant (like 1.0) or a variable (like x) without quantifier. 
                    # https://stackoverflow.com/questions/12448583/z3-const-declaration
                    # TODO: encode list as a sequence of Ints, Reals, Bools or Strings.
                    # Currently we do not solve for a list, so we always define a list as a sequence of strings.
                    # The only operation allowed for lists is containment, i.e. x in y.                     
                    symbols[var_name] = z3.Const(var_name, z3.SeqSort(z3.StringSort())) # list always encoded as a sequence of strings  
                else:
                    #raise RuleVerificationException("Cannot convert type {} for {}".format(var_type.__name__, expr))
                    pass

        #print(json.dumps(symbols, indent=2, default=str))            
        
        try:
            for i, (c, comment, neg) in enumerate(formulas.constraints):  # ignore comments
                if neg:
                    c = "Not({})".format(c)
                if negation:
                    constraints.append(z3.Not(eval(c, Z3_SYMBOLS, symbols)))  # Why do we need z3.Or and z3.Not here?
                else:
                    constraints.append(eval(c, Z3_SYMBOLS, symbols))
                node_id, index, source_expr = formulas.constraint_sources[i]    
                constraint_sources.append((node_id, index, source_expr))

            for c, comment, neg in datetime_ignore_time_constraints:  # ignore comments
                if neg:
                    c = "Not({})".format(c)
                if negation:
                    constraints.append(z3.Not(eval(c, Z3_SYMBOLS, symbols)))  # Why do we need z3.Or and z3.Not here?
                else:
                    constraints.append(eval(c, Z3_SYMBOLS, symbols))
                constraint_sources.append(None)

        except Exception as ex:
            #print(formulas.get_z3_formulas(), file=sys.stderr)
            raise RuleVerificationException("{}, cannot add constraint {}:".format(ex, c)).with_traceback(sys.exc_info()[2]) from ex 

        assert(len(constraints) == len(constraint_sources))

        if negation:
            #print(z3.Or(constraints))
            if self.unsat_core:
                raise RuleVerificationException("Unsat core is not supported for negation")
            self.solver.add(z3.Or(constraints))
        else:
            #print(z3.And(constraints))
            if self.unsat_core:
                label_order_map = {}
                for i, (c, constraint_source) in enumerate(zip(constraints, constraint_sources)):
                    if constraint_source is None or constraint_source[0] is None:
                        self.solver.add(c)
                    else:
                        label = constraint_source[0] if constraint_source[1] is None else '{}.{}'.format(constraint_source[0], constraint_source[1])
                        label_order_map[label] = i
                        constraint_source_map[label] = constraint_source
                        if isinstance(c, bool): 
                            c = z3.And(c) # Wrap True or False with And since boolean constrants are not supported by assert_and_track()
                        try: 
                            self.solver.assert_and_track(c, label)
                        except Exception as ex:
                            raise RuleVerificationException("Cannot add constraint '{}' <-> '{}' at {}: {}".format(c, constraint_source_map[label][2], label, ex)).with_traceback(sys.exc_info()[2]) from ex
            else:
                self.solver.add(z3.And(constraints))
   
        sat_result = self.solver.check()
        if sat_result == z3.unknown:
            return SolverResult(sat_result)
        
        elif sat_result == z3.unsat: 
            if self.unsat_core:
                sorted_conflict_labels = sorted(self.solver.unsat_core(), key = lambda label: label_order_map[label.decl().name()])
                conflict_sources = [constraint_source_map[label.decl().name()] for label in sorted_conflict_labels if constraint_source_map.get(label.decl().name()) is not None]
                conflict_nodes = [conflict_source[0] if conflict_source[1] is None else {'node_id': conflict_source[0], 'child_idx': conflict_source[1]} for conflict_source in conflict_sources]
                conflict_constraints = [constraint_source_map[label.decl().name()][2] for label in sorted_conflict_labels if constraint_source_map.get(label.decl().name()) is not None]
                return SolverResult(sat_result, conflict_locations=conflict_nodes, conflict_constraints=conflict_constraints)
            else:
                return SolverResult(sat_result)       
    
        model = self.solver.model()

        # Convert Z3 data types into python data types.
        if self.unsat_core:
            solver_result = SolverResult(sat_result, model={expr_map[v.name()]: self._to_pyval(model[v], formulas.variables[v.name()] ) for v in model if v.name() in formulas.variables}) # Excluding constraint labels generated by unsat core 
        else:
            solver_result = SolverResult(sat_result, model={expr_map[v.name()]: self._to_pyval(model[v], formulas.variables[v.name()] ) for v in model if v.name()})
        
        return solver_result


class _Statement:
    def __init__(self, node_id: str, index: int = 0):
        self.node_id = node_id
        self.index = index

 # For constraint statement, e.g. ("a > b", False), ("c < d", False)
class _Constraint(_Statement):
    def __init__(self, constraint: str, node_id: str, index: int = 0, negation: bool = False):
        super().__init__(node_id, index)
        self.constraint = constraint
        self.negation = negation

# For assignment statement, e.g. ("x", "b + c"), ("y", "a - b")
class _Assignment(_Statement):
    def __init__(self, name: str, expr: str, node_id: str, index: int = 0):
        super().__init__(node_id, index)
        self.name = name
        self.expr = expr

# _State stores the state of the current node, e.g. list of constraints accumulated from the first node to the current node.
class _State:
    def __init__(self, statements: list[_Statement] = [], path: list[str] = [], xpath: list[str | dict] = []):
        self.statements = statements
        self.path = path # Visited nodes, e.g. ["node1", "node2", "node3"]
        self.xpath = xpath # Visited xpath, e.g. ["node1", {"node_id": "node2", "child_idx": 1}, "node3"]


# Convert regex pattern to z3 expression string
def _convert_regex_to_z3(pattern: str) -> str:
    chunks = re.split(r'(\*|\?)', pattern)  # split by * or ? but keep the delimiters in captured groups
    z3_chunks = []
    for chunk in chunks:
        if chunk == '':
            continue
        if chunk == '*':
            z3_chunks.append("Star(AllChar(ReSort(StringSort())))")  # .*
        elif chunk == '?':
            z3_chunks.append("AllChar(ReSort(StringSort()))")   # .
        else:
            z3_chunks.append("Re({})".format(repr(chunk)))

    return "Concat({})".format(', '.join(z3_chunks))  


# Convert switch operator to Z3 python expression. Some are mapped to python operator directly. Others are mapped to z3 functions.   
# For examples, is_in -> in, is_not_in -> not in, like -> InRe(), not_like -> Not(InRe()).
# TODO: is_overlap, ...
def _convert_switch_operator_to_python_expression(expr: str, op:str, case: object) -> str:
    try:
        operator = OP[op]
    except (TypeError, KeyError) as error:
        raise NotImplementedError('Unknown operator "{}" in SwitchNode'.format(op)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred        
    # Convert operator to Z3 operator
    if operator in (OP.eq, OP['=']):
        return "({}) == ({})".format(expr, case)
    elif operator in (OP.neq, OP['<>']):
        return "({}) != ({})".format(expr, case)      
    elif operator in (OP.lt, OP['<']):
        return "({}) < ({})".format(expr, case)        
    elif operator in (OP.le, OP['<=']):
        return "({}) <= ({})".format(expr, case)   
    elif operator in (OP.gt, OP['>']):
        return "({}) > ({})".format(expr, case)
    elif operator in (OP.ge, OP['>=']):
        return "({}) >= ({})".format(expr, case)
    elif operator in (OP.like, OP.not_like):  # TODO: Ignore case. Possibly convert everything to lowercase before building Z3 fomulas.
        # Convert wildcard to to RegEx, i.e. * to .* and ? to .
        if not isinstance(case, str):
            raise RuleVerificationException("Operator LIKE needs string pattern")
        literal = ast.literal_eval(case)
        if not isinstance(literal, str):  # Convert to string
            raise RuleVerificationException("Cannot parse string pattern '{}' to string".format(case))
        constraint = "InRe({}, {})".format(expr, _convert_regex_to_z3(literal))
        if operator == OP.not_like:
            constraint = "Not({})".format(constraint)
        return constraint
    elif operator in (OP.is_in, OP.is_not_in):        
        if operator == OP.is_in:
            constraint = "{} in {}".format(expr, case)
        else:
            constraint = "Not({} in {})".format(expr, case)
        return constraint
    else:
        raise RuleVerificationException("Operator {} not supported in verification".format(op))
    
    
def _append_verification_result(analysis: dict, verification: dict) -> None:
    if 'verifications' not in analysis:
        analysis['verifications'] = []
    analysis['verifications'].append(verification)


def _get_path_label(rule_package: RulePackage, xpath: list[str | dict]) -> str:
    path_with_cases = []
    for elem in xpath:
        if isinstance(elem, str):
            elem = {'node_id': elem}
        node = rule_package.get_node(elem['node_id'])
        if isinstance(node, SwitchNode):
            if 'child_idx' in elem:
                oper, case, child = node.children[elem['child_idx']]
                path_with_cases.append("{}({} {})".format(node.node_id, oper, case))
            elif 'default' in elem:
                path_with_cases.append("{}(*)".format(node.node_id))
            else:
                path_with_cases.append(node.node_id)
        else:
            path_with_cases.append(node.node_id)

    return '-> '.join(path_with_cases)


def _verify_path(rule_package: RulePackage, xpath: list[str | dict], symbols: dict, state: _State, analysis: dict = {}, config: dict = {}) -> dict:
    '''
    The internal function to verify if a path specified by xpath is contingent or contradict.

    Parameters
    ----------
    rule_package: RulePackage
        Rule package that contains all nodes.
    xpath: list[str | dict]
        The list of node ids or node dicts that represents a path, e.g. ['node1', 'node2', 'node3'] for a simple xpath.
        If a node has multiple outputs, a dict must be used to indicate a specific output; 
        otherwise, all outputs that match the next node in the path are verified
        Fields in the dict depends on the node type. SwitchNode has "child_idx" or "default" fields.    
        For example, a switch node can be {node_id": "switch2", "child_idx": 1} or {"node_id": "switch3", "default": "default"}
    symbols: dict
        A dict that maps a symbol to an example value or a data type. 
        It represents an input transaction which contains variables to the rules. 
        Note that all values converted to their data types internally.
        Do not change the symbols in the recursion.
    state: _State
        The internal variables to keep tracking the state of the verification.
    analysis: dict
        A dict to keep tracking all verification results.
    config: dict
        A dict of verification configuation, e.g. {'datetime_ignore_time': True} to ignore time in datetime.
       
    Returns:
    --------
        An analysis dict having 'verifications' key for a list of verification results.
    '''    

    if len(xpath) == 0:
        datetime_ignore_time = config.get('datetime_ignore_time', True)
        z3f = Z3Formulas(symbols, datetime_ignore_time=datetime_ignore_time)
        for statement in state.statements:
            if isinstance(statement, _Assignment):
                z3f.add_assignment(statement.name, statement.expr)
            elif isinstance(statement, _Constraint):
                z3f.add_constraint(statement.constraint, negation=statement.negation, node_id=statement.node_id, index=statement.index)
            else:
                raise RuleVerificationException("Unsupported statement {}".format(statement))

        path_label = _get_path_label(rule_package, state.xpath)
        formulas = z3f.get_z3_formulas()
        #print(formulas)
        solver = Z3Solver(unsat_core=config.get('z3_unsat_core', True))
        solver_result = solver.solve(z3f)
        verification = {
            'path': state.path.copy(),
            'xpath': state.xpath.copy(),
            'path_label': path_label,
            'z3': formulas
        }
        if solver_result.is_contradict():
            verification['result'] = 'Not reachable'
            verification['conflict_constraints'] = solver_result.get_conflict_constraints()
            verification['conflict_locations'] = solver_result.get_conflict_locations()
        elif solver_result.is_tautology():
            verification['result'] = 'Always reachable'
        elif solver_result.is_unknown():
            verification['result'] = 'Cannot decide'
        else:
            verification['result'] = 'Has solution'
            verification['solution'] = solver_result.get_solution()

        _append_verification_result(analysis, verification)
        return analysis       
        
    last_statements: list[_Statement] = state.statements
    last_path: list[str] = state.path
    last_xpath: list[str | dict] = state.xpath

    new_statements: list[_Statement] = last_statements.copy()
    new_path: list[str] = last_path.copy()
    new_xpath: list[str] = last_xpath.copy()

    head, tail = xpath[0], xpath[1:] if len(xpath) > 1 else []
    
    head = {'node_id': head} if isinstance(head, str) else head 
    node_id = head['node_id']
    node = rule_package.get_node(node_id)
    if node is None:
        raise RuleVerificationException("Node {} not found in rule package".format(head))
    
    next_node = None  # Look forward to the next node for checking if it is a child of the current node.
    if len(tail) > 0:
        next_node = rule_package.get_node(tail[0] if isinstance(tail[0], str) else tail[0].get('node_id'))

    try:

        if isinstance(node, (ForkNode, BigTableNode)):  # These node types do not affect the formulas.
            new_path.append(node.node_id)
            new_xpath.append(node.node_id)
            new_state = _State(new_statements, new_path, new_xpath) 

        elif isinstance(node, TransformNode):   # This node type creates an assignment statement in formulas.
            expr = node.transformer.raw
            if not isinstance(expr, str):
                raise RuleVerificationException("Only expression string is supported in verification")
            
            # Note: Assume that checking if required fields are available is done by a other method (e.g. RulePackage.analyze()).
            field_name = node.field_name
            new_path.append(node.node_id)
            new_xpath.append(node.node_id)
            new_statements.append(_Assignment(field_name, expr, node.node_id, None))   
            new_state = _State(new_statements, new_path, new_xpath)

        elif isinstance(node, SelectNode):  # This node filters variables. 
            # TODO: Filter variables. Currently we ignore this node and assume the checking is done in RulePackage.analyze()
            #       The filter below doesn't work because if the selected variables depends on the unselected variables, 
            #         an exception occurs as some symbols are unknown. 
            #       For example, given name and age initially. if x = age + 10, then filter only x.
            #       When x is evaluated later, age is unknown.
            #       One possible solution is to pass Z3Formulas into the recursion. The assignments and constraints are inserted online into Z3Formulas 
            #          while visiting the node (not at the end of the path). Z3Formulas object must have copy() method to work with recurion.
            #          Then in SelectNode, the Z3Formulas object is updated with the selected variables. Not easy.
            #field_names = node.field_names
            #new_symbols = {key: symbols[key] for key in symbols if key in field_names}  # SelectNode only keeps symbols that are in field_names 
            #new_assignments = [assignment for assignment in new_assignments if assignment[0] in field_names]

            new_path.append(node.node_id)
            new_xpath.append(node.node_id)
            new_state = _State(new_statements, new_path, new_xpath)

        elif isinstance(node, SwitchNode):  # This node adds one or more constraints to the formulas.

            # Note: Assume that checking if required fields are available is done by another method (e.g. RulePackage.analyze()).
            expr = node.raw
            if not isinstance(expr, str):
                raise RuleVerificationException("Only expression string is supported in verification")

            if 'child_idx' not in head and 'default' not in head and len(tail) == 0: # Verify every case and default
                negation_constraints = []
                for c_idx, (oper, case, child) in enumerate(node.children): # Loop all cases and we need to negate all previous cases
                    constraint = _convert_switch_operator_to_python_expression(expr, oper, case)    
                    new_statements = last_statements.copy()       
                    for neg_idx, negation_constraint in enumerate(negation_constraints):  # Negate the previous cases
                        new_statements.append(_Constraint(negation_constraint, node.node_id, neg_idx, negation=True))  # Negate the previous case
                    new_statements.append(_Constraint(constraint, node.node_id, c_idx, negation=False))     
                    new_path = last_path.copy()
                    new_path.append(node.node_id)
                    new_xpath = last_xpath.copy()
                    new_xpath.append({"node_id": node.node_id, "child_idx": c_idx})
                    new_state = _State(new_statements, new_path, new_xpath)
     
                    _verify_path(rule_package, tail, symbols, new_state, analysis, config=config) 
                    
                    negation_constraints.append(constraint)  # Store the previous case for negation                    

                if node.default_child is not None:
                    new_statements = last_statements.copy()
                    for neg_idx, (oper, case, child) in enumerate(node.children): # Loop all cases to negate them  
                        constraint = _convert_switch_operator_to_python_expression(expr, oper, case) 
                        new_statements.append(_Constraint(constraint, node.node_id, neg_idx, negation=True))
                    new_path = last_path.copy()
                    new_path.append(node.node_id)
                    new_xpath = last_xpath.copy()
                    new_xpath.append({"node_id": node.node_id, "default": "default"})
                    new_state = _State(new_statements, new_path, new_xpath)

                    _verify_path(rule_package, tail, symbols, new_state, analysis, config=config)

                return analysis

            if 'child_idx' in head:  # Verify a specific case by child_idx
                child_idx = head.get('child_idx')
                negation_constraints = []
                for c_idx, (oper, case, child) in enumerate(node.children): # Loop all cases and we need to negate all previous cases
                    constraint = _convert_switch_operator_to_python_expression(expr, oper, case)
                    
                    if c_idx == child_idx:
                        new_statements = last_statements.copy()      
                        for neg_idx, negation_constraint in enumerate(negation_constraints):  # Negate the previous cases
                            new_statements.append(_Constraint(negation_constraint, node.node_id, neg_idx, negation=True))  # Negate the previous case   
                        new_statements.append(_Constraint(constraint, node.node_id, c_idx, negation=False))                                                    
                        new_path = last_path.copy()
                        new_path.append(node.node_id)
                        new_xpath = last_xpath.copy()
                        new_xpath.append({"node_id": node.node_id, "child_idx": c_idx})
                        new_state = _State(new_statements, new_path, new_xpath)

                        if next_node is not None and next_node != child: # Check if the next node is the right child of the matching case
                            raise RuleVerificationException('Incorrect link from {}({} {}) to node {}'.format(node_id, oper, case, next_node.node_id))

                        # Recursively to the next node                       
                        return _verify_path(rule_package, tail, symbols, new_state, analysis, config=config) 
                                           
                    negation_constraints.append(constraint)  # Store the previous case for negation 

                new_path = last_path.copy()
                new_path.append(node.node_id)
                new_xpath = last_xpath.copy()
                new_xpath.append(node.node_id)
                raise RuleVerificationException("Cannot find the matching case in SwitchNode {}".format(head))

            if 'default' in head:  # Verify the default case
                new_statements = last_statements.copy()
                for neg_idx, (oper, case, child) in enumerate(node.children): # Loop all cases to negate them  
                    constraint = _convert_switch_operator_to_python_expression(expr, oper, case) 
                    new_statements.append(_Constraint(constraint, node.node_id, neg_idx, negation=True))
                new_path = last_path.copy()
                new_path.append(node.node_id)
                new_xpath = last_xpath.copy()
                new_xpath.append({"node_id": node.node_id, "default": "default"})
                new_state = _State(new_statements, new_path, new_xpath)
                
                if next_node is not None and next_node != node.default_child: # Check if the next node is the default child of the current node
                    raise RuleVerificationException('Incorrect link from {}(*) to node {}'.format(node_id, next_node.node_id))
                
                # Recursively to the next node
                return _verify_path(rule_package, tail, symbols, new_state, analysis, config=config)                
                 
            # Find child_idx or default based on the next node that matches
            if next_node is not None:
                negation_constraints = []
                for c_idx, (oper, case, child) in enumerate(node.children): # Loop all cases and we need to negate all previous cases
                    constraint = _convert_switch_operator_to_python_expression(expr, oper, case)
                    if child == next_node:
                        new_statements = last_statements.copy()
                        for neg_idx, negation_constraint in enumerate(negation_constraints):  # Negate the previous cases
                            new_statements.append(_Constraint(negation_constraint, node.node_id, neg_idx, negation=True))  # Negate the previous case
                        new_statements.append(_Constraint(constraint, node.node_id, c_idx, negation=False))                                                        
                        new_path = last_path.copy()
                        new_path.append(node.node_id)
                        new_xpath = last_xpath.copy()
                        new_xpath.append({"node_id": node.node_id, "child_idx": c_idx})
                        new_state = _State(new_statements, new_path, new_xpath)

                        # Recursively to the next node                       
                        _verify_path(rule_package, tail, symbols, new_state, analysis, config=config) 
                    
                    negation_constraints.append(constraint)  # Store the previous case for negation         
    
                if node.default_child is not None and node.default_child == next_node:
                    new_statements = last_statements.copy()
                    for neg_idx, (oper, case, child) in enumerate(node.children): # Loop all cases to negate them  
                        constraint = _convert_switch_operator_to_python_expression(expr, oper, case) 
                        new_statements.append(_Constraint(constraint, node.node_id, neg_idx, negation=True))
                    new_path = last_path.copy()
                    new_path.append(node.node_id)
                    new_xpath = last_xpath.copy()
                    new_xpath.append({"node_id": node.node_id, "default": "default"})
                    new_state = _State(new_statements, new_path, new_xpath)

                    _verify_path(rule_package, tail, symbols, new_state, analysis, config=config)

                return analysis

            # If all the above fail, 
            new_path.append(node.node_id)
            new_xpath = last_xpath.copy()
            new_xpath.append(node.node_id)
            raise RuleVerificationException("Cannot find the matching case in SwitchNode {}".format(head))

        elif isinstance(node, (RuleNode, FlagNode)):  # This node validates the formulas.
            if isinstance(node, FlagNode):
                if isinstance(node.template, Template):
                    for name in node.template.get_identifiers():
                        #facts.add(name)
                        # Note: Assume that checking if required fields are available is done by a other method (e.g. RulePackage.analyze()).
                        pass
                elif isinstance(node.template, dict):
                    query = jsonpath_ng.parse("$..*") # Find all possible children
                    for match in query.find(node.template): # For each matching element
                        if match.path == jsonpath_ng.jsonpath.Fields('$ref'):
                            #facts.add(match.value) 
                            # Note: Assume that checking if required fields are available is done by a other method (e.g. RulePackage.analyze()).
                            pass
                        elif isinstance(match.value, Template):
                            for name in match.value.get_identifiers():
                                #facts.add(name)
                                # Note: Assume that checking if required fields are available is done by a other method (e.g. RulePackage.analyze()).
                                pass                     
                else: 
                    raise RuleVerificationException('Unknown template {}'.format(node.template))
                
            new_path.append(node.node_id)
            new_xpath.append(node.node_id)          
            new_state = _State(new_statements, new_path, new_xpath)  # Update state for the next node

        # TODO: SubRuleNode.
        else:
            new_path.append(node.node_id)
            new_xpath.append(node.node_id)           
            raise RuleVerificationException("{} is not supported in verification".format(node.__class__.__name__))

    except RuleVerificationException as ex:  # If exception is raised at the current node, just skip this node and return.
        path_label = _get_path_label(rule_package, new_xpath)                
        verification = {
            'path': new_path,
            'xpath': new_xpath,
            'path_label': path_label,
            'z3': None,
            'result': 'Skipped',
            'error': '{}: {}'.format(ex.__class__.__name__, str(ex))
        }
        _append_verification_result(analysis, verification)
        return analysis    
    
    if next_node is not None and next_node not in node.children:  # Check if the next node is a child of the current node
        raise RuleVerificationException('Incorrect link from {} to node {}'.format(node.node_id, next_node.node_id))
    
    return _verify_path(rule_package, tail, symbols, new_state, analysis, config=config)


def verify_path(rule_package: RulePackage, xpath: list[str | dict], symbols: dict, config: dict = {}) -> dict:
    '''
    Verify if a path specified by xpath is contingent or contradict.

    Parameters
    ----------
    rule_package: RulePackage
        Rule package that contains all nodes.
    xpath: list[str | dict]
        The list of node ids or node dicts that represents a path, e.g. ['node1', 'node2', 'node3'] for a simple xpath.
        If a node has multiple outputs, a dict must be used to indicate a specific output; 
        otherwise, all outputs that match the next node in the path are verified
        Fields in the dict depends on the node type. SwitchNode has "child_idx" or "default" fields.    
        For example, a switch node can be {node_id": "switch2", "child_idx": 1} or {"node_id": "switch3", "default": "default"}
    symbols: dict
        A dict that maps a symbol to an example value or a data type. 
        It represents an input transaction which contains variables to the rules. 
        Note that all values converted to their data types internally.
    config: dict
        A dict of verification configuation, e.g. {'datetime_ignore_time': True} to ignore time in datetime.
       
    Returns:
    --------
        An analysis dict having 'verifications' key for a list of verification results.
    '''
    analysis = {
        'verifications': []
    }
    state = _State([], [], [])
    _verify_path(rule_package, xpath, symbols, state, analysis, config=config) 

    return analysis


def _verify_all_paths(rule_package: RulePackage, node: Node, symbols: dict, ancestors: list[str | dict], analysis: dict = {}, config: dict = {}) -> dict:
    '''
    This is an internal function to verify if all paths to flag or rule nodes in RulePackage is contingent or contradict against symbols.

    Parameters
    ----------
    rule_package: RulePackage
        Rule package that contains all nodes.
    node: Node
        A node in the rule package as the current visited node.
    symbols: dict
        A dict that maps a symbol to an example value or a data type. 
        It represents an input transaction which contains variables to the rules. 
        Note that all values converted to their data types internally.
    ancestors: list[str | dict]
        The list of node ids or node dicts that represents visited nodes in the current path.
    analysis: dict
        The variable to keep verification results.
    config: dict
        A dict of verification configuation, e.g. {'datetime_ignore_time': True} to ignore time in datetime.        
        
    Returns:
    --------
        An analysis dict having 'verifications' key for a list of verification results.
    '''

    if node is None: 
        return analysis

    if isinstance(node, SwitchNode):  # This node adds one or more constraints to the formulas.
        for child_idx, (oper, case, child) in enumerate(node.children): # Loop all cases and we need to negate all previous cases
            # Recursively verify paths for all children of SwitchNode.
            new_ancestors = ancestors + [{'node_id': node.node_id, 'child_idx': child_idx}]
            _verify_all_paths(rule_package, child, symbols, new_ancestors, analysis, config=config)   

        if node.default_child is not None:
            # Recursively verify paths for all children of SwitchNode.
            new_ancestors = ancestors + [{'node_id': node.node_id, 'default': 'default'}]
            _verify_all_paths(rule_package, node.default_child, symbols, new_ancestors, analysis, config=config)

    elif isinstance(node, BranchNode):
        child = node.children[0] # Since it is not supported so no need to repeat for all children.
        new_ancestors = ancestors + [node.node_id]
        _verify_all_paths(rule_package, child, symbols, new_ancestors, analysis, config=config)  
        return 

    else:
        if isinstance(node, (RuleNode, FlagNode)):  # This node validates the formulas.
            xpath = ancestors + [node.node_id]
            path_analysis = verify_path(rule_package, xpath, symbols, config=config)

            for verification in path_analysis['verifications']:
                _append_verification_result(analysis, verification)  

        # Recursively verify paths for all children of the current node.
        for child in node.children:
            new_ancestors = ancestors + [node.node_id]
            _verify_all_paths(rule_package, child, symbols, new_ancestors, analysis, config=config)   

    return analysis


def verify_all_paths(rule_package: RulePackage, symbols: dict, config: dict = {}) -> dict:
    '''
    Verify if all paths to flag or rule nodes in RulePackage is contingent or contradict against symbols.

    Parameters
    ----------
    rule_package: RulePackage
        Rule package that contains all nodes.
    symbols: dict
        A dict that maps a symbol to an example value or a data type. 
        It represents an input transaction which contains variables to the rules. 
        Note that all values converted to their data types internally.
    config: dict
        A dict of verification configuation, e.g. {'datetime_ignore_time': True} to ignore time in datetime.             
        
    Returns:
    --------
        An analysis dict having 'verifications' key for a list of verification results.
    '''      
    analysis = {
        'verifications': []
    }
    for child in rule_package.children:
        _verify_all_paths(rule_package, child, symbols, [], analysis, config=config) 

    return analysis    


# TODO: Obsolete. To be removed in the future.
def locate_first_conflict(rule_package: RulePackage, xpath: list[str | dict], symbols: dict, config: dict = {}) -> list[str | dict]:
    '''
    Locate the first conflict from beginning of the path. (OBSOLETE)

    Parameters
    ----------
    rule_package: RulePackage
        Rule package that contains all nodes.
    xpath: list[str | dict]
        The list of node ids or node dicts that represent a path in question.
    config: dict
        A dict of verification configuation, e.g. {'datetime_ignore_time': True} to ignore time in datetime.             
        
    Returns:
    --------
        The list of the first node to the node in xpath that causes the first conflict; or None if no conflict is found.
    '''    
    for i in range(0, len(xpath)):
        inspected_xpath = xpath[:i]
        if len(inspected_xpath) > 0:
            node_id = inspected_xpath[-1] if isinstance(inspected_xpath[-1], str) else inspected_xpath[-1]['node_id']
            node = rule_package.get_node(node_id)
            if node is None:
                raise RuleVerificationException("Node {} not found in rule package".format(inspected_xpath[-1]))        
            
            if not isinstance(node, SwitchNode): 
                next # If not a SwitchNode, just skip checking because it doesn't cause conflict. 

        analysis = verify_path(rule_package, inspected_xpath, symbols, config=config)
        for verification in analysis['verifications']:
            if verification['result'] == 'Not reachable':
                return inspected_xpath
            elif verification['result'] == 'Skipped':
                raise RuleVerificationException("Unexpected exception occurs")
            elif verification['result'] == 'Cannot decide':    
                raise RuleVerificationException("Cannot decide")
            
    return None


class RuleVerificationException(Exception):
    pass

