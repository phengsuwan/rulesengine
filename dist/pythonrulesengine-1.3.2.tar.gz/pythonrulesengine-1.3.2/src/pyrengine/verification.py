import ast
import builtins
import inspect
import typing
import types


# Explicitly import modules as globals() works only for the current module 
from pyrengine.objectlist import *
from z3 import *


_LITERAL_TYPE = ast.Constant | ast.List
_VAR_TYPE = ast.Name | ast.Attribute | ast.Call


# https://stackoverflow.com/questions/70967266/what-exactly-is-python-typing-callable
# https://stackoverflow.com/questions/3061/calling-a-function-of-a-module-by-using-its-name-a-string
def _get_return_type(callable_name: str, class_name: str = None) -> typing.Type:
    # callable_name: function or method name

    if class_name:
        # globals() can see only imports in the current module 
        cls = globals().get(class_name)
        if not (cls and inspect.isclass(cls)): 
            raise Exception("Class {} not found in verification import".format(class_name))    

        callable = getattr(cls, callable_name, None)    # Method not bound to an object is treated as a function.
        if not (callable and inspect.isfunction(callable)): 
            raise Exception("Method {} not found in verification import".format(callable_name))    
    else:
        callable = globals().get(callable_name)
        if not callable: 
            callable = getattr(builtins, callable_name)  # https://stackoverflow.com/questions/68919220/using-getattr-to-access-built-in-functions
        if not (callable and (inspect.isbuiltin(callable) or inspect.isfunction(callable))): 
            raise Exception("Function {} not found in verification import".format(callable_name))            
        
    hints = typing.get_type_hints(callable)
    return_type = hints.get('return') # https://stackoverflow.com/questions/49560974/inspect-params-and-return-types
    
    #https://stackoverflow.com/questions/74544539/python-how-to-check-what-types-are-in-defined-types-uniontype
    origin = typing.get_origin(return_type)  # For return type with Union or |
    if origin is typing.Union or origin is types.UnionType:   #  types.UnionType if using |
        return_type = typing.get_args(return_type)[0]  # Get only the first type

    return return_type or float

    
# https://gist.github.com/jtpio/cb30bca7abeceae0234c9ef43eec28b4
# https://greentreesnakes.readthedocs.io/en/latest/
# https://docs.python.org/3/reference/grammar.html
# https://docs.python.org/3/library/ast.html
class Z3Formulas(ast.NodeVisitor):
    """
    Convert AST tree to Z3 formulas    

    """

    def __init__(self, context: dict):
        self.variable_map: dict[str, int] = {}   # Map of seen expression to variable index
        self.variables: list[tuple[str, typing.Type]] = [] # List of tuple (variable, type)
        self.assignment_map: dict[str, str] =  {}  # Dict of assignment, e.g. x = a + b
        self.constraints: list[str] = []
        self.context = context # Map of identifier to object


    # https://stackoverflow.com/questions/70967266/what-exactly-is-python-typing-callable
    # https://stackoverflow.com/questions/3061/calling-a-function-of-a-module-by-using-its-name-a-string
    def _get_variable_return_type(self, variable: _VAR_TYPE) -> typing.Type:
        if isinstance(variable, ast.Name):
            id = variable.id

            idx = self.variable_map.get(id)  # First from seen (local) variable
            if idx is not None:
                return self.variables[idx][1]
                        
            # TODO: Get type from external mapping
            if id.startswith("c_"):   # Second priority from transaction
                return OBJECTLIST        

            if id in self.context:   # Third from context vars
                obj = self.context[id]
                return type(obj)

            name = getattr(builtins, id, None)  # https://stackoverflow.com/questions/68919220/using-getattr-to-access-built-in-functions

            if not name:
                raise Exception("Name {} not found in verification".format(id))            
            
            if inspect.isbuiltin(name) or inspect.isfunction(name): 
                callable = name
            else:
                raise Exception("Name {} not a function in verification".format(name))            

        elif isinstance(variable, ast.Call):  # function call func() or method call obj.attr()
            cls = self._get_variable_return_type(variable.func)   # Determine return type based on function name, ignoring any arguments
            return cls

        elif isinstance(variable, ast.Attribute):  # Attribute obj.attr
            cls = self._get_variable_return_type(variable.value)
            if not (cls and inspect.isclass(cls)): 
                raise Exception("Class {} not found in verification".format(cls))    
            attr = getattr(cls, variable.attr, None)    
            if not attr:
                raise Exception("Attribute {} not found for class {} in verification".format(variable.attr, cls.__name__))
            if inspect.isfunction(attr): # Method not bound to an object is treated as a function.
                callable = attr
        else:
            raise Exception("Require python variable, function or method call but {} is found".format(variable))

            
        hints = typing.get_type_hints(callable)
        return_type = hints.get('return') # https://stackoverflow.com/questions/49560974/inspect-params-and-return-types
        
        #https://stackoverflow.com/questions/74544539/python-how-to-check-what-types-are-in-defined-types-uniontype
        origin = typing.get_origin(return_type)  # For return type with Union or |
        if origin is typing.Union or origin is types.UnionType:   #  types.UnionType if using |
            return_type = typing.get_args(return_type)[0]  # Get only the first type

        return return_type or float
        

    # Return the mapped variables x0, x1, ... for seen expressions or create a new one.
    def getOrCreateVariable(self, expr: str, expr_type: typing.Type) -> str:
        idx = self.variable_map.get(expr)
        if idx is None:
            idx = len(self.variables)
            self.variable_map[expr] = idx
            self.variables.append((f"x{idx}", expr_type))
            #print(expr, idx)
        return self.variables[idx][0]
    
        
    def add_constraint(self, expr: str):
        tree = ast.parse(expr, mode='eval')
        constraint = self.visit(tree)  # The returned constraint is converted with mapped variables. 
        self.constraints.append(constraint)

    
    # For assignment statement x = a + b
    def add_assignment(self, name: str, expr: str):
        tree = ast.parse(expr, mode='eval')      
        expression = self.visit(tree)  # The returned expression is converted with mapped variables.
        # Add new variable, assuming no duplication
        idx = len(self.variables)
        self.variable_map[name] = idx
        var_name = f"x{idx}"
        self.variables.append((var_name, None))  # Type is None since this variable is evaluated in python
        self.assignment_map[var_name] = expression
        #print(name, idx)
     

    def get_z3_formulas(self) -> str:
        variable_declarations = []
        for expr, idx in self.variable_map.items():
            var_name, var_type = self.variables[idx]
            if var_type is None:
                variable_declaration = "{} = {} # {}".format(var_name, self.assignment_map[var_name], expr)
            elif issubclass(var_type, types.NoneType): 
                variable_declaration = "{} = None".format(var_name)
            elif issubclass(var_type, int):
                variable_declaration = "{} = Int('{}') # {}".format(var_name, var_name, expr)  
            elif issubclass(var_type, float):
                variable_declaration = "{} = Real('{}') # {}".format(var_name, var_name, expr)  
            elif issubclass(var_type, bool):
                variable_declaration = "{} = Bool('{}') # {}".format(var_name, var_name, expr)  
            elif issubclass(var_type, str):
                variable_declaration = "{} = String('{}') # {}".format(var_name, var_name, expr)  
            else:
                raise Exception("Cannot convert type {}".format(var_type.__name__))
            variable_declarations.append(variable_declaration)
        
        head_section = "\n".join(variable_declarations)    
        body_section = "solve({})".format(",".join(self.constraints))
        return "\n".join([head_section, body_section])


    def _convert_literal(self, node: _LITERAL_TYPE) -> str:
        
        literal = ast.literal_eval(node)
        if isinstance(literal, types.NoneType | int | float | str):
            return repr(literal)
        
        if isinstance(literal, list) and len(literal) > 0:
            if not isinstance(literal[0], types.NoneType | int | float | str):
                raise Exception("Element in list must be a primitive data type, but type {} is found".format(type(literal[0])))

            if not all(type(literal[0]) == type(e) for e in literal):
                raise Exception("All elements in list must have the same type")
            
            return repr(literal)
        
        raise Exception("Type {} not allow in literal".format(type(literal)))


    def visit_Expression(self, node: ast.Expr) -> str:
        return self.visit(node.body)
    

    def visit_Name(self, node: ast.Name) -> str:  # Variable name
        var_type = self._get_variable_return_type(node)
        var = self.getOrCreateVariable(node.id, var_type)        
        return var


    def visit_Constant(self, node: ast.Constant) -> str: # Primitive constant
        return self._convert_literal(node)


    def visit_List(self, node: ast.List) -> str: # List 
        return self._convert_literal(node)


    def visit_Call(self, node: ast.Call) -> str: # Function call
        var_type = self._get_variable_return_type(node)
        return self.getOrCreateVariable(ast.unparse(node), var_type)
    
    
    def visit_Attribute(self, node: ast.Attribute) -> str: # Method call
        var_type = self._get_variable_return_type(node)
        return self.getOrCreateVariable(ast.unparse(node), var_type)
            

    def visit_BoolOp(self, node: ast.BoolOp) -> str:
        values = " ".join(["{} {}".format(self.visit(node.op), self.visit(value)) for value in node.values[1:]])
        return "({} {})".format(self.visit(node.values[0]), values)


    def visit_BinOp(self, node: ast.BinOp) -> str:
        l_operand = node.left
        if isinstance(l_operand, _LITERAL_TYPE):
            left = self._convert_literal(l_operand)
        elif isinstance(l_operand, _VAR_TYPE):
            left_type = self._get_variable_return_type(l_operand)
            left = self.getOrCreateVariable(ast.unparse(l_operand), left_type)
        else: 
            # TODO: what is allowed to visit() or raise Exception
            left = self.visit(l_operand)

        op = self.visit(node.op)
        
        r_operand = node.right
        if isinstance(r_operand, _LITERAL_TYPE):
            right = self._convert_literal(r_operand)
        elif isinstance(r_operand, _VAR_TYPE):
            right_type = self._get_variable_return_type(r_operand)
            right = self.getOrCreateVariable(ast.unparse(r_operand), right_type)
        else:
            # TODO: what is allowed to visit() or raise Exception
            right = self.visit(r_operand)
       
        return "({} {} {})".format(left, op, right)
    

    def visit_Compare(self, node: ast.Compare) -> str:
        if len(node.ops) > 1:
            raise Exception("Support simple expression")
        
        l_operand = node.left
        if isinstance(l_operand, _LITERAL_TYPE):
            left = self._convert_literal(l_operand)
        elif isinstance(l_operand, _VAR_TYPE):
            left_type = self._get_variable_return_type(l_operand)
            left = self.getOrCreateVariable(ast.unparse(l_operand), left_type)
        else:
            # TODO: what is allowed to visit() or raise Exception
            left = self.visit(l_operand)

        op = self.visit(node.ops[0])

        r_operand = node.comparators[0]
        if isinstance(r_operand, _LITERAL_TYPE):
            right = self._convert_literal(r_operand)
        elif isinstance(r_operand, _VAR_TYPE):
            right_type = self._get_variable_return_type(r_operand)
            right = self.getOrCreateVariable(ast.unparse(r_operand), right_type)
        else:
            # TODO: what is allowed to visit() or raise Exception
            right = self.visit(r_operand)

        return "({} {} {})".format(left, op, right)


    def visit_Or(self, node: ast.Or) -> str:
        return("or")


    def visit_And(self, node: ast.And) -> str:
        return("and")        
    

    def visit_Eq(self, node: ast.Eq) -> str:
        return("==")


    def visit_NotEq(self, node: ast.NotEq) -> str:
        return("!=")


    def visit_Lt(self, node: ast.Lt) -> str:
        return("<")


    def visit_LtE(self, node: ast.LtE) -> str:
        return("<=")


    def visit_Gt(self, node: ast.Gt) -> str:
        return(">")

    def visit_GtE(self, node: ast.GtE) -> str:
        return(">=")


    def visit_Is(self, node: ast.Is) -> str:
        return("is")


    def visit_IsNot(self, node: ast.IsNot) -> str:
        return("is not")


    def visit_In(self, node: ast.In) -> str:
        return("in")


    def visit_NotIn(self, node: ast.NotIn) -> str:
        return("not in")


    def visit_Add(self, node: ast.Add) -> str:
        return("+")


    def visit_Mult(self, node: ast.Mult) -> str:
        return("*")


    def visit_Not(self, node: ast.Not) -> str:
        return("not")     
    

    def generic_visit(self, node: ast.AST) -> None:
        raise NotImplementedError(f"Unsupported syntax '{type(node).__name__}'")
        

class Z3Solver():
    def __init__(self):
        self.solver = Solver()


    # Return solution (dict) or None
    def solve(self, formulas: Z3Formulas, negation: bool = False) -> dict: 
        """
        Find a solution (aka. model) to formulas.

        Parameters
        ----------
        formulas : Z3Formulas
            Z3 formulas object
        negation : bool, default = False
            Negate the formulars before solve, e.g. (x > 1 and y < 0) becomes (x <= 1 or y >=0).

        Returns
        -------
        dict
            A solution if satisfiable or None if unsatisfiable. Each variable appears as a key of dict. 
            If key is not found, it means the value of the variable can be any (don't care).

        Raises
        ------
        Exception
            Any error.

        """        
        symbols = {}  # Variables for Z3       
        expr_map = {}   # Map x1 -> expression
        for expr, idx in formulas.variable_map.items():
            var_name, var_type = formulas.variables[idx]
            expr_map[var_name] = expr
            if var_type is None:
                symbols[var_name] = eval(formulas.assignment_map[var_name], {}, symbols)
            elif issubclass(var_type, types.NoneType): 
                symbols[var_name] = None
            elif issubclass(var_type, int):
                symbols[var_name] = Int(var_name) 
            elif issubclass(var_type, float):
                symbols[var_name] = Real(var_name)
            elif issubclass(var_type, bool):
                symbols[var_name] = Bool(var_name)
            elif issubclass(var_type, str):
                symbols[var_name] = String(var_name)
            else:
                raise Exception("Cannot convert type {}".format(var_type.__name__))

        #print(json.dumps(symbols, indent=2, default=str))            
        
        constraints = []
        for c in formulas.constraints:
            if negation:
                constraints.append(Not(eval(c, symbols)))
            else:
                constraints.append(eval(c, symbols))

        if negation:
            self.solver.add(Or(constraints))
        else:
            self.solver.add(And(constraints))
   
        if self.solver.check() == unsat:
            return None
    
        model = self.solver.model()

        return {expr_map[v.name()]: model[v] for v in model}
        

    def is_contradict(self, model: dict) -> bool:
        """
        Check if model is contradict (no possible assignment).

        Parameters
        ----------
        model : dict
            A solution from solve()

        Returns
        -------
        bool
            True if contradict; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """              
        if model is None:   # Unsatisfiable
            return True
        
        return False
    

    def is_tautology(self, model: dict) -> bool:
        """
        Check if model is a tautology (True for any assignment).

        Parameters
        ----------
        model : dict
            A solution from solve()

        Returns
        -------
        bool
            True if tautology; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """              
        if self.is_contradict(model):
            return False
        
        if isinstance(model, dict) and len(model) == 0: # Tautology. All variables are not necessary
            return True
        
        return False    
        

    def is_contingent(self, model: dict) -> bool:
        """
        Check if model is contingent. In other words, the true or false of formulas depends on the variable assignment (data).

        Parameters
        ----------
        model : dict
            A solution from solve()

        Returns
        -------
        bool
            True if not tautology and not contradiction; otherwise False. 

        Raises
        ------
        Exception
            Any error.

        """                
        if self.is_contradict(model):
            return False
        
        if self.is_tautology(model):
            return False
        
        return True
        
