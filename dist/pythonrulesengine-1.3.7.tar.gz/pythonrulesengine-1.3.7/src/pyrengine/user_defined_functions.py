from pyrengine.objectlist import OBJECTLIST
import pyrengine.builtin_objectlist_functions as fn

def count_itemcode_in_history(c_serv_history:OBJECTLIST,itemcode:str) -> int:
    """
    Count the occurrences of a specific item code in the service history.

    Parameters
    ----------
    c_serv_history: the history of service records to search in
    itemcode: the item code to count occurrences of

    Returns
    -------
    int: the number of occurrences of the item code

    Examples
    --------
    >>> count_itemcode_in_history(service_history, 'ITEM123')
    5
    
    Profile
    -------
    ```{json}
    {
        "name": "count_itemcode_in_history", 
        "display_name": "Count Item Code in History",
        "description": "Count the occurrences of a specific item code in the service history.", 
        "params": [
            { "name": "c_serv_history", "description": "the history of service records to search in", "type": ["objectlist"]},
            { "name": "itemcode", "description": "the item code to count occurrences of", "type": ["string"]}
        ],
        "return_type": {
            "type": "number"
        }
    }
    ```
    """
    all_c_serv = fn._get_collective_field(c_serv_history,'C_SERV')
    count = all_c_serv.where('ITEM_CODE','eq',itemcode).count()
    return count
    
