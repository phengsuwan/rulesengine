from datetime import datetime
from typing import Dict, Optional,Union,Tuple
from pyrengine.objectlist import *
from string import Template


def _get_intersect_object_list(
    x:OBJECTLIST,
    y:OBJECTLIST,
    key:str,
    show_details:Optional[bool] = False
    ) -> Union[ARRAY[str], Dict[str,OBJECTLIST]]:
    """
    Get intersection of two OBJECTLISTs based on the key
    
    Parameters
    ----------
    x : OBJECTLIST
        An OBJECTLIST
    y : OBJECTLIST
        An OBJECTLIST
    key : str
        The string to use as the key. Use '$your_attribute' for represent any attribute
    show_details : (Optional) bool=False
        given true for show more details
        
    Returns
    -------
    ARRAY (return when show_details is false)
        An ARRAY of intersection keys 
    dict (return when show_details is true)
        A dict to map intersect key to the intersect members per each intersection group

    Raises
    ------
    Exception
        Any errors cause exception.
    NotImplementedError
        Unsupported operation or arguments.
        
    Examples
    --------
    >>>  get_intersect_object_list(
    >>>    OBJECTLIST([
    >>>    {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx1','stdcode': 'A002', 'billgrcs': 'A', 'qty': 21},]),
	>>>    OBJECTLIST([
    >>>    {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx2','stdcode': 'B002', 'billgrcs': 'B', 'qty': 21},]),
	>>>    key="$stdcode")
    ARRAY(['A001']) 
    >>>  get_intersect_object_list(
    >>>    OBJECTLIST([
    >>>    {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx1','stdcode': 'A002', 'billgrcs': 'A', 'qty': 21},]),
	>>>    OBJECTLIST([
    >>>    {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12},
    >>>    {'trans_no':'Tx2','stdcode': 'B002', 'billgrcs': 'B', 'qty': 21},]),
	>>>    key="$billgrcs|$stdcode", show_details=True)
    {'A|A001': OBJECTLIST([
        {'trans_no':'Tx1','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12, '__intersect_key': 'A|A001'}
        {'trans_no':'Tx2','stdcode': 'A001', 'billgrcs': 'A', 'qty': 12, '__intersect_key': 'A|A001'}
    ])}
    """ 
    template = Template(key)
    
    
    new_x = OBJECTLIST([{**i,"__intersect_key":template.substitute(i)} for i  in x])
    new_y = OBJECTLIST([{**i,"__intersect_key":template.substitute(i)} for i  in y])
    
    intersect_results = {}
    for results_x in new_x:
        results_x : dict
        __intersect_key = results_x.get("__intersect_key")
        results_y = new_y.where("__intersect_key","eq",__intersect_key) # results_y is an OBJECTLIST
        if results_y.count() >= 1:
            intersect_results[__intersect_key] = OBJECTLIST([results_x,*results_y])
    if show_details:
        return intersect_results
    return ARRAY(intersect_results.keys())


def _similarity_score(x:OBJECTLIST,y:OBJECTLIST,key:str) -> Tuple[float,Dict[str,OBJECTLIST]]:
    """
    Calculate similarity score for x and y based on the key
    
    Parameters
    ----------
    x : OBJECTLIST
        An OBJECTLIST
    y : OBJECTLIST
        An OBJECTLIST
    key : str
        The string to use as the key. Use '$your_column' for represent any column
    
    Returns
    -------
    Tuple
        float
            The similarity score between 0.0 (no matched) to 1.0 (exact matched).
        Dict [str,OBJECTLIST]
            intersect results for x and y

    Raises
    ------
    Exception
        Any errors cause exception.
    NotImplementedError
        Unsupported operation or arguments.
        
    Examples
    --------
    >>> similarity_score(ARRAY(['stdcode1']), ARRAY(['stdcode1', 'stdcode2']))
    0.6666666666
    """ 
    
    intersect_things = _get_intersect_object_list(x,y,key,show_details=True)
    score = 2*len(ARRAY(intersect_things.keys()))/(x.count() + y.count())
    return score,intersect_things
    

def find_duplicated_items(c_serv :OBJECTLIST) -> OBJECTLIST:
    """
    Identify items with duplicate entries based on item_code and bill billgrcs.

    Parameters
    ----------
    c_serv (OBJECTLIST): A OBJECTLIST , each object containing `item_code`, `billgrcs`, and `stdcode`

    Returns
    -------
    OBJECTLIST: An OBJECTLIST, each representing an item with duplicates. Each dictionary includes:
                - `billgrcs` : billgrcs value
                - `stdcode` : stdcode value
                - `item_code` : item_code value
                - `count`: The number of duplicates found (including the current record)

    Examples
    --------
    >>> c_serv = OBJECTLIST([
    >>>    {"item_code":"I001","billgrcs":"B001","stdcode":"S001"},
    >>>    {"item_code":"I001","billgrcs":"B001","stdcode":"S002"},
    >>>    {"item_code":"I001","billgrcs":"B002","stdcode":"S003"},
    >>> ])
    >>> find_duplicated_items(c_serv)
    OBJECTLIST([
        {"billgrcs": "B001", "stdcode": "S001", "item_code": "I001", "count": 2},
    ])

    Profile
    -------
    ```{json}
    {
        "name": "find_duplicated_items", 
        "display_name": "Get duplicated items",
        "description": "Identify items with duplicate entries based on item_code and bill billgrcs.", 
        "params" : [
            { "name" : "c_serv" , "description" : "c_serv field" , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attribute" : [
                {"name" : "billgrcs" , "description":  "billgrcs value", "type" : "number"},
                {"name" : "stdcode" , "description":  "stdcode value", "type" : "string"},
                {"name" : "item_code" , "description":  "item_code value", "type" : "string"},
                {"name" : "count" , "description":  "number of duplicates found (including the current record)", "type" : "number"}
            ]
        }
    }
    ```
    """
    results = []
    for serv_item in c_serv :
        stdcode = serv_item["stdcode"]
        item_code = serv_item["item_code"]
        billgrcs = serv_item["billgrcs"]
        c_serv_filtered = c_serv.where("item_code","eq",item_code).where("billgrcs","eq",billgrcs)
        count = c_serv_filtered.count()
        if count >= 2 : 
            data = dict()
            data["billgrcs"] = billgrcs
            data["stdcode"] = stdcode
            data["item_code"] = item_code
            data["count"] = count
            results.append(data)
    return OBJECTLIST(results)


def calculate_duplication_score(
        trans_no: str,
        hcode: str,
        pdx : str,
        c_serv: OBJECTLIST,
        c_trans_by_date: OBJECTLIST
    ) -> OBJECTLIST:
    """
    Calculate a duplication score between a source transaction and multiple target transactions based on item similarities.
    
    Parameters
    ----------
    trans_no (str): The transaction number for the source transaction.
    hcode (str): The hcode for the source transaction.
    pdx (str): The pdx for the source transaction.
    c_serv (OBJECTLIST): A OBJECTLIST associated with the source transaction.
    c_trans_by_date (OBJECTLIST): A OBJECTLIST, each containing a list of service records.

    Returns
    -------
    OBJECTLIST: A OBJECTLIST, each representing the score between the source transaction and a target transaction. Each item includes:
                - `trans_source`: The source transaction number.
                - `trans_target`: The target transaction number.
                - `hcode_score`: Score based on matching hcode (1 if matches, 0 otherwise).
                - `pdx_score`: Score based on matching pdx (1 if matches, 0 otherwise).
                - `item_score`: Similarity score based on common items.
                - `duplication_score`: Overall duplication score calculated from hcode, pdx, and item scores.
                - `send_date`: The send date of the target transaction.
                - `c_intersect_c_serv`: A collection of intersecting service records between source and target transactions.

    Examples
    --------
    >>> c_serv = OBJECTLIST([{"item_code":"I001","billgrcs":"B001","qty":1}])
    >>> c_trans_by_date = OBJECTLIST([{
        "trans_no" : "T124",
        "hcode" : "H001",
        "pdx" : "P002",
        "send_date" : "2024-08-05",
        c_serv : OBJECTLIST([{"item_code":"I001","billgrcs":"B001","qty":1}])
    }])
    >>> calculate_duplication_score("T123", "H001", "P001", c_serv, c_trans_by_date)
    OBJECTLIST([
        {
            "trans_source": "T123",
            "trans_target": "T124",
            "hcode_score": 1,
            "pdx_score": 0,
            "item_score": 1.0,
            "duplication_score": 0.75,
            "send_date": "2024-08-05",
            'c_intersect_c_serv': OBJECTLIST([{"item_code": "I001", "billgrcs": "B001"}]),
        }
    ])
    
    Profile
    -------
    ```{json}
    {
        "name": "calculate_duplication_score", 
        "display_name": "Calculate duplication score",
        "description": "Calculate a duplication score between a source transaction and multiple target transactions based on item similarities.", 
        "params" : [
            { "name" : "trans_no" , "description" : "trans_no field" , "type" : ["string"]},
            { "name" : "hcode" , "description" : "hcode field" , "type" : ["string"]},
            { "name" : "pdx" , "description" : "pdx field" , "type" : ["string"]},
            { "name" : "c_serv" , "description" : "c_serv field" , "type" : ["objectlist"]},
            { "name" : "c_trans_by_date" , "description" : "c_trans_by_date field" , "type" : ["objectlist"]}
        ],
        "return_type" : {
            "type" : "objectlist",
            "attribute" : [
                {"name" : "trans_source" , "description":  "the source transaction", "type" : "string"},
                {"name" : "trans_target" , "description":  "the target transaction", "type" : "string"},
                {"name" : "hcode_score" , "description":  "score based on matching hcode", "type" : "number"},
                {"name" : "pdx_score" , "description":  "score based on matching pdx", "type" : "number"},
                {"name" : "item_score" , "description":  "score based on matching item_code", "type" : "number"},
                {"name" : "duplication_score" , "description":  "overall duplication score ", "type" : "number"},
                {"name" : "send_date" , "description":  "the send date of the target transaction ", "type" : "datetime"}
            ]
        }
    }
    ```
    """
    c_scores = []
    this_c_serv_with_trans_no = OBJECTLIST([{"trans_no":trans_no,**i} for i in c_serv])
    
    for t in c_trans_by_date:
        that_c_serv_with_trans_no = OBJECTLIST([{"trans_no":t['trans_no'],**i} for i in  t['c_serv']])
        
        item_score,c_intersect_c_serv = _similarity_score(
            this_c_serv_with_trans_no,
            that_c_serv_with_trans_no,
            key="$billgrcs|$item_code")
        
        hcode_score = 1 if hcode == t['hcode'] else 0
        pdx_score = 1 if pdx == t['pdx'] else 0
        c_scores.append({
            "trans_source" : trans_no,
            "trans_target" : t["trans_no"],
            "hcode_score" :  hcode_score ,
            "pdx_score" :  pdx_score ,
            "item_score" : item_score,
            "duplication_score" :  ( hcode_score * 0.25)+ (pdx_score * 0.25)+ (item_score * 0.5),
            "send_date" : t['send_date'],
            'c_intersect_c_serv': OBJECTLIST(c_intersect_c_serv),
        })
    return OBJECTLIST(c_scores)
