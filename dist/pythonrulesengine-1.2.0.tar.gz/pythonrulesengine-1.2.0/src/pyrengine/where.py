# https://dev.to/zchtodd/building-parsers-for-fun-and-profit-with-pyparsing-4l9e
# https://github.com/pyparsing/pyparsing/blob/master/examples/simpleArith.py
# https://docs.python.org/3/reference/grammar.html

from typing import Union
from pyparsing import *
import fnmatch

from pyrengine.op import OP


class None__(object):
    def __init__(self, tokens):
        self.value = tokens[0]

    def eval(self, obj, context=None) -> None:
        return None

    def __str__(self):
        return "None"
    

class String(object):
    def __init__(self, tokens):
        self.value = tokens[0]

    def eval(self, obj, context=None) -> str:
        return self.value

    def __str__(self):
        return "'{}'".format(self.value.replace("'", "\\'"))


class Integer(object):
    def __init__(self, tokens):
        self.value = int(tokens[0])

    def eval(self, obj, context=None) -> int:
        return self.value

    def __str__(self):
        return f"{self.value}"


class Real(object):
    def __init__(self, tokens):
        self.value = float(tokens[0])

    def eval(self, obj, context=None) -> float:
        return self.value

    def __str__(self):
        return f"{self.value}"


class Identifier(object):
    def __init__(self, tokens):
        self.name = tokens[0]

    def eval(self, obj, context=None) -> object:
        if self.name not in obj:
            #return None
            raise InvalidExpressionException("Unknown column name {}".format(self.name))
        return obj[self.name]

    def __str__(self):
        return self.name


class PlaceHolder(object):
    def __init__(self, tokens):
        self.name = tokens[0].name # tokens[0] is an Identifier

    def eval(self, obj, context=None) -> object:
        if context is None:
            raise InvalidExpressionException("Placeholder '${}' requires context".format(self.name))
        if self.name not in context:
            #return None
            raise InvalidExpressionException("Unknown placeholder '${}' in context".format(self.name))
        return context[self.name]

    def __str__(self):
        return f"${self.name}"
    

class List__(object):
    def __init__(self, tokens):
        self.elements = tokens

    def eval(self, obj, context=None) -> list:
        return [e.eval(obj, context) for e in self.elements]

    def __str__(self):
        return "[{}]".format(', '.join([str(e) for e in self.elements]))


class BoolBinOp(object):
    pass
class BoolAnd(BoolBinOp):
    def __init__(self, tokens):
        self.args = tokens[0][0::2]

    def eval(self, obj, context=None) -> bool:
        return all([arg.eval(obj, context) for arg in self.args])

    def __str__(self):
        return "({})".format(" and ".join([str(arg) for arg in self.args]))
    

class BoolOr(BoolBinOp):
    def __init__(self, tokens):
        self.args = tokens[0][0::2]

    def eval(self, obj, context=None) -> bool:
        return any([arg.eval(obj, context) for arg in self.args])

    def __str__(self):
        return "({})".format(" or ".join([str(arg) for arg in self.args]))


class Condition(object):
    def __init__(self, tokens):
        self.lval = tokens[0]
        self.op = tokens[1]
        self.rval = tokens[2]
        if isinstance(self.op, str):        
            try:
                self.operator = OP[self.op]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator {} in where()'.format(self.op)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred

    def eval(self, obj, context=None) -> Union[None, bool]:
        # TODO: context argument has been prepared but the calling OBJECTLIST has no reference of the context to pass to 
        #         this argument. The current transaction may be pushed into TransactionContext before the Rule.execute()
        #         is called and popped out after. With good exception handling. https://stackoverflow.com/a/792163
        # TODO: Type checking for each operator, e.g. gt needs both operands have the same type 
        # TODO: Check and assign the specific operator at the __init__() to reduce several if-then-else statements.
        # TODO: How to handle obj without specified column (raise KeyError exception?)
        lval = self.lval.eval(obj, context)
        rval = self.rval.eval(obj, context)
        if self.operator in (OP.gt, OP['>']):
            return (lval is not None and rval is not None and lval > rval)
        elif self.operator in (OP.ge, OP['>=']):
            return (lval is not None and rval is not None and lval >= rval)
        elif self.operator in (OP.eq, OP['=']):
            return lval == rval
        elif self.operator in (OP.neq, OP['<>']):
            return lval != rval
        elif self.operator in (OP.lt, OP['<']):
            return (lval is not None and rval is not None and lval < rval)
        elif self.operator in (OP.le, OP['<=']):
            return (lval is not None and rval is not None and lval <= rval)
        elif self.operator in (OP.is_in, OP.is_not_in):
            switch = False if self.operator == OP.is_in else True  # It is used for XOR (^) 
            if isinstance(rval, list):
                return (lval in rval) ^ switch
            else:
                raise NotImplementedError('{} not supported by {} operator where() is_in/is_not_in'.format(type(rval), self.operator.name))
        elif self.operator in (OP.like, OP.not_like):
            switch = False if self.operator == OP.like else True  # It is used for XOR (^)
            return fnmatch.fnmatch(lval.lower(), rval.lower()) ^ switch
        else:
            raise NotImplementedError('Unknown operator {} in where()'.format(self.operator))        

    def __str__(self):
        return f"({self.lval} {self.op} {self.rval})"
    
class InvalidExpressionException(Exception):
    pass    
     
none__ = Keyword("None").set_parse_action(None__)
identifier = (Word(alphas + "_", alphanums + "_")).set_parse_action(Identifier)
placeholder = (Suppress("$") + identifier).set_parse_action(PlaceHolder)
string = QuotedString(quoteChar="'", escChar="\\").set_parse_action(String)
integer = Combine(Optional(Char("+" + "-")) + Word(nums)).set_parse_action(Integer)
real = Combine(Optional(Char("+" + "-")) + Word(nums) + '.' + ZeroOrMore(Word(nums))).set_parse_action(Real)
number = real | integer
term = none__ | identifier | number | string | placeholder
list__ = (Suppress("[") + Optional(delimitedList(term)) + Suppress("]")).set_parse_action(List__)
operand = term | list__
_and_ = Literal("and")
_or_ = Literal("or")
operator = oneOf(["is_in", "is_not_in", "eq", "=", "neq", "<>", "gt", ">", "lt", "<", "ge", ">=", "le", "<=", "like"])

conditions = Forward()
condition = (operand + operator + operand).set_parse_action(Condition)
conditions = infixNotation(
    condition,
    [
        (_and_, 2, opAssoc.LEFT, BoolAnd),
        (_or_, 2, opAssoc.LEFT, BoolOr)
    ]
)


__WHERE_CACHE = {}  # Cache to improve performance

def parse_string(expression: str, cache=True) -> Union[BoolBinOp, Condition]:
    try: 
        if cache:
            if expression not in __WHERE_CACHE:        
                __WHERE_CACHE[expression] = conditions.parse_string(expression, parse_all=True) # Set parse_all = True for the entire expression to match the grammar.
            parseResults = __WHERE_CACHE[expression]
        else:
            parseResults = conditions.parse_string(expression, parse_all=True) # Set parse_all = True for the entire expression to match the grammar.
        return parseResults[0]
    except ParseException as ex:
        raise InvalidExpressionException("Cannot parse where() expression {}: {}".format(expression, ex))