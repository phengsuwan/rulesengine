from pyrengine.objectlist import OBJECTLIST


# filter fields that contain array list and convert
# into OBJECTLIST object
def convert(input_json):
    fields_names = list(input_json.keys())
    for fn in fields_names:
        if type(input_json[fn]) is list and len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict:
            input_json[fn] = OBJECTLIST(input_json[fn])
    return input_json
