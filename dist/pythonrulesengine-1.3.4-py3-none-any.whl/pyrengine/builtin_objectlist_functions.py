from pyrengine.objectlist import OBJECTLIST
from typing import Union,Optional


def _get_collective_field(data:OBJECTLIST,field:str) -> OBJECTLIST:
    """
    Extracts and aggregates elements from a collective field in a collective data.

    Parameters
    ----------
    data: A collective data containing multiple items, where each item has a collective field
    field: The name of the field to extract from each item in `data`

    Returns
    -------
    OBJECTLIST: A new collective data containing all aggregated elements from the collective field

    Raises
    ------
    ValueError: If any item in the collective field is not of type OBJECTLIST
    
    Examples
    --------
    >>> data = OBJECTLIST([
    ...     {"items": OBJECTLIST([{"item":1},{"item":2}])},
    ...     {"items": OBJECTLIST([{"item":4}]), }
    ... ])
    >>> get_collective_field(data, "items")
    OBJECTLIST([{"item":1},{"item":2},{"item":4])

    Profile
    -------
    ```{json}
    {
        "name": "get_collective_field", 
        "display_name": "Get Collective Field",
        "description": "Extracts and aggregates elements from a collective field in a collective data.", 
        "params": [
            { "name": "data", "description": "A collective data containing multiple items, where each item has a collective field ", "type": ["objectlist"]},
            { "name": "field", "description": "The name of the field to extract from each item in `data`", "type": ["string"]}
        ],
        "return_type": {
            "type": "objectlist"
        }
    }
    ```
    """
    output = []
    for item in data.select(field):
        if not isinstance(item,OBJECTLIST):
            raise ValueError(f"field must be of type OBJECTLIST")
        for j in item :
            output.append(j)

    return OBJECTLIST(output)

def _c_groupby_count(data:OBJECTLIST,columns:Union[str,list[str]],count_column:Optional[str]) -> int:
    """
    Count values for a specified column, grouped by specified columns in the data.

    Parameters
    ----------
    data: The data object containing entries to be grouped and counted
    columns: Columns to group by, specified as a string or a list of strings
    count_column: Column name to count

    Returns
    -------
    int: The count of entries grouped by the specified columns

    Examples
    --------
    >>> c_groupby_count(data, 'column_name', 'count_column')
    42
    
    Profile
    -------
    ```{json}
    {
        "name": "c_groupby_count", 
        "display_name" : "Count Group By",
        "description": "Count values for a specified column, grouped by specified columns in the data.", 
        "params" : [
            { "name" : "data" , "description" : "The data object containing entries to be grouped and counted" , "type" : ["OBJECTLIST"]},
            { "name" : "columns" , "description" : "Columns to group by, specified as a string or a list of strings" , "type" : ["string", "list_string"]},
            { "name" : "count_column" , "description" : "Column name to count" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "objectlist"
        }
    }
    ```
    """
    return data.group_by(columns).count(count_column)

def _c_groupby_sum(data:OBJECTLIST,columns:Union[str,list[str]],sum_column:str) -> Union[float,int]:
    """
    Sum values for a specified column, grouped by specified columns in the data.

    Parameters
    ----------
    data: The data object containing entries to be grouped and summed
    columns: Columns to group by, specified as a string or a list of strings
    sum_column: Column name whose values will be summed

    Returns
    -------
    float : The sum of values in the specified column, grouped by the specified columns

    Examples
    --------
    >>> c_groupby_sum(data, 'column_name', 'sum_column')
    123.45
    
    Profile
    -------
    ```{json}
    {
        "name": "c_groupby_sum", 
        "display_name" : "Sum Group By",
        "description": "Sum values for a specified column, grouped by specified columns in the data.", 
        "params" : [
            { "name" : "data" , "description" : "The data object containing entries to be grouped and summed" , "type" : ["objectlist"]},
            { "name" : "columns" , "description" : "Columns to group by, specified as a string or a list of strings" , "type" : ["string", "list_string"]},
            { "name" : "sum_column" , "description" : "Column name whose values will be summed" , "type" : ["string"]}
        ],
        "return_type" : {
            "type" : "objectlist"
        }
    }
    ```
    """
    return data.group_by(columns).sum(sum_column)

