"""
   Provide two custom NULL types to handle NULL (unknown) values in expressions. 
   First is NullType which raises exception on comparison and arithmetic operations.
   Second is LooselyNullType which returns False for comparison operations and raise exception for arithmetic operations.
   The default NULL is NullType. To use LooselyNullType, set environment variable USE_LOOSELYNULLTYPE=1.
"""
import os

class NullValueException(Exception):
    """
    Custom exception for invalid operations on NullType.
    """
    pass

# https://stackoverflow.com/questions/31177629/can-i-create-an-object-that-receives-arbitrary-method-invocation-in-python
# https://stackoverflow.com/questions/6760685/creating-a-singleton-in-python
class NullType:
    """
    NullType class mimicking NoneType behavior, but raises NullTypeException
    when used in comparison or arithmetic operations.
    """
    __slots__ = ()  # To prevent attribute creation and mimic immutability

    def __new__(cls):
        # Ensure only one instance exists (Singleton pattern)
        if not hasattr(cls, '_instance'):
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self):
        return 'NULL'

    def __str__(self):
        return 'NULL'

    def __bool__(self):
        return False

    def __eq__(self, other):
        raise NullValueException("Comparison operations are not allowed on NULL.")

    def __ne__(self, other):
        raise NullValueException("Comparison operations are not allowed on NULL.")
        
    def __lt__(self, other):
        raise NullValueException("Comparison operations are not allowed on NULL.")

    def __le__(self, other):
        raise NullValueException("Comparison operations are not allowed on NULL.")

    def __gt__(self, other):
        raise NullValueException("Comparison operations are not allowed on NULL.")

    def __ge__(self, other):
        raise NullValueException("Comparison operations are not allowed on NULL.")

    def __add__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __sub__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __mul__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __truediv__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __floordiv__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __mod__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __pow__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __getattr__(self, name):
        raise AttributeError(f"'NULL' object has no attribute '{name}'")

    def __setattr__(self, name, value):
        raise AttributeError("'NULL' object is immutable")

    def __delattr__(self, name):
        raise AttributeError("'NULL' object is immutable")

    def __call__(self, *args, **kwargs):
        raise TypeError("'NULL' object is not callable")


class LooselyNullType:
    """
    Similar to NullType, but LooselyNullType returns False for comparison operations.
    """
    __slots__ = ()  # To prevent attribute creation and mimic immutability

    def __new__(cls):
        # Ensure only one instance exists (Singleton pattern)
        if not hasattr(cls, '_instance'):
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self):
        return 'NULL'

    def __str__(self):
        return 'NULL'

    def __bool__(self):
        return False

    def __eq__(self, other):
        #raise NullValueException("Comparison operations are not allowed on NULL.")
        return False

    def __ne__(self, other):
        #raise NullValueException("Comparison operations are not allowed on NULL.")
        return True

    def __lt__(self, other):
        #raise NullValueException("Comparison operations are not allowed on NULL.")
        return False        

    def __le__(self, other):
        #raise NullValueException("Comparison operations are not allowed on NULL.")
        return False    

    def __gt__(self, other):
        #raise NullValueException("Comparison operations are not allowed on NULL.")
        return False        

    def __ge__(self, other):
        #raise NullValueException("Comparison operations are not allowed on NULL.")
        return False        

    def __add__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __sub__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __mul__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __truediv__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __floordiv__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __mod__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __pow__(self, other):
        raise NullValueException("Arithmetic operations are not allowed on NULL.")

    def __getattr__(self, name):
        raise AttributeError(f"'NULL' object has no attribute '{name}'")

    def __setattr__(self, name, value):
        raise AttributeError("'NULL' object is immutable")

    def __delattr__(self, name):
        raise AttributeError("'NULL' object is immutable")

    def __call__(self, *args, **kwargs):
        raise TypeError("'NULL' object is not callable")
    

# Create the singleton instance
if os.getenv('USE_LOOSELYNULLTYPE', '0') == '1':
    NULL = LooselyNullType()
else:
    NULL = NullType()

# is_null() is used in json rule. For normal python expression, use X is NULL. 
def is_null(value):
    """
    Check if the given value is NULL.
    """
    return value is NULL


# Usage example
if __name__ == "__main__":
    print(NULL)           # Output: NULL
    print(bool(NULL))     # Output: False

    try:
        NULL == None
    except NullValueException as e:
        print(e)  # Output: Comparison operations are not allowed on NULL.

    try:
        NULL + 5
    except NullValueException as e:
        print(e)  # Output: Arithmetic operations are not allowed on NULL.
