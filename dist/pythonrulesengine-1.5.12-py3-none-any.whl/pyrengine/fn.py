import fnmatch

# Should operator.add() be used instead?
# import operator
# operator.add(1, 2)
def ADD(op1, op2): 
    """
    Return op1 + op2.
    
    It provides operator + as a function. 
    
    Parameters
    ----------
    op1 : 
        Left operand.
    op2 : 
        Right operand.

    Returns
    -------
    The summation of left and right operands.
    """    
    return op1 + op2


def MUL(op1, op2): 
    """
    Return op1 * op2.
    
    It provides operator * as a function. 
    
    Parameters
    ----------
    op1 : 
        Left operand.
    op2 : 
        Right operand.

    Returns
    -------
    The summation of left and right operands.
    """    
    return op1 * op2


def LIKE(a: str, pattern: str) -> bool:
    """
    Check if a string matches a pattern (ignoring case) with wildcard support.

    Parameters
    ----------
    a: the string to check
    pattern: the pattern with '*' for multiple characters and '?' for a single character

    Returns
    -------
    bool: True if the string matches the pattern, False otherwise

    Examples
    --------
    >>> LIKE("hello", "h*o")
    True
    >>> LIKE("hello", "h?llo")
    True
    >>> LIKE("hello", "h*llo")
    True

    """

    return fnmatch.fnmatch(a.lower(), pattern.lower())


def NOT_LIKE(a: str, pattern: str) -> bool:
    return not LIKE(a, pattern)