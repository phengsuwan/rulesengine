from __future__ import annotations  # To use class defined below in type hint.

import copy
import itertools
from string import Template
from collections import OrderedDict

from pyrengine.model import RulePackage, DecisionTableNode, FlagNode
from pyrengine.verification import _State, _Statement, _Constraint, _call_solver, _append_verification_result, RuleVerificationResult


'''
    {
        "name": "Conclusion",
        "description": "Some description",
        "inputs": ["coverage", "legal"],  # Flag code for input
        "outputs": ["result_status", "message", "tag", "value"],  # Result_status, message, tag, value are fixed for output
        "result_status_name": [ # Optional mapping of result_status to result_name
            {"result_status": "PASS", "result_name": "PASS"}, 
            {"result_status": "FAIL", "result_name": "FAIL"}, 
            {"result_status": "UNKNOWN", "result_name": "UNKNOWN"}
        ],  
        "hit_policy": "first",
        "rules": [
            {
                "conditions": {
                    "all": [
                        {
                            "flag": "coverage",
                            "operator": "==",
                            "result_status": "PASS",
                            "quantifier": "ALL"
                        },
                        {
                            "flag": "legal",
                            "operator": "==",
                            "result_status": "FAIL",
                            "quantifier": "ANY"
                        }
                    ]
                },
                "actions": {
                    "result_status": "FAIL",
                    "message": "Some message",
                    "tag": "score",
                    "value": -100
                },
                "description": "Some description"
            },
            {
                "conditions": {},
                "actions": {
                    "result_status": "UNKNOWN",
                    "message": "Some message",
                    "tag": "score",
                    "value": 0
                }, 
                "description": "Default rule"
            }
        ]
    }
'''
 

FLAG_CODE = "conclusion" # The flag code for conclusion flag. It is fixed to "conclusion".
FLAG_MESSAGE = {  # The flag message for conclusion flag. The referenced values must be built by rule actions.
    "result_status": {"$ref": "result_status"},
    "tag": {"$ref": "tag"},
    "value": {"$ref": "value"},
    "description": {"$ref": "message"}
}

class ConclusionTable:
    def __init__(self, table: dict, config: dict = {}):
        self.table = table
        self.config = config
        self.dtable: dict = None  # A copy of table replaced conditions with COUNT function.
        self.term_map: dict[str, (str, str)] = {}  # Map expression COUNT('flag', 'result_status') to tuple (flag, result_status) for entire table
        self.rule_term_map: list[dict[str, (str, str)]] = None  # Same as self.term_map but per rule id        
        self.result_status_name: dict[str | int , str]= {d['result_status']: d['result_name'] for d in self.table['result_status_name']} if 'result_status_name' in self.table else {}
        if "list_string_formatter" in config:
            self.list_string_formatter = config["list_string_formatter"]
        else:
            self.list_string_formatter = self._list_formatting_by_commas

        inputs = self.table['inputs']  # Input flag codes
        outputs = self.table['outputs']  # Output field names

        # Create a DecisionTableNode from table. There are some format conversions.
        # Convert rule conditions to an expression string with COUNT function
        #   and actions['flag'] to repr(actions['flag'])
        #   and actions['result_status'] to repr(actions['result_status'])
        #   ...
        #   since expression strings are used with verification.
        dtable = copy.deepcopy(table)
        self.rule_term_map = [{}]*len(dtable['rules'])   # Populate a list of len() empty dicts 
        for i, rule in enumerate(dtable['rules']):
            expr = self.convert_conditions_to_count_expression(i, rule['conditions'])
            rule['conditions'] = expr
            for output in outputs:
                rule['actions'][output] = repr(rule['actions'][output])
            
        self.dtable = dtable

        # Create a rule package with DecisionTableNode, assuming that the table is valid and pre-verified.
        # dtable -> flag
        # The input to dtable node is a transaction with flag_table field, the output has result_status, tag, value, message added.
        # The message is a template string not yet evaluated.
        # The flag node will emit the flag using the output field from dtable node. However, the message is still not evaluated.
        self.conclusion_rule_package = RulePackage('conclusion')   
        with self.conclusion_rule_package:
            self.dnode = DecisionTableNode('dtable', dtable)  # Fix node name to 'dtable'
            self.fnode = FlagNode("flag", FLAG_CODE, FLAG_MESSAGE)  # Flag code is fixed to "conclusion"
        self.conclusion_rule_package.attach(self.dnode)
        self.dnode.add_child(self.fnode)
        self.conclusion_rule_package.validate()


    def convert_conditions_to_count_expression(self, i: int, conditions: dict) -> str:
        if len(conditions) == 0:
            return "(True)"
        if 'all' in conditions:
            connective = 'all'
        elif 'any' in conditions:
            connective = 'any'
        else:
            raise Exception("Unknown connective 'all' or 'any' in conditions {}".format(conditions))
        
        expressions = []
        self.rule_term_map[i] = {}
        for condition in conditions[connective]:
            flag = condition['flag']
            if flag not in self.table['inputs']:
                raise Exception("Flag {} is not defined in inputs".format(flag))
            
            result_status = condition['result_status']
            if condition['operator'] not in ('==', 'eq'):
                raise Exception("Operator {} not supported".format(condition['operator']))
            if condition['quantifier'] == "ANY":
                # flag_table.COUNT('coverage', 'PASS') > 0
                func = "flag_table.COUNT({}, {})".format(repr(flag), repr(result_status))
                operator = ">"
                count = "0"
                self.term_map[func] = (flag, result_status)
                self.rule_term_map[i][func] = (flag, result_status)
                expression = "({} {} {})".format(func, operator, count)
            elif condition['quantifier'] == "ALL":
                # flag_table.COUNT('coverage', 'PASS') == flag_table.COUNT('coverage')
                func = "flag_table.COUNT({}, {})".format(repr(flag), repr(result_status))
                operator = "=="
                count = "flag_table.COUNT({})".format(repr(flag))
                self.term_map[func] = (flag, result_status)
                self.term_map[count] = (flag, None)
                self.rule_term_map[i][func] = (flag, result_status)
                self.rule_term_map[i][count] = (flag, None)
                expression = "({} {} {} and {} > 0)".format(func, operator, count, func)
            elif condition['quantifier'] == "NO":
                # flag_table.COUNT('coverage', 'PASS') == 0
                func = "flag_table.COUNT({}, {})".format(repr(flag), repr(result_status))
                operator = "=="
                count = "0"
                self.term_map[func] = (flag, result_status)
                self.rule_term_map[i][func] = (flag, result_status)
                expression = "({} {} {})".format(func, operator, count)
            else:
                raise Exception("Quantifier {} not supported".format(condition['quantifier']))
            
            expressions.append(expression)
        
        if connective == 'all':
            return ' and '.join(expressions)
        else:
            return ' or '.join(expressions)


    def get_internal_decision_table(self):
        return self.dtable
     
     
    def _find_rule_package_constraints(self, rule_package: RulePackage) -> list[_Constraint]:
        '''
        Analyze RulePackage for additional constraints on quantifier expressions. 
        If the conclusion table refers to (flag, result_status) but RulePackage has no such one, 
         an 'equal to zero' constraint is added.
        For each flag group, add group constraints like flag_table.COUNT('coverage') == flag_table.COUNT('coverage', 'PASS') + flag_table.COUNT('coverage', 'FAIL')
        The more contraints we can find, the more precise verification result we can have.

        Parameters
        ----------
        rule_package: RulePackage
            A RulePackage
                
        Return:
        --------
            A list of constraints.
        '''

        # Find a set of possible ('flag', 'result_status') produced from rule.
        # If ('flag', 'result_status') not in self.term_map means, don't care.
        possible_flag_status: set[tuple] = set()
        for node_id, node in rule_package.known_nodes.items():
            if isinstance(node, FlagNode):
                flag = node.flag
                result_status = node.template['result_status']
                possible_flag_status.add((flag, result_status))

        constraints: list[_Constraint] = []
        for expr, (flag, result_status) in self.term_map.items():  # We care only ('flag', 'result_status') in self.term_map.
            if (flag, result_status) not in possible_flag_status:
                # Since no flag generates ('coverage', 'PASS'), then
                # flag_table.COUNT('coverage', 'PASS') == 0
                constraints.append(_Constraint("{} == 0".format(expr), "dtable", -1, negation=False))
                #print("{} == 0".format(expr))

        # For each flag group, add group constraints like flag_table.COUNT('coverage') == flag_table.COUNT('coverage', 'PASS') + flag_table.COUNT('coverage', 'FAIL')
        flag_groups: dict[str, set] = {}  # Group flags by flag only.
        for flag, result_status in possible_flag_status:
            if flag not in flag_groups:
                flag_groups[flag] = set()
            flag_groups[flag].add(result_status)
        for flag in flag_groups.keys():
            if flag not in self.table['inputs']:  # Only care about flags in inputs
                continue
            result_statuses = flag_groups[flag]
            left =  "flag_table.COUNT({})".format(repr(flag))
            right = " + ".join(["flag_table.COUNT({}, {})".format(repr(flag), repr(result_status)) for result_status in result_statuses])
            constraints.append(_Constraint("{} == {}".format(left, right), "dtable", -1, negation=False))           
            #print("{} == {}".format(left, right)) 

        # If the conclusion table refers to (flag, result_status) and RulePackage has only zero or 
        #   more (flag, result_status) and no (flag, other_result_status), 
        #   then COUNT(flag, result_status) > 0 implies COUNT(flag, result_status) == COUNT(flag), 
        #   in other words, ANY result_status == ALL result_status.             
        # for expr, (flag, result_status) in self.term_map.items():
        #     if result_status is not None and (flag, result_status) in possible_flag_status:
        #         is_only_status = True
        #         for (f, rs) in possible_flag_status:
        #             if f == flag and rs != None and rs != result_status:
        #                 is_only_status = False
        #                 break
                
        #         if is_only_status:
        #             # flag_table.COUNT('coverage', 'PASS') == flag_table.COUNT('coverage')
        #             expr2 = "flag_table.COUNT({})".format(repr(flag))
        #             constraints.append(_Constraint("{} == {}".format(expr, expr2), "dtable", -1, negation=False))
        #             #print("{} == {}".format(expr, expr2))                    

        return constraints
    
    def verify_for_uniqueness(self, symbols: dict, prologue: list[_Statement] = [], epilogue: list[_Statement] = [], analysis: dict = {}, config: dict = {}) -> dict:
        '''
        Verify the decision table for hit policy 'unique'. Only overlapping rules and error are reported.
        We check if a solution existed for a pair of rules. If so, both are overlapping (not unique) and we can get an example.
        An alternative approach, we check if every rule Pi and the disjunction of all other rules: 
        #  Pi ^ (P1 v P2 v Pi-1 v Pi+1 v ... v Pn) is unsatisfied, then it is unique. It should be faster 
        #  but we cannot get details which ones overlap.

        Parameters
        ----------
        symbols: dict
            A dict that maps a symbol to an example value or a data type. 
            It represents an input transaction which contains variables to the rules. 
            Note that all values converted to their data types internally.
        analysis: dict
            The variable to keep verification results.        
        config: dict
            A dict of verification configuation, e.g. {'datetime_ignore_time': True} to ignore time in datetime.
                
        Return:
        --------
            An analysis dict having 'verifications' key for a list of verification results.
        '''

        table = self.table
        dtable = self.dtable
        if dtable['hit_policy'] != 'unique':  # Verify only if hit policy == 'unique'
            return analysis
        
        # Check for non-overlapping rules under the constraints of the current path
        # Loop all pairs of rules to check if they can be true (has a solution) at the same time

        rule_ids = list(range(len(dtable['rules'])))
        
        for i, j in list(itertools.combinations(rule_ids, 2)):
            statements = prologue.copy()
            rule_i = dtable['rules'][i]             
            rule_j = dtable['rules'][j]
            conditions_i = rule_i['conditions'] if rule_i['conditions'] != '' else 'True'  # Empty condition means always true
            conditions_j = rule_j['conditions'] if rule_j['conditions'] != '' else 'True'  # Empty condition means always true
            if not isinstance(conditions_i, str) or not isinstance(conditions_j, str):
                raise Exception("Only expression string is supported in conditions for conclusion verification")

            statements.append(_Constraint(conditions_i, "dtable", i, negation=False))
            statements.append(_Constraint(conditions_j, "dtable", j, negation=False))

            # Additional constraints for rule uniqueness for this pair of rules.
            #   flag_table.COUNT('coverage', 'PASS') >= 0
            #   flag_table.COUNT('coverage', 'FAIL') >= 0
            #   flag_table.COUNT('coverage') >= flag_table.COUNT('coverage', 'PASS') + flag_table.COUNT('coverage', 'FAIL')
            additional_constraints: list[_Constraint] = []
            pair_term_map = self.rule_term_map[i] | self.rule_term_map[j]  # Merge two dicts
            for expr in pair_term_map.keys():
                additional_constraints.append(_Constraint("{} >= 0".format(expr), "dtable", -1, negation=False))
            for input in self.table['inputs']:
                left =  "flag_table.COUNT({})".format(repr(input))
                if left not in pair_term_map: # No condition refers to flag_table.COUNT('coverage') 
                    continue
                right = " + ".join(["flag_table.COUNT({}, {})".format(repr(flag), repr(result_status)) for flag, result_status in pair_term_map.values() if flag == input and result_status is not None])
                additional_constraints.append(_Constraint("{} >= {}".format(left, right), "dtable", -1, negation=False))
                

            statements.extend(additional_constraints)
            statements.extend(epilogue)

            path = ["dtable"]     
            xpath = ["datable"]
            state = _State(statements, path, xpath)
            formulas, solver_result = _call_solver(self.conclusion_rule_package, symbols, state, config)
            
            if not solver_result.is_contradict():
                verification = {
                    'decision_table': "dtable",
                    'z3': formulas,
                }             
                if solver_result.is_unknown():
                    verification['result'] = RuleVerificationResult.CannotDecide.value
                else:  # Has solution
                    verification['result'] = RuleVerificationResult.OverlappingRules.value
                    verification['overlapping_rules'] = [i, j]
                    verification['solution'] = solver_result.get_solution()

                _append_verification_result(analysis, verification)
                return analysis  # if decision table verification fails for 'unique' hit policy, stop further verification.                          
            
        return analysis

    def verify_for_completeness(self, symbols: dict, prologue: list[_Statement] = [], epilogue: list[_Statement] = [], analysis: dict = {}, config: dict = {}) -> dict: 
        '''
        Verify the conclusion table completeness.

        Parameters
        ---------- 
        symbols: dict
            A dict that maps a symbol to an example value or a data type. 
            It represents an input transaction which contains variables to the rules. 
            Note that all values converted to their data types internally.
        analysis: dict
            The variable to keep verification results.        
        config: dict
            A dict of verification configuation, e.g. {'datetime_ignore_time': True} to ignore time in datetime.
                
        Return:
        --------
            An analysis dict having 'verifications' key for a list of verification results.
        '''
        statements = prologue.copy()
        for rule_id, rule in enumerate(self.dtable['rules']):
            conditions = rule['conditions']
            if not isinstance(conditions, str):
                raise Exception("Only expression string is supported in verification")
            
            constraint = conditions if conditions != '' else 'True'  # Empty condition means always true 
            statements.append(_Constraint(conditions, "dtable", -1, negation=True))  # Negate the conditions

        statements.extend(epilogue)
        path = ["dtable"]     
        xpath = ["datable"]
        state = _State(statements, path, xpath)
        formulas, solver_result = _call_solver(self.conclusion_rule_package, symbols, state, config)
                  
        if not solver_result.is_contradict():
            verification = {
                'decision_table': "dtable",
                'z3': formulas,
            }             
            if solver_result.is_unknown():
                verification['result'] = RuleVerificationResult.CannotDecide.value
            else:  # Has solution
                verification['result'] = RuleVerificationResult.NotComplete.value
                verification['solution'] = solver_result.get_solution()

                _append_verification_result(analysis, verification)
        
        return analysis


    def verify(self, rule_package: RulePackage = None, config: dict = {}) -> dict:
        '''
        Verify the conclusion table for uniqueness (if hit policy unique) and then completeness.

        Parameters
        ---------- 
        rule_package: RulePackage, default to None
            If provided, verify with additional constraints discovered from rule_package for completness check.      
        config: dict
            A dict of verification configuation, e.g. {'datetime_ignore_time': True} to ignore time in datetime.
                
        Return:
        --------
            An analysis dict having 'verifications' key for a list of verification results.
        '''        
        analysis = {
            'verifications': []
        }        
        symbols = {'flag_table': FlagTable}
        
        # Verify rule uniqueness
        # TODO: should we have additional constraints from rule_package for uniqueness check?
        self.verify_for_uniqueness(symbols, analysis=analysis, config=config)
        #print(analysis['verifications'])

        # Add additional constraints from the entire table
        #   flag_table.COUNT('coverage', 'PASS') >= 0
        #   flag_table.COUNT('coverage', 'FAIL') >= 0
        #   flag_table.COUNT('coverage') >= flag_table.COUNT('coverage', 'PASS') + flag_table.COUNT('coverage', 'FAIL')
        additional_constraints: list[_Constraint]= []
        for expr in self.term_map.keys():
            additional_constraints.append(_Constraint("{} >= 0".format(expr), "dtable", -1, negation=False))
        for input in self.table['inputs']:
            left =  "flag_table.COUNT({})".format(repr(input))
            if left not in self.term_map: # No condition refers to flag_table.COUNT('coverage') 
                continue
            right = " + ".join(["flag_table.COUNT({}, {})".format(repr(flag), repr(result_status)) for flag, result_status in self.term_map.values() if flag == input and result_status is not None])
            additional_constraints.append(_Constraint("{} >= {}".format(left, right), "dtable", -1, negation=False))
 
        # Add any constraints discovered from rule_package
        additional_constraints.extend(self._find_rule_package_constraints(rule_package) if rule_package is not None else [])

        # Then, verify rule completeness        
        self.verify_for_completeness(symbols, epilogue=additional_constraints, analysis=analysis, config=config)
        #print(analysis['verifications'])

        # Convert count function from solution into trial with array of dicts.
        # Original: {"flag_table.COUNT('legal')": 1, "flag_table.COUNT('legal', 'PASS')": 1}
        # New: [{"flag": "legal", "result_status": "PASS", "operator": "==", "quantifier": "ALL"}]
        for verification in analysis['verifications']:
            if 'solution' in verification:
                trial = []
                for expr, value in verification['solution'].items():
                    if expr in self.term_map:
                        flag, result_status = self.term_map[expr]
                        if result_status is None:
                            continue
                        
                        flag_group = "flag_table.COUNT({})".format(repr(flag)) 
                        if value == 0:
                            quantifier = "NO"
                        elif value > 0:
                            if flag_group in verification['solution']:
                                flag_group_count = verification['solution'][flag_group]
                                if value < flag_group_count:
                                    quantifier = "ANY"
                                else:
                                    quantifier = "ALL"
                            else:
                                quantifier = "ANY"
                        else:
                            raise Exception("{}={}".format(expr, value))

                        trial.append({"flag": flag, "operator": "==", "result_status": result_status, "quantifier": quantifier})        
                    else:
                        #raise Exception("Count function {} not found".format(expr))
                        pass # It may be added by additional constraints.
                    
                verification['trial'] = trial

        return analysis['verifications']
    

    def conclude(self, flags: list[dict]) -> dict:
        '''
          "flags": [
              {
                "flag": "V001",
                "message": {
                  "audit_rule_id": 1,
                  "result_status": 1,
                  "tag": "score",
                  "value": 100,
                  "description": "Some description",
                  "details": {}
                }
              },
              ...
          ]
        '''
        # Assume that the table is valid and pre-verified.
        flag_table = FlagTable(flags)
        # Create a transaction for input and output. 
        #   Field flag_table is used for condition evaluation for COUNT functions. 
        tx = {'flag_table': flag_table}  
        self.conclusion_rule_package.execute(tx)
        execution_result = self.conclusion_rule_package.get_audit_result()
        if len(execution_result["flags"]) != 1:
            raise Exception("Cannot conclude because the number of conclusion flags is {}".format(len(execution_result["flags"])))
        
        # Get the required final conclusion flag. 
        conclusion_flag = {k: execution_result["flags"][0][k] for k in ['flag', 'message', 'trace']} 

        # Post processing flag to evaluate the 'description' message template string.
        # First, find which rule id.
        # Second, find all placehoder variables.
        # Third, create necessary variables.
        # Last, evaluate the template string
        if conclusion_flag['trace'][0]['node_id'] != "dtable":
            raise Exception("Conclusion require the DecisionTableNode being the first node")
        rule_id = conclusion_flag['trace'][0]['rules'][0]['rule_id']   # From the first node find the first matching rule.
        template = Template(conclusion_flag['message']['description'])   # TODO: cache the template using rule id
        placeholders = template.get_identifiers()
        if len(placeholders) > 0:
            symbols = {}
            for placeholder in placeholders:
                if placeholder == "value":
                    symbols["value"] = conclusion_flag['message']['value']
                elif placeholder == "condition":
                    symbols["condition"] = self._conditions_as_string(rule_id)
                elif placeholder == "description":
                    symbols['description'] = self._collect_descriptions_as_string(flag_table, rule_id)
                else:
                    raise Exception("Unknown placeholder variable ${}".format(placeholder))
            conclusion_flag['message']['description'] = template.substitute(symbols)

        return conclusion_flag


    def _conditions_as_string(self, rule_id: int) -> str:
        conditions = self.table["rules"][rule_id]["conditions"]["all"]
        conds = [
            "{} {} {}".format(
                condition['quantifier'], 
                self.result_status_name.get(condition['result_status'], condition['result_status']), 
                condition['flag']
            ) 
            for condition in conditions
        ]
        return self.list_string_formatter(conds)


    def _collect_descriptions_as_string(self, flag_table: FlagTable, rule_id: int) -> str:
        conditions = self.table["rules"][rule_id]["conditions"]["all"]
        descriptions: dict[str, int] = OrderedDict()  # Use ordered dict to deduplicate and keep order, instead of set()
        for condition in conditions:
            if condition['quantifier'] in ('ALL', 'ANY'):
                flags = flag_table.SELECT(condition['flag'], condition['result_status'])
                descriptions.update([(f['message']['description'], 1) for f in flags])
        return self.list_string_formatter(descriptions.keys())
    

    def _list_formatting_by_commas(self, items: list[str]) -> str:
        return ', '.join(items)


class FlagTable:
    def __init__(self, flags: list[dict]):
        self.flags = flags
        self.count_cache: dict[tuple, int] = {}  # Cache COUNT() output


    def COUNT(self, flag: str, result_status: str | int = None) -> int:
        key = (flag, result_status)
        if key not in self.count_cache:
            if result_status is None:
                result = sum([1 for e in self.flags if e['flag'] == flag])
            else:
                result = sum([1 for e in self.flags if e['flag'] == flag and e['message']['result_status'] == result_status])
    
            self.count_cache[key] = result
            
        return self.count_cache[key]
    
    
    def SELECT(self, flag: str, result_status: str | int = None) -> list[dict]:

        if result_status is None:
            result = [e for e in self.flags if e['flag'] == flag]
        else:
            result = [e for e in self.flags if e['flag'] == flag and e['message']['result_status'] == result_status]
            
        return result       