from __future__ import annotations # For forware reference
from typing import Type, Union
from string import Template
from collections import OrderedDict
from datetime import datetime
from enum import Enum

import copy
import itertools
import msgpack 
import warnings
import graphviz
import html
import sys
import fnmatch
import keyword

from pyrengine.compiler import *
from pyrengine.objectlist import OBJECTLIST, ARRAY
from pyrengine.lookup import LOOKUP
from pyrengine.converter import ExprToJson
from pyrengine.rulecontext import txcntx, lookupcntx
from pyrengine.op import OP

import threading
import multiprocessing
from multiprocessing import Process, Manager, Queue

# Disable pdoc3 document generating for these classes/methods
__pdoc__ = {
    'load_rule_by_id': False,
    'RulePackageContext': False,
}

# TODO: Load from json file
# Mockup function only.
def load_rule_by_id(id: str) -> Rule:
    sample_rule = {
        "id": id,
        "name": "Sample Rule",
        "conditions": {
            "all": [
                {
                    "fact": "count_nvisits_by_date",
                    "operator": 'ge',
                    "value": 2
                }
            ]
        }
    }
    return Rule(sample_rule)

# TODO: Check schema
converter = ExprToJson(schema_path=None, bypass_schema=True, auto_expr_is_true=False)
def convert_expression(expression: str) -> Union[Fact, Condition, Operand]:
    '''
    Convert expression string to Condition, Fact or Operand.
    Currently do not check for any schema. 
    
    Returns
    -------
      Fact or Condition or Operand.
    
    Example
    -------
    >>> convert_expression("a")
    Fact(None, '$', 'a')
    >>> convert_expression("a > 0")
    Condition(None, '$', {"fact": "a", "operator": "gt", "value": 0})    
    >>> convert_expression("a.b(1)")
    Fact(None, '$', {'fact': 'a', 'chain': [{'method': 'b', 'args': [1]}]})
    >>> convert_expression("a + b")
    Fact(None, '$', {'function': 'ADD', 'args': ['a', 'b']})
    >>> convert_expression("a and b") 
    Condition(None, '$', {'all': [{'fact': 'a'}, {'fact': 'b'}]})
    >>> convert_expression("a > b")
    Condition(None, '$', {"fact": "a", "operator": "gt", "value": {"fact": "b"}})
    >>> convert_expression("999")
    Operand(None, '$', 999)  
    >>> convert_expression("'THIS IS A STRING'")
    Operand(None, '$', 'THIS IS A STRING')       
    '''
    if expression.isidentifier() and not (keyword.iskeyword(expression) or expression == "NULL"):
        return Fact(None, '$', expression)
    
    d = converter.convert(expression) # First convert expression to dict of condition or dict of fact
    if isinstance(d['conditions'], dict):
        if 'fact' in d['conditions'] and 'operator' not in d['conditions']:
            return Fact(None, '$', d['conditions']['fact']) # fact is an atomic condition (no AND and OR).
        else:
            return Condition(None, '$', d['conditions'])  # For comparison and compound conditions
    else:
        return Operand(None, '$', d['conditions'])  # For primitive data type 

    

# Interesting idea to prevent the constructor __init__() be called directly.
# https://stackoverflow.com/questions/42735421/how-to-restrict-object-instantiation-only-via-a-factory-in-python5
class Node:
    """
    Node is the base class for all nodes. It should not be used directly.
    Usually a node instance is created from a subclass of Node.
    Current subclasses are BigTable, ForkNode, TransformNode, SelectNode, SwitchNode, FlagNode, RuleNode, SubRuleNode, InPortNode and OutPortNode.
    Each node must have an ID which looks like a python identifer.
    A node can connect to zero or more children (downstream nodes) depending on the subclasses.
    For example a ForkNode allow multiple children but not the FlagNode.
    A node can connect to zero or more parents (upstream nodes).
    For a node to connect to other nodes, they must be in the same rule package.
    Nodes from different rule packages cannot connect.
    Multiple nodes can form a DAG (Directed Acyclic Graph).

    Some node types have specific restrictions on use. For example, BigTable node has single parent. 
    For other examples, FlagNode and RuleNode cannot be used in the same rule package.
    InPortNode and OutPortNode cannot be used with FlagNode or RuleNode in the same rule package.
    However, these restrictions are not enforced.
    """
    def __init__(self, node_id: str, name: str = None, description: str = None, children: list[Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):   # Use **kwargs to ignore unknown keyword argument error.
        if node_id is None or not node_id.isidentifier():
            raise Exception("Node id must be in a valid python identifier format")
        self.node_id: str = node_id
        self.name: str = name
        self.description = description
        self.children: list[Node] = []  # Used in main operations. *** For SwitchNode, type is dict of key to Node ***
        self.parents: list[Node] = []  # Have not been used in main operations.
        self.rule_package = None  # RulePackager owner
        if rule_package is None:
            rule_package = RulePackageContext.get_current_context()
        if rule_package is not None:
            rule_package.add_node(self)

        if children:
            for child in children:
                if isinstance(child, dict):
                    node = Node.from_dict(child)
                    self.add_child(node)
                else:
                    self.add_child(child)

    def execute(self, input, execution_result: dict, metrics: Metrics = None, verbose=False, debug=False):
        pass

    def pause(self):  
        self.rule_package.shared_command_queue.get()  # Block until a command is received

    def add_child(self, node: Node) -> None:
        if node is None:
            return        
        # Allow node = None due to BranchNode
        if node is not None and node in self.children:
            raise Exception("Node {} has already been added".format(str(node)))
        if node.rule_package != self.rule_package:
            raise RulePackageException("Mismatched RulePackage between two nodes: {} and {}".format(self.rule_package, node.rule_package))
        if node == self:
            raise Exception("Loop to itself is not allowed")
        self.children.append(node)
        if node is not None:
            node.parents.append(self)

    def __str__(self) -> str:
        return "({}, {})".format(type(self).__name__, self.node_id)
    
    def __repr__(self) -> str:
        return "({}, {})".format(type(self).__name__, self.node_id)    
    
    def to_dict(self) -> dict:
        """
        Obsolete. Node.to_dict() does not preserve DAG structure, resulting in tree.
        """
        d = {'node_type': self.__class__.__name__, 'node_id': self.node_id}
        if self.name is not None:
            d['name'] = self.name
        if self.description is not None:
            d['description'] = self.description
        # rule_package is not serialized otherwise RulePackage.from_dict() throws mismatched RulePackage. 
        #if self.rule_package is not None:
        #    d['rule_package'] = self.rule_package
        if self.children:
            d['children'] = []
            for child in self.children:
                d['children'].append(child.to_dict() if isinstance(child, Node) else None)
        return d

    @staticmethod
    def from_dict(d: dict) -> Node:
        """
        Beware! It's OK for deserializing one node (no children in dict d). It must not be used for deserializing 
        the output from Node.to_dict(). Node.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        node_type = d.get('node_type')
        cls = globals().get(node_type)
        if cls is None:
            raise Exception("Unknown node type {}".format(node_type))
        if not issubclass(cls, Node):
            raise Exception("{} is not a subclass of Node".format(node_type))
        
        try:
            obj = cls(**d)  # Only known arguments in cls.__init__() are used.
        except NodeDeserializationException as ex:
            raise NodeDeserializationException([node_type] + ex.path, ex.msg)
        except Exception as ex:
            raise NodeDeserializationException([node_type], "{} while deserializing {}".format(str(ex), str(d)))

        return obj
    
    def to_graph(self) -> dict:
        d = {'node_id': self.node_id, 'node_type': self.__class__.__name__}
        if self.description is not None:
            d['description'] = self.description  
        if self.name is not None:
            d['name'] = self.name
        return d                  
    

class BigTableNode(Node):
    """
    An input is copied to the single child node.
    """
    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                if verbose is True:
                    execution_result['tracing'].append({'node_id': self.node_id, 'input_tx': None, 'output_tx': copy.deepcopy(input)})
                else:    
                    execution_result['tracing'].append({'node_id': self.node_id})
                need_pop = True       

            for child in self.children:
                child.execute(input, execution_result, metrics, verbose=verbose, debug=debug)     
                if metrics is not None:
                    metrics.add_traffic((self.node_id, child.node_id), 1)

            if need_pop:
                execution_result['tracing'].pop()     
        except Exception as ex:         
            #if need_pop:
            #    execution_result['tracing'].pop() 
                           
            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      

    def add_child(self, node):
        super().add_child(node)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")      
        

class ForkNode(Node):
    """
    An input is copied to all children nodes.
    """
    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                if verbose is True:
                    execution_result['tracing'].append({'node_id': self.node_id, 'input_tx': copy.deepcopy(input), 'output_tx': copy.deepcopy(input)})
                else: 
                    execution_result['tracing'].append({'node_id': self.node_id})
                need_pop = True       

            for child in self.children:
                child.execute(input, execution_result, metrics, verbose=verbose, debug=debug)     
                if metrics is not None:
                    metrics.add_traffic((self.node_id, child.node_id), 1)            

            if need_pop:
                execution_result['tracing'].pop()     
        except Exception as ex:
            #if need_pop:
            #    execution_result['tracing'].pop()  

            # https://realpython.com/python-raise-exception/
            # https://stackoverflow.com/questions/6062576/adding-information-to-an-exception
            # https://stackoverflow.com/questions/696047/re-raise-exception-with-a-different-type-and-message-preserving-existing-inform
            #raise Exception("Node {} got an exception.".format(self.node_id)) from ex 
            #raise type(ex)(ex).with_traceback(sys.exc_info()[2])
            #ex.add_note("An exception occurs while executing {}".format(' -> '.join([t['node_id'] for t in execution_result['tracing']] + [self.node_id])))
            #raise  # Reraise current exception  
            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      


class TransformNode(Node):
    """
    Input is transformed to a single child, i.e. existing field is changed or new field is added.
    The transformed input is only passed to all descendant nodes. The ancestor nodes never see changes.

    Note that the input is shallow copied into an internal variable. 
    The values of the nested structure of the input, if exists, are not copied.
    Changes in the nested structure will remain so it is not suggested to change inner data. 
    """
    def __init__(self, node_id: str, field_name: str, transformer: Union[dict, Transformer], name: str=None, description: str = None, 
                 children: list[Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=children, description=description, rule_package=rule_package)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")        
        self.field_name: str = field_name
        self.transformer: Transformer = None
        if isinstance(transformer, Transformer):
            self.transformer = transformer
        elif isinstance(transformer, dict):
            self.transformer = Transformer(transformer['expression'], transformer.get('description'))
        else:
            raise Exception("Invalid transformer")            
        #else:  
        #    expression = transformer['expression'] if 'expression' in transformer else None
        #    desc = transformer['description'] if 'description' in transformer else None
        #    self.transformer = Transformer(expression, desc)

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:        
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id})
                need_pop = True            

            if self.field_name in input:
                saved = input[self.field_name]
                is_new_field = False
            else:
                is_new_field = True
            
            # Transform input to output
            output = input   # Output and input refer to the same object to reduce copy() overhead.
            if self.transformer is not None:
                result = self.transformer.transform(input, execution_result)
                input_tx = copy.deepcopy(input) if verbose is True else None  # Need to clone input before changing it since input == output              
                output[self.field_name] = result
                if need_pop:
                    if verbose is True:
                        execution_result['tracing'][-1].update({'field_name': self.field_name, 'result': result, 'input_tx': input_tx, 'output_tx': copy.deepcopy(output)})
                    else:
                        execution_result['tracing'][-1].update({'field_name': self.field_name, 'result': result})

            for child in self.children:
                child.execute(output, execution_result, metrics, verbose=verbose, debug=debug)   
                if metrics is not None:
                    metrics.add_traffic((self.node_id, child.node_id), 1)

            # After all children have been executed, restore original input 
            if is_new_field:
                del input[self.field_name]
            else:
                input[self.field_name] = saved

            if need_pop:
                execution_result['tracing'].pop()    
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()   

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      
 
    def add_child(self, node):
        super().add_child(node)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")        

    def to_dict(self) -> dict:
        """
        Obsolete. TransformNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        d = super().to_dict()
        d['field_name'] = self.field_name
        d['transformer'] = self.transformer.to_dict()
        return d

    def to_graph(self) -> dict:
        d = super().to_graph()
        d['field_name'] = self.field_name
        d['transformer'] = self.transformer.to_dict()
        return d
    

class SelectNode(Node):
    """
    Input is transformed by allowing only selected fields passed to a child node.
    The ancestor nodes never see changes.

    Note that the input is shallow copied into an internal variable. 
    The values of the nested structure of the input, if exists, are not copied.
    Changes in the nested structure will remain so it is not suggested to change inner data. 
    """
    def __init__(self, node_id: str, field_names: list[str], name: str=None, description: str = None, 
                 children: list[Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=children, description=description, rule_package=rule_package)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")        
        self.field_names: list[str] = field_names

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            
            # Select specific fields from input to output
            output = {k: input[k] for k in self.field_names}
            if execution_result is not None:
                if verbose is True: 
                    execution_result['tracing'].append({'node_id': self.node_id, 'field_names': self.field_names, 'input_tx': copy.deepcopy(input), 'output_tx': copy.deepcopy(output)})
                else: 
                    execution_result['tracing'].append({'node_id': self.node_id, 'field_names': self.field_names})
                need_pop = True
            for child in self.children:
                child.execute(output, execution_result, metrics, verbose=verbose, debug=debug)   
                if metrics is not None:
                    metrics.add_traffic((self.node_id, child.node_id), 1)

            if need_pop:
                execution_result['tracing'].pop()     
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()   

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      

    def add_child(self, node):
        super().add_child(node)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")        

    def to_dict(self) -> dict:
        """
        Obsolete. SelectNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        d = super().to_dict()
        d['field_names'] = self.field_names
        return d

    def to_graph(self) -> dict:
        d = super().to_graph()
        d['field_names'] = self.field_names
        return d    


class SwitchNode(Node):
    """
    SwitchNode allows one child among many to pass the input to.
    Input is tested the selector and compare with cases to select which child to pass input to.
    children is a list of [operator, case, node], e.g. [['eq', 'True', node2], ['eq', 'False', node3]]
    """

    # Selector can come from json rule or expression (conditions or fact).
    # Each child of children is a tuple of (str, str, Union[Node, dict]) for (operator, operand, node).
    def __init__(self, node_id: str, selector: Union[str, dict], name:str = None, description: str = None, 
                 children: list[tuple[str, str, Union[Node, dict]]] = None, 
                 default_child: Union[Node, dict] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=None, description=description, rule_package=rule_package)

        if selector is None:
            raise Exception("selector is required")       
        
        self.rule: Rule = None
        self.expression: Union[Condition, Fact, Operand] = None
        self.raw = selector
        self.packed = msgpack.packb(self.raw)

        if isinstance(selector, str):  # Expression string
            self.expression = convert_expression(selector)
        elif isinstance(selector, dict):
            if "id" in selector:  # Rule
                self.rule_id = selector["id"]       
                if "conditions" in selector:
                    self.rule = Rule(selector)
                else:
                    self.rule = load_rule_by_id(selector["id"]) 
            elif 'conditions' in selector: # A selector can be conditions, e.g. a > b.
                    self.expression = Condition(None, '$', selector['conditions'])
            elif 'fact' in selector: # A selector can be a fact
                    self.expression = Fact(None, '$', selector['fact'])
            else:
                raise Exception("Invalid selector {}".format(selector))
        else:                     
            raise Exception("Invalid selector {}".format(selector))
        
        self.children: list[tuple[str, str, Node]] = []
        self.case_exprs : list[tuple[OP, Union[Condition, Fact, Operand]]] = []
        if children and isinstance(children, list):
            for e in children:
                oper, case, child = e[0], e[1], e[2]
                if isinstance(child, dict):
                    node = Node.from_dict(child)
                    self.append_child(case, node, oper)
                else:
                    self.append_child(case, child, oper)
        self.default_child: Node = None
        if default_child:
            if isinstance(default_child, dict):
                self.set_default_child(Node.from_dict(default_child))
            else:
                self.set_default_child(default_child)

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:     
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id})
                need_pop = True

            if self.rule is not None:
                (result, audit_tree) = self.rule.apply(input)  # Use rule.audit() for more verbose
                tracing = {'rule_id': self.rule_id, 'result': result, 'ids': audit_tree}
            else:
                #audit_tree = msgpack.unpackb(self.packed) 
                audit_tree = None
                result = self.expression.execute(input, audit_tree, verbose=False)
                tracing = {'result': result} 

            if need_pop:
                if verbose is True:
                    tracing['input_tx'] = copy.deepcopy(input)
                    tracing['output_tx'] = copy.deepcopy(input)
                execution_result['tracing'][-1].update(tracing)

            selected_child = None
            for child_idx, (oper, case, child) in enumerate(self.children):
                operator, case_expr = self.case_exprs[child_idx]
                case_result = case_expr.execute(input, None, verbose=False)
                if operator in (OP.eq, OP['=']):
                    if result == case_result: # and type(result) == type(case_result):  # Recall that 1 == True in python. How about 1 == 1.0? So we check type too.
                        selected_child = child                
                elif operator in (OP.gt, OP['>']):
                    if result > case_result:
                        selected_child = child
                elif operator in (OP.ge, OP['>=']):
                    if result >= case_result:
                        selected_child = child
                elif operator in (OP.neq, OP['<>']):
                    if result != case_result:
                        selected_child = child                    
                elif operator in (OP.lt, OP['<']):
                    if result < case_result:
                        selected_child = child
                elif operator in (OP.le, OP['<=']):
                    if result <= case_result:
                        selected_child = child
                elif operator == OP['is']:   # Cannot use OP.is (reserved word maybe)
                    if result is case_result:
                        selected_child = child            
                elif operator == OP['is_not']:   
                    if result is not case_result:
                        selected_child = child                    
                elif operator in (OP.is_in, OP.is_not_in):
                    switch = False if operator == OP.is_in else True  # It is used for XOR (^) 
                    if isinstance(case_result, list):
                        selected_child = child if (result in case_result) ^ switch else None
                    else:
                        raise NotImplementedError('{} not supported by "{}" operator'.format(type(case_result), operator.name))                                    
                elif operator in (OP.like, OP.not_like):
                    switch = False if operator == OP.like else True  # It is used for XOR (^)
                    if isinstance(result, str):
                        selected_child = child if (fnmatch.fnmatch(result.lower(), case_result.lower())) ^ switch else None
                    else:
                        raise NotImplementedError('{} must be string for "{}" operator'.format(type(result), operator.name))  
                elif operator in (OP.between, OP.not_between):  # case_result is an array of [a, b]
                    switch = False if operator == OP.between else True  # It is used for XOR (^)
                    if not isinstance(case_result, list) or len(case_result) != 2:
                        raise Exception('Operator {} requires [a, b] as the right operand'.format(self.operator.name))                      
                    if isinstance(case_result[1], datetime):  # Specifically for datetime, right operator is <.
                        if (result >= case_result[0] and result < case_result[1]) ^ switch:
                            selected_child = child
                    elif (result >= case_result[0] and result <= case_result[1]) ^ switch:  # For int and float, right operator is <=
                        selected_child = child
                elif operator in (OP.contains, OP.is_overlap, OP.is_not_overlap):
                    bound_method = getattr(result, operator.name, None)
                    if bound_method is not None and callable(bound_method):
                        selected_child = child if bound_method(case_result) else None
                    else: 
                        raise NotImplementedError('{} has no method "{}"'.format(type(result), operator.name))  
                else:
                    raise NotImplementedError('Unknown operator "{}" in SwitchNode'.format(operator))
                          
                if selected_child is not None:
                    if need_pop:
                        execution_result['tracing'][-1].update({'operator': oper, 'case': case_result, 'child_idx': child_idx})
                    selected_child.execute(input, execution_result, metrics, verbose=verbose, debug=debug)
                    if metrics is not None:
                        metrics.add_traffic((self.node_id, selected_child.node_id), 1)
                    if need_pop:
                        execution_result['tracing'].pop()
                    return
      
            if self.default_child:
                if need_pop:
                    execution_result['tracing'][-1].update({'default': result})
                self.default_child.execute(input, execution_result, metrics, verbose=verbose, debug=debug)
                if metrics is not None:
                    metrics.add_traffic((self.node_id, self.default_child.node_id), 1)

            if need_pop:
                execution_result['tracing'].pop()
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()            

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      
  
    def set_child(self, case: object, node: Node, op: str = 'eq'):
        raise Exception("set_child() is deprecated. Use append_child().")


    def append_child(self, case: str, node: Node, op: str = 'eq'):
        if node == self:
            raise Exception("Loop to itself is not allowed")
        if node.rule_package != self.rule_package:
            raise Exception("Mismatched RulePackage between two nodes: {} and {}".format(self.rule_package, node.rule_package))  
        if not isinstance(case, str):
            raise Exception("Need expression string for argument 'case' but {} is found".format(type(case)))      
        if isinstance(op, str):
            try:
                operator = OP[op]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator "{}" in SwitchNode'.format(op)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred        
        if node is not None:
            node.parents.append(self)
        self.children.append((op, case, node)) 
        self.case_exprs.append((operator, convert_expression(case)))      

    def set_default_child(self, node: Node):
        if node == self:
            raise Exception("Loop to itself is not allowed")   
        if node.rule_package != self.rule_package:
            raise Exception("Mismatched RulePackage between two nodes: {} and {}".format(self.rule_package, node.rule_package))            
        if self.default_child is not None:
            self.default_child.parents.remove(self)        
        if node is not None:
            node.parents.append(self)
        self.default_child = node

    def add_child(self, node):
        raise Exception("Use append_child() or set_default_child()")

    def to_dict(self) -> dict:
        """
        Obsolete. SwitchNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        d = super().to_dict()
        if self.rule is not None:
            d['selector'] = {'id': self.rule_id}
        elif self.expression is not None:
            d['selector'] = self.raw

        if self.children:
            d['children'] = [[oper, case, child.to_dict()] for oper, case, child in self.children]
        if self.default_child:
            d['default_child'] = self.default_child.to_dict()
        return d
    
    def to_graph(self) -> dict:
        d = super().to_graph()
        if self.rule is not None:
            d['selector'] = {'id': self.rule_id}
        elif self.expression is not None:
            d['selector'] = self.raw
        return d    


class DecisionTableNode(Node):
    """
    A DecisionTableNode consists of multiple rules (condition-action).
    Each rule is tested with the input record. The action of the matching rule transforms the input to the output.

    The parameter table is a dict. The table is assumed to be a valid table. Field name and description are ignored.
    Inputs is a list of all field names in conditions from all rules. Outputs is a list of all field names in actions from all rules.
    The hit policy is allowed to be "unique" or "first". 
    Field conditions can be both simple python expression string (required for verification) or a condition dict.
    If field conditions is None, an empty string or empty dict, it is evaluated to True. So it can be used as the default rule.
    For each action, the value is an expression string or a dict of condition, fact or operand. A table dict looks like:
    {
        "name": "Customer Discount Table",
        "description": "Calculates discount percentage and offers free shipping based on customer status and total purchase.",
        "inputs": ["is_premium_member", "total_purchase_amount"],
        "outputs": ["discount_percent", "offer_free_shipping"],
        "hit_policy": "first",
        "rules": [
            {
                "conditions": "is_premium_member == True and total_purchase_amount >= 100",
                "actions": {
                    "discount_percent": "15",
                    "offer_free_shipping": "True"
                },
                "description": "Premium members with purchases of $100 or more get a 15% discount and free shipping."
            },
            {
                "conditions": {
                    "all": [
                        {
                            "fact": "is_premium_member",
                            "operator": "is",
                            "value": True
                        },
                        {
                            "fact": "total_purchase_amount",
                            "operator": "<",
                            "value": 100
                        }
                    ]
                },
                "actions": {
                    "discount_percent": "5",
                    "offer_free_shipping": "True"
                },
                "description": "Premium members with purchases under $100 get a 5% discount and free shipping."
            },
            {
                "conditions": "",
                "actions": {
                    "discount_percent": "0",
                    "offer_free_shipping": "False"
                },
                "description": "Default rule"
            }
        ]
    }

    """
    class Action:
        def __init__(self, field_name: str, transformer: Transformer):
            self.field_name = field_name
            self.transformer = transformer
    

    class Rule:
        def __init__(self, rule: dict):
            if rule['conditions'] is None or rule['conditions'] == "":
                self.condition = Operand(None, '$', True)
            elif isinstance(rule['conditions'], str):
                self.condition = convert_expression(rule['conditions'])
            elif isinstance(rule['conditions'], dict):
                if rule['conditions'] == {}: 
                    self.condition = Operand(None, '$', True)
                else:
                    self.condition = Condition(None, '$', rule['conditions'])
            else:
                raise Exception("rule['conditions] = {} is not valid.".format(rule['conditions']))

            self.actions = []
            for key, expression in rule['actions'].items():
                if isinstance(expression, str):
                    action = DecisionTableNode.Action(key, Transformer(expression))
                elif isinstance(expression, dict):
                    if 'conditions' in expression: # An expression can be conditions, e.g. a > b.
                        expr = Condition(None, '$', expression['conditions'])
                    elif 'fact' in expression:
                        expr = Fact(None, '$', expression['fact'])
                    elif 'operand' in expression:
                        expr = Operand(None, '$', expression['operand'])
                    else:
                        raise Exception("Invalid expression {}".format(expression))   
                    action = DecisionTableNode.Action(key, Transformer(expr))                 
                self.actions.append(action)


    # Selector can come from json rule or expression (conditions or fact).
    # Each child of children is a tuple of (str, str, Union[Node, dict]) for (operator, operand, node).
    def __init__(self, node_id: str, table: dict, name:str = None, description: str = None, 
                 children: list[Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=None, description=description, rule_package=rule_package)

        if table is None:
            raise Exception("table is required")       
        
        self.table: dict = table
        if self.table['hit_policy'] not in ['unique', 'first']:
            raise Exception("Hit policy {} is supported in DecisionTableNode".format(self.table['hit_policy']))
        
        self.rules: list[DecisionTableNode.Rule] = [DecisionTableNode.Rule(rule) for rule in self.table["rules"]]


    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:     
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id})
                need_pop = True

            selected_rule_ids = []
            for rule_idx, rule in enumerate(self.rules):
                if rule.condition.execute(input, None, verbose=False) is True:
                    selected_rule_ids.append(rule_idx)
                    if self.table['hit_policy'] == 'first':
                        break
        
            if len(selected_rule_ids) > 0:
                if self.table['hit_policy'] == 'unique' and len(selected_rule_ids) > 1:
                    raise Exception("Hit policy 'unique' in DecisionTableNode {} matches multiple rules {}".format(self.node_id, ', '.join([str(id) for id in selected_rule_ids])))
                
                selected_rule_idx = selected_rule_ids[0]  # Only one rule is allowed for 'first' and 'unique' hit policy.

                # Transform input to output
                output = input   # Output and input refer to the same object to reduce copy() overhead.
                input_tx = copy.deepcopy(input) if verbose is True else None  # Need to clone input before changing it since input == output              
                rule = self.rules[selected_rule_idx]
                actions = []
                saved = {}
                for action in rule.actions:
                    result = action.transformer.transform(input, execution_result)

                    # Save original input fields that may be changed by actions
                    if action.field_name in input:
                        saved[action.field_name] = {'is_new_field': False, 'value': input[action.field_name]}
                    else:
                        saved[action.field_name] = {'is_new_field': True}

                    output[action.field_name] = result
                    actions.append({'field_name': action.field_name, 'result': result})

                if need_pop:
                    if verbose is True:
                        execution_result['tracing'][-1].update({'rules': [{'rule_id': selected_rule_idx, 'actions': actions}], 'input_tx': input_tx, 'output_tx': copy.deepcopy(output)})
                    else:
                        execution_result['tracing'][-1].update({'rules': [{'rule_id': selected_rule_idx, 'actions': actions}]})

                for child in self.children:
                    child.execute(output, execution_result, metrics, verbose=verbose, debug=debug)   
                    if metrics is not None:
                        metrics.add_traffic((self.node_id, child.node_id), 1)

                # After all children have been executed, restore original input 
                for key in saved.keys():
                    if saved[key]['is_new_field'] is True:
                        del input[key]
                    else:
                        input[key] = saved[key]['value']
            else:
                #raise Exception("No rule matched in DecisionTableNode {}".format(self.node_id))
                pass

            if need_pop:
                execution_result['tracing'].pop()
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()            

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      
  
    def add_child(self, node):
        super().add_child(node)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")        

    def to_dict(self) -> dict:
        """
        Obsolete. DecisionTableNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        d = super().to_dict()
        d['table'] = self.table
        return d

    def to_graph(self) -> dict:
        d = super().to_graph()
        d['table'] = self.table
        return d


class FlagNode(Node):
    """
    A flag is inserted into execution result and then the input is simply passed to the next node.
    The template is used to create a message in the execution result. It has two types. 
    
    First is a python Template string, for example, 
    ```py
    "Total expense $total < 1000"
    ```
    The placeholder $total will be substituted by the value of input field of the same name (total).
    A placeholder is defined by the dollar sign followed by a valid identifier. Use $$ for a literal dollar sign.
    
    Second is a user-defined dict. The value of a key can be number, string, Template string or a dict (nested dict is allowed).
    If a dict d has only one key $ref, it is substituted by input field named d["$ref"].
    For example, if template is 
    ```py
    {
        "type": 1, "description": 
        "Total expense $total < 1000", 
        "details": {"$ref": "some_field_name"}
    }
    ```
    "details" value is substituted by input["some_field_name"]

    RuleNode and FlagNode should not be used in the same package as they serve on different purpose.
    """
    def __init__(self, node_id: str, flag: str, template: Union[str, dict] = "", name: str = None, description: str = None, 
                 children: list[Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=children, description=description, rule_package=rule_package)
        self.flag = flag
        self.raw = template
        self.template: Union[Template, dict] = None
        if isinstance(template, str):
            self.template = Template(template)
        elif isinstance(template, dict):
            self.template = msgpack.unpackb(msgpack.packb(self.raw))  # Like copy.deepcopy()
            self.prepare_dict_template(self.template) # Note that msgpack cannot deep copy Template object
        else: 
            raise Exception("template must be string or dict")

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id})           
                need_pop = True                 

            if isinstance(self.template, Template):           
                args = {name: input[name].to_list() if isinstance(input[name], (OBJECTLIST, ARRAY)) else input[name] for name in self.template.get_identifiers()}
                message = self.template.substitute(args)
            elif isinstance(self.template, dict):
                message = self.fill_dict_template(self.template, input)
            else:
                message = None
            if need_pop:
                if verbose is True:
                    execution_result['tracing'][-1].update({'flag': self.flag, 'input_tx': copy.deepcopy(input), 'output_tx': copy.deepcopy(input)}) 
                else:
                    execution_result['tracing'][-1].update({'flag': self.flag})           
                execution_result['flags'].append({
                    'flag': self.flag,
                    'message': message,
                    'trace': execution_result['tracing'].copy()
                })

            for child in self.children:
                child.execute(input, execution_result, metrics, verbose=verbose, debug=debug)
                if metrics is not None:
                    metrics.add_traffic((self.node_id, child.node_id), 1)      

            if need_pop:
                execution_result['tracing'].pop()   
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()                  

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      
 
    def add_child(self, node):
        super().add_child(node)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")                    

    # Convert list value with placeholer string to Template
    def prepare_list_template(self, list_template: list) -> None:
        for idx, value in enumerate(list_template):
            if isinstance(value, str): 
                template = Template(value)
                if len(template.get_identifiers()):
                    list_template[idx] = template
            elif isinstance(value, dict): # Recursive to embeded dict
                self.prepare_dict_template(value)
            elif isinstance(value, list): # Recursive to embeded list
                self.prepare_list_template(value)    

    # Convert dict value with placeholer string to Template
    def prepare_dict_template(self, dict_template: dict) -> None:
        for key, value in dict_template.items():
            if isinstance(value, str): 
                template = Template(value)
                if len(template.get_identifiers()):
                    dict_template[key] = template
            elif isinstance(value, dict): # Recursive to embeded dict
                self.prepare_dict_template(value)
            elif isinstance(value, list): # Recursive to embeded list
                self.prepare_list_template(value)

    # Create output list by substituting Templates from input contents.
    # Objects are copied by reference, not deep copy.
    def fill_list_template(self, list_template: list, input) -> list:  
        output_list = list_template.copy() # Shallow copy list
        for idx, value in enumerate(output_list):
            if isinstance(value, Template): 
                args = {name: input[name].to_list() if isinstance(input[name], (OBJECTLIST, ARRAY)) else input[name] for name in value.get_identifiers()}
                output_list[idx] = value.substitute(args)                
            if isinstance(value, dict):
                if value.keys() == {'$ref'}: # If value has only $ref, replace this dict with input field
                    if value['$ref'] in input:
                        output_list[idx] = input[value['$ref']].to_list() if isinstance(input[value['$ref']], (OBJECTLIST, ARRAY)) else input[value['$ref']]
                else:  # Recursive to embeded dict                
                    output_list[idx] = self.fill_dict_template(value, input)
            elif isinstance(value, list):
                output_list[idx] = self.fill_list_template(value, input)

        return output_list

    # Create output dict by substituting Templates from input contents.
    # Objects are copied by reference, not deep copy.
    # https://stackoverflow.com/questions/45858084/what-is-a-fast-pythonic-way-to-deepcopy-just-data-from-a-python-dict-or-list
    def fill_dict_template(self, dict_template: dict, input) -> dict:
        output_dict = dict_template.copy() # Shallow copy dict     

        for key, value in output_dict.items():
            if key == '$ref': 
                pass
            elif isinstance(value, dict):
                if value.keys() == {'$ref'}: # If value has only $ref, replace this dict with input field
                    if value['$ref'] in input:
                        output_dict[key] = input[value['$ref']].to_list() if isinstance(input[value['$ref']], (OBJECTLIST, ARRAY)) else input[value['$ref']]
                else:  # Recursive to embeded dict
                    output_dict[key] = self.fill_dict_template(value, input) 
            elif isinstance(value, Template):
                args = {name: input[name].to_list() if isinstance(input[name], (OBJECTLIST, ARRAY)) else input[name] for name in value.get_identifiers()}
                output_dict[key] = value.substitute(args)
            elif isinstance(value, list):
                output_dict[key] = self.fill_list_template(value, input)

        return output_dict

    def to_dict(self) -> dict:
        """
        Obsolete. FlagNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        d = super().to_dict()
        d['flag'] = self.flag
        d['template'] = self.raw
        return d      

    def to_graph(self) -> dict:
        d = super().to_graph()
        d['flag'] = self.flag
        d['template'] = self.raw
        return d           


class RuleNode(Node):
    """
    A rule node simply outputs a string referring to a rule which is used by rule dispatcher to execute a specific rule.
    RuleNode and FlagNode should not be used in the same package as they serve on different purpose.
    
    """
    def __init__(self, node_id: str, rule: str, name: str = None, description: str = None, 
                 children: list[Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=children, description=description, rule_package=rule_package)
        self.rule = rule

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                if verbose is True:
                    execution_result['tracing'].append({'node_id': self.node_id, 'rule': self.rule, 'input_tx': copy.deepcopy(input), 'output_tx': None}) 
                else:
                    execution_result['tracing'].append({'node_id': self.node_id, 'rule': self.rule})  

                execution_result['rules'].append({
                    'rule': self.rule,
                    'trace': execution_result['tracing'].copy()
                })
                need_pop = True     

            for child in self.children:
                child.execute(input, execution_result, metrics, verbose=verbose, debug=debug)
                if metrics is not None:
                    metrics.add_traffic((self.node_id, child.node_id), 1)                                 

            if need_pop:
                execution_result['tracing'].pop()   
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()                  

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      
 
    def add_child(self, node):
        raise Exception("RuleNode {} cannot have a child".format(self.node_id)) 
        #super().add_child(node)
        #if len(self.children) > 1:
        #    raise Exception("More than one child not allowed")                               

    def to_dict(self) -> dict:
        """
        Obsolete. RuleNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        d = super().to_dict()
        d['rule'] = self.rule
        return d      

    def to_graph(self) -> dict:
        d = super().to_graph()
        d['rule'] = self.rule
        return d         
    

class InPortNode(Node):
    """
    An InPortNode is used to define input port for SubRule.
    An InportNode can not be used with RuleNode and FlagNode in the same package as they serve on different purpose.
    """
    def __init__(self, node_id: str, name: str = None, description: str = None, 
                 children: list[Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=children, description=description, rule_package=rule_package)

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id})
                if verbose is True:
                    execution_result['tracing'][-1].update({'input_tx': copy.deepcopy(input), 'output_tx': copy.deepcopy(input)}) 

                need_pop = True                

            for child in self.children:
                child.execute(input, execution_result, metrics, verbose=verbose, debug=debug)    
                if metrics is not None:
                    metrics.add_traffic((self.node_id, child.node_id), 1)                

            if need_pop:
                execution_result['tracing'].pop()   

        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()                  

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      
 
    def add_child(self, node):
        super().add_child(node)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")    
        

class OutPortNode(Node):
    """
    An OutPortNode is used to define output port for SubRule.
    An OutportNode can not be used with RuleNode and FlagNode in the same package as they serve on different purpose.
    """
    def __init__(self, node_id: str, name: str = None, description: str = None, 
                 children: list[Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=children, description=description, rule_package=rule_package)

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id})
                if verbose is True:
                    execution_result['tracing'][-1].update({'input_tx': copy.deepcopy(input), 'output_tx': copy.deepcopy(input)}) 
                
                execution_result['outputs'].append({
                    'outport': self.node_id,
                    'output_tx': input.copy(), #  Shallow copy 
                    'trace': execution_result['tracing'].copy()
                })
                need_pop = True             

            if need_pop:
                execution_result['tracing'].pop()   
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()                  

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      
 
    def add_child(self, node):
        raise Exception("OutPortNode {} cannot have a child".format(self.node_id))                    
    

class SubRuleNode(Node):
    """
    A subrule node executes subgraph as part of the current graph. 
    Input fields of a transaction are passed by value into fields used in a subrule. 
    Which input fields are passed are defined by in_mapping.keys().
    Output fields are merged to the transaction; except any mapped input fields (arguments to subrule).
    Output fields which are duplicated to the input transaction are prohibited.
    Each subrule can have only one InPortNode; but one or more OutPortNodes.

    subrule is a string referring to a rule package or a RulePackage object. 
    If it is a string, rule_package is required.

    in_mapping is a dict of input_field -> subrule_field. (one-to-many or one-to-one).
    It could be like field1 -> field_A for string.
      or field1 -> {'name': 'field_A', 'attrs': {'name': 'firstname'}} for OBJECTLIST.

    children is a dict of outport_id -> (node, out_mapping), e.g. {'outport1': (node2, {}), 'outport2': (node3, {'x': 'y'})}
    """
    def __init__(self, node_id: str, subrule: str | dict | RulePackage, in_mapping: dict[str, str | dict], name: str = None, description: str = None, 
                 children: dict[str, tuple[Union[Node, dict], dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=None, description=description, rule_package=rule_package)
        self.in_mapping = in_mapping
        self.subrule = subrule
        if isinstance(subrule, str):
            #raise NotImplementedError("subrule must be a RulePackage object.")
            if self.rule_package is None or subrule not in self.rule_package.subpackages:
                raise RulePackageException("Cannot find definition for subrule {}".format(subrule))
            self.subpackage = self.rule_package.subpackages[subrule]
        elif isinstance(subrule, dict):
            self.subpackage = RulePackage.from_graph(subrule)
        elif isinstance(subrule, RulePackage):
            self.subpackage = subrule
        else:
            raise RulePackageException("Cannot create subrule")
        mapped_fields = []
        for k, v in self.in_mapping.items():
            if isinstance(v, str):
                mapped_fields.append(v)
            elif isinstance(v, dict): 
                if 'name' not in v:
                    mapped_fields.append(v)
                else:
                    mapped_fields.append(v['name'])
            else:
                raise Exception('Wrong mapping for {}'.format(k))
        if len(set(mapped_fields)) < len(mapped_fields):
            raise Exception('Many-to-one input mapping not allowed.')
        self.argument_fields = set(mapped_fields)  
        
        self.children: dict[str, tuple[Node, dict]] = {}
        if children and isinstance(children, dict):
            for outport, (child, out_mapping) in children.items():
                if isinstance(child, dict):
                    node = Node.from_dict(child)
                    self.set_child(outport, node, out_mapping)
                else:
                    self.set_child(outport, child, out_mapping)        

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False

            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id, 'subrule': self.subpackage.package_id})           
                need_pop = True                
            
            parent_ctx = txcntx.get() # Save the parent context. 
            if parent_ctx != input: # It should be the same as input.
                raise Exception("Wrong context!")

            # Create sub-transaction
            #subinput = {k_subrule: input[k_in] for k_in, k_subrule in self.in_mapping.items()}
            subinput = {}
            for f_in, f_subrule in self.in_mapping.items():
                if isinstance(f_subrule, str):
                    subinput[f_subrule] = input[f_in]  # TODO: always copy ARRAY or OBJECTLIST by value if performance does not matter
                elif isinstance(f_subrule, dict) and isinstance(input[f_in], OBJECTLIST):
                    field_name = f_subrule['name'] if 'name' in f_subrule else f_in
                    if 'attrs' in f_subrule:
                        subinput[field_name] = OBJECTLIST([{column_subrule: o.get(column_in) for column_in, column_subrule in f_subrule['attrs'].items()} for o in input[f_in].data])
                    else:
                        subinput[field_name] = input[f_in]   # TODO: always copy OBJECTLIST by value if performance does not matter
                
                else:
                    raise RulePackageException("in_mapping for {} is not correct".format(f_in))

            # Change context
            txcntx.set(subinput)

            # Execute subrule
            self.subpackage.execute(subinput, verbose=verbose)
            outputs = self.subpackage.get_subrule_result()['outputs']

            # Restore the parent context
            txcntx.set(parent_ctx)                  

            # Forward each output
            for output in outputs:
                outport, returned_output, return_trace = output['outport'], output['output_tx'], output['trace']
                child, out_mapping = self.children.get(outport)
                if child is not None:
                    if need_pop:
                        if verbose is True:
                            execution_result['tracing'][-1].update({ 'input_tx': copy.deepcopy(input)})           

                    # Merge sub-transaction, i.e. merge input with returned_output; rename field if provided.
                    output_tx = input.copy()
                    if out_mapping is not None:
                        returned_output = {out_mapping.get(k_subrule, k_subrule): v for k_subrule, v in returned_output.items()}  # Rename field if provided
                    for k_subrule, v in returned_output.items():
                        if k_subrule in self.argument_fields:  # Skip merging the argument fields
                            continue
                        if k_subrule in output_tx:
                            raise NodeExecuteException('Cannot merge duplicated field {} to transaction'.format(k_subrule))
                        output_tx[k_subrule] = v

                    if need_pop:
                        execution_result['tracing'][-1].update({'outport': outport})
                        if verbose is True:
                            execution_result['tracing'][-1].update({'output_tx': output_tx, 'trace': return_trace})
                                           
                    child.execute(output_tx, execution_result, metrics, verbose=verbose, debug=debug)
                                        
                    if metrics is not None:
                        metrics.add_traffic((self.node_id, child.node_id), 1)  

                    if need_pop:
                        execution_result['tracing'][-1] = {'node_id': self.node_id, 'subrule': self.subpackage.package_id}   

            if need_pop:
                execution_result['tracing'].pop()
                        

        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()                  

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      

    def set_child(self, outport_id: str, node: Node, out_mapping: dict = {}):
        """
        out_mapping (optional) is a dict of subrule_field -> new_field. (one-to-many or one-to-one). Default to subrule_field -> subrule_field.
        """
        if node == self:
            raise Exception("Loop to itself is not allowed")
        if node.rule_package != self.rule_package:
            raise Exception("Mismatched RulePackage between two nodes: {} and {}".format(self.rule_package, node.rule_package))  
        if not isinstance(outport_id, str):
            raise Exception("Need string for argument 'outport_id' but {} is found".format(type(outport_id)))    
        if len(set(out_mapping.values())) < len(out_mapping.values()):
            raise Exception('Many-to-one output mapping not allowed.')          
        if node is not None:
            node.parents.append(self)
        self.children[outport_id] = (node, out_mapping)

    def add_child(self, node):
        raise Exception("Use set_child()")              

    def to_dict(self) -> dict:
        """
        Obsolete. RuleNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        raise NotImplementedError("Obsolete")   

    def to_graph(self) -> dict:
        d = super().to_graph()
        d['subrule'] = self.subrule.to_graph() if isinstance(self.subrule, RulePackage) else self.subrule
        d['in_mapping'] = self.in_mapping
        return d             


class _SubRuleNode_pass_by_reference(Node):
    """
    Unused. This is SubRuleNode with pass-by-reference. 
    A subrule node executes subgraph as part of the current graph. 
    Input fields of a transaction are mapped into fields used in a subrule. 
    Output fields are mapped back to the transaction. Local fields are ignored.
    Each subrule can have only one InPortNode; but one or more OutPortNodes.

    subrule is a string referring to a rule package or a RulePackage object.

    mapping is a dict of input_field -> subrule_field. (one-to-one).    
    
    children is a dict of outport_id -> node, e.g. {'outport1': node2, 'outport2': node3}
    """
    def __init__(self, node_id: str, subrule: RulePackage, mapping: dict, name: str = None, description: str = None, 
                 children: dict[str, Union[Node, dict]] = None, rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=None, description=description, rule_package=rule_package)
        self.mapping = mapping
        self.subrule = subrule
        if not isinstance(subrule, RulePackage):
            raise NotImplementedError("subrule must be a RulePackage object.")
        self.subpackage = subrule
        self.reversed_mapping = {k_subrule: k_in for k_in, k_subrule in self.mapping.items()}
        if len(self.mapping) != len(self.reversed_mapping):
            raise Exception('One-to-one mapping required; but duplicated mapping found')
        
        self.children: dict[str, Node] = {}
        if children and isinstance(children, dict):
            for outport, child in children.items():
                if isinstance(child, dict):
                    node = Node.from_dict(child)
                    self.set_child(outport, node)
                else:
                    self.set_child(outport, child)        

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id, 'subrule': self.subpackage.package_id})           
                need_pop = True               
            
            parent_ctx = txcntx.get() # Save the parent context. 
            if parent_ctx != input: # It should be the same as input.
                raise Exception("Wrong context!")

            # Create sub-transaction
            subinput = {k_subrule: input[k_in] for k_subrule, k_in in self.reversed_mapping.items()}

            # Change context
            txcntx.set(subinput)

            # Execute subrule
            self.subpackage.execute(subinput, verbose=verbose)
            outputs = self.subpackage.get_subrule_result()['outputs']
        
            # Restore the parent context
            txcntx.set(parent_ctx)                  

            # Forward each output
            for output in outputs:
                outport, returned_output, return_trace = output['outport'], output['output_tx'], output['trace']
                child = self.children.get(outport)
                if child is not None:
                    if need_pop:
                        if verbose is True:
                            execution_result['tracing'][-1].update({'input_tx': copy.deepcopy(input)})

                    # Merge sub-transaction, i.e. merge input with returned_output, skipping local transforms
                    output_tx = input.copy()
                    output_tx.update({self.reversed_mapping[k_subrule]: v for k_subrule, v in returned_output.items() if k_subrule in self.reversed_mapping})
                    if need_pop:
                        execution_result['tracing'][-1].update({'outport': outport})
                        if verbose is True:
                            execution_result['tracing'][-1].update({'output_tx': output_tx, 'trace': return_trace})
                                           
                    child.execute(output_tx, execution_result, metrics, verbose=verbose, debug=debug)
                                        
                    if metrics is not None:
                        metrics.add_traffic((self.node_id, child.node_id), 1)                      

                    if need_pop:
                        execution_result['tracing'][-1] = {'node_id': self.node_id, 'subrule': self.subpackage.package_id}  

            if need_pop:
                execution_result['tracing'].pop()                          

        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()                  

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      

    def set_child(self, outport_id: str, node: Node):
        if node == self:
            raise Exception("Loop to itself is not allowed")
        if node.rule_package != self.rule_package:
            raise Exception("Mismatched RulePackage between two nodes: {} and {}".format(self.rule_package, node.rule_package))  
        if not isinstance(outport_id, str):
            raise Exception("Need string for argument 'outport_id' but {} is found".format(type(outport_id)))      
        if node is not None:
            node.parents.append(self)
        self.children[outport_id] = node

    def add_child(self, node):
        raise Exception("Use set_child()")              

    def to_dict(self) -> dict:
        """
        Obsolete. RuleNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        raise NotImplementedError("Obsolete")  

    def to_graph(self) -> dict:
        raise NotImplementedError("Not yet implemented")          

class AuditNode(Node):
    """
    Obsolete. Input is audited with a rule and passed to the next node.
    """
    def __init__(self, node_id: str, rule: dict, name: str = None, description: str = None, children: list[Union[Node, dict]] = None, 
                 rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=children, description=description, rule_package=rule_package)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")
        if "id" not in rule:
            raise Exception("Require id in rule")
        self.rule_id = rule["id"]
        self.rule: Rule = None
        if "conditions" in rule:
            self.rule = Rule(rule)
        else:
            self.rule = load_rule_by_id(rule["id"])

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:   
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            (result, audit_tree) = self.rule.apply(input)  # Use rule.audit() for more verbose.
            if execution_result is not None:
                if verbose is True:
                    execution_result['tracing'].append({'node_id': self.node_id, 'rule_id': self.rule_id, 'result': result, 'ids': audit_tree, 'input_tx': copy.deepcopy(input), 'output_tx': copy.deepcopy(input)})
                else:
                    execution_result['tracing'].append({'node_id': self.node_id, 'rule_id': self.rule_id, 'result': result, 'ids': audit_tree})
                need_pop = True
            for child in self.children:
                child.execute(input, execution_result, metrics, verbose=verbose, debug=debug)
                if metrics is not None:
                    metrics.add_traffic((self.node_id, child.node_id), 1)     

            if need_pop:
                execution_result['tracing'].pop()   
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()                 

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      

    def add_child(self, node):
        super().add_child(node)
        if len(self.children) > 1:
            raise Exception("More than one child not allowed")        

    def to_dict(self) -> dict:
        """
        Obsolete. AuditNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        d = super().to_dict()
        d['rule'] = {'id': self.rule_id}
        return d

    def to_graph(self) -> dict:
        d = super().to_graph()
        d['rule'] = {'id': self.rule_id}
        return d
    

class BranchNode(Node):
    """
    Obsolete. Use SwitchNode instead. 
    Test the input with a rule to select which child (between then and else) to go.
    """
    def __init__(self, node_id: str, condition_rule: dict, name: str = None, description: str = None, children: list[Union[Node, dict]] = None, 
                 rule_package: RulePackage = None, **kwargs):
        super().__init__(node_id, name=name, children=None, description=description, rule_package=rule_package)
        self.children = [None, None]    # Child Index 0 is for then, 1 is for else.
        if children and isinstance(children, list):
            if len(children) > 2:
                raise Exception("More than two children not allowed")
            children = [Node.from_dict(child) if isinstance(child, dict) else child for child in children]
            children = children + [None]*(2 - len(children)) # Fill None until 2 elements
            self.set_then(children[0])
            self.set_otherwise(children[1])     
 
        if "id" not in condition_rule:
            raise Exception("Require id in rule")
        self.rule_id = condition_rule["id"]
        self.rule: Rule = None       
        if "conditions" in condition_rule:
            self.condition_rule = Rule(condition_rule)
        else:
            self.condition_rule = load_rule_by_id(condition_rule["id"])       

    def execute(self, input, execution_result, metrics = None, verbose=False, debug=False):
        try:
            if debug:
                self.rule_package.shared_execution_result.update(execution_result) # Put the current execution result to parent process
                self.pause()

            need_pop = False
            if execution_result is not None:
                execution_result['tracing'].append({'node_id': self.node_id, 'rule_id': self.rule_id})
                need_pop = True            

            (result, audit_tree) = self.condition_rule.apply(input) # Use rule.audit() for more verbose
            if need_pop:
                if verbose is True:
                    execution_result['tracing'][-1].update({'result': result, 'case': result, 'ids': audit_tree, 'input_tx': copy.deepcopy(input), 'output_tx': copy.deepcopy(input)})
                else:
                    execution_result['tracing'][-1].update({'rule_id': self.rule_id, 'result': result, 'case': result, 'ids': audit_tree})
                
            if result:
                if self.children[0] is not None:
                    self.children[0].execute(input, execution_result, metrics, verbose=verbose, debug=debug)
                    if metrics is not None:
                        metrics.add_traffic((self.node_id, self.children[0].node_id), 1)
            else:
                if self.children[1] is not None:
                    self.children[1].execute(input, execution_result, metrics, verbose=verbose, debug=debug)
                    if metrics is not None:
                        metrics.add_traffic((self.node_id, self.children[1].node_id), 1)
            
            if need_pop:
                execution_result['tracing'].pop()
        except Exception as ex: 
            #if need_pop:
            #    execution_result['tracing'].pop()                 

            if isinstance(ex, NodeExecuteException):
                raise   # Reraise current exception
            else: 
                raise NodeExecuteException("{}, while executing {}".format(ex, ' -> '.join([t['node_id'] for t in execution_result['tracing']]))).with_traceback(sys.exc_info()[2]) from ex                      

    def set_then(self, then: Node = None):
        if then == self:
            raise Exception("Loop to itself is not allowed")        
        if self.children[0] is not None:
            self.children[0].parents.remove(self)
        self.children[0] = then
        if then is not None:
            then.parents.append(self)

    def set_otherwise(self, otherwise: Node = None): 
        if otherwise == self:
            raise Exception("Loop to itself is not allowed")        
        if self.children[1] is not None:
            self.children[1].parents.remove(self)      
        self.children[1] = otherwise
        if otherwise is not None:
            otherwise.parents.append(self)

    def add_child(self, node):
        raise Exception("Use set_then() or set_otherwise()")        
        #super().add_child(node)
        #if len(self.children) > 2:
        #    raise Exception("More than two children not allowed. Use set_then() or set_otherwise()")

    def to_dict(self) -> dict:
        """
        Obsolete. BranchNode.to_dict() does not preserve DAG structure, resulting in tree.
        """        
        d = super().to_dict()
        d['condition_rule'] = {'id': self.rule_id}
        return d
    
    def to_graph(self) -> dict:
        d = super().to_graph()
        d['condition_rule'] = {'id': self.rule_id}
        return d    


# https://stackoverflow.com/questions/59323688/difference-on-context-manager-with-and-without-as-clause
class RulePackageContext:
    """
    RulePackageContext is used to keep the current RulePackage context.

    >>> with package1:
    >>>    switch1 = SwitchNode(...)
    """

    contexts = []

    @classmethod
    def get_current_context(cls) -> RulePackage:
        return cls.contexts[-1] if cls.contexts else None

class RulePackage:
    """
    A collection of DAGs. It also provides a container for nodes. 
    A node can be created in a rule package.
    Or a node can be created outside of any rule package and added to a rule package later.
    All nodes added into the same rule package must checked for a unique node id. 
    RulePackage.validate() needs to be called before execution.
    Any changes made to the RulePackage after validate() needs re-validate() again.

    Example
    -------
    >>> package1 = RulePackage("package1")
    >>> with package1:
    >>>     branch1 = SwitchNode("branch1", r_opbkk01)
    >>>     package1.attach(branch1)
    >>>     flag1 = FlagNode("flag1", 'VT', "Flag True")
    >>>     flag2 = FlagNode("flag2", 'VF', 'Flag False')     
    >>>     branch1.append_child('True', flag1)
    >>>     branch1.append_default_child(flag2)
    >>> package1.validate()
    >>> package1.execute(input)
    >>> audit_result = package1.get_audit_result()
    >>> g = package1.to_graphviz()
    >>> d = package1.to_graph()
    >>> package2 = RulePackage.from_graph(d)

    An audit result is a dict of flags like:
    ```py
    {
      "flags": [
        {
          "flag": "V001",
          "message": "count_nvisits_by_date 2 >= 2",
          "trace": [
            {
              "node_id": "branch1",
              "rule_id": "opbkk01",
              "result": True,
              "case": True,
              "child_idx": 0,              
              "operator": "eq",
              "ids": [
                0,
                1
              ]
            },
            {
              "node_id": "flag1",
              "flag": "V001"
            }            
          ]
        }
      ],
    }
    ```

    A dispatch result is a dict of rules like:
    ```py
    {
      "rules": [
        {
          "rule": "rule1",
          "trace": [
            {
              "node_id": "branch1",
              "rule_id": "opbkk01",
              "result": True,
              "case": True,
              "child_idx": 0,              
              "operator": "eq",
              "ids": [
                0,
                1
              ]
            },
            {
              "node_id": "rule1",
              "rule": "Rule1"
            }            
          ]
        }
      ],
    }
    ```    

    """
    def __init__(self, package_id: str, name: str = None, description:str = None, subpackages: list[RulePackage] = [], **kwargs):
        if package_id is None or not package_id.isidentifier():
            raise Exception("Package id must be in a valid python identifier format")        
        self.package_id = package_id
        self.name = name
        self.description = description
        self.subpackages: dict[str, RulePackage] = {subpackage.package_id: subpackage for subpackage in subpackages}
        self.known_nodes: dict[str, Node] = OrderedDict()
        self.children = []
        self.is_valid = False
        self.execution_result = {}
        self.metrics = None
        self.is_debugee_running = False  # True if subprocess is running for debugging.

    # Detect cycle in directed graph using white-gray-black algorithm.  
    def is_cycle(self, vertex: Union[Node, RulePackage], gray_set: set[Union[Node, RulePackage]], black_set: set[Union[Node, RulePackage]]):
        # visiting this vertex, make it gray
        gray_set.add(vertex)

        # visit children
        for child in vertex.children:
            if isinstance(vertex, SwitchNode):
                # If SwitchNode, child is a tuple of (operator, case, the next Node).
                oper, case, child = child
            elif isinstance(vertex, SubRuleNode):
                # If SubRuleNode, children is a mapping of outport to the tuple of (next_node, out_mapping).
                child, out_mapping = vertex.children[child]
            elif isinstance(vertex, _SubRuleNode_pass_by_reference):
                child = vertex.children[child]

            # check if this vertex is present in gray set, means cycle is found
            if child in gray_set:
                raise RulePackageException("Cycle detected for node {}".format(child)) 

            # check if this vertex is present in black set, means this vertex is already done
            if child in black_set:
                continue

            # do traversal from this vertex
            self.is_cycle(child, gray_set, black_set)

        # if here means cycle is not found from this vertex, make it black from gray
        gray_set.remove(vertex)
        black_set.add(vertex)
        return     

    '''  
    # Obsolete
    def validate_node(self, node: Node, parent_paths: dict, current_parent_path: list):
        # Obsolete.
        # First check a node has at most one parent.
        node_id_key = "node-id-{}".format(node.node_id)
        paths = parent_paths.get(node_id_key)
        if paths is not None:
            raise RulePackageException("Node {} can have at most one parent".format(str(node)))
        else:
            parent_paths[node.node_id] = [current_parent_path]

        if isinstance(node, (AuditNode, BranchNode)):
            rule_id_key = "rule-id-{}".format(node.rule_id)
            paths = parent_paths.get(rule_id_key)
            if paths is None:
                paths = []
                parent_paths[rule_id_key] = paths
            for path in paths:
                # Find the last common parent node
                last_common_node = None
                for node0, node1 in zip(current_parent_path, path):
                    if node0 == node1:
                        last_common_node = node0
                    else:
                        break
                # Check if it is None or branch node.
                if last_common_node is None or not isinstance(last_common_node, BranchNode):
                    raise RulePackageException("Possible conflict audit result for rule id {} between parent path {} and {}".format(node.rule_id, current_parent_path, path))

            paths.append(current_parent_path)
            #print('parent path:', current_parent_path, node)

        for child in node.children:
            if child is not None:
                self.validate_node(child, parent_paths, current_parent_path + [node])
    '''

    # Obsolete.
    #            
    # Check 
    #   1) For all nodes, there exists at most one parent only.                
    #   2) For AuditNode and BranchNode, if the last common parent node between two nodes 
    #      having the same rule_id must be a branch node. (Since two nodes are allowed to have the
    #      same rule). There should be a single result from rule_id.
    #def validate(self) -> bool:
    #    # Find all parent paths of each rule
    #    parent_paths = {}
    #    for child in self.children:
    #        current_parent_path = []
    #        self.validate_node(child, parent_paths, current_parent_path)
    #
    #    self.is_valid = True
    #    return True
                
    def validate(self) -> bool:
        # Test for orphan children
        for node_id, node in self.known_nodes.items():
            if not node.parents and node not in self.children:
                raise RulePackageException("Node {} has no parent".format(node))

        # Test for cycle
        gray_set: set[Union[Node, RulePackage]] = set()
        black_set: set[Union[Node, RulePackage]] = set()
        for child in self.children:  
            self.is_cycle(child, gray_set, black_set)        
        self.is_valid = True
        return True   

    def get_node(self, node_id: str) -> Node:
        return self.known_nodes.get(node_id)

    def add_node(self, node: Node):
        """
        Add node to known nodes and set node's RulePackage owner
        """
        if node is None:
            raise RulePackageException("Node must not be None")
        if node.node_id == self.package_id:
            raise RulePackageException("Node {} has duplicated id with package".format(node.node_id))
        # Disable checking for double add the same node to the same package.
        #if node.node_id in self.known_nodes:
        #    raise RulePackageException("Node {} has already been added".format(node.node_id))
        if node.rule_package is not None and node.rule_package != self:
            raise RulePackageException("Mismatched RulePackage {} than {}".format(self, node.rule_package))
        node.rule_package = self
        self.known_nodes[node.node_id] = node

    def attach(self, node: Node): 
        if node == self:
            raise RulePackageException("Loop to itself is not allowed")        
        if node is None:
            return
        if node.rule_package != self:
            raise RulePackageException("Cannot attach node due to mismatched RulePackage {} than {}".format(self, node.rule_package))       
        self.children.append(node)
    
    def execute(self, input, verbose=False):
        if not self.is_valid:
            raise RulePackageException("Please validate RulePackage first")
        
        self.execution_result = {
            "flags": [],  # For output from FlagNode
            "rules": [],  # For output from RuleNode
            "outputs": [], # For output from SubRuleNode
            "tracing": []
        }
        try:
            txcntx.set(input)
            lookupcntx.set(LOOKUP)
            for child in self.children:
                child.execute(input, self.execution_result, self.metrics, verbose=verbose, debug=False)
                if self.metrics is not None:
                    self.metrics.add_traffic((self.package_id, child.node_id), 1)
        except:
            raise  # Reraise current exception
        finally:
            txcntx.set(None)
            lookupcntx.set(None)

    # Experimental debug execution
    def _subprocess_execute(self, input: dict, verbose: bool = False, function_modules: list[str] = [], lookup_dir: str = None):
        
        if lookup_dir is not None:
            LOOKUP.set_reference_dir(lookup_dir)

        for module in function_modules:
            register_functions_from_module(module)
        #print(FUNCTIONCALL_SYMBOLS)

        self.execution_result = {
            "flags": [],  # For output from FlagNode
            "rules": [],  # For output from RuleNode
            "outputs": [], # For output from SubRuleNode
            "tracing": []
        }        
        try:
            txcntx.set(input)
            lookupcntx.set(LOOKUP)
            for child in self.children:
                child.execute(input, self.execution_result, self.metrics, verbose=verbose, debug=True)
                if self.metrics is not None:
                    self.metrics.add_traffic((self.package_id, child.node_id), 1)
        except Exception as ex:
            self.shared_exception_queue.put(ex)  # Put exception into shared queue and die silently
        finally:
            self.shared_execution_result.update(self.execution_result)
            txcntx.set(None)
            lookupcntx.set(None)

    # Experimental debug execution
    # Parameter
    #   function_modules: List of module to load additional functions. They are updated to the default functions.
    #   lookup_dir: Path storing lookup tables. The default lookup_dir is replaced. 
    def start_debugging(self, input:dict , verbose: bool = False, function_modules: list[str] = [], lookup_dir: str =None):
        if self.is_debugee_running:
            print("Already in debugging mode", file=sys.stderr)
            return
        
        self.is_debugee_running = True
        if multiprocessing.get_start_method() == 'spawn':
            # https://stackoverflow.com/questions/29199004/multiprocessing-process-with-spawn-method-which-objects-are-inherited
            warnings.warn("Starting subprocess by the method 'spawn' does not copy all memory context.\n"
                          "So, make sure necessary global variables are set in the top-level script environment\n"
                          "(starting script) that serves as the entry point for a program's execution."
                          )
        
        if threading.active_count() > 1:
            warnings.warn("Multithreading detected which may cause debugging mode to fail")

        if not self.is_valid:
            raise RulePackageException("Please validate RulePackage first")
        
        manager = Manager()
        self.shared_execution_result = manager.dict()
        self.shared_exception_queue = Queue()
        self.shared_command_queue = Queue()
        # TODO: To support 'spawn' method better, module variables like compiler.FUNCTIONCALL_SYMBOLS  
        #         and LOOKUP context should be passed as arguments to target function.
        self.subprocess = Process(target=self._subprocess_execute, args=(input, verbose, function_modules, lookup_dir))
        self.subprocess.start()

    def stop_debugging(self) -> None:
        if not self.is_debugee_running:
            print("Not in debugging mode", file=sys.stderr)
            return
                
        if self.subprocess.is_alive():
            self.subprocess.terminate()

        self.subprocess.join()
        self.is_debugee_running = False

    # Usage:
    #    package1.start_debugging(input, verbose=True)
    #    while package1.step():
    #        debug_result = package1.get_debug_result()        
    def step(self) -> bool:
        if not self.is_debugee_running:
            print("Not in debugging mode", file=sys.stderr)
            return False
                
        if not self.shared_exception_queue.empty():
            ex = self.shared_exception_queue.get()
            raise ex  # Raise child exception

        if not self.subprocess.is_alive():
            self.subprocess.join()
            self.is_debugee_running = False
            return False
        
        self.shared_command_queue.put('step')
        return True

    def get_debug_result(self) -> dict:
        return dict(self.shared_execution_result) # Convert from manager.dict to normal dict       

    def get_audit_result(self)-> dict:
        return {"flags": self.execution_result["flags"], "tracing": self.execution_result["tracing"]}
    
    def get_exception_tracing(self)-> dict:
        return self.execution_result["tracing"]
    
    def get_dispatch_result(self)-> dict:
        return {"rules": self.execution_result["rules"], "tracing": self.execution_result["tracing"]}

    def get_subrule_result(self)-> dict:
        return {"outputs": self.execution_result["outputs"], "tracing": self.execution_result["tracing"]}    

    def initialize_metrics(self) -> None:
        self.metrics = Metrics()

    def get_metrics(self) -> Metrics:
        return self.metrics
    
    def reset_metrics(self) -> None:
        self.metrics = Metrics()
    
    def create_node(self, cls: Type[Node], *args, **kwargs):
        node = cls(*args, **kwargs)
        if node.rule_package is not None and node.rule_package != self:
            raise RulePackageException("Conflict rule_package in argument")
        if node.rule_package is None:
            node.rule_package = self
            self.add_node(node)
        return node    
    
    def auditNode(self, *args, **kwargs):
        return self.create_node(AuditNode, *args, **kwargs)

    def bigTableNode(self, *args, **kwargs):
        return self.create_node(BigTableNode, *args, **kwargs)   
    
    def forkNode(self, *args, **kwargs):
        return self.create_node(ForkNode, *args, **kwargs)    

    def transformNode(self, *args, **kwargs):
        return self.create_node(TransformNode, *args, **kwargs) 

    def selectNode(self, *args, **kwargs):
        return self.create_node(SelectNode, *args, **kwargs) 

    def branchNode(self, *args, **kwargs):
        return self.create_node(BranchNode, *args, **kwargs) 

    def switchNode(self, *args, **kwargs):
        return self.create_node(SwitchNode, *args, **kwargs)     

    def RuleNode(self, *args, **kwargs):
        return self.create_node(RuleNode, *args, **kwargs)           

    def flagNode(self, *args, **kwargs):
        return self.create_node(FlagNode, *args, **kwargs)        
    
    def inPortNode(self, *args, **kwargs):
        return self.create_node(InPortNode, *args, **kwargs)

    def outPortNode(self, *args, **kwargs):
        return self.create_node(OutPortNode, *args, **kwargs)          
    
    def SubRuleNode(self, *args, **kwargs):
        return self.create_node(SubRuleNode, *args, **kwargs)          

    def __enter__(self):
        RulePackageContext.contexts.append(self)
        return self
     
    def __exit__(self, exc_type, exc_value, exc_traceback):
        RulePackageContext.contexts.pop()

    def __str__(self) -> str:
        return "({}, {}, {})".format(self.package_id, type(self).__name__, id(self))
    
    def __repr__(self) -> str:
        return "({}, {})".format(self.package_id, type(self).__name__)  

    def to_dict(self) -> dict:
        """
        Obsolete as it does not preserve DAG structure. Same node will be cloned into multiple nodes
        """
        warnings.warn("RulePackage.to_dict() does not preserve DAG structure, resulting in tree.")
        d = {'package_id': self.package_id}
        if self.description is not None:
            d['description'] = self.description
        if self.name is not None:
            d['name'] = self.name
        if self.children:
            d['children'] = [child.to_dict() for child in self.children]
        return d  

    def to_graph(self) -> dict:
        d = {'package_id': self.package_id}
        if self.description is not None:
            d['description'] = self.description
        if self.name is not None:
            d['name'] = self.name            
        if self.known_nodes:
            d['nodes'] = [node.to_graph() for node_id, node in self.known_nodes.items()]
        edges = []
        for node_id, node in self.known_nodes.items():
            src_id = node_id
            if isinstance(node, SwitchNode):
                for oper, case, child in node.children:
                    if child is not None:
                        dst_id = child.node_id
                        edges.append({'src_id': src_id, 'dst_id': dst_id, 'case': case, 'op': oper}) 
                if node.default_child is not None:
                    dst_id = node.default_child.node_id
                    edges.append({'src_id': src_id, 'dst_id': dst_id, 'default': None})
            elif isinstance(node, SubRuleNode):
                for outport, (child, out_mapping) in node.children.items():
                    if child is not None:
                        dst_id = child.node_id
                        edges.append({'src_id': src_id, 'dst_id': dst_id, 'outport': outport, 'out_mapping': out_mapping})                 
            elif isinstance(node, BranchNode):
                if node.children[0]:
                    dst_id = node.children[0].node_id
                    edges.append({'src_id': src_id, 'dst_id': dst_id, 'case': True})
                if node.children[1]:
                    dst_id = node.children[1].node_id
                    edges.append({'src_id': src_id, 'dst_id': dst_id, 'case': False})
            else:
                for child in node.children:
                    if child is not None:
                        dst_id = child.node_id
                        edges.append({'src_id': src_id, 'dst_id': dst_id})     
        if edges:
            d['edges'] = edges
        if self.children:
            d['attached_nodes'] = [child.node_id for child in self.children]
        return d  
    
    def  to_graphviz(self, flag: dict = None, highlight_color: str = 'blue') -> graphviz.graphs.Digraph:
        """
        Generate graphviz. If flag is given, highlight the trace (path) of the flag.  

        Parameters
        ----------
        flag : dict, optional
            A flag in an audit result from execute(), by default None
        highlight_color: str, default to 'blue'
            Color name defined by graphviz. https://graphviz.org/doc/info/colors.html 

        Returns
        -------
        graphviz.graphs.Digraph
            A graph in graphviz dot language format
        """        
        g = graphviz.Digraph(self.package_id)
        g.attr(rankdir='LR')
        node_shapes = {  # https://graphviz.org/doc/info/shapes.html
            BigTableNode: 'cylinder',
            ForkNode: 'point', 
            TransformNode: 'rect', 
            DecisionTableNode: 'rect',
            SelectNode: 'invtrapezium',
            SwitchNode: 'switch',   # switch is a special type, not a graphiz node type.
            RuleNode: 'house', 
            FlagNode: 'parallelogram', 
            AuditNode: 'circle',
            BranchNode: 'diamond',
            InPortNode: 'Mcircle',
            OutPortNode: 'Mcircle', 
            SubRuleNode: 'tab'     # TODO: draw it like a SwitchNode
        }
        nodes = {node_type: [] for node_type, node_shape in node_shapes.items()}
        #print(nodes)

        for node_id, node in self.known_nodes.items():
            node_type = type(node)
            nodes[node_type].append(node)

        g.attr('node', shape = 'folder')
        g.node(self.package_id, label=self.name if self.name else self.package_id)
        for node_type, node_list in nodes.items():
            shape = node_shapes[node_type]
            if shape == 'switch':
                g.attr('node', shape = 'none') # HTML like shape. https://graphviz.org/doc/info/shapes.html#html
                for node in node_list:
                    rows = []
                    node_name = node.name if node.name else node.node_id
                    selector = node.raw if isinstance(node.raw, str) else node_name
                    selector = "{}...".format(selector[:25]) if len(selector) > 25 else selector  # Truncate too long selector
                    selector = html.escape(selector)
                    rows.append('<')
                    rows.append('<table border="0" cellborder="1" cellspacing="0" cellpadding="2">')
                    rows.append('<tr><td port="selector" align="center">{}</td></tr>'.format(selector))
                    idx = 0
                    for oper, case, child in node.children:
                        case = html.escape("{}...".format(case[:25]) if len(case) > 25 else case)  # Escape and truncate too long case)  
                        if oper in ('=', 'eq'):
                            rows.append('<tr><td port="f{}" align="center">{}</td></tr>'.format(idx, case))
                        else:
                            rows.append('<tr><td port="f{}" align="center">{} {}</td></tr>'.format(idx, html.escape(oper), case))                            
                        idx = idx + 1
                    if node.default_child is not None:
                        rows.append('<tr><td port="default" align="center">default</td></tr>')
                    rows.append('</table>')
                    rows.append('>')
                    label = ''.join(rows)  # https://graphviz.org/doc/info/shapes.html#html-like-label-examples
                    g.node(node.node_id, label=label)
                
                '''
                # Using record shape is replaced by HTML-like shape.
                g.attr('node', shape = 'record') # https://graphviz.org/doc/info/shapes.html#record
                for node in node_list:
                    rows = []
                    node_name = html.escape(node.name) if node.name else node.node_id
                    rows.append('<selector> {}'.format(node_name))
                    idx = 0
                    for oper, case, child in node.children:  
                        if oper in ('=', 'eq'):
                            rows.append('<f{}> {}'.format(idx, case))    
                        else:
                            rows.append('<f{}> {} {}'.format(idx, oper, case))
                        idx = idx + 1
                    if node.default_child is not None:
                        rows.append('<default> default')
                    label = '|'.join(rows)  # https://graphviz.org/Gallery/directed/datastruct.html
                    g.node(node.node_id, label=label)
                '''
            else:
                g.attr('node', shape=shape)
                for node in node_list:
                    label = html.escape(node.name) if node.name else (node.node_id if not isinstance(node, FlagNode) else node.flag)
                    if node_type == TransformNode:
                        label = "{}\n{}".format(label, node.field_name)
                    elif node_type == DecisionTableNode:
                        label = "{}\n{}".format(label, "\n".join(node.table['outputs']))
                    g.node(node.node_id, label=label)

        trace_edges = set()
        if flag is not None:
            trace = flag.get('trace')
            if isinstance(trace, list) and len(trace) > 2:
                for src, dst in zip(trace, trace[1:]):
                    if 'child_idx' in src: # If src is a SwitchNode, (src, dst, child_idx)
                        trace_edges.add((src['node_id'], dst['node_id'], src['child_idx']))  
                    elif 'case' in src: # If src is a BranchNode, (src, dst, True/False)
                        trace_edges.add((src['node_id'], dst['node_id'], src['result'])) # src['result'] == src['case']
                    else:
                        trace_edges.add((src['node_id'], dst['node_id']))

        for child in self.children:
            dst = '{}:selector'.format(child.node_id) if isinstance(child, SwitchNode) else child.node_id                
            g.edge(self.package_id, dst)
        for node_id, node in self.known_nodes.items():
            if isinstance(node, SwitchNode):
                idx = 0
                for child_idx, (oper, case, child) in enumerate(node.children): 
                    dst = '{}:selector'.format(child.node_id) if isinstance(child, SwitchNode) else child.node_id
                    color = highlight_color if (node_id, child.node_id, child_idx) in trace_edges else 'black'
                    g.edge('{}:f{}'.format(node_id, idx), dst, color=color)
                    idx = idx + 1
                if node.default_child is not None:
                    child = node.default_child
                    dst = '{}:selector'.format(child.node_id) if isinstance(child, SwitchNode) else child.node_id
                    color = highlight_color if (node_id, child.node_id) in trace_edges else 'black'
                    g.edge('{}:default'.format(node_id), dst, color=color)
            elif isinstance(node, BranchNode):
                if node.children[0]:
                    child = node.children[0]
                    dst = '{}:selector'.format(child.node_id) if isinstance(child, SwitchNode) else child.node_id    
                    color = highlight_color if (node_id, child.node_id, True) in trace_edges else 'black'
                    g.edge(node_id, dst, label="T", color=color)
                if node.children[1]:
                    child = node.children[1]
                    dst = '{}:selector'.format(child.node_id) if isinstance(child, SwitchNode) else child.node_id
                    color = highlight_color if (node_id, child.node_id, False) in trace_edges else 'black'             
                    g.edge(node_id, dst, lable='F', color=color)
            else:
                for child in node.children:
                    dst = '{}:selector'.format(child.node_id) if isinstance(child, SwitchNode) else child.node_id
                    color = highlight_color if (node_id, child.node_id) in trace_edges else 'black'              
                    g.edge(node_id, dst, color=color)
        return g    
   
    def analyze(self, tx: dict = None) -> dict:
        """
        Analyze a RulePackage. 
        
        1) External facts. They are fields required from input in order to execute RulePackage successfully.
        They are the union of external facts of all nodes in the package.
        
        2) Computed facts. All facts in the package which are computed from external facts or other computed facts.
        It is possible to have many nodes compute the same fact. 
        For SubRuleNode, all computed facts inside are included; no matter they are sent to outports.
        
        3) Analysis of each node like its external facts. 
         
        4) Any errors like required fields not found in a specific path.

        5) Any warnings.

        Both external and computed facts are possibly overlapped. For example, b = a + b. 
        External facts are a and b, while computed fact is b.

        Note that it is expensive to store the analysis of the computed facts for each individual node since 
        they depend on a specific path to the node. So they are skipped for now.

        Parameters
        ----------
        tx: dict, default = None
            If not None, analyze if a node has enough data (from tx or computed within a path)
        convert_set_to_list : bool, default = False
            If True, output value having data type set will be converted to list, for better JSON serialization.

        Returns
        -------
        dict 
            A dict of analysis result.

        Raises
        ------
        Exception
            Any errors cause exception.        
        """
        analysis = {
            'external_facts': set(), # For global external facts, they are field names.  
            'computed_facts': set(),  # For global computed facts, each element is a pair of (NODE_ID, FIELD_NAME) of a TransformNode or SubRuleNode. For SubRuleNode, all computed facts inside are included; no matter they are sent to outports.
            'nodes': {}, # A dict of NODE_ID and its analysis (dict).
            'errors': [],
            'warnings': [],
            'output_paths': []  # Only for subrule, all possible paths to outputs and output facts are listed here.  
        }
        stack = [
            {
                'tx': tx,  # The transaction provided. It must be passed along the stack without change.
                'current_path': [],
                'current_computed_facts': set() # Keep track of computed facts in the current path.
            }
        ]
        for child in self.children:
            _analyze_(child, stack, analysis) 

        # Convert set value to list value
        # Use lambda data_field, data, field where data is the parent, field is the current key and data_field is equal to data[field]
        # https://stackoverflow.com/questions/63287113/update-json-data-with-context-in-python-using-jsonpath-ng
        # https://stackoverflow.com/questions/8230315/how-to-json-serialize-sets            
        #if convert_set_to_list:
        #    query = jsonpath_ng.parse("$..*") # Find all possible children
        #    query.update(analysis, lambda data_field, data, field: data.update({field: list(data[field]) if isinstance(data[field], set) else data[field]}))

        return analysis
    
    @staticmethod
    def from_dict(d: dict) -> RulePackage:
        """
        Obsolete as it does not preserve DAG structure. Same node will be cloned into multiple nodes.
        """       
        warnings.warn("RulePackage.from_dict() does not preserve DAG structure, resulting in tree.")
        description = d.get('description')
        rule_package = RulePackage(d['package_id'], description)
        cls = globals().get('Node')
        if cls is None:
            raise RulePackageException("Unknown class Node")        
        for child in d.get('children', []):
            obj = cls.from_dict(child)
            rule_package.add_node(obj)
            rule_package.attach(obj)
        rule_package.validate()
        return rule_package

    @staticmethod
    def from_graph(d: dict, subrules: list[dict] = []) -> RulePackage:
        name = d.get('name')
        description = d.get('description')
        subpackages = []
        for subrule in subrules:
            try:
                subpackage = RulePackage.from_graph(subrule)
                subpackage.validate()
            except Exception as ex:
                raise RulePackageException('Fail to create subrule: {}'.format(ex.msg))
            subpackages.append(subpackage)
        rule_package = RulePackage(d['package_id'], name, description, subpackages)
        cls = globals().get('Node')
        graph_nodes = {}
        if cls is None:
            raise RulePackageException("Unknown class Node")           
        for node in d.get('nodes', []):
            node_with_rule_package = {**node, 'rule_package': rule_package} # rule_package is set here too as SubRuleNode.from_graph() needs rule_package.
            obj = cls.from_dict(node_with_rule_package)   
            graph_nodes[node['node_id']] = obj
            rule_package.add_node(obj)   # rule_package is set twice.
        for edge in d.get('edges', []):
            src = graph_nodes.get(edge['src_id'])
            if src is None:
                raise RulePackageException("Node id {} not found in graph".format(edge['src_id']))
            dst = graph_nodes.get(edge['dst_id'])
            if dst is None:
                raise RulePackageException("Node id {} not found in graph".format(edge['dst_id']))
            if isinstance(src, SwitchNode):
                if 'case' in edge:
                    oper = 'eq' if 'op' not in edge else edge['op']
                    src.append_child(edge['case'], dst, oper)
                elif 'default' in edge:
                    src.set_default_child(dst)                
                else:
                    raise RulePackageException("Edge format {} not correct for SwitchNode".format(edge))
            elif isinstance(src, SubRuleNode):
                if 'outport' in edge and 'out_mapping' in edge:
                      src.set_child(edge['outport'], dst, edge['out_mapping'])           
                else:
                    raise RulePackageException("Edge format {} not correct for SubRuleNode".format(edge))                
            elif isinstance(src, BranchNode):
                if 'case' not in edge:
                    raise RulePackageException("Edge format {} not correct for BranchNode".format(edge))
                if edge['case']:
                    src.set_then(dst)
                else:
                    src.set_otherwise(dst)
            else:
                src.add_child(dst)

        for node_id in d.get('attached_nodes', []):
            node = graph_nodes.get(node_id)
            if node is None:
                raise RulePackageException("Node id {} not found in graph".format(node_id))
            rule_package.attach(node)

        rule_package.validate()              
        return rule_package

    
class Transformer:
    """
    Transform input to something. The expression can be an expression string or a dict.
    For some examples, 

    An expression string: 'diagnosis.where("dxtype", "is_in", [1, 2, 3])'

    A dict of conditions: 
    {
        "conditions": {
            "all": [
                ...
            ]
        }
    }
    
    A dict of Fact:
    {
        "fact": {
            "fact": "diagnosis"
            "chain": [
                ...
            ]
        }
    }

    A dict of Operand:
    {
        "operand": 100.0
    }
    """
    def __init__(self, expression: Union[str, dict], description: str = None, **kwargs):
        self.raw = expression
        self.description = description
        self.expression: Union[Condition, Fact, Operand] = None
        if isinstance(expression, dict):
            if 'conditions' in expression: # An expression can be conditions, e.g. a > b.
                self.expression = Condition(None, '$', expression['conditions'])
            elif 'fact' in expression:
                self.expression = Fact(None, '$', expression['fact'])
            elif 'operand' in expression:
                self.expression = Operand(None, '$', expression['operand'])
            else:
                raise Exception("Invalid expression {}".format(expression))
        elif isinstance(expression, str):
            self.expression = convert_expression(expression)
        else:
            raise Exception("Invalid expression {}".format(expression))

    def transform(self, input, execution_result) -> object:
        audit_tree = None
        result = self.expression.execute(input, audit_tree)
        return result
    
    def to_dict(self) -> dict:
        d = {'expression': self.raw}
        if self.description is not None:
            d['description'] = self.description
        return d    
    
    @staticmethod
    def from_dict(d: dict) -> Transformer:
        return Transformer(**d)
    

class NodeDeserializationException(Exception):
    def __init__(self, path: list, msg: str):
        self.path = path
        self.msg = msg
        super().__init__()

    def __str__(self) -> str:
        return "{}: {}".format('->'.join(self.path), self.msg)
    

class RulePackageException(Exception):
    pass


class NodeExecuteException(Exception):
    pass


# TODO: Shall we implement Metrics as a subclass of dict?
class Metrics():
    def __init__(self):
        self.traffics: dict = {}
    
    def add_traffic(self, key: object, value: float = 0) -> None:
        self.traffics[key] = self.traffics.get(key, 0) + value

    def get_traffic(self, key: object):
        return self.traffics.get(key, 0)
    
    # Reform to serializable dict (JSON key cannot be a tuple)
    def to_dict(self) -> dict:
        traffic = [{'key': k, 'value': v} for k, v in self.traffics.items()]
        return {'traffic': traffic}

    def clear(self):
        self.traffics.clear()

ModelError = Enum("ModelError", [
    "UnknownVariable", # Required variable but not found.
])

ModelWarning = Enum("ModelWarning", [
    "UnusedVariable", # Variable not used.
])

def _analyze_(node: Node, stack: list, analysis: dict = {}, recursive: bool = True) -> dict:
    # Analysis the external and computed facts when visit each node.
    # The external facts are facts required from fields. The global external facts are unioned with the missing external facts on each node visit (due to multiple paths)    
    # Check that given available external and computed facts along a path, does each node have enough facts to execute.    
    # Analysis result is stored in analysis dict.
    # The stack is a dict to track information along a path to this node, including computed facts.
    # The recursive argument is to recursively traverse into all children of the node (the next node in the same graph; not the inner graph of subrule).
    node_facts = set()  # All facts required in this node. Some come from input (known as external facts). Others come from computed facts in the current path.
    new_facts = set()  # Facts created in this node
    def collect_fact(node):
        if isinstance(node, (Fact, Field)):
            if isinstance(node.fact, str):
                node_facts.add(node.fact)

    if isinstance(node, (ForkNode, BigTableNode, RuleNode, InPortNode)):
        pass
    elif isinstance(node, OutPortNode):          
        analysis['output_paths'].append({
            'outport': node.node_id,
            'path': stack[-1]['current_path'] + [node.node_id],
            'path_computed_facts': stack[-1]['current_computed_facts'].copy()
        })
    elif isinstance(node, TransformNode):
        node.transformer.expression.traverse(collect_fact)
        new_facts.add(node.field_name)
    elif isinstance(node, SelectNode):
        node_facts.update(node.field_names)
    elif isinstance(node, DecisionTableNode):
        for rule in node.rules:
            rule.condition.traverse(collect_fact)
            for action in rule.actions:
                action.transformer.expression.traverse(collect_fact)

        # For simplicity, we use the intersection of facts computed in actions of all rules.
        # TODO: If we need to analyze the computed facts per rules, we must check them in the recursive section below.
        rule_new_facts = []
        for rule in node.rules:
            rule_new_facts.append(set(action.field_name for action in rule.actions))
        new_facts.update(set.intersection(*rule_new_facts)) # intersection of multiple sets 
    elif isinstance(node, SwitchNode):
        # Collect facts used in selector
        if node.rule is not None:
            node.rule.traverse(collect_fact)
        else:
            node.expression.traverse(collect_fact)
        # Collect facts used in case expressions
        for operator, case_expr in node.case_exprs:
            case_expr.traverse(collect_fact)           
    elif isinstance(node, FlagNode):
        if isinstance(node.template, Template):
            for name in node.template.get_identifiers():
                node_facts.add(name)
        elif isinstance(node.template, dict):
            query = jsonpath_ng.parse("$..*") # Find all possible children
            for match in query.find(node.template): # For each matching element
                if match.path == jsonpath_ng.jsonpath.Fields('$ref'):
                    node_facts.add(match.value) 
                elif isinstance(match.value, Template):
                    for name in match.value.get_identifiers():
                        node_facts.add(name)                     
        else: 
            raise RulePackageException('Unknown template {}'.format(node.template))
    elif isinstance(node, SubRuleNode): 
        node_facts.update(node.in_mapping.keys())  # Add facts from in_mapping.
        subrule_analysis = {
            'external_facts': set(), # For global external facts, they are field names.  
            'computed_facts': set(),  # For global computed facts, each element is a pair of (NODE_ID, FIELD_NAME) of a TransformNode or SubRuleNode. For SubRuleNode, all computed facts inside are included; no matter they are sent to outports.
            'nodes': {}, # A dict of NODE_ID and its analysis (dict).
            'errors': [],
            'warnings': [],
            'output_paths': []  # Only for subrule, all possible paths to outputs and output facts are listed here.    
        }

        subtx = {}  # Set to {} as a trick to let the outer graph get all external and computed facts of a subrule; otherwise set to dummy subtx (following line) to check for path errors in subrule graph.
        # TODO: Currently we analyze subrule as an opaque node and thus skip to analyze the inner graph which actually may have path errors too.
        #subtx = {k_subrule: None for k_in, k_subrule in node.in_mapping.items()}  # Create dummy subtx with None value to check the inner graph of subrule.

        subrule_stack = [
            {
                'tx': subtx,  
                'current_path': [],
                'current_computed_facts': set() # Keep track of computed facts in the current path.
            }
        ]
        for child in node.subrule.children:  # Traverse into subrule inner graph
            _analyze_(child, subrule_stack, subrule_analysis, recursive)   

        # subrule_analysis['external_facts'] is a set of facts to run this SubRuleNode. Check if all of them must be mapped from node_facts.
        mapped_fields = []
        for k, v in node.in_mapping.items():
            if isinstance(v, str):
                mapped_fields.append(v)
            elif isinstance(v, dict): 
                if 'name' not in v:
                    mapped_fields.append(v)
                else:
                    mapped_fields.append(v['name'])
            else:
                raise RulePackageException('Wrong mapping for {}'.format(k))
        unmapped_facts = subrule_analysis['external_facts'] - set(mapped_fields)  # Find fields used in subrule but not mapped from transaction
        node_facts.update(['{}.{}'.format(node.node_id, f) for f in unmapped_facts])
        # Check unused mapped facts
        unused_mapped_facts = set(mapped_fields) - subrule_analysis['external_facts']
        if len(unused_mapped_facts):
            analysis['warnings'].append({
                'type': 'warning',
                'code': ModelWarning.UnusedVariable.name,
                'path': stack[-1]['current_path'] + [node.node_id],
                'message': 'Node {} pass values to unused variable {}'.format(node.node_id, ', '.join(unused_mapped_facts))
            })

        # Manage mapping for subrule computed facts of all outports (union them all). 
        subrule_computed_facts = set(field for node_id, field in subrule_analysis['computed_facts'])
        for outport, (child, out_mapping) in node.children.items():
            if out_mapping is not None:
                mapped_output_facts = [out_mapping.get(field, field) for field in subrule_computed_facts]  # Rename field if provided
                new_facts.update(mapped_output_facts)     
            else:
                new_facts.update(subrule_computed_facts)
        
    elif isinstance(node, AuditNode):
        node.rule.traverse(collect_fact)
    elif isinstance(node, BranchNode):
        node.rule.traverse(collect_fact)
    else:
        raise RulePackageException("Cannot analyze node type {}".format(node.__class__.__name__))
    
    external_node_facts = node_facts.difference(stack[-1]['current_computed_facts'])  # A = A - B. Get the remaining external facts by removing the current computed facts in-place
    analysis['external_facts'].update(external_node_facts) # The input must have the remaining required facts unioned in-place
    analysis['computed_facts'].update(set([(node.node_id, fact) for fact in new_facts])) # Simply update the computed facts 

    # Update node analysis without considering a path. Since there are possible multiple parents, union them.
    node_analysis = analysis['nodes'].get(node.node_id)
    if node_analysis is None:
        node_analysis = {
            'external_facts': set()
        }
        analysis['nodes'][node.node_id] = node_analysis
    node_analysis['external_facts'].update(external_node_facts)        
    
    # Update node analysis along a path.
    # Given available external and computed facts along a path, does each node have enough facts to execute.
    tx = stack[-1]['tx'] 
    if tx is not None:
        unknown_facts = external_node_facts.difference(tx.keys())
        if len(unknown_facts): 
            analysis['errors'].append({
                'type': 'error',
                'code': ModelError.UnknownVariable.name,
                'path': stack[-1]['current_path'] + [node.node_id],
                'message': 'Require field(s) {}'.format(', '.join(unknown_facts))
            })
    
    if recursive:
        if isinstance(node, SwitchNode):
            new_current_path = stack[-1]['current_path'] + [node.node_id]            
            new_computed_facts = stack[-1]['current_computed_facts'].copy().union(new_facts) 
            stack.append(
                {
                    'tx': tx,  # Do not change tx.
                    'current_path': new_current_path,
                    'current_computed_facts': new_computed_facts
                } 
            )     

            # SwitchNode never has new facts.
            for oper, case, child in node.children:
                _analyze_(child, stack, analysis, recursive=recursive)  
                
            if node.default_child is not None:   
                _analyze_(node.default_child, stack, analysis, recursive=recursive)    

            stack.pop() 

        # TODO: The idea to analyze computed facts per rule in DecisionTableNode. BUT never tested and require reformatting the analyze() output.
        # if isinstance(node, DecisionTableNode):
        #     new_current_path = stack[-1]['current_path'] + [node.node_id]            

        #     # DecisionTableNode has new facts depending on the matching rule.
        #     assert(len(new_facts) == 0)
        #     for rule in node.rules:
        #         new_facts = set()
        #         for action in rule.actions:
        #             new_facts.add(action.field_name)  

        #         new_computed_facts = stack[-1]['current_computed_facts'].copy().union(new_facts) 
        #         stack.append(
        #             {
        #                 'tx': tx,  # Do not change tx.
        #                 'current_path': new_current_path,
        #                 'current_computed_facts': new_computed_facts
        #             } 
        #         )                         
        #         _analyze_(child, stack, analysis, recursive=recursive)  
                
        #         stack.pop() 

        elif isinstance(node, SelectNode):
            new_current_path = stack[-1]['current_path'] + [node.node_id]            
            new_computed_facts = stack[-1]['current_computed_facts'].copy().union(new_facts) 
            stack.append(
                {
                    'tx': {k: v for k, v in tx.items() if k in node.field_names},  # Do not change tx. Select makes tx less fields.
                    'current_path': new_current_path,
                    'current_computed_facts': new_computed_facts
                } 
            )     

            for child in node.children:
                _analyze_(child, stack, analysis, recursive=recursive)

            stack.pop() 

        elif isinstance(node, SubRuleNode):
            for output_path in subrule_analysis['output_paths']:
                outport, path, path_computed_facts = output_path['outport'], output_path['path'], output_path['path_computed_facts'] 
                new_current_path = stack[-1]['current_path'] + [node.node_id]  # TODO: if two outports connect to the same child. The node_id should be appended with outport.
                child, out_mapping = node.children[outport]
                if out_mapping is not None:
                    output_facts = [out_mapping.get(field, field) for field in path_computed_facts]  # Rename field if provided 
                else:  
                    output_facts = path_computed_facts
                new_computed_facts = stack[-1]['current_computed_facts'].copy().union(output_facts) #  new_computed_facts depends on each outport
                stack.append(
                    {
                        'tx': tx,  # Do not change tx.
                        'current_path': new_current_path,
                        'current_computed_facts': new_computed_facts
                    } 
                )             

                _analyze_(child, stack, analysis, recursive=recursive)

                stack.pop()
            
        else:
            new_current_path = stack[-1]['current_path'] + [node.node_id]            
            new_computed_facts = stack[-1]['current_computed_facts'].copy().union(new_facts) 
            stack.append(
                {
                    'tx': tx,  # Do not change tx.
                    'current_path': new_current_path,
                    'current_computed_facts': new_computed_facts
                } 
            )     

            for child in node.children:
                _analyze_(child, stack, analysis, recursive=recursive)
    
            stack.pop()


    return analysis
