import decimal
import jsonpath_ng
import html
import graphviz
import json
import random
import importlib
import inspect
import xml.etree.ElementTree as ET 
import re
import warnings
import uuid

from types import NoneType
from string import Template
from datetime import datetime, date, time
from operator import add
from cached_property import cached_property
from typing import Iterable

from pyrengine.objectlist import OBJECTLIST
from pyrengine.objectlist import ARRAY
from pyrengine.model import *
from pyrengine.null import NULL, NullType, LooselyNullType
from pyrengine.converter import ExprToJson


TYPE_MAPPING = {
    "str": "",
    "integer": 0,
    "float": 0.0,
    "bool": False,
    "datetime": '2024-01-01 00:00:00',
    "OBJECTLIST": OBJECTLIST([]),
    "ARRAY": ARRAY([])
}

# filter fields that contain array list and convert
# into OBJECTLIST object
def convert(input_json):
    fields_names = list(input_json.keys())
    for fn in fields_names:
        if type(input_json[fn]) is list : 
            if len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict :
                input_json[fn] = OBJECTLIST(input_json[fn])
            else: 
                input_json[fn] = ARRAY(input_json[fn])
    return input_json

# This is the previous version of convert
# def convert(input_json):
#     fields_names = list(input_json.keys())
#     for fn in fields_names:
#         if type(input_json[fn]) is list and len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict:
#             input_json[fn] = OBJECTLIST(input_json[fn])
#     return input_json


# Update the rule dict by *non-verbose* audit tree dict. The structure of rule dict and 
#   result dict are required to be compatible; otherwise an exception or unexpected outcome occurs.
# https://stackoverflow.com/questions/71396284/python-how-to-recursively-merge-2-dictionaries
def merge_rule_result(rule: dict, result: dict):
    for key, val in result.items():
        if key == "__result__":
            rule[key] = val
            continue

        if key in rule:
            if isinstance(val, dict):
                if not isinstance(rule[key], dict):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a dict".format(key))
                merge_rule_result(rule[key], val)
            elif isinstance(val, list):
                if not isinstance(rule[key], list):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a list".format(key))
                if len(val) != len(rule[key]):
                    raise Exception("The value of rule's key {} has different length than that of result".format(key))
                for i in range(len(val)):
                    if not isinstance(val[i], dict):
                        raise Exception("Expect element {} of result's key {} to be a dict".format(i, key))
                    if not isinstance(rule[key][i], dict):
                        raise Exception("Expect element {} of rule's key {} to be a dict".format(i, key))                
                    merge_rule_result(rule[key][i], val[i])
            else:
                pass # Skip other primitive values
        else:
            raise Exception('Unknown result key {}'.format(key))


def validate_by_example(obj: object, example: dict, deep = False, numeric_compatible=False) -> bool:
    """
    A helper function to validate data type of an input object. The structure of 
    the input object must be a superset of the example, i.e. having same or more keys with
    the exact same data type (not subclasses).

    Parameters
    ----------
    obj : object
        An input object 
    example : dict
        An object prototype. 
    deep : bool, optional
        Recursively validate sub-structure too, by default False (Not implemented yet).
    numeric_compatible : bool, optional
        Allow int and float and decimal.Decimal values to be compatible, by default False.

    Returns
    -------
    bool
        True if the input object has the same structure as least as the example.

    Raises
    ------
    NotImplementedError
        Not implemented yet. Future maybe.
    Exception
        Any error found.
    """    
    if deep:
        raise NotImplementedError('deep validation not support yet')
    
    if not isinstance(obj, dict):
        raise NotImplementedError('For now, obj argument must be a dict')
    
    for key in example:
        if key not in obj:
            raise Exception('Key {} not found in the obj'.format(key))
        
        if numeric_compatible and isinstance(example[key], (int, float, decimal.Decimal)) and isinstance(obj[key], (int, float, decimal.Decimal)):
            continue
        
        if type(obj[key]) != type(example[key]):
            raise Exception('The value of {} is of type {} but expected {}'.format(key, type(obj[key]).__name__, type(example[key]).__name__))
        
    return True


def json_rules_to_example(rules: Iterable[dict], dtype: dict) -> dict:
    """
    A helper function to generate example json data from a list of rules and type mapping file. 
    The field names come from rule condition. The data types come from mapping file. 

    Parameters
    ----------
    rules : Iterable[dict]
        A sequence of json rules. 
    dtype : dict
        A type mapping for json data. 

    Returns
    -------
    dict
        example json (dict) data.

    Raises
    ------
    NotImplementedError
        Not implemented yet. Future maybe.
    Exception
        Any error found.
    """    

    query = jsonpath_ng.parse("$..[fact]") # Find any facts in the tree
    example = {}
    for rule in rules:
        for match in query.find(rule): # For each matching fact
            fieldname = match.value
            if isinstance(fieldname, str):
                fieldtype = dtype.get(fieldname)
                if fieldtype is None:
                    raise Exception("Field name {} is not found in type mapping file".format(fieldname))
                mapped_fieldtype = TYPE_MAPPING.get(fieldtype)
                if mapped_fieldtype is None:
                    raise Exception("Field type {} is unknown".format(fieldtype))

                example[fieldname] = mapped_fieldtype

    return example


def _validate_by_object_schema(obj: dict, field_schema: dict, collective_field_schema: dict = None, null_allowed = False) -> bool:
    found_keys = set()
    for field in field_schema:
        if field['name'] not in obj:
            raise Exception('Key {} not found in the obj'.format(field['name']))
        
        value = obj[field['name']]
        if (value is None or value is NULL) and null_allowed: 
            pass
        else:
            if type(value) not in (str, int, float, datetime, bool, ARRAY, OBJECTLIST):
                raise Exception('Field {} has unknown type {}'.format(field['name'], value.__class__.__name__))
            
            if (type(value) == int and field['type'] in ('int', 'float')):  # Allow int value in int or float field.
                pass 
            elif field['type'] != value.__class__.__name__:
                raise Exception('Field {} must be type {} but {} found'.format(field['name'], field['type'], value.__class__.__name__))
        
        found_keys.add(field['name'])

        # Check optional schema for sub-structure
        if type(value) == ARRAY and field.get('items') is not None:
            element_type = field['items']['type']
            if not all([e.__class__.__name__ == element_type for e in value]):  # Check type of every element
                raise Exception('All elements in field {} must be type {}'.format(field['name'], element_type))
        
        elif type(value) == OBJECTLIST and collective_field_schema is not None:  # Check type of each object in OBJECTLIST 
            for o in value:
                _validate_by_object_schema(o, collective_field_schema[field['name']], None, null_allowed)  # one level; not nested

    return True
    

def validate_by_profile(obj: dict, profile: dict, validate_collective = False, null_allowed = False) -> bool:
    """
    A helper function to validate data type of an input object using profile. The structure of 
    the input object must exactly match the profile, i.e. having same key and data type (not subclasses).

    Parameters
    ----------
    obj : dict
        An input object 
    profile : dict
        An input profile. 
    validate_collective : bool, optional
        Validate OBJECTLIST one level (not nested) too if collective schema available, by default False.   
    null_allowed : bool, optional
        Allow NULL (and None) value, by default False.             

    Returns
    -------
    bool
        True if the input object has the same structure as least as the example.

    Raises
    ------
    NotImplementedError
        Not implemented yet. Future maybe.
    Exception
        Any error found.
    """    
    
    if not isinstance(obj, dict):
        raise NotImplementedError('For now, obj argument must be a dict')
    
    schema_profile = profile.get('schema_profile')
    if schema_profile is None:
        raise Exception("No schema_profile found in profile")
    
    schema_profile_fields = schema_profile.get('fields', [])
    collective_fields = schema_profile.get('collective_fields') if validate_collective else None # Optional

    _validate_by_object_schema(obj, schema_profile_fields, collective_fields, null_allowed)
        
    return True


def to_lowercase_key(input: dict | list) -> dict | list:
    """
    A helper function to convert all keys of dict to lowercase recursively, including dicts in any 
    objectlists.
    Keys must be string; otherwise an exception raises.

    Parameters
    ----------
    input : dict | list
        An input dict. If input is a list, apply to each element in the list. 

    Returns
    -------
    dict | list
        Output dict or list, corresponding to the input.

    Raises
    ------
    Exception
        Any error found.
    """    

    if isinstance(input, dict):
        output = {k.lower(): to_lowercase_key(v) if isinstance(v, (dict, list)) else
                                OBJECTLIST([to_lowercase_key(o) for o in v.data]) if isinstance(v, OBJECTLIST) else 
                                v
                  for k, v in input.items()}        
    elif isinstance(input, list):
        output = [to_lowercase_key(e) if isinstance(e, (dict, list)) else
                    OBJECTLIST([to_lowercase_key(o) for o in e.data]) if isinstance(e, OBJECTLIST) else
                    e
                  for e in input]
    else:
        raise NotImplementedError("Unsupport data type {}".format(type(input)))

    return output


def _property_diff(old: dict, new: dict) -> dict:
    old_keys = set(old.keys())
    new_keys = set(new.keys())
    added_properties = set(new_keys).difference(old_keys)
    deleted_properties = set(old_keys).difference(new_keys)
    same_properties = set(old_keys).intersection(new_keys)
    diff = {}
    if added_properties:
        diff['add'] = [{'property': key, 'value': new[key]} for key in sorted(added_properties)]
    if deleted_properties:
        diff['delete'] = [{'property': key, 'value': old[key]} for key in sorted(deleted_properties)]
    if same_properties:
        modified = [{'property': key, 'old_value': old[key], 'new_value': new[key]} for key in sorted(same_properties) if old[key] != new[key]] 
        if modified: 
            diff['modify'] = modified
    return diff


# TODO: Support multiple edges from SwitchNode to the same destination.
#       Support operator for SwitchNode
def rpdiff(old: RulePackage | dict, new: RulePackage | dict) -> dict:
    """
    Compare two rule packages.

    Parameters
    ----------
    old : RulePackage | dict
        Old rule package or json graph.
    new : RulePackage | dict
        New rule package or json graph. 

    Returns
    -------
    dict
        Changes (add, delete, modify) between two versions.
    """ 

    # First, convert to json graph for comparison.
    if isinstance(old, dict):
        o = RulePackage.from_graph(old)  # Validate format
        old = o.to_graph()  # Get properties only what we want
    elif isinstance(old, RulePackage):
        old = RulePackage.to_graph()  # Convert to json graph

    if isinstance(new, dict):
        n = RulePackage.from_graph(new)  # Validate format
        new = n.to_graph()  # Get properties only what we want
    elif isinstance(new, RulePackage):
        new = RulePackage.to_graph()  # Convert to json graph    

    old_package_id = old['package_id']
    new_package_id = new['package_id']        

    old_components = dict()
    old_components.update({node['node_id']: node for node in old.get('nodes') or []})
    old_components.update({(edge['src_id'], edge['dst_id']): edge for edge in old.get('edges') or []})
    old_components.update({(old_package_id, node_id): None for node_id in old.get('attached_nodes') or []})

    new_components = dict()
    new_components.update({node['node_id']: node for node in new.get('nodes') or []})
    new_components.update({(edge['src_id'], edge['dst_id']): edge for edge in new.get('edges') or []})
    new_components.update({(old_package_id, node_id): None for node_id in new.get('attached_nodes') or []})

    diff = {}
    """
    # diff dict looks like:
    diff = {
        'add': {
            'nodes': [

            ],
            'edges': [

            ],
            'attached_nodes': [

            ]
        },
        'delete': {
            'nodes': [

            ],
            'edges': [

            ],
            'attached_nodes': [
                
            ]
        },
        'modify': {
            'package': {
                'modify': [
                    {'property': 'package_id', 'old_value': 'a', 'new_value': 'x'},
                ],
            },
            'nodes': [
                {
                    'node_id': 'abcde',
                    'add': [
                        {'property': 'template', 'value': 'Hello World'},
                    ],
                    'delete': [
                        {'property': 'property2', 'value': 'Some value'},
                    ]
                    'modify': [
                        {'property': 'node_type', 'old_value': 'a', 'new_value': 'x'},
                        {'property': 'expression', 'old_value': 'b', 'new_value': 'y'}
                    ]
                },
                {
                    'node_id': '12344', 
                    'modify': [
                        {'property': 'node_type', 'old_value': 'a', 'new_value': 'x'},
                        {'property': 'expression', 'old_value': 'a', 'new_value': 'x'}
                    ]
                }
            ], 
            'edges': [
                {
                    'src_id': 'a',
                    'dst_id': 'b',
                    'add': [
                        {'property': 'property3', 'value': 'Some value'},
                    ],
                    'modify': [
                        {'property': 'case', 'old_value': 'a', 'new_value': 'x'}
                    ]
                }

            ]

        }
    }
    """

    # Check nodes
    old_nodes = {node['node_id'] for node in old.get('nodes') or []}
    new_nodes = {node['node_id'] for node in new.get('nodes') or []}
    added_nodes = new_nodes.difference(old_nodes)
    deleted_nodes = old_nodes.difference(new_nodes)
    if added_nodes:
        if 'add' not in diff:
            diff['add'] = {}
        diff['add']['nodes'] = [new_components[node] for node in sorted(added_nodes)]
    if deleted_nodes:
        if 'delete' not in diff:
            diff['delete'] = {}
        diff['delete']['nodes'] = [old_components[node] for node in sorted(deleted_nodes)]

    # Check edges
    old_edges = {(edge['src_id'], edge['dst_id']) for edge in old.get('edges') or []}
    new_edges = {(edge['src_id'], edge['dst_id']) for edge in new.get('edges') or []}
    added_edges = new_edges.difference(old_edges)
    deleted_edges = old_edges.difference(new_edges)
    if added_edges:
        if 'add' not in diff:
            diff['add'] = {}        
        diff['add']['edges'] = [new_components[edge] for edge in sorted(added_edges)]
    if deleted_edges:
        if 'delete' not in diff:
            diff['delete'] = {}        
        diff['delete']['edges'] = [old_components[edge] for edge in sorted(deleted_edges)]

    # Check attached nodes
    old_attached_nodes = {node_id for node_id in old.get('attached_nodes') or []}     
    new_attached_nodes = {node_id for node_id in new.get('attached_nodes') or []}
    added_attached_nodes = new_attached_nodes.difference(old_attached_nodes)
    deleted_attached_nodes = old_attached_nodes.difference(new_attached_nodes)
    if added_attached_nodes:
        if 'add' not in diff:
            diff['add'] = {}         
        diff['add']['attached_nodes'] = sorted(added_attached_nodes)
    if deleted_attached_nodes:
        if 'delete' not in diff:
            diff['delete'] = {}        
        diff['delete']['attached_nodes'] = sorted(deleted_attached_nodes)

    # Check property change
    if old_package_id != new_package_id:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['package'] = {
            'modify': [
                {'property': 'package_id', 'old_value': old_package_id, 'new_value': new_package_id}
            ]
        }
    same_nodes = old_nodes.intersection(new_nodes)
    modified_nodes = []
    for node in sorted(same_nodes):
        prop_diff = _property_diff(old_components[node], new_components[node])
        if prop_diff:
            node_diff = {'node_id': old_components[node]['node_id']}
            node_diff.update(prop_diff)
            modified_nodes.append(node_diff)
    if modified_nodes:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['nodes'] = modified_nodes

    
    modified_edges = []
    same_edges = old_edges.intersection(new_edges)
    for edge in sorted(same_edges):
        prop_diff = _property_diff(old_components[edge], new_components[edge])
        if prop_diff:
            edge_diff = {'src_id': old_components[edge]['src_id'], 'dst_id': old_components[edge]['dst_id']}
            edge_diff.update(prop_diff)
            modified_edges.append(edge_diff)
    if modified_edges:
        if 'modify' not in diff:
            diff['modify'] = {}
        diff['modify']['edges'] = modified_edges     

    return diff


def  rpdiff_to_graphviz(old: RulePackage | dict, new: RulePackage | dict) -> graphviz.graphs.Digraph:
    """
    Compare two rule packages.

    Parameters
    ----------
    old : RulePackage | dict
        Old rule package or json graph.
    new : RulePackage | dict
        New rule package or json graph. 

    Returns
    -------
    graphviz.graphs.Digraph
        A graph in graphviz dot language format to show changes (add, delete, modify) between two versions.
    """     
    diff = rpdiff(old, new)

    delete_color = 'lightgray'  # '#FFCCCC'
    add_color = 'blue'
    modify_color = 'red'

    # all_components are union of old and new components.
    all_nodes = old.get('nodes') or []
    all_edges = old.get('edges') or []
    all_attached_nodes = old.get('attached_nodes') or []
    color_map = {}
    if diff.get('add') is not None:
        if diff['add'].get('nodes') is not None:
            all_nodes = all_nodes + diff['add']['nodes']
            color_map.update({node['node_id']: add_color for node in diff['add']['nodes']})
        if diff['add'].get('edges') is not None:
            all_edges = all_edges + diff['add']['edges']
            # TODO: For SwitchNode, multiple cases can go to the same destination, should update with (src, dst, child_idx)
            #       For BranchNode, multiple cases can go to the same destination, should update with (src, dst, case)
            color_map.update({(edge['src_id'], edge['dst_id']): add_color for edge in diff['add']['edges']})
        if diff['add'].get('attached_nodes') is not None:
            all_attached_nodes = all_attached_nodes + diff['add']['attached_nodes']
            color_map.update({(old['package_id'], node_id): add_color for node_id in diff['add']['attached_nodes']})

    if diff.get('delete') is not None:
        if diff['delete'].get('nodes') is not None:
            color_map.update({node['node_id']: delete_color for node in diff['delete']['nodes']})
        if diff['delete'].get('edges') is not None:
            color_map.update({(edge['src_id'], edge['dst_id']): delete_color for edge in diff['delete']['edges']})
        if diff['delete'].get('attached_nodes') is not None:
            color_map.update({(old['package_id'], edge['dst_id']): delete_color for edge in diff['delete']['attached_nodes']})

    if diff.get('modify') is not None:
        if diff['modify'].get('package') is not None:
            color_map.update({old['package_id']: modify_color})
        if diff['modify'].get('nodes') is not None:
            color_map.update({node['node_id']: modify_color for node in diff['modify']['nodes']})
        if diff['modify'].get('edges') is not None:
            color_map.update({(edge['src_id'], edge['dst_id']): modify_color for edge in diff['modify']['edges']})

    all_components = {}
    all_components.update({node['node_id']: node for node in all_nodes})
    all_components.update({(edge['src_id'], edge['dst_id']): edge for edge in all_edges})
    all_components.update({(old['package_id'], node_id): None for node_id in all_attached_nodes})

    # TODO: Find better way to display modified components.
    # new_components is a dict used only for displaying modified package and edges.
    new_components = {}
    new_components.update({node['node_id']: node for node in new.get('nodes') or []})
    new_components.update({(edge['src_id'], edge['dst_id']): edge for edge in new.get('edges') or []})
    new_components.update({(new['package_id'], node_id): None for node_id in new.get('attached_nodes') or []})    

    g = graphviz.Digraph(old['package_id'])
    g.attr(rankdir='LR')
    node_shapes = {
        'BigTableNode': 'cylinder',
        'ForkNode': 'point', 
        'TransformNode': 'rect', 
        'DecisionTableNode': 'rect',       
        'SelectNode': 'invtrapezium',
        'SwitchNode': 'switch', # switch is a special type, not a graphiz node type.
        'RuleNode': 'house',
        'FlagNode': 'parallelogram', 
        'AuditNode': 'circle',
        'BranchNode': 'diamond',
        'InPortNode': 'Mcircle',
        'OutPortNode': 'Mcircle', 
        'SubRuleNode': 'tab'     # TODO: draw it like a SwitchNode        
    }
    nodes = {node_type: [] for node_type, node_shape in node_shapes.items()}

    for node in all_nodes:
        nodes[node['node_type']].append(node)

    edges = {}
    for edge in all_edges:
        if edges.get(edge['src_id']) is None:
            edges[edge['src_id']] = []
        edges[edge['src_id']].append(edge)

    g.attr('node', shape = 'folder')
    color = color_map.get(old['package_id'], 'black')
    if color == modify_color and old['package_id'] != new['package_id']:
        label = '<<s>{}</s> {}>'.format(html.escape(old['package_id']), html.escape(new['package_id']))
    else: 
        label = html.escape(old.get('name') if old.get('name') else old['package_id']) 
    g.node(old['package_id'], label=label, color=color, fontcolor=color)
    for node_type, node_list in nodes.items():
        shape = node_shapes[node_type]
        if shape == 'switch':
            g.attr('node', shape = 'record')
            for node in node_list:
                rows = []
                node_name = html.escape(node.get('name')) if node.get('name') else node['node_id']
                rows.append('<selector> {}'.format(node_name))
                idx = 0
                for edge in edges.get(node['node_id']) or []:
                    rows.append('<f{}> '.format(idx))
                    idx = idx + 1   
                label = '|'.join(rows)  # https://graphviz.org/Gallery/directed/datastruct.html
                color = color_map.get(node['node_id'], 'black')
                g.node(node['node_id'], label=label, color=color, fontcolor=color)
        else:
            g.attr('node', shape=shape)
            for node in node_list:
                #label = html.escape(node.get('name')) if node.get('name') else (node['node_id'] if node['node_type'] != 'FlagNode' else node['flag'])
                label = html.escape(node.get('name')) if node.get('name') else node['node_id']
                color = color_map.get(node['node_id'], 'black')
                g.node(node['node_id'], label=label, color=color, fontcolor=color) 

    for node_id in all_attached_nodes:
        dst = '{}:selector'.format(node_id) if all_components[node_id]['node_type'] == 'SwitchNode' else node_id    
        color = color_map.get((old['package_id'], node_id), 'black')
        g.edge(old['package_id'], dst, color=color, fontcolor=color)   
    for node_id, edge_list in edges.items():
        if all_components[node_id]['node_type'] == 'SwitchNode':
            idx = 0
            for edge in edge_list:
                dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                if edge.get('case') is not None:
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        new_case_or_default = new_edge.get('case') or 'default'
                        label = '<<s>{}</s> {}>'.format(html.escape(str(edge['case'])), html.escape(new_case_or_default)) 
                    else: 
                        label = html.escape(str(edge['case']))
                    g.edge('{}:f{}'.format(node_id, idx), dst, color=color, fontcolor=color, label=label)
                elif 'default' in edge:
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        new_case_or_default = new_edge.get('case') or 'default'
                        label = '<<s>default</s> {}>'.format(html.escape(new_case_or_default)) 
                    else: 
                        label = 'default'                    
                    g.edge('{}:f{}'.format(node_id, idx), dst, color=color, fontcolor=color, label=label)
                idx = idx + 1
        elif all_components[node_id]['node_type'] == 'BranchNode':
            for edge in edge_list:
                if edge.get('case') is not None:
                    dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                    color = color_map.get((node_id, edge['dst_id']), 'black')
                    if color == modify_color:
                        new_edge = new_components[(node_id, edge['dst_id'])]
                        label = '<<s>{}</s> {}>'.format(edge['case'], new_edge['case']) 
                    else: 
                        label = str(edge['case'])                          
                    g.edge(node_id, dst, label=label, color=color, fontcolor=color)                        
        else:
            for edge in edge_list:
                dst = '{}:selector'.format(edge['dst_id']) if all_components[edge['dst_id']]['node_type'] == 'SwitchNode' else edge['dst_id']
                color = color_map.get((node_id, edge['dst_id']), 'black')              
                g.edge(node_id, dst, color=color, fontcolor=color)

    return g            


# Create sankey plot function


# https://observablehq.com/@d3/sankey-component
def create_sankey_plot(rule_package: RulePackage, metrics: dict = None) -> str: 
    """
    Create sankey plot of traffic flow based on metrics.

    Parameters
    ----------
    rule_package: RulePackage
        Rule package.
    metrics : dict
        Metrics  

    Returns
    -------
    str
        HTML string with SVG sankey plot.
    """       
    gv = rule_package.to_graphviz()
    json_string = gv.pipe(format='json', encoding='utf-8')
    json_dict = json.loads(json_string)
    bounding_box = [float(i) for i in json_dict['bb'].split(',')]  # x0,y0,x1,y1
    width = bounding_box[2]
    height = bounding_box[3]
    #print(json.dumps(json_dict, indent=2))
    node_position_map = {}
    for obj in json_dict['objects']:
        node_position_map[obj['name']] = tuple([float(i) for i in obj['pos'].split(',')]) # node_id -> (x, y)

    # Convert into 0.0 - 1.0 range and flip vertically.
    node_position_map = {k: (v[0], height - v[1]) for k, v in node_position_map.items()} 
    #print(node_position_map)    

    value_map = {}
    if metrics is None:
        metrics = rule_package.get_metrics().to_dict()
    for metric in metrics['traffic']:
        src_id = metric['key'][0]
        dst_id = metric['key'][1]
        value_map[(src_id, dst_id)] = metric['value']
    #print(value_map)    

    graph = rule_package.to_graph()
    nodes = [
        {'id': rule_package.package_id, 
        'type': rule_package.__class__.__name__,
        'gv_x': node_position_map[rule_package.package_id][0], 
        'gv_y': node_position_map[rule_package.package_id][1]
        }
    ]
    nodes = nodes + [
        {'id': node['node_id'], 
        'name': node.get('name', ''),
        'type': node['node_type'],
        'gv_x': node_position_map[node['node_id']][0], 
        'gv_y': node_position_map[node['node_id']][1]
        } 
        for node in graph['nodes']
    ]
    links = []
    for child in rule_package.children:
        links.append({'source': rule_package.package_id, 'target': child.node_id, 'value': value_map.get((rule_package.package_id, child.node_id), 0.1)}) 
    links = links + [{'source': edge['src_id'], 'target': edge['dst_id'], 'value': value_map.get((edge['src_id'], edge['dst_id']), 0.1)} for edge in graph['edges']]
    #print(nodes)
    #print(links)

    graph = {
        'nodes': nodes,
        'links': links
    }    

    template = '''
      <!DOCTYPE html>
      <head>
        <style>
        .link:hover {
          stroke-opacity: 0.5;
          fill-opacity: 0.5;
        }
        </style>
      </head>
      <h1>$title</h1>
      <div id="$div_id"></div>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.js"></script>
      <!--script src="https://d3js.org/d3.v7.min.js"></script>
      <script src="https://unpkg.com/d3-array@1"></script>
      <script src="https://unpkg.com/d3-collection@1"></script>
      <script src="https://unpkg.com/d3-path@1"></script>
      <script src="https://unpkg.com/d3-shape@1"></script>
      <script src="https://unpkg.com/d3-sankey@0.12.3/dist/d3-sankey.js"></script-->

      <script>
        requirejs.config({
            paths: {
              "d3": "https://d3js.org/d3.v7.min",
              "d3-array": "https://unpkg.com/d3-array@1.2.4/dist/d3-array.min",
              "d3-collection": "https://unpkg.com/d3-collection@1.0.7/dist/d3-collection.min",
              "d3-path": "https://unpkg.com/d3-path@1.0.9/dist/d3-path.min",
              "d3-shape": "https://unpkg.com/d3-shape@1.3.7/dist/d3-shape.min",
              "d3-sankey": "https://unpkg.com/d3-sankey@0.12.3/dist/d3-sankey"
            },
            shim: {  // dependencies
              "d3-sankey": ["d3"]
            }
        });

        /*
        graph = {
          "nodes":[
            {"id":0,"name":"node0"},
            {"id":1,"name":"node1"},
            {"id":2,"name":"node2"},
            {"id":3,"name":"node3"},
            {"id":4,"name":"node4"}
          ],
          "links":[
            {"source":0,"target":2,"value":2},
            {"source":1,"target":2,"value":2},
            {"source":1,"target":3,"value":2},
            {"source":0,"target":4,"value":2},
            {"source":2,"target":3,"value":2},
            {"source":2,"target":4,"value":2},
            {"source":3,"target":4,"value":4}
          ]
        } 
        */

        graph = $graph

        require(['d3', 'd3-array', 'd3-collection', 'd3-path', 'd3-shape', 'd3-sankey'], 
          function (d3, d3array, d3collection, d3path, d3shape, d3sankey) {
            runit()

            function runit() {
              color = d3.scaleOrdinal(d3.schemeCategory10);  // Auto node color
              node_color_map = {  // Manually define node color
                'RulePackage': 'blue',
                'ForkNode': 'lightgreen', 
                'TransformNode': 'lightskyblue', 
                'DecisionTableNode': 'lightred',                 
                'SelectNode': 'lightseagreen',
                'SwitchNode': 'gold', 
                'RuleNode': 'orange',
                'FlagNode': 'orange', 
                'AuditNode': 'olive',
                'BranchNode': 'gold'
                'InPortNode': 'blue',
                'OutPortNode': 'orange', 
                'SubRuleNode': 'green'    // TODO: Draw it like a SwitchNode
              }              

              width = $width
              height = $height
              nodes = graph.nodes
              links = graph.links
              linkStrokeOpacity = 0.2, // link stroke opacity
              linkMixBlendMode = "multiply", // link blending mode
              linkPath = d3sankey.sankeyLinkHorizontal(), // given d in (computed) links, returns the SVG path
              nodeLabelPadding = 6, // horizontal separation between node and label    
              nodeWidth = 30, // width of node rects
              nodePadding = 30, // vertical separation between adjacent nodes
              nodeLabelPadding = 6, // horizontal separation between node and label
              arrowLen = 15 // if 0, no arrow.    

              // Compute node position
              d3sankey.sankey()
                .nodeId(function(d) {return d.id})
                .nodeWidth(nodeWidth)
                .nodePadding(nodePadding)      
                .extent([[0, 0], [width, height]])
                ({nodes, links})

              // Compute adjusted node height
              for (const node of nodes) {
                node.adjusted_height = Math.max(...[d3.max(node.sourceLinks, l => l.width), d3.max(node.targetLinks, l => l.width)].filter(e => !isNaN(e))) // d3.max([], f) returns undefined
              }      

              // We must update position x0,x1,y0,y1 of all nodes according to graphviz
              for (const node of nodes) {
                node.y0 = node.gv_y
                node.y1 = node.y0 + node.adjusted_height
                node.x0 = node.gv_x
                node.x1 = node.gv_x + nodeWidth
              }      

              // https://gist.github.com/KatiRG/90a972bad9109ae556c0
              d3sankey.sankey().update(graph);  // Recompute link positions          

              // Set node name
              for (const node of nodes) {
                if (!node.name) {
                  node.name = node.id
                }
              }      

              console.log(graph)   
              
              svg = d3.select("#$div_id")
                      .append("svg")                  
                        .attr("width", width)        
                        .attr("height", height * 1.25)
                        .attr("style", "background-color: white")

              if (arrowLen == 0) {
                // Calculate link source and target positions. If source is not a SwitchNode, use Y-center of node.
                linkPath = d3.linkHorizontal()
                  // Always use center X and Y of node.
                  //.source(d => [d.source.x1, (d.source.y0 + d.source.y1)/2])
                  //.target(d => [d.target.x0, (d.target.y0 + d.target.y1)/2])
                  .source(d => [d.source.x1, (d.source.type == 'SwitchNode' || d.source.type == 'BranchNode' ? d.y0 : (d.source.y0 + d.source.y1)/2)])
                  .target(d => [d.target.x0, d.y1])
            
                // Draw links
                link = svg.append("g")
                  .attr("fill", "none")
                  .attr("stroke-opacity", linkStrokeOpacity)
                  //.style("mix-blend-mode", linkMixBlendMode);  
                  .selectAll("path")
                  .data(links)
                  .join("path")
                    .attr("class", "link")
                    .attr("d", linkPath)
                    .attr("stroke", "black")
                    .attr("stroke-width", ({width}) => Math.max(1, width))
                    .call(path => path.append("title").text(d => d.source.name + "->" + d.target.name + "\\n" + (d.value >= 1 ? d.value : 0) )); // Set link title  

              } else {
                // Link arrow 
                //   https://github.com/plotly/plotly.js/blob/master/src/traces/sankey/render.js 
                //   https://www.sankey-diagrams.com/sankeys-with-circular-links/ 
                //   https://observablehq.com/@tomshanley/sankey-circular-deconstructed
                // Calculate link source and target positions for arrow link. 
                linkPath = function(d) {
                  curvature = 0.5
                  maxArrowLength = Math.abs((d.target.x0 - d.source.x1) / 2);
                  if(arrowLen > maxArrowLength) {
                    arrowLen = maxArrowLength;
                  }
                  x0 = d.source.x1;
                  y0 = (d.source.type == 'SwitchNode' || d.source.type == 'BranchNode' ? d.y0 : (d.source.y0 + d.source.y1)/2)
                  x1 = d.target.x0 - arrowLen;
                  y1 = d.y1
                  x2 = x3 = curvature * (x1-x0) + x0;
                  y0a = y0 - d.width / 2;
                  y0b = y0 + d.width / 2;
                  y1a = y1 - d.width / 2;
                  y1b = y1 + d.width / 2;
                  start = 'M' + x0 + ',' + y0a;
                  upperCurve = 'C' + x2 + ',' + y0a +
                    ' ' + x3 + ',' + y1a +
                    ' ' + x1 + ',' + y1a;
                  lowerCurve = 'C' + x3 + ',' + y1b +
                    ' ' + x2 + ',' + y0b +
                    ' ' + x0 + ',' + y0b;

                  rightEnd = arrowLen > 0 ? 'L' + (x1 + arrowLen) + ',' + (y1a + d.width / 2) : '';
                  rightEnd += 'L' + x1 + ',' + y1b;
                  return start + upperCurve + rightEnd + lowerCurve + 'Z';                
                }                                   

                // Draw links with filled area
                link = svg.append("g")
                  .attr("fill", "none")
                  .attr("stroke-opacity", linkStrokeOpacity)
                  //.style("mix-blend-mode", linkMixBlendMode);  
                  .selectAll("path")
                  .data(links)
                  .join("path")
                    .attr("class", "link")
                    .attr("d", linkPath)
                    .attr("fill", "black")
                    .attr("fill-opacity", linkStrokeOpacity)
                    .attr("stroke", "black")
                    .attr("stroke-width", ({width}) => width > 1 ? 0 : 1)  // If filled area, no stroke is needed.
                    .call(path => path.append("title").text(d => d.source.name + "->" + d.target.name + "\\n" + (d.value >= 1 ? d.value : 0) )); // Set link title  
                
              }

              // Draw link labels at the middle of link
              const  linkLabel = svg.append("g")
                .attr("font-family", "sans-serif")
                .attr("font-size", 10)      
                .selectAll("text")
                .data(links)
                .enter()
                  .append("text")
                  .attr("x", function(d) { return d.source.x0 + (d.target.x1 - d.source.x0)/2; })
                  .attr("y", function(d) { return ((d.source.type == 'SwitchNode' || d.source.type == 'BranchNode' ? d.y0 : (d.source.y0 + d.source.y1)/2) + d.y1)/2; }) 
                  .text(function(d) {return d.value < 1 ? 0 : d.value;})

              // Create graphic elements for nodes
              const node = svg.append("g")
                //.attr("stroke", nodeStroke)
                //.attr("stroke-width", nodeStrokeWidth)
                //.attr("stroke-opacity", nodeStrokeOpacity)
                //.attr("stroke-linejoin", nodeStrokeLinejoin)
                .attr("font-family", "sans-serif")
                .attr("font-size", 10)      
                .selectAll(".node")
                .data(nodes)
                .join("g")
                  .attr("class", "node")
                  .attr("transform", d => "translate(" + d.x0 + "," + (d.y1 + d.y0 - d.adjusted_height)/2 + ")") 
                  .call(d3.drag()
                    .subject(d => d)
                    .on('start', function () { this.parentNode.appendChild(this); })
                    .on('drag', dragmove))        
            
              // Draw nodes
              node
                .append("rect")
                  .attr("x", 0)
                  .attr("y", 0)
                  .attr("height", d => Math.max(d.adjusted_height, 1))
                  .attr("width", d => d.x1 - d.x0)      
                  //.attr("fill", d => color(d.id))
                  .attr("fill", d => node_color_map[d.type])
                .append("title")
                  .text(d => d.name)  // Hover text

              // Set node labels
              node.append("text")
                //.attr("x", d => d.x0 < width / 2 ? d.x1 + nodeLabelPadding : d.x0 - nodeLabelPadding)
                //.attr("y", d => (d.y1 + d.y0) / 2)
                .attr("x", d => d.x0 < width/2 ? nodeWidth + nodeLabelPadding : - nodeLabelPadding)
                .attr("y", d => d.adjusted_height/2)
                .attr("dy", "0.35em")
                .attr("text-anchor", d => d.x0 < width / 2 ? "start" : "end")
                .text(d => d.name)

              function dragmove(event, d) {
                var rectY = d3.select(this).select("rect").attr("y");
                var rectX = d3.select(this).select("rect").attr("x");
                d.y0 = d.y0 + event.dy;      
                d.y1 = d.y1 + event.dy;   
                d.x1 = d.x1 + event.dx;
                d.x0 = d.x0 + event.dx; 
                var yTranslate = (d.y1 + d.y0 - d.adjusted_height)/2 
                var xTranslate = d.x0 - rectX;
                d3.select(this).attr('transform', "translate(" + (xTranslate) + "," + (yTranslate) + ")");
                d3sankey.sankey().update(graph);  // Recompute link positions
                link.attr('d', linkPath);  // Update link
                linkLabel.attr("x", function(d) { return d.source.x0 + (d.target.x1 - d.source.x0)/2; }) // Update link label x
                linkLabel.attr("y", function(d) { return ((d.source.type == 'SwitchNode' || d.source.type == 'BranchNode' ? d.y0 : (d.source.y0 + d.source.y1)/2) + d.y1)/2; })  // Update link label y
              }    
              
            } // runit()

          }
        )
      
      </script>
    '''
    jstr = Template(template).substitute({'title': 'Sankey', 'graph': json.dumps(graph), 'width': width, 'height': height, 'div_id': 'sankey-id-{}'.format(random.randint(10000, 99999))})
    #print(jstr)

    return jstr    


# TODO: Respect __all__ if defined in module
# https://stackoverflow.com/questions/43059267/how-to-do-from-module-import-using-importlib
# https://stackoverflow.com/questions/63447803/how-do-i-list-all-functions-for-a-python-module-ignoring-functions-the-module-im
def from_package_import(module: str, names: str | list[str] = None) -> dict:
    '''
    Create mapping with from module import names. The module must be existed in python path.

    Parameters
    ----------
    module: str
        Module (package) name
    names : str | list[str], default to None
        Name or list of names in the module. Use '*' or None for all names.

    Returns:
    --------
    dict
        A dict of names in the module. To make them available in the current namespace, 
        the dict must be updated into globals(): globals().update(d).
    '''
    if isinstance(names, str):
        names = [names]
    
    # get a handle on the module
    m = importlib.import_module(module)
    
    if names is None or names == ["*"]:    
        names = [name for name in dir(m) if not name.startswith("_")]

    d = {}
    for name in names:
        attr = getattr(m, name)
        if inspect.getmodule(attr) == m:  # Get only name defined in this module; not those imported.
            d[name] = attr

    return d


def convert_to_json_encodeable(obj: object) -> dict:
    '''
    Convert an object to JSON encodeable dict which is ready for JSON encoding.
    For a dict, convert only values, not keys.

    Parameters
    ----------
    obj: object
        An object to convert.

    Returns:
    --------
    dict
        A dict which is ready for JSON encoding.
    '''    
    if isinstance(obj, (bool, str, int, float, NoneType)):
        return obj
    elif isinstance(obj, (NullType, LooselyNullType)):
        return None
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, dict): 
        return {key: convert_to_json_encodeable(value) for key, value in obj.items()} # If the key needs to be converted, we must reimplement this.
    elif isinstance(obj, list):
        return [convert_to_json_encodeable(e) for e in obj]
    elif isinstance(obj, set):
        return [convert_to_json_encodeable(e) for e in obj]
    elif isinstance(obj, tuple):
        return [convert_to_json_encodeable(e) for e in obj]
    elif isinstance(obj, OBJECTLIST):
        return convert_to_json_encodeable(obj.data)
    else:
        raise NotImplementedError('No idea how to convert an object of type {} to JSON'.format(type(obj)))


def convert_none_to_null(obj: object) -> object:
    '''
    Traverse basic python object and convert None to NULL.

    Parameters
    ----------
    obj: object
        An object to convert.

    Returns:
    --------
    object
        Converted object.
    '''       
    if type(obj) in (datetime, bool, str, int, float):
        return obj
    elif type(obj) == NoneType:
        return NULL
    elif type(obj) == dict:
        return {key: convert_none_to_null(value) for key, value in obj.items()}
    elif type(obj) == list:
        return [convert_none_to_null(e) for e in obj]
    else:
        raise NotImplementedError('No idea how to convert an object of type {} to NULL'.format(type(obj)))


def _validate_sklearn_clf(clf, feature_names: list[str] = None, class_names: list[str] = None):
    if clf.tree_.n_outputs > 1: 
        raise Exception('Multi-output problem not supported')

    n_classes = clf.tree_.n_classes if isinstance(clf.tree_.n_classes, int) else clf.tree_.n_classes[0] 
    if n_classes < 2:
        raise Exception('Only binary or multiclass classification problem supported')

    return True
 

# https://scikit-learn.org/stable/auto_examples/tree/plot_unveil_tree_structure.html
def _recurse_sklearn_tree(rulePackage: RulePackage, tree, feature_names: list[str], class_names: list[str], node_id: int, parent_id: int = None):

    left_child_id = tree.children_left[node_id]
    right_child_id = tree.children_right[node_id] 

    if left_child_id != -1:  # node_id is not a leaf.
        feature_name = feature_names[tree.feature[node_id]]
        threshold = tree.threshold[node_id]
        #print("Node {}: {} <= {}".format(node_id, feature_name, threshold))
        #print("Node {} (true) -> node {}".format(node_id, left_child_id))
        #print("Node {} (false) -> node {}".format(node_id, right_child_id))

        # Scikit Learn uses only <=
        switchNode = SwitchNode("node_{}".format(node_id), selector="{} <= {}".format(feature_name, threshold), name=feature_name, description="{} <= {}".format(feature_name, threshold), rule_package=rulePackage)
        if parent_id is None:
            bigtable1 = rulePackage.get_node('bigtable1')
            bigtable1.add_child(switchNode)
        else:
            parentNode = rulePackage.get_node('node_{}'.format(parent_id))
            if tree.children_left[parent_id] == node_id:
                parentNode.append_child('{}'.format(True), switchNode) # Left child is True
            else:
                parentNode.append_child('{}'.format(False), switchNode) # Right child is False

        _recurse_sklearn_tree(rulePackage, tree, feature_names, class_names, left_child_id, parent_id=node_id)
        _recurse_sklearn_tree(rulePackage, tree, feature_names, class_names, right_child_id, parent_id=node_id)
    else: 
        # value[i, j, k]: the summary of the training samples that reached node i for output j and class k
        values = tree.value[node_id][0]
        argmax = max(range(len(values)), key=lambda i: values[i])
        #print("Node {} flag {}".format(node_id, class_names[argmax]))
        #print("Node {} impurity {}".format(node_id, tree.impurity[node_id]))
        flagNode = FlagNode("node_{}".format(node_id), flag=class_names[argmax], name=class_names[argmax], template={"tag": "gini", "value": tree.impurity[node_id]}, rule_package=rulePackage)
        if parent_id is None:
            bigtable1 = rulePackage.get_node('bigtable1')
            bigtable1.add_child(flagNode)
        else:
            parentNode = rulePackage.get_node('node_{}'.format(parent_id))
            if tree.children_left[parent_id] == node_id:
                parentNode.append_child('{}'.format(True), flagNode) # Left child is True
            else:
                parentNode.append_child('{}'.format(False), flagNode) # Right child is False


def from_sklearn_clf(clf, package_id: str, feature_names: list[str], class_names: list[str]) -> RulePackage:
    '''
    Convert scikit learn decision tree classifier to a RulePackage.

    Parameters
    ----------
    clf: DecisionTreeClassifier
        A decision tree classifier to convert.
    package_id: str
        Package ID
    feature_names: list[str]
        A list of feature name. Since scikit learn uses feature index only, feature names are required.      
    class_names: list[str]
        A list of class name. Since scikit learn uses class index only, class names are required.  

    Returns:
    --------
    RulePackage
        RulePackage.
    '''       

    _validate_sklearn_clf(clf)
    package = RulePackage(package_id)
    package.attach(BigTableNode("bigtable1", rule_package=package))  # Fix bigtable1 name for being the parent of node_0

    _recurse_sklearn_tree(package, clf.tree_, feature_names, class_names, 0)

    return package


class DiaGraph:

    operator_map = {
        '<=': 'le',
        '<': 'lt',
        '>=': 'ge',
        '>': 'gt',
        '=': 'eq',
        '<>': 'neq',
        'in': 'is_in',
        'not_in': 'is_not_in'
    }

    @staticmethod
    def _convert_bigTableNode(node: BigTableNode, x, y) -> dict:
        return {
            "id": node.node_id,
            "type": "BigTable",
            "data": {
                "id": node.node_id,
                "type": "BigTable",
                "style": {
                    "backgroundColor": "white"
                },
                "name": "BigTable",
                "description": "Description something",
                "setting": {},
                #"engineOption": {}
            },
            "position": {
                "x": x,
                "y": y
            },
            "measured": {
                "width": 50,
                "height": 50
            },
            "selected": False,
            "dragging": False
        }


    # Return a dict that looks like:
    # {
    #     "combination": "and",
    #     "rules": [
    #         {
    #             "combination": "and",
    #             "rules": [
    #                 {
    #                     "id": "7cb",
    #                     "field": "bigTable.hcode",
    #                     "op": "eq",
    #                     "values": [
    #                         {
    #                             "type_head": "constant",
    #                             "type": "str",
    #                             "value": "0007"
    #                         }
    #                     ]
    #                 }
    #             ]
    #         }
    #     ]
    # }    
    @staticmethod    
    def _parse_conditions(conditions: dict, parent_id: str, i: int) -> dict:

        if 'fact' in conditions and 'operator' in conditions and 'value' in conditions:
            field = conditions['fact']
            operator = conditions['operator']
            value = conditions['value']

            operator = DiaGraph.operator_map.get(operator, operator)
            if operator not in DiaGraph.operator_map.values():
                raise Exception('Unknown operator {} in DiaGraph conversion'.format(operator))
            
            if isinstance(value, str):
                value_type = "str"
            elif isinstance(value, (int, float)):
                value_type = "number" 
            elif isinstance(value, list):
                if isinstance(value[0], str):
                    value_type = "array_str"
                elif isinstance(value[0], (int, float)):
                    value_type = "array_number" 
                else:
                    raise NotImplementedError("Support only primitive and list of primitives value: {}".format(value))                    
            else:
                raise NotImplementedError("Support only primitive value: {}".format(value))
            
            return {                   
                "id": "{}_{}".format(parent_id, i),
                "field": "bigTable.{}".format(field),
                "op": operator,
                "values": [
                    {
                        "type_head": "constant",
                        "type": value_type,
                        "value": value
                    }
                ]                                    
            }
        
        elif 'all' in conditions:
            return {
                "combination": "and",
                "rules": [
                    DiaGraph._parse_conditions(cond, "{}_{}".format(parent_id, i), idx)  for idx, cond in enumerate(conditions['all'])
                ]
            }
        elif 'any' in conditions:
            return {
                "combination": "or",
                "rules": [
                    DiaGraph._parse_conditions(cond, "{}_{}".format(parent_id, i), idx)  for idx, cond in enumerate(conditions['any'])
                ]
            }
        else:
            raise Exception("DiaGraph found unknown condition format: {}".format(conditions))


    @staticmethod
    def _convert_ifElseNode(node: SwitchNode, x, y) -> dict:
        expr = node.raw        
        node_id = node.node_id
        converter = ExprToJson(schema_path=None, bypass_schema=True, auto_expr_is_true=False)
        d = converter.convert(expr)  
        if not isinstance(d['conditions'], dict):
            raise Exception("DiaGraph failed to parse conditions {}".format(expr))            
        
        conditions = DiaGraph._parse_conditions(d['conditions'], node_id, 0) 
        if 'combination' not in conditions:  # A simple condition must be wrapped within another AND
            conditions = {
                "combination": "and",
                "rules": [
                    conditions
                ]
            } 
        conditions = {
                        "combination": "and",  # This is the outermost AND
                        "rules": [
                            conditions
                        ]
                    }
        
        return {
            "id": node.node_id,
            "type": "IfElse",
            "position": {
                "x": x,
                "y": y
            },
            "data": {
                "id": node.node_id,
                "type": "IfElse",
                "style": {
                    "backgroundColor": "#ffffff"
                },
                "name": node.name,
                "description": "Description something",
                "setting": {
                    "conditions": conditions
                },
                #"engineOption": {
                #    "type": "number"
                #}
            },
            "measured": {
                "width": 50,
                "height": 50
            },
            "selected": False
        }    
    
    
    @staticmethod
    def _convert_switchNode(node: SwitchNode, x, y) -> dict:
        cases = []
        for idx, (operator, operand, child) in enumerate(node.children):
            operator = DiaGraph.operator_map.get(operator, operator)
            if operator not in DiaGraph.operator_map.values():
                raise Exception('Unknown operator {} in DiaGraph conversion'.format(operator))
            
            try:
                value = ast.literal_eval(operand)
            except:
                raise NotImplementedError("Support only simple literal: {}".format(operand))
            
            if isinstance(value, str):
                value_type = "str"
            elif isinstance(value, (int, float)):
                value_type = "number" 
            elif isinstance(value, list):
                if isinstance(value[0], str):
                    value_type = "array_str"
                elif isinstance(value[0], (int, float)):
                    value_type = "array_number" 
                else:
                    raise NotImplementedError("Support only primitive and list of primitives value: {}".format(value))    
            else:
                raise NotImplementedError("Support only primitive and list of primitives value: {}".format(value))
            
            cases.append({
                "id": "case_{}".format(idx),
                "op": operator,
                "values": [
                    {
                        "type_head": "constant",
                        "type": value_type,
                        "value": value
                    }
                ]                
            })

        return         {
            "id": node.node_id,
            "type": "Switch",
            "position": {
                "x": x,
                "y": y
            },
            "data": {
                "id": node.node_id,
                "type": "Switch",
                "style": {
                    "backgroundColor": "#ffffff"
                },
                "name": node.name,
                "description": "Description something",
                "setting": {
                    "select_field": "bigTable.{}".format(node.raw),
                    "cases": cases
                },
                #"engineOption": {
                #    "type": "number"
                #}
            },
            "measured": {
                "width": 50,
                "height": 50
            },
            "selected": False
        }
    
    @staticmethod    
    def _convert_flagNode(node: FlagNode, x, y) -> dict:
        return         {
            "id": node.node_id,
            "type": "Flag",
            "position": {
                "x": x,
                "y": y
            },
            "data": {
                "id": node.node_id,
                "type": "Flag",
                "style": {
                    "backgroundColor": "#ffffff"
                },
                "name": node.name,
                "description": "Description something",
                "setting": {
                    "flag": {
                        "name": node.flag
                    },
                    "result_status": {
                        "name": None
                    },
                    "tag": "gini",
                    "value": {
                        "type_head": "constant",
                        "type": "number",
                        "value": node.template.get("value", -1)
                    },
                    "message": {
                        "value": [
                        ]
                    },
                    "details": []
                },
                #"engineOption": {}
            },
            "measured": {
                "width": 50,
                "height": 50
            },
            "selected": False,
            "dragging": False
        }    

    @staticmethod    
    def _convert_selectNode(node: SelectNode, x, y) -> dict:
        return         {
            "id": node.node_id,
            "type": "Select",
            "position": {
                "x": x,
                "y": y
            },
            "data": {
                "id": node.node_id,
                "type": "Select",
                "style": {
                    "backgroundColor": "#ffffff"
                },
                "name": node.name,
                "description": "Description something",
                "setting": {
                    "selecteds": ["bigTable.{}".format(field_name) for field_name in node.field_names]
                },
                #"engineOption": {}
            },
            "measured": {
                "width": 50,
                "height": 50
            },
            "selected": False,
            "dragging": False
        }    

    @staticmethod    
    def _convert_forkNode(node: ForkNode, x, y) -> dict:
        return         {
            "id": node.node_id,
            "type": "Fork",
            "position": {
                "x": x,
                "y": y
            },
            "data": {
                "id": node.node_id,
                "type": "Fork",
                "style": {
                    "backgroundColor": "#ffffff"
                },
                "name": node.name,
                "description": "Description something",
                #"engineOption": {}
            },
            "measured": {
                "width": 50,
                "height": 50
            },
            "selected": False,
            "dragging": False
        }    

    @staticmethod
    def _need_IfElseNode(node: Node):
        if not isinstance(node, SwitchNode):
            return False

        expr = node.raw
        if not isinstance(expr, str):
            raise Exception('Support only condition string: {}'.format(expr))   
               
        return not expr.isidentifier()

    @staticmethod
    def convert_node(node: Node, node_position_map: dict) -> dict:
        pos = node_position_map.get(node.node_id)
        if pos is None:
            raise Exception('No position for node {}'.format(node.node_id))
        x, y = pos
        if isinstance(node, BigTableNode):
            return DiaGraph._convert_bigTableNode(node, x, y)
        elif isinstance(node, SwitchNode):
            expr = node.raw
            if not isinstance(expr, str):
                raise Exception('Support only condition string: {}'.format(expr))     
                   
            if DiaGraph._need_IfElseNode(node):
                return DiaGraph._convert_ifElseNode(node, x, y)
            else:
                return DiaGraph._convert_switchNode(node, x, y)
        elif isinstance(node, FlagNode):
            return DiaGraph._convert_flagNode(node, x, y)
        elif isinstance(node, SelectNode):
            return DiaGraph._convert_selectNode(node, x, y)
        elif isinstance(node, ForkNode):
            return DiaGraph._convert_forkNode(node, x, y)        
        else:
            raise Exception("Node type {} not support".format(type(node)))    
        

def convert_to_diagraph(rule_package: RulePackage) -> dict:
    '''
    Convert a simple RulePackage to Editor Diagraph format. Not support all node types, non-primitive data types, and complex conditions.

    Parameters
    ----------
    rule_package: RulePackage
        A RulePackage to convert.

    Returns:
    --------
    dict
        DiaGraph json format.
    '''           

    # Use Graphviz for Sugiyama layout (tree layout).
    # Other libraries that can use Sugiyama layout inclues igraph, grandalf and fast-sugiyama.
    # For example, 
    #     import igraph as ig
    #     g = ig.Graph(directed=True)
    #     layout = g.layout_sugiyama().transform(lambda t: (t[1], t[0]))        
    gv = rule_package.to_graphviz()
    json_string = gv.pipe(format='json', encoding='utf-8')
    json_dict = json.loads(json_string)
    bounding_box = [float(i) for i in json_dict['bb'].split(',')]  # x0,y0,x1,y1
    width = bounding_box[2]
    height = bounding_box[3]
    #print(json.dumps(json_dict, indent=2))
    node_position_map = {}
    for obj in json_dict['objects']:
        node_position_map[obj['name']] = tuple([float(i) for i in obj['pos'].split(',')]) # node_id -> (x, y)

    # Convert into 0.0 - 1.0 range and flip vertically.
    y_scale = 2
    node_position_map = {k: (v[0], y_scale*(height - v[1])) for k, v in node_position_map.items()} 
    #print(node_position_map)  

    diagraph = {}
    diagraph['nodes'] = [DiaGraph.convert_node(node, node_position_map) for node_id, node in rule_package.known_nodes.items()]

    edges = []
    for node_id, node in rule_package.known_nodes.items():  
        if DiaGraph._need_IfElseNode(node):
            for idx, (operator, operand, child) in enumerate(node.children):
                dst_id = child.node_id
                operand = ast.literal_eval(operand)
                if not isinstance(operand, bool):
                    raise Exception("Operand for IfElseNode is either True/False but {} is found".format(operand))
                edges.append({
                    "source": node_id,
                    "sourceHandle": "{}-output".format(node_id),
                    "target": dst_id,
                    "targetHandle": "{}-input".format(dst_id),
                    "type": "EdgeSmooth",
                    "style": {
                        "stroke": "#26474C"
                    },
                    "id": "xy-edge__{}{}-output-{}{}-input".format(node_id, node_id, dst_id, dst_id),                
                    "data": {
                        "id": operand
                    }
                })
        elif isinstance(node, SwitchNode):
            for idx, (operator, operand, child) in enumerate(node.children):
                dst_id = child.node_id
                edges.append({
                    "source": node_id,
                    "sourceHandle": "{}-output".format(node_id),
                    "target": dst_id,
                    "targetHandle": "{}-input".format(dst_id),
                    "type": "EdgeSmooth",
                    "style": {
                        "stroke": "#26474C"
                    },
                    "id": "xy-edge__{}{}-output-{}{}-input".format(node_id, node_id, dst_id, dst_id),                
                    "data": {
                        "id": "case_{}".format(idx)
                    }
                })
            if node.default_child is not None:
                dst_id = node.default_child.node_id
                edges.append({
                    "source": node_id,
                    "sourceHandle": "{}-output".format(node_id),
                    "target": dst_id,
                    "targetHandle": "{}-input".format(dst_id),
                    "type": "EdgeSmooth",
                    "style": {
                        "stroke": "#26474C"
                    },
                    "id": "xy-edge__{}{}-output-{}{}-input".format(node_id, node_id, dst_id, dst_id),                
                    "data": {
                        "id": "default"
                    }
                })                      
        else:
            for child in node.children:
                if child is not None:
                    dst_id = child.node_id
                    edges.append({
                        "source": node_id,
                        "sourceHandle": "{}-output".format(node_id),
                        "target": dst_id,
                        "targetHandle": "{}-input".format(dst_id),
                        "type": "EdgeSmooth",
                        "style": {
                            "stroke": "#26474C"
                        },
                        "id": "xy-edge__{}{}-output-{}{}-input".format(node_id, node_id, dst_id, dst_id)
                    })         

    diagraph['edges'] = edges
    return diagraph

class PMMLCategory:
  """
  Class describing a categorical data type.

  Adapted from sklearn-pmml-model:
  Copyright (c) 2018, Dennis Collaris
  BSD 2-Clause License

  Parameters
  ----------
  base_type : callable
      The original native data type of the category. For example, `str`, `int` or `float`.

  categories : list
      List of all categories for a particular feature.

  ordered : bool
      Boolean indicating whether the categories are ordinal (sorting categories makes sense) or not.

  """

  def __init__(self, base_type, categories, ordered=False):
    assert isinstance(categories, list)
    assert isinstance(ordered, bool)

    self.base_type = base_type

    self.categories = [base_type(cat) for cat in categories]
    self.ordered = ordered

  def __eq__(self, other):
    return isinstance(other, PMMLCategory) and \
      self.base_type == other.base_type and \
      self.categories == other.categories and \
      self.ordered == other.ordered

  def __contains__(self, item):
    return item in self.categories

  def __call__(self, value):
    value = self.base_type(value)

    if value not in self:
      raise Exception(f'Invalid categorical value: {value}')

    return value
  
  def __str__(self):
    return str(self.categories)
  
  def __repr__(self):
    return str(self.categories)
  

class PMMLClassificationTree:
  '''
  PMMLClassificationTree has the same attributes as sklearn decision tree.
  https://scikit-learn.org/stable/auto_examples/tree/plot_unveil_tree_structure.html

  Adapted from sklearn-pmml-model:
  Copyright (c) 2018, Dennis Collaris
  BSD 2-Clause License
  '''

  switch_operator_mapping = {
    "equal": "=",
    "notEqual": "<>",
    "lessThan": "<",
    "lessOrEqual": "<=",
    "greaterThan": ">",
    "greaterOrEqual": ">="
  }

  python_operator_mapping = {
    "equal": "==",
    "notEqual": "!=",
    "lessThan": "<",
    "lessOrEqual": "<=",
    "greaterThan": ">",
    "greaterOrEqual": ">=",
    "isIn": "in",
    "isNotIn": "not in"
  }  

  array_regex = re.compile(r"""('.*?'|".*?"|\S+)""")

  def __init__(self, pmml):

    it = ET.iterparse(pmml)

    # Remove namespace
    ns_offset = None
    for _, el in it:
        if ns_offset is None:
            ns_offset = el.tag.find('}') + 1
        el.tag = el.tag[ns_offset:]  # strip all namespaces

    self.root = it.root
    self.classes_ = self.get_type(self.target_field).categories  # List of possible target classes
    self.n_classes_ = len(self.classes_)
    self.n_outputs_ = 1

    # Validate PMML
    if not all([e.find("FieldRef") is not None for e in self.root.findall(".//DerivedField")]):
        raise NotImplementedError("Feature transformation not supported")

    #print(self.tostring()) # Print whole XML
    #print('\n'.join([str(x) for x in self.field_mapping.items()]))  # Print fields and their data types
    
    treeModel = self.root.find('TreeModel')
    if treeModel is None: # Find TreeModel only in the first Segment of Segmentation
      treeModel = self.root.find('MiningModel[@functionName="classification"]/Segmentation/Segment/TreeModel')
    if treeModel is None:
      raise Exception('No TreeModel found in PMML document.')
    
    split = treeModel.get('splitCharacteristic')
    if split == 'binarySplit':
      first_node = treeModel.find('Node')
    else:
      first_node = self.unflatten(treeModel.find('Node'))
      
    #with open("../unflatten.xml", "w") as f:
    #  f.write(ET.tostring(first_node).decode())   
    #print(ET.tostring(first_node).decode())  # Print unflattened decision tree  

    self.binary_tree = first_node


  def tostring(self):
    return ET.tostring(self.root).decode()
  

  def findall(self, element, path):
    """Safe helper method to find XML elements with guaranteed return type."""
    if element is None:
      return []
    return element.findall(path)
  

  def get_type(self, data_field, derives=None):
    """
    Parse type defined in <DataField> object and returns it.

    Parameters
    ----------
    data_field : ET.Element
        <DataField> or <DerivedField> XML element that describes a column.

    derives : ET.Element
        <DataField> XML element that the derived field derives.

    Returns
    -------
    callable
        Type of the value, as a callable function.

    """

    op_type = data_field.get('optype')

    if op_type not in ['categorical', 'ordinal', 'continuous']:
      raise Exception('Unsupported operation type.')   
     
    data_type = data_field.get('dataType') 
    if data_type is None: 
      if op_type == 'continuous':
        data_type = 'float'
      elif op_type == 'categorical':
        data_type = 'string'

    type_mapping = {
      'string': str,
      'integer': int,
      'float': float,
      'double': float,
      'boolean': lambda x: x.lower() in ['1', 'true', 'yes'] if type(x) is str else bool(x),
      'date': date,
      'time': time,
      'dateTime': datetime,
      'dateDaysSince0': int,
      'dateDaysSince1960': int,
      'dateDaysSince1970': int,
      'dateDaysSince1980': int,
      'timeSeconds': int,
      'dateTimeSecondsSince0': int,
      'dateTimeSecondsSince1960': int,
      'dateTimeSecondsSince1970': int,
      'dateTimeSecondsSince1980': int,
    }

    if type_mapping.get(data_type) is None:
      raise Exception('Unsupported data type {}'.format(data_type))

    if op_type == 'continuous':
      # <DataField name="sepal length (cm)" optype="continuous" dataType="float"/>
      return type_mapping.get(data_type)
    else:
      # <DataField name="Class" optype="categorical" dataType="integer">
      #   <Value value="0"/>
      #   <Value value="1"/>
      #   <Value value="2"/>
      # </DataField>
      categories = [
        e.get('value')
        for e in self.findall(data_field, 'Value') + self.findall(derives, 'Value')
      ]

      return PMMLCategory(type_mapping[data_type], categories=categories, ordered=op_type == 'ordinal')
    

  @cached_property
  def field_mapping(self):
    """
    Map field name to a column index and lambda function that converts a value to the proper type.
    The column index is set for target column too (not set to None). 

    Returns
    -------
    { str: (int, callable) }
        Dictionary mapping column names to tuples with 1) index of the column
        and 2) type of the column.

    """
    target = self.target_field.get('name')
    #fields = {name: field for name, field in self.fields.items() if name != target}
    fields = {name: field for name, field in self.fields.items()}
    field_labels = list(fields.keys())

    field_mapping = {
      name: (
        field_labels.index(name),
        self.get_type(e)
      )
      for name, e in fields.items()
      if e.tag == 'DataField'
    }

    '''
    <DerivedField name="double(x3)" optype="continuous" dataType="double">
        <FieldRef field="x3"/>
    </DerivedField>
    '''
    field_mapping.update({
      name: (
        field_labels.index(e.find('FieldRef').get('field')),  # Use referenced field index
        self.get_type(e, derives=fields[e.find('FieldRef').get('field')])
      )
      for name, e in fields.items()
      if e.tag == 'DerivedField' and e.find('FieldRef') is not None
    })

    #field_mapping.update({
    #  self.target_field.get('name'): (
    #    None,
    #    self.get_type(self.target_field)
    #  )
    #})

    return field_mapping
  

  @cached_property
  def fields(self):
      """
      Return an ordered mapping from field name to XML DataField or DerivedField element.

      Returns
      -------
      OrderedDict { str: ET.Element }
          Where keys indicate field names, and values are XML elements.

      """
      data_dictionary = self.root.find('DataDictionary')
      global_transforms = self.root.find('TransformationDictionary')
      local_transforms = self.root.findall('.//LocalTransformations')  # Find all LocalTransformations in any level

      local_derived_fields = [self.findall(x, 'DerivedField') for x in local_transforms] # Return a list of lists of DeriedFields
      local_derived_fields = [field for sublist in local_derived_fields for field in sublist]  # Unflatten the list

      derived_fields = self.findall(global_transforms, 'DerivedField') + local_derived_fields

      fields = OrderedDict({
        e.get('name'): e
        for e in self.findall(data_dictionary, 'DataField')
      })

      if derived_fields:
        fields.update({
          e.get('name'): e
          for e in derived_fields
        })

      return fields


  @cached_property
  def feature_names(self) -> list[str]:
    """
    Return list of feature names used for classification, including those created by transformation.

    Returns
    -------
    list[str]
        List of feature names used for classification.

    """
    target = self.target_field.get('name')
    return [
      name
      for name in self.fields.keys()
      if name != target
    ]
  

  @cached_property
  def target_field(self) -> ET.Element:
    """
    Return the XML DataField or DerivedField element corresponding to the classification target.

    Returns
    -------
    ET.Element
        Representing the target field for classification, or None if no
        MiningSchema or MiningField specified.

    """
    mining_schema = next(self.root.iter('MiningSchema'), None)

    if mining_schema is not None:
      mining_field = next(
        (s for s in mining_schema if s.get('usageType') in ['target', 'predicted']),
        None
      )

      if mining_field is not None:
        return self.fields[mining_field.get('name')]

    return None  
  
  @cached_property
  def field_types(self) -> dict:
      """
      Return a mapping from field name (including derived fields) to python type.

      Returns
      -------
      dict 
          For example, {"name": str, "age": int}

      """
      return {key: value[1] for key, value in self.field_mapping.items()}
  

  @cached_property
  def datafield_types(self) -> dict:
      """
      Return a mapping from field name (excluding derived fields) to python type.

      Returns
      -------
      dict 
          For example, {"name": str, "age": int}

      """
      data_dictionary = self.root.find('DataDictionary')
      data_fields = [e.get('name') for e in self.findall(data_dictionary, 'DataField')]

      return {key: value[1] for key, value in self.field_mapping.items() if key in data_fields}
    

  def unflatten(self, node) -> ET.Element:
    """
    Convert a `multiSplit` into a `binarySplit` decision tree which is expressively equivalent.

    Parameters
    ----------
    node : ET.Element
        XML Node element representing the current node.

    Returns
    -------
    node : ET.Element
      Modified XML Node element representing the flattened decision tree.

    """    
    child_nodes = node.findall('Node')
    child_nodes = [
      node for node in child_nodes
      if getattr(node.find('SimplePredicate'), 'attrib', {}).get('operator') != 'isMissing'  # filter isMissing nodes
    ]

    parent = node
    node.set('uuid', str(uuid.uuid4()))  # Assign unique id to the root of the unflattened tree for debugging purposes
    for child in child_nodes:
      new_node = ET.Element('Node')
      new_node.append(ET.Element('True'))
      new_node.set('score', parent.get('score', '0'))
      new_node.set('uuid', str(uuid.uuid4()))
      new_node.set('new_node', '1')  # Assign new_node property for debugging purposes
      predicate = [e for e in parent if e.tag != 'Node']
      left_child = self.unflatten(child)

      if left_child.find('True') is not None and left_child.find('Node') is None:  # leaf node
        parent[:] = left_child[:]
        parent.attrib = left_child.attrib
      else:
        parent[:] = [*predicate, left_child, new_node]

      parent = new_node

    return node
  
  
  def parse_array(self, array):
    """
    Convert <Array> or <SparseArray> element into list.

    Parameters
    ----------
    array : eTree.Element (Array or SparseArray)
        PMML <Array> or <SparseArray> element, or type-prefixed variant (e.g., <REAL-Array>).

    Returns
    -------
    output : list
      Python list containing the items described in the PMML array element.

    """
    tag = array.tag.lower()
    array_type = array.get('type', '').lower()

    def is_type(t):
      return tag.startswith(t) or array_type == t

    if tag.endswith('sparsearray'):
      raise Exception("Sparse array found!")
      #return parse_sparse_array(array)

    if is_type('string'):
      # Deal with strings containing spaces wrapped in quotes (e.g., "like this")
      return [
        x.replace('"', '').replace('▲', '"')
        for x in PMMLClassificationTree.array_regex.findall(array.text.replace('\\"', '▲'))
      ]

    if is_type('int'):
      return [int(x) for x in array.text.split(' ')]

    if is_type('num') or is_type('real') or is_type('prob') or is_type('percentage'):
      return [float(x) for x in array.text.split(' ')]

    raise Exception('Unknown array type encountered.')


  def parse_simple_predicate(self, node, feature_names: list[str] = None) -> str:
      """
      Convert <SimplePredicate> into an expression. 

      Parameters
      ----------
      node : eTree.Element (SimplePredicate)
          A simple predicate tree.
      feature_names : list[str], optional
          A list of custom feature names to use instead of those in the PMML.          

      Returns
      -------
      output : str
        Expression string.

      """
      column, field_type = self.field_mapping[node.get('field')]

      # TODO: handle missing value predicates
      operand = field_type(node.get('value'))

      operator = PMMLClassificationTree.python_operator_mapping.get(node.get('operator'))
      if operator is None:
        raise Exception('Unknown how to process predicate operator {}'
                        .format(node.get('operator'))) 
      
      target_column, _ = self.field_mapping[self.target_field.get('name')]
      feature_column = column if column < target_column else column - 1
      feature_name = feature_names[feature_column] if feature_names is not None else list(self.fields.keys())[column]
      feature_name = re.sub('\W|^(?=\d)','_', feature_name)  # Remove special characters
      return "{} {} {}".format(feature_name, operator, repr(operand)) 


  def parse_simple_set_predicate(self, node, feature_names: list[str] = None) -> str:
      """
      Convert <SimpleSetPredicate> into an expression. 

      Parameters
      ----------
      node : eTree.Element (SimpleSetPredicate)
          A simple set predicate tree.
      feature_names : list[str], optional
          A list of custom feature names to use instead of those in the PMML.

      Returns
      -------
      output : str
        Expression string.

      """
      column, field_type = self.field_mapping[node.get('field')]

      # TODO: handle missing value predicates
      child = node.find('Array')
      if child is None:
        raise Exception('No Array child in SimpleSetPredicate')
      
      value = self.parse_array(child)
      n = child.get('n') # Optional number of elements.
      if n is not None and int(n) != len(value):
        raise Exception('Number of elements {} does not match n={}'
                        .format(len(value), n))

      operator = PMMLClassificationTree.python_operator_mapping.get(node.get('booleanOperator'))
      if operator is None:
        raise Exception('Unknown how to process set predicate operator {}'
                        .format(node.get('booleanOperator'))) 
      
      target_column, _ = self.field_mapping[self.target_field.get('name')]
      feature_column = column if column < target_column else column - 1
      feature_name = feature_names[feature_column] if feature_names is not None else list(self.fields.keys())[column]
      feature_name = re.sub('\W|^(?=\d)','_', feature_name)  # Remove special characters

      return "{} {} {}".format(feature_name, operator, repr(value))

  
  def parse_compound_predicate(self, node, feature_names: list[str] = None) -> str:
    """
    Convert <CompoundPredicate> into an expression. 

    Parameters
    ----------
    node : eTree.Element (CompoundPredicate)
        A compound predicate tree.
    feature_names : list[str], optional
          A list of custom feature names to use instead of those in the PMML.        

    Returns
    -------
    output : str
      Expression string.

    """
    operator = node.get('booleanOperator')
    if operator not in ['and', 'or', 'surrogate']:
      raise Exception('Unsupported compound predicate operator "{}"'.format(operator))

    expressions = []
    for child in node:
      if child.tag == 'SimplePredicate':
        expressions.append("({})".format(self.parse_simple_predicate(child)))
      elif child.tag == 'SimpleSetPredicate':
        expressions.append("({})".format(self.parse_simple_set_predicate(child)))  
      elif child.tag == 'CompoundPredicate':
        expressions.append("({})".format(self.parse_compound_predicate(child)))
      else:
        raise Exception('Unsupported predicate type "{}" in compound predicate.'.format(child.tag))
      
      if operator == 'surrogate': # Since we assume no missing value, the first predicate is enough.
          warnings.warn('Surrogate operator is replaced with first predicate only.')
          break

    if len(expressions) > 1:
        joiner = ' {} '.format(operator)
        return joiner.join(expressions)
    else:
        return expressions[0]
  

  def _votes_for(self, node, field):
    distribution = node.find(f"ScoreDistribution[@value='{field}']")

    # Deal with case where target field is a double, but ScoreDistribution value is an integer.
    if distribution is None and isinstance(field, float) and field.is_integer():
      return node.find(f"ScoreDistribution[@value='{int(field)}']")

    return distribution    
  

  def construct_tree(self, rulePackage: RulePackage, node, feature_names: list[str] = None, class_names: list[str] = None, i=0, rescale_factor=1):
    """
    Generate a graph from a classiciation tree in the RulePackage. 
    The return values are similar to those used in sklearn-pmml-model but ignored here.

    Parameters
    ----------
    node : ET.Element
        XML Node element representing the current node.

    feature_names : list[str], optional
        List of feature names.

    class_names: list[str], optional
        List of class names.

    i: int, optional
        Next available index

    rescale_factor : float, optional
        Factor to scale the output of every node with. Required for gradient
        boosting trees. Optional, and 1 by default.

    Returns
    -------
    (nodes, values) : tuple, but to be removed soon. Do not use.

        nodes : [()]
            List of nodes represented by: left child (int), right child (int),
            field index (int), value (int, float, str, bool),
            impurity (float), sample count (int) and weighted sample count (int).

        values : [[]]
            List with training sample distributions at this node in the tree.

    """

    child_nodes = node.findall('Node')
    impurity = 0  # TODO: impurity doesn't affect predictions, but is nice to have
    i += 1

    if not child_nodes:
      record_count = node.get('recordCount')

      if record_count is not None and self.classes_ is not None:
        node_count_weighted = float(record_count)
        node_count = int(node_count_weighted)
        votes = [[[float(self._votes_for(node, c).get('recordCount')) if self._votes_for(node, c) is not None else 0.0 for c in self.classes_]]]
      else:
        score = node.get('score')
        node_count, node_count_weighted = (0, 0.0)

        if self.classes_ is None:
          # FIXME: unsure about `10 x rescale_factor`, but seems required, at least for r2pmml generated models
          votes = [[[float(score) * 10 * rescale_factor]]]
        else:
          votes = [[[1.0 if str(c) == score else 0.0 for c in self.classes_]]]

      argmax = max(range(len(votes[0][0])), key=lambda i: votes[0][0][i])
      class_name = "{}".format(class_names[argmax] if class_names is not None else self.classes_[argmax])
      #print('Node {}: class {}'.format(i-1, class_name))
      flagNode = FlagNode("node_{}".format(i-1), flag=class_name, name=class_name, template={"tag": "gini", "value": impurity}, rule_package=rulePackage)
      return [(-1, -1, -1, -1, impurity,
              node_count, node_count_weighted)], votes

    predicate = child_nodes[0].find('SimplePredicate')
    compound_predicate = child_nodes[0].find('CompoundPredicate')
    set_predicate = child_nodes[0].find('SimpleSetPredicate')

    left_node, left_value = self.construct_tree(rulePackage, child_nodes[0], feature_names, class_names, i, rescale_factor)
    offset = len(left_node)
    right_node, right_value = self.construct_tree(rulePackage, child_nodes[1], feature_names, class_names, i + offset, rescale_factor)

    children = left_node + right_node
    distributions = left_value + right_value

    if predicate is not None:
      column, field_type = self.field_mapping[predicate.get('field')]
      selector = self.parse_simple_predicate(predicate, feature_names)
      operator = "eq"
      value = True

    elif compound_predicate is not None:
        column = -1  # No feature index for compound predicate
        selector = self.parse_compound_predicate(compound_predicate, feature_names)
        operator = "eq"
        value = True

    elif set_predicate is not None:
        column, field_type = self.field_mapping[set_predicate.get('field')]
        selector = self.parse_simple_set_predicate(set_predicate, feature_names)
        operator = "eq"
        value = True

    else:
      raise Exception('Unsupported tree format: unknown predicate structure in Node {}'
                      .format(child_nodes[0].get('id')))

    if self.classes_ is None:
      distribution = [[0]]
      sample_count_weighted = 0
      sample_count = 0
    else:
      distribution = [list(map(add, distributions[0][0], distributions[offset][0]))]
      sample_count_weighted = sum(distribution[0])
      sample_count = int(sample_count_weighted)

    #print('Node {}: {}'.format(i-1, selector))
    #print('Node {} (True) -> Node {}'.format(i-1, i))
    #print('Node {} (False) -> Node {}'.format(i-1, i + offset))
    switchNode = SwitchNode("node_{}".format(i-1), selector=selector, name=selector, description=selector, rule_package=rulePackage)
    switchNode.append_child("True", rulePackage.get_node("node_{}".format(i)), operator) # The left child has id i.
    switchNode.append_child("False", rulePackage.get_node("node_{}".format(i + offset)), operator) # The right child has id i + offset.
    #switchNode.set_default_child(rulePackage.get_node("node_{}".format(i + offset))) # The right child has id i + offset.
    return [(i, i + offset, column, value, impurity, sample_count, sample_count_weighted)] + children, \
          [distribution] + distributions


def from_pmml(pmml, package_id: str, feature_names: list[str] = None, class_names: list[str] = None) -> RulePackage:
    '''
    Convert PMML decision tree classifier to a RulePackage. If PMML contains multiple models, find only the first TreeModel in the first Segment. 

    Parameters
    ----------
    pmml: PMML filename, file pointer or PMMLClassificationTree
        A decision tree classifier to convert.
    package_id: str
        Package ID
    feature_names: list[str]
        A list of feature name.        
    class_names: list[str]
        A list of class name.   

    Returns:
    --------
    RulePackage
        RulePackage.
    '''       

    package = RulePackage(package_id)
    bigtable1 = BigTableNode("bigtable1", rule_package=package)
    package.attach(bigtable1)  # Fix bigtable1 name for being the parent of node_0

    if isinstance(pmml, PMMLClassificationTree):
        pmml_tree = pmml
    else:
        pmml_tree = PMMLClassificationTree(pmml)

    nodes, values = pmml_tree.construct_tree(package, pmml_tree.binary_tree, feature_names, class_names)
    
    bigtable1.add_child(package.get_node("node_0"))

    return package
