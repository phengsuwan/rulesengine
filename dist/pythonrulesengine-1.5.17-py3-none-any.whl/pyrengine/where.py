# https://dev.to/zchtodd/building-parsers-for-fun-and-profit-with-pyparsing-4l9e
# https://github.com/pyparsing/pyparsing/blob/master/examples/simpleArith.py
# https://github.com/pyparsing/pyparsing/blob/master/examples/simpleBool.py
# https://github.com/pyparsing/pyparsing/blob/master/examples/eval_arith.py
# https://docs.python.org/3/reference/grammar.html

from typing import Union
from pyparsing import *
import fnmatch
import inspect
from datetime import datetime

from pyrengine.op import OP
from pyrengine.null import NULL, NullType
from pyrengine.rulecontext import txcntx, lookupcntx, FUNCTIONCALL_SYMBOLS


# Not currently used due to nested placeholders issue.
# See BUG in MethodCall.find_placeholders()
class PlaceHolderFinderMixin:  # Helper class 
    def find_placeholders(self) -> set:
        return set()


class None__(PlaceHolderFinderMixin):
    def __init__(self, tokens):
        self.value = tokens[0]

    # obj is an object in OBJECTLIST
    # context refers to an outer transaction 
    def eval(self, obj, context=None) -> None:   # return None is equivalent to NoneType. https://stackoverflow.com/a/71559867
        return None

    def __str__(self):
        return "None"
    

class NULL__(PlaceHolderFinderMixin):
    def __init__(self, tokens):
        self.value = tokens[0]

    # obj is an object in OBJECTLIST
    # context refers to an outer transaction 
    def eval(self, obj, context=None) -> NullType:
        return NULL

    def __str__(self):
        return "NULL"    
    

class True__(PlaceHolderFinderMixin):
    def __init__(self, tokens):
        self.value = tokens[0]

    def eval(self, obj, context=None) -> bool:
        return True

    def __str__(self):
        return "True"    
    

class False__(PlaceHolderFinderMixin):
    def __init__(self, tokens):
        self.value = tokens[0]

    def eval(self, obj, context=None) -> bool:
        return False

    def __str__(self):
        return "False"   
    

class String(PlaceHolderFinderMixin):
    def __init__(self, tokens):
        self.value = tokens[0]

    def eval(self, obj, context=None) -> str:
        return self.value

    def __str__(self):
        return "'{}'".format(self.value.replace("'", "\\'"))


class Integer(PlaceHolderFinderMixin):
    def __init__(self, tokens):
        self.value = int(tokens[0])

    def eval(self, obj, context=None) -> int:
        return self.value

    def __str__(self):
        return f"{self.value}"


class Real(PlaceHolderFinderMixin):
    def __init__(self, tokens):
        self.value = float(tokens[0])

    def eval(self, obj, context=None) -> float:
        return self.value

    def __str__(self):
        return f"{self.value}"


class Identifier(PlaceHolderFinderMixin):
    def __init__(self, tokens):
        self.name = tokens[0]

    def eval(self, obj, context=None) -> object:
        if self.name not in obj:
            #return None
            raise InvalidExpressionException("Unknown column name {}".format(self.name))
        return obj[self.name]

    def __str__(self):
        return self.name


class PlaceHolder:
    def __init__(self, tokens):
        self.name = tokens[0].name # tokens[0] is an Identifier

    def eval(self, obj, context=None) -> object:
        if context is None:
            raise InvalidExpressionException("Placeholder '${}' requires transaction context".format(self.name))
        if self.name in context:
            return context[self.name]

        if self.name == 'LOOKUP':
            lookup = lookupcntx.get()
            if lookup is None:
                raise InvalidExpressionException("LOOKUP not set in lookup context")
            return lookup
         
        #return None
        raise UnknownPlaceHolderException("Unknown placeholder '${}' in context".format(self.name))

    def __str__(self):
        return f"${self.name}"
    
    def find_placeholders(self) -> set:
        return {self.name}    
    

class List__:
    def __init__(self, tokens):
        self.elements = tokens

    def eval(self, obj, context=None) -> list:
        return [e.eval(obj, context) for e in self.elements]

    def __str__(self):
        return "[{}]".format(', '.join([str(e) for e in self.elements]))

    def find_placeholders(self) -> set:
        return set.union(*[e.find_placeholders() for e in self.elements]) if self.elements else set()


class ArithAdd:
    def __init__(self, tokens):
        self.args = tokens[0]   # tokens[0] is an array of [operand, '+', operand, '-', operand, ...]

    def eval(self, obj, context=None) -> object:
        sum = self.args[0].eval(obj, context)
        it = iter(self.args[1:])
        for op, val in zip(it, it):   # Create pairs of (op, val) from remaining args
            if op == "+":
                sum += val.eval(obj, context)
            if op == "-":
                sum -= val.eval(obj, context)
        return sum    

    def __str__(self):
        return "({})".format(" ".join([str(arg) for arg in self.args]))   

    def find_placeholders(self) -> set:
        return set.union(*[self.args[i].find_placeholders() for i in range(0, len(self.args), 2)])     
    
        
class ArithMul:
    def __init__(self, tokens):
        self.args = tokens[0]   # tokens[0] is an array of [operand, '*', operand, '/', operand, ...]

    def eval(self, obj, context=None) -> object:
        prod = self.args[0].eval(obj, context)
        it = iter(self.args[1:])
        for op, val in zip(it, it):  # Create pairs of (op, val) from remaining args
            if op == "*":
                prod *= val.eval(obj, context)
            if op == "/":
                prod /= val.eval(obj, context)
        return prod
    
    def __str__(self):
        return "({})".format(" ".join([str(arg) for arg in self.args]))    

    def find_placeholders(self) -> set:
        return set.union(*[self.args[i].find_placeholders() for i in range(0, len(self.args), 2)])     
    

class BoolBinOp:
    pass


class BoolAnd(BoolBinOp):
    def __init__(self, tokens):
        self.args = tokens[0][0::2]   # tokens[0] is an array of [condition, 'and', condition, 'and', condition, ...] 

    def eval(self, obj, context=None) -> bool:
        return all([arg.eval(obj, context) for arg in self.args])

    def __str__(self):
        return "({})".format(" and ".join([str(arg) for arg in self.args]))
    
    def find_placeholders(self) -> set:
        return set.union(*[arg.find_placeholders() for arg in self.args])     


class BoolOr(BoolBinOp):
    def __init__(self, tokens):
        self.args = tokens[0][0::2]  # tokens[0] is an array of [condition, 'or', condition, 'or', condition, ...] 

    def eval(self, obj, context=None) -> bool:
        return any([arg.eval(obj, context) for arg in self.args])

    def __str__(self):
        return "({})".format(" or ".join([str(arg) for arg in self.args]))

    def find_placeholders(self) -> set:
        return set.union(*[arg.find_placeholders() for arg in self.args])     


class Condition:
    def __init__(self, tokens):
        self.lval = tokens[0]
        self.op = tokens[1]
        self.rval = tokens[2]
        if isinstance(self.op, str):        
            try:
                self.operator = OP[self.op]
            except (TypeError, KeyError) as error:
                # TODO: https://stackoverflow.com/questions/24716723/issue-extending-enum-and-redefining-getitem
                raise NotImplementedError('Unknown operator {} in where()'.format(self.op)) from None # https://stackoverflow.com/questions/52725278/during-handling-of-the-above-exception-another-exception-occurred

    def eval(self, obj, context=None) -> Union[None, bool]:
        # context argument can be passed by the caller or available globally per thred from TransactionContext. 
        # The current transaction is set into TransactionContext by the Rule.audit() or RulePackage.execute()
        # TODO: With good exception handling. https://stackoverflow.com/a/792163
        # TODO: Type checking for each operator, e.g. gt needs both operands have the same type 
        # TODO: Check and assign the specific operator at the __init__() to reduce several if-then-else statements.
        # TODO: How to handle obj without specified column (raise KeyError exception?)
        context = context if context is not None else txcntx.get()
        lval = self.lval.eval(obj, context)
        rval = self.rval.eval(obj, context)
        if self.operator in (OP.gt, OP['>']):
            return (lval is not None and rval is not None and lval > rval)
        elif self.operator in (OP.ge, OP['>=']):
            return (lval is not None and rval is not None and lval >= rval)
        elif self.operator in (OP.eq, OP['=']):
            return lval == rval
        elif self.operator in (OP.neq, OP['<>']):
            return lval != rval
        elif self.operator in (OP.lt, OP['<']):
            return (lval is not None and rval is not None and lval < rval)
        elif self.operator in (OP.le, OP['<=']):
            return (lval is not None and rval is not None and lval <= rval)
        elif self.operator == OP['is']:
            return lval is rval
        elif self.operator == OP['is_not']:
            return lval is not rval        
        elif self.operator in (OP.is_in, OP.is_not_in):
            switch = False if self.operator == OP.is_in else True  # It is used for XOR (^) 
            if isinstance(rval, list):
                return (lval in rval) ^ switch
            else:
                raise NotImplementedError('{} not supported by {} operator where() is_in/is_not_in'.format(type(rval), self.operator.name))
        elif self.operator in (OP.like, OP.not_like):
            switch = False if self.operator == OP.like else True  # It is used for XOR (^)
            return fnmatch.fnmatch(lval.lower(), rval.lower()) ^ switch
        elif self.operator in (OP.between, OP.not_between):  # rval is an array of [a, b]
            switch = False if self.operator == OP.between else True  # It is used for XOR (^)
            if not isinstance(rval, list) or len(rval) != 2:
                raise Exception('Operator {} requires [a, b] as the right operand'.format(self.operator.name))  
            if isinstance(rval[1], datetime):  # Specifically for datetime, right operator is <; otherwise <=.     
                return (lval is not None and rval is not None and ((lval >= rval[0] and lval < rval[1]) ^ switch))    
            return (lval is not None and rval is not None and ((lval >= rval[0] and lval <= rval[1]) ^ switch))
        else:
            raise NotImplementedError('Unknown operator {} in where() expression'.format(self.operator))        

    def __str__(self):
        return f"({self.lval} {self.op} {self.rval})"
    
    def find_placeholders(self) -> set:
        return set.union(self.lval.find_placeholders(), self.rval.find_placeholders()) 

    
class FunctionCall:
    def __init__(self, tokens):
        self.identifier = tokens[0]
        self.name = str(self.identifier)
        self.arguments = tokens[1:]

    def eval(self, obj, context=None) -> object:
        func = FUNCTIONCALL_SYMBOLS.get(self.name) #https://stackoverflow.com/questions/3061/calling-a-function-of-a-module-by-using-its-name-a-string 
        if func is None:
            raise InvalidExpressionException("Unknown function name '{}'".format(self.name))
        
        if not inspect.isfunction(func):
            raise InvalidExpressionException("'{}' is not a function".format(self.name))
        
        arguments =  [e.eval(obj, context) for e in self.arguments]
        return func(*arguments)

    def __str__(self):
        return "{}({})".format(self.name, ', '.join([str(e) for e in self.arguments]))    

    def find_placeholders(self) -> set:
        return set.union(*[arg.find_placeholders() for arg in self.arguments]) if self.arguments else set()     
    

class MethodCall:
    def __init__(self, tokens):
        self.object = tokens[0]
        self.groups = tokens[1:]

    def eval(self, obj, context=None) -> object:
        var = self.object.eval(obj, context)
        for group in self.groups:
            method = group[0]
            arguments = group[1:]    
            method_name = str(method)        
            attr = getattr(var, method_name, None)
            if attr is None and callable(attr):
                class_name = var.__name__ if isinstance(var, type) else var.__class__.__name__
                raise InvalidExpressionException("'{}' has no method '{}'".format(class_name, method_name))        
            
            arguments =  [arg.eval(obj, context) for arg in arguments]
            var = attr(*arguments)

        return var

    def __str__(self):
        method_list = ['{}({})'.format(str(group[0]), ', '.join([str(e) for e in group[1:]])) for group in self.groups]
        return "{}.{}".format(self.object, '.'.join(method_list))

    # BUG: Cannot find placeholders in the nested where() like obj.where('''fee_schedule_code is_in $total_group_cs_08.where('fee_schedule_code = $fsc')''')
    #      Only total_group_cs_08 is determined but not fsc because 'fee_schedule_code = $fsc' has been parsed as String. 
    #      We cannot call global find_placeholders('fee_schedule_code = $fsc') again because we need to call only if $total_group_cs08.where() is OBJECTLIST.where().
    #      ***But we don't know if $total_group_cs_08 is OBJECTLIST until we evaluate it.***
    #      The problem becomes harder if we have a chain of method calls like $a.select(['a', 'b']).where('fee_schedule_code = $fsc'). 
    #      This problem doesn't occur with self.eval() since self.eval() evalulates it and the chain of all methods.
    #      Due to this reason, The find_placeholders() and PlaceHolderMaxin are not used.
    def find_placeholders(self) -> set:
        return set.union(*([self.object.find_placeholders()] + [arg.find_placeholders() for group in self.groups for arg in group[1:]]))      


class Subscription:
    def __init__(self, tokens):
        self.subscriptable = tokens[0]
        self.indices = tokens[1:]

    def eval(self, obj, context=None) -> object:
        var = self.subscriptable.eval(obj, context)
        if not hasattr(var, "__getitem__") and not hasattr(var, "__class_getitem__"):
            raise InvalidExpressionException("'{}' not support subscription []".format(self.subscriptable))
        
        for index in self.indices:
            idx = index.eval(obj, context)
            try: 
                var = var[idx]
            except Exception as ex: 
                raise InvalidExpressionException("'{}' has index error for '{}'".format(self.subscriptable, index))
            
        return var

    def __str__(self):
        return "{}{}".format(self.subscriptable, ''.join(['[{}]'.format(index) for index in self.indices]))
    
    def find_placeholders(self) -> set:
        return set.union(*[idx.find_placeholders() for idx in self.indices])      
   

class InvalidExpressionException(Exception):
    pass    

class UnknownPlaceHolderException(InvalidExpressionException):
    pass
     
none__ = Keyword("None").set_parse_action(None__)
null__ = Keyword("NULL").set_parse_action(NULL__)
true__ = Keyword("True").set_parse_action(True__)
false__ = Keyword("False").set_parse_action(False__)
identifier = (Word(alphas + "_", alphanums + "_")).set_parse_action(Identifier)
placeholder = (Suppress("$") + identifier).set_parse_action(PlaceHolder)
string = QuotedString(quoteChar="'", escChar="\\").set_parse_action(String)
integer = Combine(Optional(Char("+" + "-")) + Word(nums)).set_parse_action(Integer)
real = Combine(Optional(Char("+" + "-")) + Word(nums) + '.' + ZeroOrMore(Word(nums))).set_parse_action(Real)
number = real | integer
term = none__ | null__ | true__ | false__ | identifier | number | string | placeholder
arithexprs = Forward() # Forward declaration for arithmetic expression 
function_call = Forward() # Forward declaration for 'func(args)'
method_call = Forward() # Forward declaration for 'object.method(args)'
subscription = Forward() # Forward declaration for 'array[idx]' or 'dict[key]'
# TODO: Support casting '2020-10-01'::DATETIME
list__ = (Suppress("[") + Optional(delimitedList(function_call | term)) + Suppress("]")).set_parse_action(List__)

# function_call as defined by identifier() takes higher priority to prevent parsing to normal identifier without '()'.
# method_call takes higher priority than function_call as function_call is the first part of subscription.
# subscription takes higher priority than method_call and function_call as they are the first part of subscription.
# Note: after we allow arithexprs in operand, the parsing time grows several times larger.
operand = subscription | method_call | function_call | arithexprs | term | list__
#operand.set_name("OPERAND")   # The set_name() and set_debug() is used to debug the pyparsing.
#operand.set_debug()  # The set_name() and set_debug() is used to debug the pyparsing.

_add_ = oneOf(["+", "-"])
_mul_ = oneOf(["*", "/"])
arith_operand = subscription | method_call | function_call | term 
#arith_operand = number
#arith_operand.set_name("ARITHOPERAND")
#arith_operand.set_debug()
arithexprs <<= infixNotation(
    arith_operand,
    [
        (_mul_, 2, opAssoc.LEFT, ArithMul),
        (_add_, 2, opAssoc.LEFT, ArithAdd)
    ]
)
#arithexprs.set_name("ARITHEXPRS")
#arithexprs.set_debug()

_and_ = Literal("and")
_or_ = Literal("or")
operator = oneOf(["is", "is_in", "is_not_in", "eq", "=", "neq", "<>", "gt", ">", "lt", "<", "ge", ">=", "le", "<=", "like", "not_like", "between", "not_between"])
#operator.set_name("OPERATOR")
#operator.set_debug()

conditions = Forward()
condition = (operand + operator + operand).set_parse_action(Condition)
conditions <<= infixNotation(
    condition,
    [
        (_and_, 2, opAssoc.LEFT, BoolAnd),
        (_or_, 2, opAssoc.LEFT, BoolOr)
    ]
)

function_call <<= (identifier + Suppress("(") + Optional(delimitedList(operand)) + Suppress(")")).set_parse_action(FunctionCall)
method_call <<= ( (function_call | identifier | placeholder) + OneOrMore(Group(Suppress(".") + identifier + Suppress("(") + Optional(delimitedList(operand)) + Suppress(")"))) ).set_parse_action(MethodCall) 
subscriptable = function_call | method_call | identifier | placeholder | list__
subscription <<= (subscriptable + OneOrMore(Suppress("[") + term + Suppress("]"))).set_parse_action(Subscription) # TODO: Allow array index from expression evaluation
#subscription.set_name("SUBSCRIPTION")
#subscription.set_debug()

__WHERE_CACHE = {}  # Cache to improve performance

def parse_string(expression: str, cache=True) -> Union[BoolBinOp, Condition]:
    try: 
        if cache:
            if expression not in __WHERE_CACHE:        
                __WHERE_CACHE[expression] = conditions.parse_string(expression, parse_all=True) # Set parse_all = True for the entire expression to match the grammar.
            parseResults = __WHERE_CACHE[expression]
        else:
            parseResults = conditions.parse_string(expression, parse_all=True) # Set parse_all = True for the entire expression to match the grammar.
        return parseResults[0]
    except ParseException as ex:
        raise InvalidExpressionException("Cannot parse where() expression {}: {}".format(expression, ex))
    

# Not currently used due to nested placeholders issue.
def find_placeholders(expression: str) -> set:
    parseResults = conditions.parse_string(expression, parse_all=True) 
    return parseResults[0].find_placeholders()