from pyrengine.objectlist import OBJECTLIST
from pyrengine.objectlist import ARRAY


# filter fields that contain array list and convert
# into OBJECTLIST object
def convert(input_json):
    fields_names = list(input_json.keys())
    for fn in fields_names:
        if type(input_json[fn]) is list : 
            if len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict :
                input_json[fn] = OBJECTLIST(input_json[fn])
            else: 
                input_json[fn] = ARRAY(input_json[fn])
    return input_json

# This is the previous version of convert
# def convert(input_json):
#     fields_names = list(input_json.keys())
#     for fn in fields_names:
#         if type(input_json[fn]) is list and len(input_json[fn]) != 0 and type(input_json[fn][0]) is dict:
#             input_json[fn] = OBJECTLIST(input_json[fn])
#     return input_json


# Update the rule dict by *non-verbose* audit tree dict. The structure of rule dict and 
#   result dict are required to be compatible; otherwise an exception or unexpected outcome occurs.
# https://stackoverflow.com/questions/71396284/python-how-to-recursively-merge-2-dictionaries
def merge_rule_result(rule: dict, result: dict):
    for key, val in result.items():
        if key == "__result__":
            rule[key] = val
            continue

        if key in rule:
            if isinstance(val, dict):
                if not isinstance(rule[key], dict):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a dict".format(key))
                merge_rule_result(rule[key], val)
            elif isinstance(val, list):
                if not isinstance(rule[key], list):
                    #target[key] = {}
                    raise Exception("Expect the value of rule's key {} to be a list".format(key))
                if len(val) != len(rule[key]):
                    raise Exception("The value of rule's key {} has different length than that of result".format(key))
                for i in range(len(val)):
                    if not isinstance(val[i], dict):
                        raise Exception("Expect element {} of result's key {} to be a dict".format(i, key))
                    if not isinstance(rule[key][i], dict):
                        raise Exception("Expect element {} of rule's key {} to be a dict".format(i, key))                
                    merge_rule_result(rule[key][i], val[i])
            else:
                pass # Skip other primitive values
        else:
            raise Exception('Unknown result key {}'.format(key))
