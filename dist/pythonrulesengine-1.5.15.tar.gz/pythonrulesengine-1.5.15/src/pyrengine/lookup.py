from __future__ import annotations # For forware reference
import json
import csv
import os
import sys
import logging
from typing import Type, Self
from ast import literal_eval

from pyrengine.objectlist import ARRAY, OBJECTLIST
from pyrengine.op import OP
from pyrengine.where import parse_string
from typing import Union

REFERENCE_DIR = "./db/lookup"

# Disable pdoc3 document generating for developer methods
__pdoc__ = {
    'LOOKUP.cache': False,
    'LOOKUP.listtable': False,
    'LOOKUP.load': False,
    'LOOKUP.reference_dir': False,
    'LOOKUP.remove': False,
    'LOOKUP.reset': False,
    'LOOKUP.set': False,
    'LOOKUP.set_reference_dir': False,
    'LOOKUP_TABLE_META': False,
}

# current version will support only three data types
# another data type will be proceeded by 'eval' method 
TYPE_CONVERTER = {
    'str': str,
    'float': float,
    'int': int,
}


# Make inherited methods like LOOKUP.where() to returns LOOKUP_TABLE instead of OBJECTLIST.
# https://stackoverflow.com/questions/65917217/wrap-all-methods-of-python-superclass
# https://discuss.python.org/t/return-child-object-when-parent-methods-are-called/21337/2
def _wrap_objectlist_method(fun):
    """Turn from Base- to Child-instance-returning function."""
    def wrapper(*args, **kwargs):
        result = fun(*args, **kwargs)
        if type(result) is OBJECTLIST:
            return LOOKUP_TABLE(result)
        return result
    
    return wrapper


# This class is no longer used as we use type(self) in the OBJECTLIST method instead.
# This class and function _wrap_objectlist_method() can be removed in the future.
# LOOKUP_TABLE_META class is used to override __new__() method of the LOOKUP_TABLE class.
# https://divyakhatnar.medium.com/metaclass-in-python-bbf4a628e978
class LOOKUP_TABLE_META(type):

    def __new__(cls, name, bases, dct):
        child = super().__new__(cls, name, bases, dct)
        for base in bases:
            for field_name, field in base.__dict__.items():  # For inherited fields
                # https://stackoverflow.com/questions/7751930/is-there-a-way-to-identify-an-inherited-method-in-python
                if callable(field) and field_name not in child.__dict__:  # Field is a method and it is not overridden
                    setattr(child, field_name, _wrap_objectlist_method(field))
        return child    
    

class LOOKUP():   
    """
    LOOKUP is used to access a static lookup table from external source like JSON or CSV file.

    Example
    -------
    The following expression returns the lookup table named 'group_cs_05'.
    >>> LOOKUP.get('group_cs_05')

    Or equivalently, 
    >>> LOOKUP['group_cs_05']
    """    
    cache = {}
    reference_dir = REFERENCE_DIR

    # set_reference_dir is used to set the lookup table base directory 
    @classmethod
    def set_reference_dir(cls, reference_dir=REFERENCE_DIR): 
        cls.reference_dir = reference_dir


    @classmethod
    def __dtype(cls, val, data_type) -> Type:
        #try:
        #    result = TYPE_CONVERTER[data_type](val)
        #    # result = TYPE_CONVERTER[data_type](literal_eval(val))
        #except KeyError:
        #    try: 
        #        result = literal_eval(val)
        #    except: 
        #        result = None
        #except Exception as e:
        #    result = None
        result = TYPE_CONVERTER[data_type](val)
        return result


    # check a file in the lookup table directory and identify file type (json or csv)
    # if file does not exist or file extensions are not json nor csv, the method will return None
    @classmethod
    def __lookup_file(cls, name: str) -> str: 
        if os.path.isfile('{}/{}.json'.format(cls.reference_dir, name)): 
            lftype = "json"
        elif os.path.isfile('{}/{}.csv'.format(cls.reference_dir, name)): 
            lftype = "csv"
        else: 
            print('file {}'.format(name) + ' missed, either json or csv format')
            lftype = None

        return lftype


    # load csv file to create lookup table
    @classmethod
    def __lookup_csv(cls, name: str) -> LOOKUP_TABLE: 
        filename = '{}/{}.csv'.format(cls.reference_dir, name)
        #print('Loading {}'.format(filename))
        try: 
            with open(filename, 'r', encoding="utf8") as f:
                cr = csv.reader(f, delimiter=',')
                headers = next(cr, None)
                dtypes = next(cr, None)
                num_cols = len(headers)
                csv_dict = [{headers[i]: cls.__dtype(row[i], dtypes[i]) for i in range(num_cols)} for row in cr]
                ref = LOOKUP_TABLE(csv_dict)
                cls.cache[name] = ref
                return ref
        except Exception as ex:
            print('Loading file {}'.format(filename) + ' failed: {}'.format(ex))
            return None


    # TODO: Check file format.
    # TODO: Error handling.
    @classmethod
    def __load_json(cls, name: str) -> LOOKUP_TABLE:
        filename = '{}/{}.json'.format(cls.reference_dir, name)
        #print('Loading {}'.format(filename))
        try:
            with open(filename, 'r') as f:
                ref = json.load(f)
                ref = LOOKUP_TABLE(ref)
                cls.cache[name] = ref
                return ref
        except Exception as ex:
            print('Loading file {}'.format(filename) + ' failed: {}'.format(ex))
            return None


    @classmethod
    def load(cls, name: str) -> LOOKUP_TABLE:
        lf_type = cls.__lookup_file(name)
        if lf_type is not None: 
            f_lookup = cls.__load_json if lf_type == "json" else cls.__lookup_csv
            return f_lookup(name)
        else: 
            return None


    @classmethod
    def get(cls, name: str) -> LOOKUP_TABLE:
        """
        Return a static lookup table from external source like JSON or CSV file.

        Returns
        -------
        `pyrengine.lookup.LOOKUP_TABLE`
            A static lookup table from external source like JSON or CSV file.

        Example
        -------
        The following expression returns the lookup table named 'group_cs_05'.
        >>> LOOKUP.get('group_cs_05')

        Or equivalently, 
        >>> LOOKUP['group_cs_05']        

        Raises
        ------
        Exception
            Any errors cause exception.
        """            
        if name not in cls.cache:
            rt=cls.load(name)
            if rt is None:
                 #return None
                 raise Exception("Fail to load LOOKUP {}".format(name))

        return cls.cache[name]

    # Class subscription
    # https://stackoverflow.com/a/63663183
    # https://stackoverflow.com/questions/73562722/extending-generic-class-getitem-in-python-to-accept-more-params
    @classmethod
    def __class_getitem__(cls, name: str) -> LOOKUP_TABLE:  # Support LOOKUP[name]  
        return cls.get(name)
        
    @classmethod
    def set(cls, name: str, db: Union[list, OBJECTLIST]) -> bool:
        if not isinstance(db, OBJECTLIST):
            db = OBJECTLIST(db)
        cls.cache[name]=db
        return True

    @classmethod
    def remove(cls, name: str) -> bool:
        rf=False
        if name in cls.cache:
            rf=True
            del cls.cache[name]

        return rf

    @classmethod
    def listtable(cls) -> list:
        ret=[]
        for r in cls.cache.keys():
            ret.append(r)

        return ret
    
    @classmethod
    def reset(cls) -> bool:
        cls.cache.clear()

        return True
    

#class LOOKUP_TABLE(OBJECTLIST, metaclass=LOOKUP_TABLE_META):  # Use LOOKUP_TABLE_META to wrap superclass methods 
class LOOKUP_TABLE(OBJECTLIST):
    '''
    LOOKUP_TABLE is a subclass of `pyrengine.objectlist.OBJECTLIST`. 
    It refers to an OBJECTLIST that stays constant and is used many times within a transaction or with many transactions.
    LOOKUP_TABLE uses hash indices when joined with the left OBJECTLIST. The indices are automatically created during the first use.
    So, the first use is slow but the subsequent uses are fast. 
    For example, 
    >>> objectlist.inner_join(lookup_table, 'fscode')

    Note: but if used as in the left side like `lookup_table.inner_join(objectlist)`, it won't use indices.

    LOOKUP_TABLE methods always return a new LOOKUP_TABLE, either cached or uncached. 
    Some parent methods are overrided to return the cached LOOKUP_TABLE output such as select() and select_distinct().
    So calling `objectlist.inner_join(lookup_table.select(['fscode', 'max_qty']))` is fast.
    
    Other methods return the new LOOKUP_TABLE which is not cached. For example using `objectlist.inner_join(lookup_table.rename('qty', 'max_qty'))` 
    on different transactions will be so slow as a new LOOKUP_TABLE will be created every time the lookup_table.rename('qty', 'max_qty') is called.
    The index created for every new LOOKUP_TABLE in the previous call is not used in the next call.

    '''  
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.index_on_keys = {}
        self.set_of_objects = None # A set of objects for faster lookup. Each object is stored as a frozenset of key-value pairs. For example, {FrozenSet{('name', 'john'), ('age', 40)}, FrozenSet{('name', 'mary'), ('age', 10)}}. 

        # We keep cache separately for each method as it is slightly faster than using a single cache for all methods.
        # Note: we can use a single cache for all methods by including the method name into the key.
        self.select_cache = {}  # Cache of select() output.
        self.select_distinct_cache = {}  # Cache of select_distinct() output.
        self.where_cache = {}  # Cache of where() output.


    # Private methods begin with __
    def __build_index(self, on_keys: list[str]) -> dict:
        index = {}
        for obj in self.data:
            keys = tuple([obj.get(key) for key in on_keys])
            objs = index.get(keys)
            if objs is None:
                objs = []
                index[keys] = objs
            index[keys].append(obj)
        self.index_on_keys[tuple(on_keys)] = index
        return index


    # @override
    def _get_possible_objects_by_keys(self, on_keys: list[str], values: list[object]) -> list[dict]:
        if len(on_keys) != len(values):
            raise Exception("Size of argument on_keys {} and values {} not matched".format(on_keys, values))
        index = self.index_on_keys.get(tuple(on_keys))
        if index is None:
            #raise Exception('No index on keys {}'.format(on_keys))
            index = self.__build_index(on_keys)

        objs = index.get(tuple(values), [])
        return objs 


    # @override
    # use_cache is developer parameter to test performance
    def select(self, column: Union[str, list], use_cache=True) -> Union[ARRAY, Self]:
        if isinstance(column, list):
            k = tuple(column)
        else:
            k = column
        if not use_cache or k not in self.select_cache:
            output = super().select(column)
            if type(output) is OBJECTLIST:
                output = type(self)(output)
            self.select_cache[k] = output

        return self.select_cache[k]
    
    
    # @override
    # use_cache is developer parameter to test performance
    def select_distinct(self, column: Union[str, list], use_cache=True) -> Union[ARRAY, Self]:
        if isinstance(column, list):
            k = tuple(column)
        else:
            k = column
        if not use_cache or k not in self.select_distinct_cache:
            output = super().select_distinct(column)
            if type(output) is OBJECTLIST:
                output = type(self)(output)
            self.select_distinct_cache[k] = output

        return self.select_distinct_cache[k]    
    

    # @override
    # use_cache is developer parameter to test performance
    def where(self, column: str, operator: Union[OP, str] = None, value: Union[str, int, float, list] = None, use_cache=True) -> Self:
        if operator is not None and value is not None and isinstance(value, (str, int)):
            # Do not use cache for where() expression as it may contains variables and placeholders 
            #   which make the key dynamically depend on the values of the transaction. For example,
            #   lookup.where('qty < $max_qty'), the string 'qty < $max_qty' is not a constant key as $max_qty varies in diffrent transactions.
            # So a single cache 'qty < $max_qty' is not enough to store all possible values of $max_qty.
            # Also support only str and int value, e.g.
            #   lookup.where('group', 'eq', 'IT')
            #   lookup.where('qty', 'lt', 50)
            #   lookup.where('qty', 'lt', max_qty)  
            # Here, the key ('qty', 'lt', max_qty) is constant because max_qty has been substitued by its value. 
            # If two transactions have 10 and 20 max_qty values, caches are created for ('qty', 'lt', 10) and ('qty', 'lt', 20).
            k = (column, operator, value) 
        else:
            logging.warning('LOOKUP_TABLE.where(column, operator, value) supports only simple str and int values, so cache is disabled.')
            use_cache = False
            k = ''

        if not use_cache or k not in self.where_cache:
            output = super().where(column, operator, value)

            if type(output) is OBJECTLIST:
                output = type(self)(output)
            self.where_cache[k] = output

        return self.where_cache[k]        
    

    # @override
    def __contains__(self, obj: dict) -> bool:
        if self.set_of_objects is None:
            try:
                self.set_of_objects = frozenset([frozenset(obj.items()) for obj in self.data])
            except Exception as ex:
                raise Exception('Fail to build object hash for LOOKUP_TABLE, {}'.format(ex)).with_traceback(sys.exc_info()[2]) from ex 
        
        return frozenset(obj.items()) in self.set_of_objects
     

    def to_string(self) -> str:    
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([str(o) for o in self.data]))
        else:
            table = ''
        return '{}([{}])'.format(type(self).__name__, table)   


    def __repr__(self) -> str:
        if len(self.data):
            table = '\n    {}\n'.format('\n    '.join([repr(o) for o in self.data]))
        else:
            table = ''        
        return '{}([{}])'.format(type(self).__name__, table)     
     

# LOOKUP_ARRAY is an immutable ARRAY that some operations faster by using set, for example,
#  obj in A
#  A.contains(obj)
#  A.is_overlap(other)
# See https://wiki.python.org/moin/TimeComplexity.
class LOOKUP_ARRAY(ARRAY):
    # @Override
    def __init__(self, *args):
        super().__init__(*args)
        self.set_data = frozenset(self)

    # @Override
    def __contains__(self, obj):  # obj in A
        return obj in self.set_data
    
    # @Override
    def contains(self, obj: object) -> bool:
        return obj in self.set_data    
    
    # This is for LOOKUP_ARRAY.is_overlap()
    # TODO: Make ARRAY.is_overlap() use LOOKUP_ARRAY.set_data. 
    # @Override    
    def is_overlap(self, other: list) -> bool:     
        if not isinstance(other, list):
            raise Exception('LOOKUP_ARRAY.is_overlap() requires a list argument')
        if isinstance(other, LOOKUP_ARRAY):
            return len(self.set_data.intersection(other.set_data)) > 0
        else:
            # LOOKUP_ARRAY is usually longer than the other list, so we loop through the other list.
            return len([obj for obj in other if obj in self.set_data]) > 0

    # This is for LOOKUP_ARRAY.intersect()
    # TODO: Make ARRAY.intersect() use LOOKUP_ARRAY.set_data. 
    # @Override        
    def intersect(self, other: list) -> ARRAY:
        if isinstance(other, LOOKUP_ARRAY):
            return ARRAY(self.set_data.intersection(other.set_data))        
        else:
            return ARRAY(self.set_data.intersection(set(other)))        
    
    def to_set(self) -> set:
        return self.set_data

    # @Override
    def insert(self, i, v):
        raise Exception('{} does not support insert()'.format(self.__class__.__name__))
    
    # @Override
    def append(self, v):
        raise Exception('{} does not support append()'.format(self.__class__.__name__))    

    # @Override
    def extend(self, v):
        raise Exception('{} does not support extend()'.format(self.__class__.__name__))
    
    # @Override
    def pop(self, *v):  # v is an optional argument
        raise Exception('{} does not support pop()'.format(self.__class__.__name__))
    
    # @Override
    def clear(self):
        raise Exception('{} does not support clear()'.format(self.__class__.__name__)) 

    # @Override
    def remove(self, v):
        raise Exception('{} does not support remove()'.format(self.__class__.__name__))     

    # @Override
    def reverse(self):
        raise Exception('{} does not support reverse()'.format(self.__class__.__name__))  

    # @Override
    def sort(self, *args):
        raise Exception('{} does not support sort()'.format(self.__class__.__name__))        
        
    # @Override
    def __iadd__(self, v):  # In-place add, IMMUTABLE_ARRAY += list, not allowed; but IMMUTABLE_ARRAY + list returns a new list.
        raise Exception('{} does not support +='.format(self.__class__.__name__))   

    # @Override
    def __imul__(self, v):  # In-place mul, IMMUTABLE_ARRAY *= 2
        raise Exception('{} does not support *='.format(self.__class__.__name__))        
    
    # @Override
    def __setitem__(self, i, v):
        raise Exception('{} does not support assignment'.format(self.__class__.__name__))    
    
    # @Override
    def __setslice__(self, i, j, v):
        raise Exception('{} does not support assignment'.format(self.__class__.__name__))    
    
    # @Override
    def __delitem__(self, *args):
        raise Exception('{} does not support del'.format(self.__class__.__name__))    
             