import ast
import json
import jsonschema


class ExprToJson(ast.NodeVisitor):
    """
    This class is a subclass of ast.NodeVisitor and will traverse the AST node of an expression. 
    It is used to convert an expression to a python dictionary according to the "Json Rule Grammar" rules,
    allowing for the creation of a JSON rule object.

    Arguments
    ---------
    schema_path: str
        The path to the schema file for validation of the resulting python dict.
    
    bypass_schema: bool, default=False
        If True, the schema validation for resulting python dict will be bypassed.
    
    chain: bool, default=True
        when converting to a python dict, the function calls within expressions will be stored under the "chain" key.

    Example
    -------
    >>> expr_to_json = ExprToJson(schema_path="./schema/json_rule.schema")

    """ 
    def __init__(self, schema_path: str, bypass_schema: bool = False, chain: bool = True) -> None:
        try:
            with open(schema_path, "r") as f:
                self.schema = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError("Schema file not found.")
        self.chain = chain
        self.bypass = bypass_schema
        if self.chain:
            self.call_stack = {}
            self.call_arg_stack = CallStack()
            self.call_arg = False
            self.call_arg_index = 0

    def convert(self, expr: str) -> dict:
        """
        This method converts an expression to a rule based on the "Json Rule Grammar" 
        and validates the resulting rule against the provided schema.
        
        Return the coversion result of an given expression to a python dict.
        
        Arguments
        ----------
        expr : str
            Expression to be converted. Needs to be a valid python expression and a string.

        Returns
        -------
        dict
            The resulting rule from the conversion of the expression.

        Example
        -------
        >>> expr_to_json.convert("test == 1")
        """
        tree = ast.parse(expr)
        self.visit(tree)
        if not self.bypass:
            jsonschema.validate(self.json, self.schema)
        return self.json

    def visit_Expr(self, node: ast.Expr) -> None:
        self.json = {"conditions": self.visit(node.value)}

    def visit_BoolOp(self, node: ast.BoolOp) -> dict:
        if isinstance(node.op, ast.And):
            return {
                "all": [self.visit(value) for value in node.values]
            }
        elif isinstance(node.op, ast.Or):
            return {
                "any": [self.visit(value) for value in node.values]
            }

    def visit_Call(self, node: ast.Call) -> dict:
        struct_call = self.visit(node.func)
        args = []

        for arg in node.args:

            if "$ref" in struct_call.get("fact", {}):
                if struct_call["method"] == "get":
                    struct_call["fact"]["$ref"] = self.visit(arg)
                    del struct_call["method"]
                    return struct_call
                elif struct_call["method"] == "select":
                    struct_call["fact"]["field"] = self.visit(arg)
                    del struct_call["method"]
                    return struct_call

            if self.chain and isinstance(arg, ast.Call):

                self.call_arg = True
                self.call_arg_index += 1

                arg_func = self.visit(arg)
                self.call_arg_index -= 1

                if self.call_arg_index == 0:
                    self.call_arg = False

                argument = arg_func
            else:
                argument = self.visit(arg)

            args.append(argument)

            # When an argument is an object, it may represent a function or method call.
            # Therefore, the expression `isinstance(args[-1].get("fact"), dict)` is used to check 
            # that there is an excess "fact" key in the argument that needs to be removed.
            if isinstance(args[-1], dict) and isinstance(args[-1].get("fact"), dict):
                args[-1] = args[-1]["fact"]

        struct_call.update({"args": args} if args else {})

        if struct_call.get("fact") == "DATE":
            date_func = {"function":  f"DATE.{struct_call['method']}"}
            date_func.update(struct_call)
            del date_func["method"], date_func["fact"]
            return {"fact": date_func}

        if self.chain:
            if self.call_arg:
                if "chain" not in struct_call:
                    self.call_arg_stack.create(self.call_arg_index, {
                        "fact": struct_call["fact"], "chain": []})
                elif "$ref" in struct_call.get("fact", {}):
                    self.call_arg_stack.create(self.call_arg_index, {
                        "fact": {"$ref": struct_call["fact"]["$ref"]}, "chain": []})

                self.call_arg_stack.chain(self.call_arg_index,
                                  {"method": struct_call["method"], "args": struct_call["args"]} if struct_call.get("args") else {"method": struct_call["method"]})

                return self.call_arg_stack.getStack(self.call_arg_index)
            else:
                if isinstance(struct_call.get("fact"), str):
                    self.call_stack = {"fact": struct_call["fact"], "chain": []}
                elif "$ref" in struct_call.get("fact", {}):
                    self.call_stack = {
                        "fact": {"$ref": struct_call["fact"]["$ref"]}, "chain": []}

                self.call_stack["chain"].append(
                    {"method": struct_call["method"], "args": struct_call["args"]} if struct_call.get("args") else {"method": struct_call["method"]})

                return {"fact": self.call_stack}

        if isinstance(node.func, ast.Attribute):
            struct_call = {"fact": struct_call}

        return struct_call

    def visit_Attribute(self, node: ast.Attribute) -> dict:
        struct_attr = {"method": node.attr}
        struct_attr.update(self.visit(node.value))

        return struct_attr

    def visit_Compare(self, node: ast.Compare) -> dict:
        struct_compare = {}
        right = self.visit(node.comparators[0])
        struct_compare.update(self.visit(node.left))
        struct_compare.update({
            "operator": self.visit(node.ops[0]),
            "value": right if not isinstance(right, dict) or isinstance(node.comparators[0], ast.Name) else right["fact"]
        })
        return struct_compare

    def visit_Subscript(self, node: ast.Subscript) -> str:
        struct_script = self.visit(node.value)
        struct_script["fact"] += f"['{self.visit(node.slice)}']"
        return struct_script

    def visit_List(self, node: list) -> list:
        struct_list = []
        for data in node.elts:
            struct_list.append(self.visit(data))
        return struct_list
    
    def visit_BinOp(self, node: ast.BinOp) -> dict:
        struct_op = {"function": self.visit(node.op), "args": []}
        struct_op["args"].append(self.visit(node.left)["fact"])
        struct_op["args"].append(self.visit(node.right)["fact"])
        return {"fact": struct_op}
    
    def visit_Add(self, node: ast.Add) -> str:
        return "ADD"

    def visit_Name(self, node: ast.Name) -> dict:
        return {"fact": node.id if node.id != "LOOKUP" else {"$ref": ""}} 

    def visit_Constant(self, node: ast.Constant) -> str:
        return node.value

    def visit_In(self, node: ast.In) -> str:
        return "in"

    def visit_Eq(self, node: ast.Eq) -> str:
        return "eq"

    def visit_NotEq(self, node: ast.NotEq) -> str:
        return "nq"

    def visit_GtE(self, node: ast.GtE) -> str:
        return "ge"

    def visit_Gt(self, node: ast.Gt) -> str:
        return "gt"

    def visit_LtE(self, node: ast.LtE) -> str:
        return "le"

    def visit_Lt(self, node: ast.Lt) -> str:
        return "lt"

    def __repr__(self) -> str:
        return repr(self.json)

    def __str__(self) -> str:
        return json.dumps(self.json, indent=2, default=str)


# Helper class of ExprToJson class to store method stack when enabling chain mode.
class CallStack:

    def __init__(self) -> None:
        self.stack = {}

    def create(self, key: int, value: dict) -> None:
        self.stack[key] = value

    def chain(self, key: int, value: dict) -> None:
        self.stack[key]["chain"].append(value)

    def getStack(self, key: int) -> dict:
        return self.stack[key]
