from __future__ import annotations # For forware reference, Base type hint
from typing import Union, Callable

import ast
import copy
import jsonpath_ng
import msgpack 
import inspect
import importlib

#from ast import literal_eval
#from examples import jsonrules
from string import Template

from pyrengine.objectlist import ARRAY
from pyrengine.fn import ADD, MUL
from pyrengine.date import DATE, DATETIME
from pyrengine.lookup import LOOKUP
from pyrengine.rulecontext import txcntx, FUNCTIONCALL_SYMBOLS

# TODO: Params, Obj, Lookup, ExternalRef, NotImplementedError
# TODO: compile() https://stackoverflow.com/questions/2220699/whats-the-difference-between-eval-exec-and-compile

# Worth reading
# https://stackoverflow.com/questions/1500718/how-to-override-the-copy-deepcopy-operations-for-a-python-object

RULE_TEMPLATE = '''
def rule_$name(tx):
    return $conditions
'''

UNARY_OPERATORS = {
    'is_true': '== True',
    'is_false': '== False',
    'is_not_empty': '!= ""'   # TODO: is not None and != '' 
}
                   
BINARY_OPERATORS = {
    'gt': '>', 
    'ge': '>=',
    'lt': '<',
    'le': '<=',
    'eq': '==',
    'ne': '!=',
    '>': '>',
    '<': '<',
    '>=': '>=',
    '<=': '<=',
    '==': '==',
    '!=': '!=',
    'equal_to': '==',
    'in': 'in',
    'is_in': 'in',
    'not_in': 'not in',
    'is_not_in': 'not in',
    'is': 'is'
}    

# Helper function to translate into a correct python expression string
# A string literal "abc" must be quoted by repr() before passed to this function. For example 
#   "abc" is passed as "'abc'" and empty string is passed as "''".
def translate_to_expression(fact: str, operator: str, value: Union[str, list[str]]) -> str:
    if fact is None:
        raise Exception('fact must exists')
           
    if operator in UNARY_OPERATORS:
        if value != "''" and value != None:
            raise Exception('Value of operator {} must be empty but {} is found'.format(operator, value))
        return '({} {})'.format(fact, UNARY_OPERATORS[operator])
        
    elif operator in BINARY_OPERATORS:
        #if value is None:
        #    raise Exception('operator {} requires two operands'.format(operator))
        if isinstance(value, list):
           value = '[{}]'.format(', '.join(value))
        return '({} {} {})'.format(fact, BINARY_OPERATORS[operator], value)
    
    elif operator == 'between':
        if value is None:
            raise Exception('operator {} requires two operands'.format(operator))
        #value = literal_eval(value)  # Convert literal string to python object
        if not isinstance(value, list) or len(value) != 2:
            raise Exception('operator {} requires a list'.format(operator))
        return '({} > {} and {} < {})'.format(fact, value[0],fact, value[1])
    
    raise NotImplementedError('{} is an unknown operator'.format(operator))


# Helper function to translate into a correct expression string for eval()
# fact and value are python objects which are only used to test for a specific type, None or ''.
# operator is a string
# Return expression as a string of 'fact', decoded operator, and 'value'.
# For example 'fact > value', 'fact == True' or 'fact == value'
def translate_to_eval(fact: object, operator: str, value: object) -> str:
    #if fact is None:
    #    raise Exception('Left operand must exists')
           
    if operator in UNARY_OPERATORS:
        if value != '' and value != None:
            raise Exception('Right operand of operator {} must be empty but {} is found'.format(operator, value))
        return '({} {})'.format('fact', UNARY_OPERATORS[operator])
        
    elif operator in BINARY_OPERATORS:
        #if value is None:
        #    raise Exception('operator {} requires two operands'.format(operator))
        return '({} {} {})'.format('fact', BINARY_OPERATORS[operator], 'value')
    
    elif operator == 'between':
        if value is None:
            raise Exception('operator {} requires two operands'.format(operator))
        if not isinstance(value, list) or len(value) != 2:
            raise Exception('operator {} requires a list'.format(operator))
        return '({} > {}[0] and {} < {}[1])'.format('fact', 'value', 'fact', 'value')
    
    raise NotImplementedError('{} is an unknown operator'.format(operator))


# Helper function to translate a certain function call into expression string
def translate_functioncall_to_expression(function: str, args: list[str]) -> str:
    if function == 'ADD':
        if len(args) != 2:
            raise NotImplementedError('ADD requires exactly two operands but {} is given'.format(len(args)))
        return "({} + {})".format(args[0], args[1])
    elif function == 'MUL':
        if len(args) != 2:
            raise NotImplementedError('MUL requires exactly two operands but {} is given'.format(len(args)))
        return "({} * {})".format(args[0], args[1])
    
    return "{}({})".format(function, ', '.join([str(arg) for arg in args]))


# selector is relative jsonpath to an element. It could be None if the element
#   is a substitute of its parent so it shares the same jsonpath with its 
#   parent.
# raw is an element which could be a primetive or an object
# jsonpath is absolute jsonpath to an element
class Base:
    def __init__(self, parent: Base, selector: str, raw: dict):
        self.parent = parent
        self.selector = selector
        self.raw = raw
        if self.parent:
            selector_str = self.selector if self.selector is not None else ''
            self.jsonpath = "{}{}".format(self.parent.jsonpath, selector_str) 
        else:
            self.jsonpath = self.selector
        self.parsed_jsonpath = jsonpath_ng.parse(self.jsonpath)

        self.parse()
        self.compiled = None

    def parse(self) -> None:
        pass

    # translate() must be invariant to tx (not depend on tx), meaning multiple calls return the same output.
    def translate(self) -> Union[str, list[str]]:
        pass

    def inspect(self, tx: dict) -> list[tuple[str, str, bool]]:
        pass

    def execute(self, tx: dict, audit_tree: dict, verbose: bool) -> object:
        raise NotImplementedError(self.__class__)
    
    def traverse(self, callback: Callable) -> None:
        pass

    def apply(self, tx: dict, target: bool = True) -> tuple[bool, list[str]]:
        """
        Evaluate the final boolean result and find condition IDs that are evaluated to True or False. So the rule needs key "id". 

        Parameters
        ----------
        tx : dict
            Transaction to evaluate.
        target : bool, optional
            Selected result of condition evaluation, by default True

        Returns
        -------
        tuple[bool, list[str]]
            Final boolean result and list of condition IDs.

        Raises
        ------
        Exception
            Any errors cause exception.            
        """

        pass


class Rule(Base):
    def __init__(self, raw: dict):
        super().__init__(None, '$', raw)
        self.packed = msgpack.packb(self.raw)

    def parse(self): 
        if not isinstance(self.raw, dict):
            raise Exception("Rule must be a dict") 
        
        self.name = None
        if "name" in self.raw and isinstance(self.raw["name"], str):
            self.name = self.raw["name"]

        if "conditions" in self.raw:
            self.conditions = Condition(self, "['conditions']", self.raw["conditions"])
            
        if self.conditions is None:
            raise Exception("Rule requires property 'conditions', only properties {} are found".format(self.raw.keys()))
    
    def translate(self): 
        conditions = self.conditions.translate()

        # Validate the syntax of translated code and convert back to cleaner code 
        ast_tree = ast.parse(conditions) # If fails, SyntaxError exception occurs
        conditions = '({})'.format(ast.unparse(ast_tree)) # Hopefully, we get cleaner code

        if self.name is not None:
            name = self.name
        else:
            name = 'somename'
        return Template(RULE_TEMPLATE).substitute(name=name, conditions=conditions)

    def inspect(self, tx):
        return self.conditions.inspect(tx)

    def audit(self, tx, verbose=False) -> tuple[bool, dict]:
        # Use msgpack for fast deepcopy()
        # https://stackoverflow.com/questions/45858084/what-is-a-fast-pythonic-way-to-deepcopy-just-data-from-a-python-dict-or-list
        #audit_tree = copy.deepcopy(self.raw)
        audit_tree = msgpack.unpackb(self.packed) 
        try: 
            txcntx.set(tx)  # Set transaction context
            return (self.conditions.execute(tx, audit_tree, verbose=verbose), audit_tree)
        except:
            raise  # Re-raise same exception and stack trace
        finally:
            txcntx.set(None)
    
    def traverse(self, callback):
        callback(self)
        self.conditions.traverse(callback)

    def apply(self, tx, target=True):
        result, ids = self.conditions.apply(tx, target)
        ids.sort()
        return (result, ids)


class Condition(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("Condition {} must be a dict".format(self.jsonpath)) 
         
        condition = None
        selector = None  # None because AtomicCondition and CompoundCondition are referred by the Condition's (parent) selector. Notice that it reinterprets this object by passing self.raw to the specific object
        if "fact" in self.raw: 
            condition = AtomicCondition(self, selector, self.raw)
        elif "all" in self.raw:
            condition = CompoundCondition(self, selector, self.raw)
        elif "any" in self.raw:
            condition = CompoundCondition(self, selector, self.raw)

        if condition is None:
            raise Exception("Condition {} requires 'fact' or 'all' or 'any' property, only properties {} are found".format(self.jsonpath, self.raw.keys()))

        self.condition = condition

    def translate(self):
        return self.condition.translate()

    def inspect(self, tx):
        return self.condition.inspect(tx)

    def execute(self, tx, audit_tree, verbose=False):
        return self.condition.execute(tx, audit_tree, verbose=verbose)
    
    def traverse(self, callback):
        #callback(self) # Do not callback here since this node is just a wrapper node of AtomicCondition or CompoundCondition. 
        self.condition.traverse(callback)

    def apply(self, tx, target=True):
        return self.condition.apply(tx, target) 
    

class AtomicCondition(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("AtomicCondition {} must be a dict".format(self.jsonpath)) 

        self.name = self.fact = self.operator = self.value = self.attr = None 

        if "name" in self.raw:
            self.name = self.raw["name"]
        
        if "fact" not in self.raw:
            raise Exception("AtomicCondition {} missing required property 'fact', only properties {} are found".format(self.jsonpath, self.raw.keys()))
        
        self.fact = Fact(self, "['fact']", self.raw["fact"])

        if "operator" not in self.raw:
            raise Exception("AtomicCondition {} missing required property 'operator', only properties {} are found".format(self.jsonpath, self.raw.keys()))
        
        self.operator = Operator(self, "['operator']", self.raw["operator"])

        if "value" in self.raw:
            #self.value = Value(self, "['value']", self.raw["value"])
            self.value = Operand(self, "['value']", self.raw["value"])
 
        # TODO: Handle attr. Should it be included with Fact
        if "attr" in self.raw:
            self.attr = Attr(self, "['attr']", self.raw["attr"])

    def translate(self):
        fact = self.fact.translate()
        operator = self.operator.translate()
        
        if self.value:
            value = self.value.translate()
        else: 
            value = None

        if self.attr:
            # TODO: Remove leading $
            attr = '.{}'.format(self.attr.translate())
        else:
            attr = '' 

        #return '({} {} {})'.format(fact, operator, value)
        return translate_to_expression(fact, operator, value)

    def inspect(self, tx):
        condition = self.translate()
        return [(self.jsonpath, condition, eval(condition, {'tx': tx}))]

    def execute(self, tx, audit_tree, verbose=False):
        fact = self.fact.execute(tx, audit_tree, verbose=verbose)
        operator = self.operator.translate()
        if self.value:
            value = self.value.execute(tx, audit_tree, verbose=verbose)
        else: 
            value = None
        #statement ='({} {} {})'.format(repr(fact), operator, repr(value))
        #print('statement', statement)
            
        # Compile the expression only once. The compiled expression refers to the variable names 'fact' and 'value'.
        #   The operator value is also constant. So, the compiled expression is invariant to the actual values of 
        #   'fact' and 'value'.
        if self.compiled is None:
            # expr = "fact {} value".format(operator)
            expr = translate_to_eval(fact, operator, value)  # Format expression according to different type of operator 
            self.compiled = compile(expr, 'expression_string', 'eval')
        result = eval(self.compiled, {'fact': fact, 'operator': operator, 'value': value, 'tx': tx})
        #print('jsonpath', self.jsonpath)
        if audit_tree:
            query = self.parsed_jsonpath
            match = query.find(audit_tree)
            location = match[0].value
            if verbose:
                pass
            else:
                location.clear()
            
            location['__result__'] = result
        return result
    
    def traverse(self, callback):
        callback(self)
        self.fact.traverse(callback)
        if self.value is not None:
            self.value.traverse(callback)

    def apply(self, tx, target=True):
        if "id" not in self.raw:
            Exception("AtomicCondition {} requires property 'id'".format(self.jsonpath))
        result = self.execute(tx, None)
        if result == target:
            return (result, [self.raw["id"]])
        return (result, [])
    

class CompoundCondition(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("CompoundCondition {} must be a dict".format(self.jsonpath)) 

        if "all" in self.raw:
            self.operator = "all"
        elif "any" in self.raw:
            self.operator = "any"
        else:
            raise Exception("CompoundCondition {} requires either all or any property, only properties {} are found".format(self.jsonpath, self.raw.keys())) 

        if not isinstance(self.raw[self.operator], list):
            raise Exception("CompoundCondition {} property 'all' or 'any' needs a list but {} is found".format(self.jsonpath, self.raw[self.operator])) 
        
        conditionList = [] 
        for i in range(len(self.raw[self.operator])):
            selector = "['{}'][{}]".format(self.operator, i)
            condition = Condition(self, selector, self.raw[self.operator][i])
            conditionList.append(condition)

        if not len(conditionList):
            raise Exception("CompoundCondition {} property 'all' or 'any' needs at least one condition".format(self.jsonpath)) 

        self.conditionList = conditionList

    def translate(self):
        conditions = [condition.translate() for condition in self.conditionList]
        if self.operator == "all":
            return "({})".format(" and ".join(conditions)) 
        else: 
            return "({})".format(" or ".join(conditions)) 

    def inspect(self, tx):
        results = []
        for condition in self.conditionList:
            result = condition.inspect(tx)
            if isinstance(result, list):
                results.extend(result)
            else:
                results.append(result)

        # TODO: How do we put the result of all or any into the returned results 
        #         as the self.translate() become larger at parent nodes?          
        return results

    def execute(self, tx, audit_tree, verbose=False):
        results = []
        for condition in self.conditionList:
            result = condition.execute(tx, audit_tree, verbose=verbose)
            if isinstance(result, list):
                raise Exception("Theoretically never reach here")
                results.extend(result)
            else:
                results.append(result)
        if self.operator == "all":
            result = all(results)
        else: 
            result = any(results)

        #print('jsonpath', self.jsonpath)
        if audit_tree:
            query = self.parsed_jsonpath
            match = query.find(audit_tree)
            location = match[0].value
            location['__result__'] = result
        return result
    
    def traverse(self, callback):
        callback(self)
        for condition in self.conditionList:
            condition.traverse(callback)

    def apply(self, tx, target=True):
        if "id" not in self.raw:
            Exception("CompoundCondition {} requires property 'id'".format(self.jsonpath))

        results = []
        ids = []
        for condition in self.conditionList:
            sub_result, sub_ids = condition.apply(tx, target)
            results.append(sub_result)
            ids.extend(sub_ids)
           
        if self.operator == "all":
            result = all(results)
        else: 
            result = any(results) 

        if result == target:
            ids = [self.raw["id"]] + ids

        return (result, ids)
    

class Fact(Base):
    def parse(self):
        if isinstance(self.raw, str):
            self.fact = self.raw
            return

        if isinstance(self.raw, dict):
            if "method" in self.raw:
                methodCall = MethodCall(self, None, self.raw) 
                self.fact = methodCall
                return
            elif "function" in self.raw:
                functionCall = FunctionCall(self, None, self.raw) 
                self.fact = functionCall
                return
            elif "chain" in self.raw:
                chain = Chain(self, None, self.raw) 
                self.fact = chain
                return                
            elif "$ref" in self.raw:
                ref = Reference(self, None, self.raw)
                self.fact = ref
                return
            else:
                raise Exception("Fact {} missing method or function property, only properties {} are found".format(self.jsonpath, self.raw.keys())) 

        raise Exception("Fact {} is not correct type (support only string and dict)".format(self.jsonpath)) 

    def translate(self): 
        if isinstance(self.fact, str):
            return "tx['{}']".format(self.fact)
        else:
            return self.fact.translate()  # fact.translate() is invariant to tx.

    def execute(self, tx, audit_tree, verbose=False):
        if isinstance(self.fact, str):
            if self.compiled is None:
                expr = self.translate()
                self.compiled = compile(expr, 'expression_string', 'eval')
            result = eval(self.compiled, {'tx': tx})
        else:
            result = self.fact.execute(tx, audit_tree, verbose=verbose)

        return result
    
    def traverse(self, callback):
        if isinstance(self.fact, str):
            callback(self)
        else:
            self.fact.traverse(callback)


class Attr(Base):
    '''
    Obsolete.
    '''
    def parse(self):
        if not isinstance(self.raw, str):
            raise Exception("Attr {} must be a string".format(self.jsonpath)) 
       
        self.attr = self.raw      

    def translate(self):
        return self.attr

class Field(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("Field {} must be a dict".format(self.jsonpath)) 

        self.fact = None 
        if "fact" not in self.raw: 
            raise Exception("Field {} missing required property 'fact', only properties {} are found".format(self.jsonpath, self.raw.keys())) 
        
        if not isinstance(self.raw["fact"], str):
            raise Exception("Field {} property 'fact' requires string".format(self.jsonpath))             
        
        self.fact = self.raw["fact"]
        
        # Todo: Handle attr
        if "attr" in self.raw:
            # TODO: Remove leading $
            self.attr = '.{}'.format(Attr(self, "['attr']", self.raw["attr"]).translate())
        else:
            self.attr = ''

    def translate(self):
        return "tx['{}']".format(self.fact)
        
    def execute(self, tx, audit_tree, verbose=False):
        if self.compiled is None:
            expr = self.translate()
            self.compiled = compile(expr, 'expression_string', 'eval')
        result = eval(self.compiled, {'tx': tx})

        #print('jsonpath', self.jsonpath)
        if audit_tree and verbose:
            query = self.parsed_jsonpath
            match = query.find(audit_tree)
            location = match[0].value
            location['__result__'] = result
        return result

    def traverse(self, callback):
        callback(self)

class Method(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("Method {} must be a dict".format(self.jsonpath)) 

        self.method = None
        
        if "method" not in self.raw:
            raise Exception("Method {} missing required property 'method', only properties {} are found".format(self.jsonpath, self.raw.keys())) 
        
        if not isinstance(self.raw["method"], str):
            raise Exception("Method {} 'method' requires string".format(self.jsonpath)) 
                
        self.method = self.raw["method"]
     
        self.params = {}
        if "params" in self.raw:
            if not isinstance(self.raw["params"], dict):
                raise Exception("Method {} params must be a dict".format(self.jsonpath))
            for k in self.raw["params"]:
                selector = "['{}'][{}]".format("params", k)
                operand = Operand(self, selector , self.raw["params"][k])
                self.params[k] = operand
            #raise NotImplementedError(str(self.params))

        self.args = []
        if "args" in self.raw:
            if not isinstance(self.raw["args"], list):
                raise Exception("Method {} args must be a list".format(self.jsonpath)) 
            for i in range(len(self.raw["args"])):
                selector = "['{}'][{}]".format("args", i)
                operand = Operand(self, selector , self.raw["args"][i]) 
                self.args.append(operand)
            #raise NotImplementedError(str(args))

    def translate(self):
        method = self.method
        args = []
        for e in self.args:
            arg = e.translate()
            if isinstance(arg, list):
                args.append('[{}]'.format(', '.join(arg)))
            else:
                args.append(arg)
        for k, v in self.params.items():
            arg = v.translate()
            if isinstance(arg, list):
                args.append('{}=[{}]'.format(k, ', '.join(arg)))
            else:
                args.append('{}={}'.format(k, arg))
        #args = [arg.translate() for arg in self.args]
        return "{}({})".format(method, ', '.join([str(arg) for arg in args]))

    # return (methodname, list_of_args)
    def execute(self, tx, audit_tree, verbose=False) -> tuple[str, list, dict]:
        method = self.method
        kwargs = {k: v.execute(tx, audit_tree, verbose=verbose) for k, v in self.params.items()}
        args = [arg.execute(tx, audit_tree, verbose=verbose) for arg in self.args]
        return (method, args, kwargs)
    
    def traverse(self, callback):
        callback(self)
        for arg in self.args:
            arg.traverse(callback)
        for k,v in self.params.items():
            v.traverse(callback)


class MethodCall(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("MethodCall {} must be a dict".format(self.jsonpath)) 

        self.method = self.fact = None
        
        if "method" not in self.raw:
            raise Exception("MethodCall {} missing required property 'method', only properties {} are found".format(self.jsonpath, self.raw.keys())) 
        
        if not isinstance(self.raw["method"], str):
            raise Exception("MethodCall {} 'method' requires string".format(self.jsonpath)) 
                
        self.method = self.raw["method"]
     
        if "fact" not in self.raw:
            raise Exception("MethodCall {} missing required property 'fact', only properties {} are found".format(self.jsonpath, self.raw.keys())) 
                    
        self.fact = Fact(self, "['fact']", self.raw["fact"])
        
        if "attr" in self.raw:
            # TODO: Remove leading $
            self.attr = '.{}'.format(Attr(self, "['attr']", self.raw["attr"]).translate())
        else:
            self.attr = ''

        self.params = {}
        if "params" in self.raw:
            if not isinstance(self.raw["params"], dict):
                raise Exception("Method {} params must be a dict".format(self.jsonpath))
            for k in self.raw["params"]:
                selector = "['{}'][{}]".format("params", k)
                operand = Operand(self, selector , self.raw["params"][k])
                self.params[k] = operand
            #raise NotImplementedError(str(self.params))

        self.args = []
        if "args" in self.raw:
            if not isinstance(self.raw["args"], list):
                raise Exception("MethodCall {} args must be a list".format(self.jsonpath)) 
            for i in range(len(self.raw["args"])):
                selector = "['{}'][{}]".format("args", i)
                operand = Operand(self, selector , self.raw["args"][i]) 
                self.args.append(operand)
            #raise NotImplementedError(str(args))

    def translate(self):
        fact = self.fact.translate()
        method = self.method
        args = []
        for e in self.args:
            arg = e.translate()
            if isinstance(arg, list):
                args.append('[{}]'.format(', '.join(arg)))
            else:
                args.append(arg)
        for k, v in self.params.items():
            arg = v.translate()
            if isinstance(arg, list):
                args.append('{}=[{}]'.format(k, ', '.join(arg)))
            else:
                args.append('{}={}'.format(k, arg))
        #args = [arg.translate() for arg in self.args]
        return "{}.{}({})".format(fact, method, ', '.join([str(arg) for arg in args]))

    # TODO: Check if methodcaller() is useful.
    #   https://docs.python.org/3/library/operator.html#operator.methodcaller
    def execute(self, tx, audit_tree, verbose=False):
        fact = self.fact.execute(tx, audit_tree, verbose=verbose)
        method = self.method
        args = [arg.execute(tx, audit_tree, verbose=verbose) for arg in self.args]
        kwargs = {k: v.execute(tx, audit_tree, verbose=verbose) for k, v in self.params.items()}
        #statement = "{}.{}({})".format(fact, method, ', '.join([str(arg) for arg in args]))
        #print('fact', fact)
        #print('statement', statement)

        if self.compiled is None:
            expr = "fact.{}(*args, **kwargs)".format(method)
            self.compiled = compile(expr, 'expression_string', 'eval')
        result = eval(self.compiled, {'fact': fact, 'args': args, 'kwargs': kwargs, 'tx': tx})
        #print('jsonpath', self.jsonpath)
        if audit_tree and verbose:
            query = self.parsed_jsonpath
            match = query.find(audit_tree)
            location = match[0].value
            location['__result__'] = result
        return result
    
    def traverse(self, callback):
        callback(self)
        self.fact.traverse(callback)
        for arg in self.args:
            arg.traverse(callback)   
        for k,v in self.params.items():
            v.traverse(callback)


class Chain(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("Chain {} must be a dict".format(self.jsonpath)) 

        self.fact = self.chain = None
        
        if "fact" not in self.raw:
            raise Exception("Chain {} missing required property 'fact', only properties {} are found".format(self.jsonpath, self.raw.keys())) 
        
        self.fact = Fact(self, "['fact']", self.raw["fact"])
     
        if "chain" not in self.raw:
            raise Exception("Chain {} missing required property 'chain', only properties {} are found".format(self.jsonpath, self.raw.keys())) 

        if not isinstance(self.raw["chain"], list):
            raise Exception("Chain {} chain must be a list".format(self.jsonpath)) 
        
        if len(self.raw["chain"]) < 1:
            raise Exception("Chain {} chain requires at least one method".format(self.jsonpath))         
                        
        self.chain = []
        for i in range(len(self.raw["chain"])):
            selector = "['{}'][{}]".format("chain", i)
            method = Method(self, selector , self.raw["chain"][i]) 
            self.chain.append(method)

    def translate(self):
        fact = self.fact.translate()
        methods = []
        for e in self.chain:
            method = e.translate()
            methods.append(method)
        return "{}.{}".format(fact, '.'.join([method for method in methods]))

    def execute(self, tx, audit_tree, verbose=False):
        fact = self.fact.execute(tx, audit_tree, verbose=verbose)
        obj = fact
        if self.compiled is None:
            self.compiled = [None]*len(self.chain)
        for i, e in enumerate(self.chain):
            (method, args, kwargs) = e.execute(tx, audit_tree, verbose=verbose)
            #statement = "{}.{}({})".format(obj, method, ', '.join([str(arg) for arg in args]))
            if self.compiled[i] is None:
                expr = "obj.{}(*args, **kwargs)".format(method) # This works since method is invariant to e.execute(tx, ...)
                self.compiled[i] = compile(expr, 'expression_string', 'eval')                
            result = eval(self.compiled[i], {'obj': obj, 'args': args, 'kwargs': kwargs, 'tx': tx})
            if audit_tree and verbose:
                query = e.parsed_jsonpath
                match = query.find(audit_tree)
                location = match[0].value
                location['__result__'] = result
            obj = result
        if audit_tree and verbose:            
            query = self.parsed_jsonpath
            match = query.find(audit_tree)
            location = match[0].value
            location['__result__'] = result
        return result

    def traverse(self, callback):
        callback(self)
        self.fact.traverse(callback)
        for e in self.chain:
            e.traverse(callback)


class Reference(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("Reference {} must be a dict".format(self.jsonpath)) 

        self.ref = self.field = None
        
        if "$ref" not in self.raw: 
            raise Exception("Reference {} missing required property '$ref', only properties {} are found".format(self.jsonpath, self.raw.keys())) 
        
        if not isinstance(self.raw["$ref"], str):
            raise Exception("Reference {} '$ref' requires string".format(self.jsonpath)) 
        
        self.ref = self.raw["$ref"]
     
        if "field" in self.raw:
            if not isinstance(self.raw["field"], str):
                raise Exception("Reference {} 'field' requires string".format(self.jsonpath))            
            self.field = self.raw["field"]

    def translate(self):
        ref = "LOOKUP.get({})".format(repr(self.ref))
        if self.field:
            return "{}.select({})".format(ref, repr(self.field))
        return ref

    # In the current design, we do not put execution result in audit_tree as it can be read from file.
    def execute(self, tx, audit_tree, verbose=False):
        ref = LOOKUP.get(self.ref)
        if self.field:
            return ref.select(self.field)
        return ref
    

class FunctionCall(Base):
    def parse(self):
        if not isinstance(self.raw, dict):
            raise Exception("FunctionCall {} must be a dict".format(self.jsonpath)) 

        self.function = None
        if "function" not in self.raw:
            raise Exception("FunctionCall {} missing required property 'function', only properties {} are found".format(self.jsonpath, self.raw.keys()))
        
        if not isinstance(self.raw["function"], str):
            raise Exception("FunctionCall {} 'function' requires string".format(self.jsonpath))
        
        self.function = self.raw["function"]
     
        self.args = []
        if "args" in self.raw:
            if not isinstance(self.raw["args"], list):
                raise Exception("FunctionCall {} args must be a list".format(self.jsonpath)) 
            for i in range(len(self.raw["args"])):
                selector = "['{}'][{}]".format("args", i)
                operand = Operand(self, selector , self.raw["args"][i]) 
                self.args.append(operand)
            #raise NotImplementedError(str(args))

        self.params = {}
        if "params" in self.raw:
            if not isinstance(self.raw["params"], dict):
                raise Exception("Method {} params must be a dict".format(self.jsonpath))
            for k in self.raw["params"]:
                selector = "['{}'][{}]".format("params", k)
                operand = Operand(self, selector , self.raw["params"][k])
                self.params[k] = operand

    # TODO: How about an argument that is a list of list of strings. ??? Complicated ???
    def translate(self):
        function = self.function
        args = []
        for e in self.args: # list of arguments
            arg = e.translate()  # translate() could return str or list[str]
            if isinstance(arg, list):  # An argument itself is a list of strings
                args.append('[{}]'.format(', '.join(arg)))
            else:
                args.append(arg) # An argument is a string      
        for k, v in self.params.items():
            arg = v.translate()
            if isinstance(arg, list):
                args.append('{}=[{}]'.format(k, ', '.join(arg)))
            else:
                args.append('{}={}'.format(k, arg))

        #return "{}({})".format(function, ', '.join([str(arg) for arg in args]))
        return translate_functioncall_to_expression(function, args) 
    
    # Worth reading
    # https://stackoverflow.com/questions/21100203/passing-arguments-to-python-eval
    def execute(self, tx, audit_tree, verbose=False):
        function = self.function
        args = [arg.execute(tx, audit_tree, verbose=verbose) for arg in self.args]
        kwargs = {k: v.execute(tx, audit_tree, verbose=verbose) for k, v in self.params.items()}
        #statement = "{}({})".format(function, ', '.join([str(arg) for arg in args]))
        #print('statement', statement)
        symbols = FUNCTIONCALL_SYMBOLS.copy()
        symbols.update({'args': args, 'kwargs': kwargs, 'tx': tx})
        if self.compiled is None:
            expr = "{}(*args, **kwargs)".format(function)
            self.compiled = compile(expr, 'expression_string', 'eval')
        result = eval(self.compiled, symbols)
        #print('jsonpath', self.jsonpath)
        if audit_tree and verbose:
            query = self.parsed_jsonpath
            match = query.find(audit_tree)
            location = match[0].value
            location['__result__'] = result
        return result


    def traverse(self, callback):
        callback(self)
        for arg in self.args:
            arg.traverse(callback)     
        for k,v in self.params.items():
            v.traverse(callback)

            
class Operator(Base):
    def parse(self):
        if not isinstance(self.raw, str):
            raise Exception("Operator {} must be a string".format(self.jsonpath)) 
        self.operator = self.raw      

    def translate(self):
        return self.operator


class Operand(Base):
    def parse(self):
        if self.raw is None:
            self.operand = self.raw
            return
        
        if isinstance(self.raw, str):
            self.operand = self.raw 
            return

        if isinstance(self.raw, (int, float, bool)):
            self.operand = self.raw
            return

        if isinstance(self.raw, dict):
            if "method" in self.raw:
                methodCall = MethodCall(self, None, self.raw)
                self.operand = methodCall
            elif "function" in self.raw:
                functionCall = FunctionCall(self, None, self.raw)
                self.operand = functionCall
            elif "chain" in self.raw:
                chain = Chain(self, None, self.raw)
                self.operand = chain
            elif "$ref" in self.raw:
                reference = Reference(self, None, self.raw)
                self.operand = reference
            elif "fact" in self.raw:
                field = Field(self, None, self.raw)
                self.operand = field
            else:
                raise Exception('Operand {} is of an unknown type from these properties {}'.format(self.jsonpath, self.raw.keys()))
            return

        if isinstance(self.raw, list):
            if all(isinstance(e, str) for e in self.raw):
                self.operand = self.raw 
                return
            elif all(isinstance(e, (int, float)) for e in self.raw):
                self.operand = self.raw
                return
            elif all(isinstance(e, dict) and 'function' in e for e in self.raw):
                operandList = []
                for i in range(len(self.raw)):
                    selector = "[{}]".format(i)
                    functionCall = FunctionCall(self, selector, self.raw[i])
                    operandList.append(functionCall)
                self.operand = operandList 
                return
            else:
                raise NotImplementedError('Operand {} not support this type of list'.format(self.jsonpath))

        raise Exception("operand {} is of an unknown type".format(self.jsonpath))

    # Can return str or list[str]
    def translate(self):
        if isinstance(self.operand, (str, int, float, bool)) or self.operand is None:
            return repr(self.operand) # repr() encloses string in quote
        elif isinstance(self.operand, list):
            operandList = []
            for e in self.operand:
                if isinstance(e, (int, float, str)):
                    operandList.append(repr(e))
                elif isinstance(e, FunctionCall):
                    operandList.append(e.translate())
                else:
                    raise NotImplementedError('Operand {} is unknown type'.format(self.jsonpath))                 
            return operandList
            #return "[{}]".format(', '.join(operandList))
            #return repr(self.operand) # repr() enclose string in quote
        else:
            return self.operand.translate()

    def execute(self, tx, audit_tree, verbose=False):
        if isinstance(self.operand, (str, int, float, bool)) or self.operand is None:
            result =  self.operand
        elif isinstance(self.operand, list):
            operandList = []
            for e in self.operand:
                if isinstance(e, (int, float, str)):
                    operandList.append(e)
                elif isinstance(e, FunctionCall):
                    operandList.append(e.execute(tx, audit_tree, verbose=verbose))
                else:
                    NotImplementedError('Operand {} is unknown type'.format(self.jsonpath))
            result = operandList
        else:
            result = self.operand.execute(tx, audit_tree, verbose=verbose)
        return result
    

    def traverse(self, callback):
        callback(self)
        if isinstance(self.operand, list):
            for e in self.operand:
                if isinstance(e, FunctionCall):
                    e.traverse(callback)
        elif isinstance(self.operand, (MethodCall, Chain, FunctionCall, Reference, Field)):
            self.operand.traverse(callback)


def register_function(name: str, func: Callable) -> None:
    FUNCTIONCALL_SYMBOLS[name] = func


def register_functions_from_module(module_name: str) -> None:
    # get a handle on the module
    m = importlib.import_module(module_name)
    
    functions = inspect.getmembers(m, inspect.isfunction)
    for name, func in functions:
        if not name.startswith("_"):    
            FUNCTIONCALL_SYMBOLS[name] = func    

register_function('ADD', ADD)
register_function('DATE', DATE)
register_function('DATETIME', DATETIME)
register_function('MUL', MUL)
register_function('ARRAY', ARRAY)


# To be removed.
# This Value class has been replaced by Operand.
class Value(Base):
    def parse(self):
        if isinstance(self.raw, list):
            operandList = []
            for i in range(len(self.raw)):
                selector = "[{}]".format(i)
                operand = Operand(self, selector, self.raw[i])
                operandList.append(operand)
            self.value = operandList
        else:    
            self.value = Operand(self, None, self.raw)
      
    def translate(self):
        if isinstance(self.value, list):
            return [operand.translate() for operand in self.value]
        else:
            return self.value.translate()

    def execute(self, tx, audit_tree, verbose=False):
        if isinstance(self.value, list):
            result = [operand.execute(tx, audit_tree, verbose=verbose) for operand in self.value]
        else:
            result = self.value.execute(tx, audit_tree, verbose=verbose)

        return result
 

# TODO: custom operators
# https://code.activestate.com/recipes/384122-infix-operators/
# definition of an Infix operator class
# this recipe also works in jython
# calling sequence for the infix is either:
#  x |op| y
# or:
# x <<op>> y
# class Infix:
#    def __init__(self, function):
#        self.function = function
#    def __ror__(self, other):
#        return Infix(lambda x, self=self, other=other: self.function(other, x))
#    def __or__(self, other):
#        return self.function(other)
#    def __rlshift__(self, other):
#        return Infix(lambda x, self=self, other=other: self.function(other, x))
#    def __rshift__(self, other):
#        return self.function(other)
#    def __call__(self, value1, value2):
#        return self.function(value1, value2)




